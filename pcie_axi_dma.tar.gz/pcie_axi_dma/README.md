# pcie_axi_dma: RTL, file list, SDC and run scripts

Package for the `pcie_axi_dma` design used in the Yosys-reference vs compcarta-yosys comparison
(`/home/test/experiments/exp10_ref`). All paths below are relative to this directory. Run every
script from here.

## Design

| Item | Value |
|---|---|
| Top module | `pcie_us_axi_dma` (Alex Forencich's PCIe UltraScale AXI DMA, read and write engines) |
| Language | Verilog-2001. No `` `include `` or `` `define ``; `-I rtl` is harmless |
| RTL | 3 files, 3,682 lines: `rtl/pcie_us_axi_dma.v` (top), `rtl/pcie_us_axi_dma_rd.v`, `rtl/pcie_us_axi_dma_wr.v` |
| File list | `filelist.f` (read order: `_rd`, `_wr`, top) |
| Ports | 85 (one clock `clk`, synchronous reset `rst`) |
| Parameters | Top-level defaults, no overrides: AXIS_PCIE_DATA_WIDTH=512, AXI_DATA_WIDTH=512, AXI_ADDR_WIDTH=64, AXI_ID_WIDTH=8, AXI_MAX_BURST_LEN=256, PCIE_ADDR_WIDTH=64, LEN_WIDTH=20, TAG_WIDTH=8, PCIE_TAG_COUNT=256 |
| Size after synthesis | about 40.9 k flops (DFF_X1), 107 k cells (compcarta) to 176 k cells (reference) |

The original `src.f` lists 66 files from the full verilog-pcie repository. The top only instantiates
`pcie_us_axi_dma_rd` and `pcie_us_axi_dma_wr`, so the other 63 files are never elaborated. Original
sources: `/home/test/designs/pcie_axi_dma/inputs/designs/` (unmodified).

## SDC

**`sdc/pcie_us_axi_dma.sdc` is the SDC used for every run.** It is the installed Assayer SDC
(`/home/test/designs/pcie_axi_dma/inputs/pcie_us_axi_dma.sdc`) with one line changed:

```
118c118
< set_load 0.004 [all_outputs]
---
> set_load 4.000 [all_outputs]  ;# load in library units (fF) ... (ASSAYER_FEEDBACK A20)
```

The nangate45 Liberty capacitance unit is fF, so `0.004` meant 0.004 fF, which is effectively no
load. 4 fF is what the Assayer profile intended. All other lines are unchanged.

| Constraint | Value |
|---|---|
| Clock | `create_clock -name clk -period 4.010 [get_ports clk]` |
| Clock uncertainty, transition, latency | 0.080 ns each |
| I/O delays | `set_input_delay` / `set_output_delay` on all data ports (84 lines), relative to `clk` |
| Input drive | `set_driving_cell -lib_cell BUF_X2 -pin Z [all_inputs -no_clocks]` |
| Output load | `set_load 4.000 [all_outputs]` (fF) |

The SDC was cross-checked against the netlist: every sequential clock pin traces to port `clk`, and
coverage is complete (see the header comment in the file). 20 ports have no sequential connection
(unused AXI ID/burst/cache fields and similar). They are constrained, but this has no effect.

All scripts (compcarta synthesis, the reference flow and STA) read this same file.

All flows also add `set_false_path -to [all_registers -async_pins]`. This design has no async
pins, so it changes nothing here.

## Technology

nangate45, typical corner:
- Liberty: `/edacloud/tools/catalyzer/tech_libs/nangate45/lib/NangateOpenCellLibrary_typical.lib`
- Latch techmap (reference flow): `/edacloud/tools/catalyzer/tech_libs/nangate45/latch_map.v`
- dont_use: TAPCELL_X1, FILLCELL_X1, AOI211_X1, OAI211_X1 (from `nangate45/tech_config.tcl`)
- `scripts/abc.constr`: `set_driving_cell BUF_X2` / `set_load 4`, derived from the SDC

## Scripts

Outputs go to `out/`.

| Script | Flow | Command |
|---|---|---|
| `scripts/reference_synthesis_sta.ys` | Yosys reference (`/home/test/tools/synthesis_sta`, yosys 0.66): `synth -flatten`, `abc -constr`, `repair_fanout -limit 16` | `/home/test/tools/synthesis_sta/yosys/yosys -m /edacloud/tools/catalyzer/third_party/yosys/share/yosys/plugins/slang.so -s scripts/reference_synthesis_sta.ys` |
| `scripts/compcarta_area.ys` | compcarta-yosys `synth_ppa -goal area` | `/home/test/experiments/yosys_p21/bin/yosys -s scripts/compcarta_area.ys` |
| `scripts/compcarta_timing.ys` | compcarta-yosys `synth_ppa -goal timing -effort medium` | `/home/test/experiments/yosys_p21/bin/yosys -s scripts/compcarta_timing.ys` |
| `scripts/sta.tcl` | Sign-off STA (OpenSTA, ideal clocks, no parasitics, max_fanout 40) | edit `out/<netlist>.v`, then `sta -exit scripts/sta.tcl` |

compcarta-yosys source: `/home/test/tools/yosys`, branch `arith-opt`, commit 937a87093. The latest
build is installed at `/home/test/experiments/yosys_p21`. It needs the OpenSTA fix on
`/home/test/tools/OpenSTA` branch `compcarta` (9ebb08ed), which is already linked into that build.

## Results (nangate45 typical, SDC above)

| Flow | Area (um^2) | Cells | WS at 4.010 ns | Min period | Synthesis wall time / peak RSS |
|---|---:|---:|---:|---:|---|
| Yosys reference | 363,589 | 175,527 | -0.417 (fails) | 4.427 ns | 3 min 15 s / 0.57 GB |
| compcarta, area goal (latest build) | 274,050 (-24.6%) | 106,800 | +0.668 | n/a | 9 min 29 s / 1.48 GB |
| compcarta, timing goal (exp10 run) | 275,235 | 107,626 | +1.176 | 2.834 ns (-36%) | 30 min / 1.70 GB |

- Hold WS is +0.006 ns for both compcarta runs.
- The reported max_slew (4) and max_cap (70) violations are pre-layout DRV reports and are not
  repaired in synthesis.
- The timing-goal row will be updated when the latest-build rerun finishes.
- These pcie_axi_dma netlists have **not** been simulated against the RTL yet. The sim10 run
  was stopped before this design finished. Simulation is planned after the latest-build rerun.
