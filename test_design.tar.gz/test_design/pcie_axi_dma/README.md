# pcie_axi_dma

Top module: **`pcie_us_axi_dma`**. RTL: 3 files (3682 lines per the benchmark list),
copied from `/home/test/designs/pcie_axi_dma` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/pcie_us_axi_dma.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/pcie_axi_dma/inputs/pcie_us_axi_dma.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |


Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| clk | clk | 4.01 |

Minimum period: **4.01 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- Read with the Yosys Verilog frontend (plain Verilog-2005).

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 180,315 | 40,872 | 370,237 | -0.341 | -3.670 | – | 178 s | 702 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 106,803 | 40,872 | 274,061 | +0.659 | 0.000 | – | 404 s | 1322 MB |
