//=============================================================================
// File        : hmac_top.sv
// Description : Top level of the APB4-programmed HMAC-SHA256 IP.
//
//               Structure
//               ---------
//
//   PCLK ------+------------------------------------------------------+
//   PRESETn -->| polarity normalise -> hmac_reset_sync -> rst_n       |
//              +--+---------------------------------------------------+
//                 |
//   APB4 -------->+---------------------+   flat TL-UL   +---------------+
//   PSEL/PENABLE  | hmac_apb4_to_tlul   |==============> | hmac_tlul     |
//   PADDR/PWDATA  |  APB completer      |                |  (VENDORED)   |
//   PSTRB/PWRITE  |  TL-UL host         | <============= |  cmd_intg_gen |
//   PRDATA/PREADY |  address decode     |                |      +        |
//   PSLVERR       +---------------------+                |  hmac core    |
//                                                        +-------+-------+
//                                                                |
//                                        intr_hmac_done_o -------+
//                                        intr_fifo_empty_o ------+
//                                        intr_hmac_err_o --------+
//                                        idle_o -----------------+
//
//               The vendored core is OpenTitan's `hmac`, unmodified, under
//               rtl/core/. It computes SHA-2 and keyed HMAC. This deliverable
//               specifies, documents and verifies SHA-256 and HMAC-SHA256; the
//               SHA-384/512 modes the core also implements are a deliberate
//               non-feature of this revision and are stated as such in
//               doc/hmac_design_spec.md.
//
//               ORIGINAL WORK is this file, hmac_pkg.sv, hmac_reset_sync.sv,
//               hmac_apb4_to_tlul.sv and everything in rtl/sva/, verif/ and
//               run/. Everything under rtl/core/ is vendored and must not be
//               edited - see rtl/core/PROVENANCE.txt.
//
//               Clocking: one domain, PCLK. No generated clocks, no gated
//               clocks. The only asynchronous input is PRESETn, and its
//               de-assertion is synchronised by hmac_reset_sync.
//
// Parameters   : see below. Every constraint is enforced by an elaboration
//                guard with a message unique to that guard;
//                run/scripts/elab_check.sh proves each one fires for its own
//                illegal value and does NOT fire for the legal ones.
//=============================================================================

`default_nettype none

module hmac_top
  import hmac_pkg::*;
#(
    // APB address bus width. Must span the core's 0x2000 block, because the
    // message FIFO window sits at 0x1000 and is not optional.
    parameter int unsigned APB_ADDR_WIDTH = 16,
    // APB data bus width. 32 only - the vendored core's TL-UL bus is 32 bits
    // wide and this revision does not carry a width converter.
    parameter int unsigned APB_DATA_WIDTH = 32,
    // 1'b0 : PRESETn is active low  (default, APB standard)
    // 1'b1 : PRESETn is active high
    parameter bit          RESET_POLARITY = 1'b0,
    // Reset synchroniser depth (asynchronous assert, synchronous de-assert).
    parameter int unsigned RESET_SYNC_STAGES = 2,
    // 1 : an access above the core's 13-bit block is answered with PSLVERR and
    //     never reaches the core.
    // 0 : the upper address bits are dropped, which is what the core does on
    //     its own - so an access to 0x2014 ALIASES onto CMD at 0x014.
    parameter bit          ADDR_DECODE_EN = 1'b1
) (
    input  wire                          PCLK,
    // SYNCASYNCNET fires here only when the bound assertion module is
    // compiled in: hmac_top_sva samples PRESETn on PCLK to prove the
    // RESET_POLARITY inversion is actually wired, which makes the port both
    // asynchronously and synchronously used. The RTL alone is clean - `make
    // lint` without rtl/sva/ reports nothing here - so this waives a
    // consequence of CHECKING the design, not a property of it. It is written
    // inline rather than by file:line so that it moves with the port.
    /* verilator lint_off SYNCASYNCNET */
    input  wire                          PRESETn,
    /* verilator lint_on SYNCASYNCNET */

    // ------------------------------------------------------------------ APB4
    input  wire                          PSEL,
    input  wire                          PENABLE,
    input  wire                          PWRITE,
    input  wire  [APB_ADDR_WIDTH-1:0]    PADDR,
    input  wire  [APB_DATA_WIDTH-1:0]    PWDATA,
    input  wire  [APB_DATA_WIDTH/8-1:0]  PSTRB,
    input  wire  [2:0]                   PPROT,

    output logic [APB_DATA_WIDTH-1:0]    PRDATA,
    output logic                         PREADY,
    output logic                         PSLVERR,

    // ------------------------------------------------------------- interrupts
    // Level-sensitive, cleared by writing 1 to the matching INTR_STATE bit.
    output logic                         irq_hmac_done,
    output logic                         irq_fifo_empty,
    output logic                         irq_hmac_err,
    // Any of the three, for an integrator with one interrupt line to spend.
    output logic                         irq,

    // Idle indication for a clock/power manager. The core drives four bits of
    // multi-bit-encoded idle; bit 0 is the plain boolean.
    output logic [3:0]                   idle
);

  //---------------------------------------------------------------------------
  // Elaboration guards
  //
  // Each message is unique so that elab_check.sh can require the SPECIFIC
  // guard under test to have fired. "Elaboration failed" is not an acceptable
  // check: an illegal parameter set also provokes unrelated width warnings, so
  // a guard that never fires would still look tested.
  //---------------------------------------------------------------------------
  if (APB_ADDR_WIDTH < HMAC_APB_ADDR_WIDTH_MIN) begin : gen_chk_aw_min
    $error("hmac_top: APB_ADDR_WIDTH must be >= %0d (got %0d) - the message FIFO window at 0x1000 must be addressable",
           HMAC_APB_ADDR_WIDTH_MIN, APB_ADDR_WIDTH);
  end
  if (APB_ADDR_WIDTH > HMAC_APB_ADDR_WIDTH_MAX) begin : gen_chk_aw_max
    $error("hmac_top: APB_ADDR_WIDTH must be <= %0d (got %0d)",
           HMAC_APB_ADDR_WIDTH_MAX, APB_ADDR_WIDTH);
  end
  // Evaluated in 64 bits on purpose. `32'(1) << 32` is zero in a 32-bit
  // context, so a 32-bit form of this comparison would reject
  // APB_ADDR_WIDTH == 32 - the widest value the guard above explicitly
  // permits, and the natural choice on a 32-bit APB.
  if ((64'(1) << APB_ADDR_WIDTH) < 64'(HMAC_BLOCK_SIZE)) begin : gen_chk_aw_span
    $error("hmac_top: APB_ADDR_WIDTH=%0d cannot span the 0x%0h byte block",
           APB_ADDR_WIDTH, HMAC_BLOCK_SIZE);
  end
  if (APB_DATA_WIDTH != 32) begin : gen_chk_dw
    $error("hmac_top: APB_DATA_WIDTH must be 32 (got %0d) - the vendored core's TL-UL bus is 32-bit and this revision carries no width converter",
           APB_DATA_WIDTH);
  end
  if (RESET_SYNC_STAGES < HMAC_RESET_SYNC_STAGES_MIN) begin : gen_chk_rss_min
    $error("hmac_top: RESET_SYNC_STAGES must be >= %0d (got %0d)",
           HMAC_RESET_SYNC_STAGES_MIN, RESET_SYNC_STAGES);
  end
  if (RESET_SYNC_STAGES > HMAC_RESET_SYNC_STAGES_MAX) begin : gen_chk_rss_max
    $error("hmac_top: RESET_SYNC_STAGES must be <= %0d (got %0d)",
           HMAC_RESET_SYNC_STAGES_MAX, RESET_SYNC_STAGES);
  end

  //---------------------------------------------------------------------------
  // Reset conditioning
  //
  //   1. Normalise the configured polarity to an internal active-low
  //      asynchronous reset.
  //   2. Synchronise the de-assertion to PCLK, removing the recovery/removal
  //      hazard.
  //
  // The vendored core has an active-low reset only, so this is the single
  // point at which RESET_POLARITY exists in the design.
  //---------------------------------------------------------------------------
  // SYNCASYNCNET fires on this net only when the bound assertion modules are
  // compiled in: hmac_reset_sync_sva samples it on the clock to prove the
  // assertion really is asynchronous, which makes it both asynchronously and
  // synchronously used. The RTL alone is clean. Waived inline so it moves with
  // the declaration rather than by a file:line key that drifts.
  /* verilator lint_off SYNCASYNCNET */
  logic rst_async_n;
  /* verilator lint_on SYNCASYNCNET */
  assign rst_async_n = RESET_POLARITY ? ~PRESETn : PRESETn;

  logic rst_n;

  hmac_reset_sync #(
      .STAGES (RESET_SYNC_STAGES)
  ) u_reset_sync (
      .clk       (PCLK),
      .rst_in_n  (rst_async_n),
      .rst_out_n (rst_n)
  );

  //---------------------------------------------------------------------------
  // APB4 <-> TileLink-UL
  //---------------------------------------------------------------------------
  logic        tl_a_valid;
  logic [2:0]  tl_a_opcode;
  logic [2:0]  tl_a_param;
  logic [3:0]  tl_a_size;
  logic [7:0]  tl_a_source;
  logic [31:0] tl_a_address;
  logic [APB_DATA_WIDTH/8-1:0] tl_a_mask;
  logic [APB_DATA_WIDTH-1:0]   tl_a_data;
  logic        tl_a_ready;

  logic        tl_d_ready;
  logic        tl_d_valid;
  logic [2:0]  tl_d_opcode;
  logic [2:0]  tl_d_param;
  logic [3:0]  tl_d_size;
  logic [7:0]  tl_d_source;
  logic [3:0]  tl_d_sink;
  logic [31:0] tl_d_data;
  logic        tl_d_denied;
  logic        tl_d_corrupt;

  hmac_apb4_to_tlul #(
      .ADDR_WIDTH     (APB_ADDR_WIDTH),
      .DATA_WIDTH     (APB_DATA_WIDTH),
      .ADDR_DECODE_EN (ADDR_DECODE_EN)
  ) u_apb4_to_tlul (
      .clk_i        (PCLK),
      .rst_ni       (rst_n),

      .paddr        (PADDR),
      .psel         (PSEL),
      .penable      (PENABLE),
      .pwrite       (PWRITE),
      .pwdata       (PWDATA),
      .pstrb        (PSTRB),
      .pprot        (PPROT),
      .prdata       (PRDATA),
      .pready       (PREADY),
      .pslverr      (PSLVERR),

      .tl_a_valid   (tl_a_valid),
      .tl_a_opcode  (tl_a_opcode),
      .tl_a_param   (tl_a_param),
      .tl_a_size    (tl_a_size),
      .tl_a_source  (tl_a_source),
      .tl_a_address (tl_a_address),
      .tl_a_mask    (tl_a_mask),
      .tl_a_data    (tl_a_data),
      .tl_a_ready   (tl_a_ready),

      .tl_d_ready   (tl_d_ready),
      .tl_d_valid   (tl_d_valid),
      .tl_d_opcode  (tl_d_opcode),
      .tl_d_param   (tl_d_param),
      .tl_d_size    (tl_d_size),
      .tl_d_source  (tl_d_source),
      .tl_d_sink    (tl_d_sink),
      .tl_d_data    (tl_d_data),
      .tl_d_denied  (tl_d_denied),
      .tl_d_corrupt (tl_d_corrupt)
  );

  //---------------------------------------------------------------------------
  // The vendored core
  //
  // hmac_tlul flattens OpenTitan's TL-UL struct ports AND runs the assembled
  // command through tlul_cmd_intg_gen. That generator is not optional:
  // tlul_pkg::TL_H2D_DEFAULT leaves cmd_intg / data_intg at all-ones, which is
  // an invalid checksum rather than a "do not check" encoding, and
  // hmac_reg_top runs tlul_cmd_intg_chk unconditionally - so without it every
  // access, however well formed, returns d_error.
  //---------------------------------------------------------------------------
  logic core_intr_done, core_intr_fifo_empty, core_intr_err;

  hmac_tlul u_hmac_core (
      .clk_i             (PCLK),
      .rst_ni            (rst_n),

      .tl_a_valid        (tl_a_valid),
      .tl_a_opcode       (tl_a_opcode),
      .tl_a_param        (tl_a_param),
      .tl_a_size         (tl_a_size),
      .tl_a_source       (tl_a_source),
      .tl_a_address      (tl_a_address),
      .tl_a_mask         (tl_a_mask),
      .tl_a_data         (tl_a_data),
      .tl_a_ready        (tl_a_ready),

      .tl_d_ready        (tl_d_ready),
      .tl_d_valid        (tl_d_valid),
      .tl_d_opcode       (tl_d_opcode),
      .tl_d_param        (tl_d_param),
      .tl_d_size         (tl_d_size),
      .tl_d_source       (tl_d_source),
      .tl_d_sink         (tl_d_sink),
      .tl_d_data         (tl_d_data),
      .tl_d_denied       (tl_d_denied),
      .tl_d_corrupt      (tl_d_corrupt),

      .intr_hmac_done_o  (core_intr_done),
      .intr_fifo_empty_o (core_intr_fifo_empty),
      .intr_hmac_err_o   (core_intr_err),
      .idle_o            (idle)
  );

  //---------------------------------------------------------------------------
  // Interrupt outputs
  //
  // Passed through, not re-registered: the core already drives them from
  // flops, and adding a stage here would put the IP's interrupt latency out of
  // step with the core's own documentation for no benefit.
  //---------------------------------------------------------------------------
  assign irq_hmac_done  = core_intr_done;
  assign irq_fifo_empty = core_intr_fifo_empty;
  assign irq_hmac_err   = core_intr_err;
  assign irq            = core_intr_done | core_intr_fifo_empty | core_intr_err;

endmodule : hmac_top

`default_nettype wire
