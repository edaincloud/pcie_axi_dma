//=============================================================================
// File        : hmac_apb4_to_tlul.sv
// Description : APB4 completer to TileLink-UL host bridge.
//
// WHY THIS EXISTS
//   The house bus is APB4. The vendored core (rtl/core/) speaks TileLink-UL,
//   because it is OpenTitan RTL and relabelling it would make this deliverable
//   lie about RTL that has not changed. This module is the converter, and it
//   is the whole of the protocol layer of this IP.
//
// PROVENANCE OF THE DESIGN
//   The transaction model, the phase at which the request is issued, the mask
//   and opcode derivation and the error mapping are taken from the proven
//   bridge in the socgen project
//   (soc_gen/dev_v2/data/ip_rtl/socgen_apb_tlul/socgen_apb_to_tlul.sv), which
//   already drives this exact core. It is re-expressed here in this
//   workspace's RTL house style (`default_nettype none`, `logic`, `always_ff`,
//   elaboration guards, parameterised reset polarity handled by the parent)
//   and extended with the address decode described below. The behaviour that
//   cost the debugging time is deliberately unchanged.
//
// THE THREE THINGS THAT ARE EASY TO GET WRONG
//
//   1. ISSUE ON THE ACCESS PHASE, NOT THE SETUP PHASE.
//      `psel` alone is SETUP. Issuing there puts a transaction on TL a cycle
//      early and then repeats it when `penable` rises, so every access happens
//      twice - which on a message FIFO means the message is corrupt and on a
//      write-one-to-trigger CMD register means the command fires twice.
//
//   2. A READ STILL NEEDS A MASK.
//      TL-UL uses `a_mask` on a Get to say which byte lanes it wants back. An
//      all-zero mask returns nothing. APB has no read strobe, so a read
//      presents all ones.
//
//   3. A PARTIAL WRITE IS A MASK, NOT A SMALLER SIZE.
//      `a_size` is log2(beat bytes) and never varies; sub-word writes are
//      expressed with PutPartialData and `a_mask` = `pstrb`. Shrinking a_size
//      instead reads back as a bus error rather than as a narrow write.
//
// INTEGRITY
//   Not handled here, deliberately. The flat TL-UL signal set has no `a_user`
//   field to carry it in, and rtl/core/hmac_tlul.sv already runs the assembled
//   command through `tlul_cmd_intg_gen #(.EnableDataIntgGen(1))` - which it
//   MUST, because tlul_pkg::TL_H2D_DEFAULT leaves cmd_intg and data_intg at
//   all-ones and that is an invalid checksum, not a "do not check" encoding.
//   Generating integrity here as well would fight it.
//
// TRANSACTION MODEL
//   One outstanding. APB is two-phase and cannot overlap accesses, so there is
//   never a second request to track; a queue here would only be testing
//   itself. An assertion in rtl/sva/ states this rather than leaving it as a
//   comment.
//=============================================================================

`default_nettype none

module hmac_apb4_to_tlul #(
    // APB address bus width. Must span the core's 13-bit block so that the
    // message FIFO window at 0x1000 is reachable.
    parameter int unsigned ADDR_WIDTH = 16,
    // APB data bus width. The core's TL-UL is 32-bit; see the guard.
    parameter int unsigned DATA_WIDTH = 32,
    // 1: an access whose address lies above the core's 13-bit block is
    //    answered with PSLVERR and never reaches TL.
    // 0: the address is truncated, which is what the core does on its own -
    //    an out-of-block access ALIASES onto a real register.
    parameter bit          ADDR_DECODE_EN = 1'b1
) (
    input  wire                       clk_i,
    input  wire                       rst_ni,       // active low, already sync-released

    // ---- APB4 completer ----------------------------------------------------
    input  wire  [ADDR_WIDTH-1:0]     paddr,
    input  wire                       psel,
    input  wire                       penable,
    input  wire                       pwrite,
    input  wire  [DATA_WIDTH-1:0]     pwdata,
    input  wire  [DATA_WIDTH/8-1:0]   pstrb,
    input  wire  [2:0]                pprot,
    output logic [DATA_WIDTH-1:0]     prdata,
    output logic                      pready,
    output logic                      pslverr,

    // ---- TileLink-UL host, flat ---------------------------------------------
    output logic                      tl_a_valid,
    output logic [2:0]                tl_a_opcode,
    output logic [2:0]                tl_a_param,
    output logic [3:0]                tl_a_size,
    output logic [7:0]                tl_a_source,
    output logic [31:0]               tl_a_address,
    output logic [DATA_WIDTH/8-1:0]   tl_a_mask,
    output logic [DATA_WIDTH-1:0]     tl_a_data,
    input  wire                       tl_a_ready,

    output logic                      tl_d_ready,
    input  wire                       tl_d_valid,
    input  wire  [2:0]                tl_d_opcode,
    input  wire  [2:0]                tl_d_param,
    input  wire  [3:0]                tl_d_size,
    input  wire  [7:0]                tl_d_source,
    input  wire  [3:0]                tl_d_sink,
    input  wire  [DATA_WIDTH-1:0]     tl_d_data,
    input  wire                       tl_d_denied,
    input  wire                       tl_d_corrupt
);

  import hmac_pkg::*;

  //---------------------------------------------------------------------------
  // Elaboration guards
  //---------------------------------------------------------------------------
  // Each guard carries a message unique enough that run/scripts/elab_check.sh
  // can match on it. "Elaboration failed" is not an acceptable check: an
  // illegal parameter set also provokes unrelated width warnings, so a guard
  // that never fires would still look tested.
  if (DATA_WIDTH != 32) begin : gen_chk_dw
    $error("hmac_apb4_to_tlul: DATA_WIDTH must be 32 (got %0d) - the vendored core's TL-UL is 32-bit", DATA_WIDTH);
  end

  // 64-bit context on purpose. `32'(1) << 32` is evaluated in 32 bits and
  // yields 0, so a 32-bit form of this comparison would reject ADDR_WIDTH=32 -
  // the widest legal value - while claiming it does not span the block.
  if ((64'(1) << ADDR_WIDTH) < 64'(HMAC_BLOCK_SIZE)) begin : gen_chk_aw_small
    $error("hmac_apb4_to_tlul: ADDR_WIDTH=%0d cannot span the 0x2000 block - the message FIFO window at 0x1000 would be unreachable", ADDR_WIDTH);
  end

  if (ADDR_WIDTH > 32) begin : gen_chk_aw_big
    $error("hmac_apb4_to_tlul: ADDR_WIDTH=%0d exceeds the 32-bit TL-UL address bus", ADDR_WIDTH);
  end

  //---------------------------------------------------------------------------
  // Constants
  //---------------------------------------------------------------------------
  // TL-UL A-channel opcodes, TileLink spec 1.8.1 table 5.
  localparam logic [2:0] TL_PUT_FULL    = 3'd0;
  localparam logic [2:0] TL_PUT_PARTIAL = 3'd1;
  localparam logic [2:0] TL_GET         = 3'd4;

  localparam int unsigned STRB_W = DATA_WIDTH / 8;

  // Every access is one full-width beat, so size is log2(bytes) and is a
  // constant. See note 3 in the header.
  localparam logic [3:0] BEAT_SIZE = 4'(unsigned'($clog2(STRB_W)));

  //---------------------------------------------------------------------------
  // Address decode
  //---------------------------------------------------------------------------
  // `out_of_block` is true when the access names an address the core cannot
  // see. The core decodes only HMAC_BLOCK_AW bits, so without this an access
  // to 0x2014 would silently hit CMD at 0x014 and start a hash.
  //
  // At ADDR_WIDTH == HMAC_BLOCK_AW there are no upper bits and the term is
  // structurally constant zero. That arm is dead in the `min` build by
  // construction and live in every wider one - see
  // run/scripts/code_coverage_exclude.txt.
  logic out_of_block;
  if (ADDR_WIDTH > HMAC_BLOCK_AW) begin : gen_decode
    assign out_of_block = ADDR_DECODE_EN &&
                          (|paddr[ADDR_WIDTH-1:HMAC_BLOCK_AW]);
  end else begin : gen_no_decode
    assign out_of_block = 1'b0;
  end

  // pprot is accepted for APB4 completeness and is not used to qualify access:
  // this IP has no privilege model of its own, and inventing one here would be
  // an undocumented deviation from the core's own register access rules.
  logic unused_pprot;
  assign unused_pprot = ^pprot;

  //---------------------------------------------------------------------------
  // Request FSM
  //---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    S_IDLE = 2'd0,   // waiting for an APB ACCESS phase
    S_REQ  = 2'd1,   // A channel request presented, waiting for a_ready
    S_RSP  = 2'd2,   // waiting for the D channel response
    S_DONE = 2'd3    // pready presented for exactly one cycle
  } state_e;

  state_e st_q;

  wire all_bytes = &pstrb;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q         <= S_IDLE;
      tl_a_valid   <= 1'b0;
      tl_a_opcode  <= TL_GET;
      tl_a_address <= '0;
      tl_a_mask    <= '0;
      tl_a_data    <= '0;
      tl_d_ready   <= 1'b0;
      prdata       <= '0;
      pready       <= 1'b0;
      pslverr      <= 1'b0;
    end else begin
      unique case (st_q)
        //---------------------------------------------------------------
        S_IDLE: begin
          pready  <= 1'b0;
          pslverr <= 1'b0;
          tl_d_ready <= 1'b0;
          if (psel && penable) begin
            if (out_of_block) begin
              // Answered locally. Nothing is presented to TL, so an address
              // the core cannot decode can never alias onto one it can.
              prdata  <= '0;
              pslverr <= 1'b1;
              pready  <= 1'b1;
              st_q    <= S_DONE;
            end else begin
              tl_a_valid   <= 1'b1;
              tl_a_opcode  <= !pwrite   ? TL_GET
                            : all_bytes ? TL_PUT_FULL
                                        : TL_PUT_PARTIAL;
              tl_a_address <= 32'(paddr);
              tl_a_data    <= pwdata;
              // Note 2: a Get must still say which lanes it wants back.
              tl_a_mask    <= pwrite ? pstrb : {STRB_W{1'b1}};
              st_q         <= S_REQ;
            end
          end
        end
        //---------------------------------------------------------------
        S_REQ: begin
          if (tl_a_ready) begin
            tl_a_valid <= 1'b0;
            tl_d_ready <= 1'b1;
            st_q       <= S_RSP;
          end
        end
        //---------------------------------------------------------------
        S_RSP: begin
          if (tl_d_valid) begin
            tl_d_ready <= 1'b0;
            prdata     <= tl_d_data;
            // Both TL failure modes reach APB as the one error bit APB has.
            // `d_corrupt` on a read means the data cannot be trusted;
            // reporting success and handing it over would be worse than
            // reporting an error.
            pslverr    <= tl_d_denied | tl_d_corrupt;
            pready     <= 1'b1;
            st_q       <= S_DONE;
          end
        end
        //---------------------------------------------------------------
        S_DONE: begin
          // Hold pready for exactly the one cycle APB samples it. A completer
          // that leaves pready high ends the NEXT transfer's setup phase too.
          pready  <= 1'b0;
          pslverr <= 1'b0;
          st_q    <= S_IDLE;
        end
        //---------------------------------------------------------------
        default: st_q <= S_IDLE;   // illegal-state recovery
      endcase
    end
  end

  //---------------------------------------------------------------------------
  // Constant A-channel fields
  //---------------------------------------------------------------------------
  assign tl_a_param  = 3'b000;
  assign tl_a_size   = BEAT_SIZE;
  assign tl_a_source = 8'h00;   // one outstanding, so one source id

  //---------------------------------------------------------------------------
  // D-channel fields the datapath does not consume
  //
  // They are brought INTO this module rather than absorbed at the top level so
  // that the bound assertions in rtl/sva/hmac_bridge_sva.sv can check the
  // response against the request that produced it - d_size and d_source must
  // echo a_size and a_source, and d_opcode must be AccessAck for a write and
  // AccessAckData for a read. Absorbing them one level up would have made
  // those checks impossible to write against module ports.
  logic unused_d;
  assign unused_d = ^{tl_d_opcode, tl_d_param, tl_d_size, tl_d_source, tl_d_sink};

endmodule : hmac_apb4_to_tlul

`default_nettype wire
