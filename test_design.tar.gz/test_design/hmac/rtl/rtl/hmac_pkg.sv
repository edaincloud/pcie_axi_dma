//=============================================================================
// hmac_pkg - the single definition of the HMAC IP's address map.
//
// The RTL, the RAL model, the reference model and the sequences all derive
// their offsets, field positions and encodings from HERE. An address or field
// change belongs in this file, never inline in a module or a testbench.
//
// The values are the register map of the vendored OpenTitan `hmac` core (see
// rtl/core/PROVENANCE.txt). They are RESTATED here rather than imported from
// hmac_reg_pkg for two reasons:
//
//   - hmac_reg_pkg is reggen output whose names, widths and struct layout are
//     an OpenTitan internal contract. Importing it would make every consumer
//     of this IP depend on a vendored package that is allowed to change shape.
//   - the verification environment must be able to state the address map
//     independently of the RTL it is checking. A RAL model generated from the
//     DUT's own package cannot disagree with the DUT, so it cannot detect a
//     decode fault.
//
// hmac_apb4_sva.sv carries an assertion set that ties the two together: the
// offsets below are checked against hmac_reg_pkg at elaboration, so a future
// vendor bump that moves a register fails the build instead of silently
// verifying the wrong address.
//=============================================================================
`ifndef HMAC_PKG_SV
`define HMAC_PKG_SV

package hmac_pkg;

  //---------------------------------------------------------------------------
  // Block geometry
  //---------------------------------------------------------------------------
  // The core's TL-UL device window is 13 address bits: 0x0000-0x0FFF is the
  // register file and 0x1000-0x1FFF is the message FIFO window. An APB address
  // bus narrower than this cannot reach the FIFO, which is why the elaboration
  // guard on APB_ADDR_WIDTH is >= 13 and not >= 12.
  parameter int unsigned HMAC_BLOCK_AW   = 13;
  parameter int unsigned HMAC_BLOCK_SIZE = 32'h0000_2000;

  // Message FIFO window. Every byte in it is the same FIFO: the address inside
  // the window carries no meaning to the core beyond byte lane selection, so
  // software may stream to a single address or walk the window. Both are used
  // in verification, because a wrapper that decodes the window as memory would
  // pass the first and fail the second.
  parameter int unsigned HMAC_MSG_FIFO_OFFSET = 32'h0000_1000;
  parameter int unsigned HMAC_MSG_FIFO_SIZE   = 32'h0000_1000;

  parameter int unsigned HMAC_REG_REGION_SIZE = 32'h0000_1000;

  //---------------------------------------------------------------------------
  // Register offsets
  //---------------------------------------------------------------------------
  parameter int unsigned HMAC_INTR_STATE_OFFSET = 32'h000;
  parameter int unsigned HMAC_INTR_ENABLE_OFFSET= 32'h004;
  parameter int unsigned HMAC_INTR_TEST_OFFSET  = 32'h008;
  parameter int unsigned HMAC_ALERT_TEST_OFFSET = 32'h00c;
  parameter int unsigned HMAC_CFG_OFFSET        = 32'h010;
  parameter int unsigned HMAC_CMD_OFFSET        = 32'h014;
  parameter int unsigned HMAC_STATUS_OFFSET     = 32'h018;
  parameter int unsigned HMAC_ERR_CODE_OFFSET   = 32'h01c;
  parameter int unsigned HMAC_WIPE_SECRET_OFFSET= 32'h020;

  // KEY_0 .. KEY_31, one 32-bit word each, contiguous.
  parameter int unsigned HMAC_KEY_BASE_OFFSET   = 32'h024;
  parameter int unsigned HMAC_NUM_KEY_WORDS     = 32;

  // DIGEST_0 .. DIGEST_15, one 32-bit word each, contiguous.
  parameter int unsigned HMAC_DIGEST_BASE_OFFSET = 32'h0a4;
  parameter int unsigned HMAC_NUM_DIGEST_WORDS   = 16;

  parameter int unsigned HMAC_MSG_LENGTH_LOWER_OFFSET = 32'h0e4;
  parameter int unsigned HMAC_MSG_LENGTH_UPPER_OFFSET = 32'h0e8;

  // The highest byte address that decodes to a register. Anything between this
  // and the FIFO window is unmapped and answers an error.
  parameter int unsigned HMAC_LAST_REG_OFFSET = HMAC_MSG_LENGTH_UPPER_OFFSET;

  //---------------------------------------------------------------------------
  // Field positions
  //---------------------------------------------------------------------------
  // INTR_STATE / INTR_ENABLE / INTR_TEST share a layout.
  parameter int unsigned HMAC_INTR_HMAC_DONE_BIT  = 0;
  parameter int unsigned HMAC_INTR_FIFO_EMPTY_BIT = 1;
  parameter int unsigned HMAC_INTR_HMAC_ERR_BIT   = 2;

  // CFG
  parameter int unsigned HMAC_CFG_HMAC_EN_BIT     = 0;
  parameter int unsigned HMAC_CFG_SHA_EN_BIT      = 1;
  parameter int unsigned HMAC_CFG_ENDIAN_SWAP_BIT = 2;
  parameter int unsigned HMAC_CFG_DIGEST_SWAP_BIT = 3;
  parameter int unsigned HMAC_CFG_KEY_SWAP_BIT    = 4;
  parameter int unsigned HMAC_CFG_DIGEST_SIZE_LSB = 5;   // [8:5]
  parameter int unsigned HMAC_CFG_DIGEST_SIZE_W   = 4;
  parameter int unsigned HMAC_CFG_KEY_LENGTH_LSB  = 9;   // [14:9]
  parameter int unsigned HMAC_CFG_KEY_LENGTH_W    = 6;

  // CMD - all four bits are write-one-to-trigger; they never read back set.
  parameter int unsigned HMAC_CMD_HASH_START_BIT    = 0;
  parameter int unsigned HMAC_CMD_HASH_PROCESS_BIT  = 1;
  parameter int unsigned HMAC_CMD_HASH_STOP_BIT     = 2;
  parameter int unsigned HMAC_CMD_HASH_CONTINUE_BIT = 3;

  // STATUS
  parameter int unsigned HMAC_STATUS_HMAC_IDLE_BIT  = 0;
  parameter int unsigned HMAC_STATUS_FIFO_EMPTY_BIT = 1;
  parameter int unsigned HMAC_STATUS_FIFO_FULL_BIT  = 2;
  parameter int unsigned HMAC_STATUS_FIFO_DEPTH_LSB = 4;  // [9:4]
  parameter int unsigned HMAC_STATUS_FIFO_DEPTH_W   = 6;

  //---------------------------------------------------------------------------
  // Reset values that the verification environment checks against
  //---------------------------------------------------------------------------
  // CFG resets to digest_size = SHA2_None and key_length = Key_None, i.e. a
  // deliberately INVALID configuration: an unprogrammed block refuses to start
  // rather than hashing with a default algorithm.
  parameter logic [31:0] HMAC_CFG_RESVAL    = 32'h0000_4100;
  parameter logic [31:0] HMAC_STATUS_RESVAL = 32'h0000_0003;  // idle + fifo empty

  //---------------------------------------------------------------------------
  // CFG.digest_size - one-hot, 4 bits
  //---------------------------------------------------------------------------
  parameter logic [3:0] HMAC_DIGEST_SHA2_256  = 4'b0001;
  parameter logic [3:0] HMAC_DIGEST_SHA2_384  = 4'b0010;
  parameter logic [3:0] HMAC_DIGEST_SHA2_512  = 4'b0100;
  parameter logic [3:0] HMAC_DIGEST_NONE      = 4'b1000;

  //---------------------------------------------------------------------------
  // CFG.key_length - one-hot, 6 bits
  //---------------------------------------------------------------------------
  parameter logic [5:0] HMAC_KEY_128  = 6'b00_0001;
  parameter logic [5:0] HMAC_KEY_256  = 6'b00_0010;
  parameter logic [5:0] HMAC_KEY_384  = 6'b00_0100;
  parameter logic [5:0] HMAC_KEY_512  = 6'b00_1000;
  parameter logic [5:0] HMAC_KEY_1024 = 6'b01_0000;
  parameter logic [5:0] HMAC_KEY_NONE = 6'b10_0000;

  //---------------------------------------------------------------------------
  // ERR_CODE values
  //---------------------------------------------------------------------------
  parameter logic [31:0] HMAC_ERR_NONE                    = 32'h0000_0000;
  parameter logic [31:0] HMAC_ERR_PUSH_MSG_SHA_DISABLED   = 32'h0000_0001;
  parameter logic [31:0] HMAC_ERR_HASH_START_SHA_DISABLED = 32'h0000_0002;
  parameter logic [31:0] HMAC_ERR_UPDATE_SECRET_INPROCESS = 32'h0000_0003;
  parameter logic [31:0] HMAC_ERR_HASH_START_WHEN_ACTIVE  = 32'h0000_0004;
  parameter logic [31:0] HMAC_ERR_PUSH_MSG_WHEN_DISALLOWED= 32'h0000_0005;
  parameter logic [31:0] HMAC_ERR_INVALID_CONFIG          = 32'h0000_0006;

  // The SHA-256 algorithm constants (block size, digest size) are NOT here.
  // They are properties of the algorithm, not of this hardware's address map,
  // and the reference model is the thing that needs them - see
  // verif/pkg/hmac_common_pkg.sv. Keeping them out of the RTL package also
  // keeps them out of the -Wall unused-parameter argument.

  //---------------------------------------------------------------------------
  // CFG.digest_size and CFG.key_length READ BACK DECODED, NOT AS WRITTEN.
  //
  // The register does not hand back the value software wrote. hmac.sv drives
  //     hw2reg.cfg.digest_size.d = digest_size    (the DECODED value)
  //     hw2reg.cfg.key_length.d  = key_length     (the DECODED value)
  // and the decode maps every unrecognised one-hot encoding to None:
  //
  //     unique case (digest_size_supplied)
  //       SHA2_256: ...  SHA2_384: ...  SHA2_512: ...
  //       default:  digest_size = SHA2_None;      // hmac.sv:296
  //     endcase
  //
  // So writing 0b1111 to digest_size reads back as 0b1000, and writing all
  // zeros to CFG reads back as 0x4100 rather than 0x0000. Every other CFG
  // field reads back raw.
  //
  // This is easy to miss and easy to get wrong in software: a read-modify-write
  // of CFG that assumes the read returns what was written will silently
  // rewrite a reserved encoding as None, and the next hash_start then fails
  // with SwInvalidConfig for a reason that is nowhere in the write.
  //---------------------------------------------------------------------------
  function automatic logic [3:0] hmac_decode_digest_size(input logic [3:0] raw);
    case (raw)
      HMAC_DIGEST_SHA2_256,
      HMAC_DIGEST_SHA2_384,
      HMAC_DIGEST_SHA2_512 : return raw;
      default              : return HMAC_DIGEST_NONE;
    endcase
  endfunction

  function automatic logic [5:0] hmac_decode_key_length(input logic [5:0] raw);
    case (raw)
      HMAC_KEY_128,
      HMAC_KEY_256,
      HMAC_KEY_384,
      HMAC_KEY_512,
      HMAC_KEY_1024 : return raw;
      default       : return HMAC_KEY_NONE;
    endcase
  endfunction

  // The value a CFG read returns, given what was last written to it.
  function automatic logic [31:0] hmac_cfg_readback(input logic [31:0] written);
    logic [31:0] v;
    v = '0;
    v[HMAC_CFG_HMAC_EN_BIT]     = written[HMAC_CFG_HMAC_EN_BIT];
    v[HMAC_CFG_SHA_EN_BIT]      = written[HMAC_CFG_SHA_EN_BIT];
    v[HMAC_CFG_ENDIAN_SWAP_BIT] = written[HMAC_CFG_ENDIAN_SWAP_BIT];
    v[HMAC_CFG_DIGEST_SWAP_BIT] = written[HMAC_CFG_DIGEST_SWAP_BIT];
    v[HMAC_CFG_KEY_SWAP_BIT]    = written[HMAC_CFG_KEY_SWAP_BIT];
    v[HMAC_CFG_DIGEST_SIZE_LSB +: 4] =
        hmac_decode_digest_size(written[HMAC_CFG_DIGEST_SIZE_LSB +: 4]);
    v[HMAC_CFG_KEY_LENGTH_LSB  +: 6] =
        hmac_decode_key_length(written[HMAC_CFG_KEY_LENGTH_LSB +: 6]);
    return v;
  endfunction

  //---------------------------------------------------------------------------
  // Byte-strobe rules for a REGISTER write
  //
  // THIS IS NOT WHAT AN APB4 PERIPHERAL USUALLY DOES, and it is the single
  // most surprising thing about programming this IP.
  //
  // A write to a register must assert EVERY byte lane that register occupies.
  // A write that misses one is rejected as a bus error - PSLVERR - and the
  // register is NOT updated. There is no byte-granular read-modify-write of a
  // register on this IP.
  //
  // The MESSAGE FIFO WINDOW is the opposite, and deliberately so: it is byte
  // writable, and the strobe together with the address inside the window is
  // what selects the message byte lane. That is what makes a message of any
  // byte length expressible.
  //
  // Extra lanes ABOVE the ones a register occupies are permitted and ignored,
  // so a full-word write is always legal.
  //
  // The values below are the vendored core's own permit table restated. They
  // are cross-checked against hmac_reg_pkg::HMAC_PERMIT at elaboration by
  // rtl/sva/hmac_map_check.sv, so a vendor bump that changes a register's width
  // fails the build rather than silently changing the programming model.
  //---------------------------------------------------------------------------
  parameter logic [3:0] HMAC_LANES_BYTE0 = 4'b0001;  // an 8-bit-or-less register
  parameter logic [3:0] HMAC_LANES_HALF  = 4'b0011;  // a 16-bit-or-less register
  parameter logic [3:0] HMAC_LANES_WORD  = 4'b1111;  // a full 32-bit register

  // The byte lanes a write to `off` must assert. Returns HMAC_LANES_WORD for
  // an offset that is not a register, which is the safe answer: it is the
  // strictest, and the caller has already decided the access is a register
  // access.
  function automatic logic [3:0] hmac_reg_write_lanes(input int unsigned off);
    if (hmac_is_msg_fifo(off)) return 4'b0000;    // the window is byte writable
    case (off)
      HMAC_INTR_STATE_OFFSET,
      HMAC_INTR_ENABLE_OFFSET,
      HMAC_INTR_TEST_OFFSET,
      HMAC_ALERT_TEST_OFFSET,
      HMAC_CMD_OFFSET      : return HMAC_LANES_BYTE0;
      HMAC_CFG_OFFSET,
      HMAC_STATUS_OFFSET   : return HMAC_LANES_HALF;
      default              : return HMAC_LANES_WORD;
    endcase
  endfunction

  // True when a write of `strb` to `off` will be accepted rather than rejected
  // as a bus error.
  function automatic bit hmac_write_strb_ok(input int unsigned off,
                                            input logic [3:0] strb);
    logic [3:0] need = hmac_reg_write_lanes(off);
    return ((need & ~strb) == 4'b0000);
  endfunction

  //---------------------------------------------------------------------------
  // Parameter limits enforced by the elaboration guards in hmac_top
  //---------------------------------------------------------------------------
  parameter int unsigned HMAC_APB_ADDR_WIDTH_MIN   = HMAC_BLOCK_AW;   // 13
  parameter int unsigned HMAC_APB_ADDR_WIDTH_MAX   = 32;
  parameter int unsigned HMAC_RESET_SYNC_STAGES_MIN = 2;
  parameter int unsigned HMAC_RESET_SYNC_STAGES_MAX = 8;

  //---------------------------------------------------------------------------
  // Helpers
  //---------------------------------------------------------------------------
  // KEY_i / DIGEST_i byte offsets. Functions rather than parameter arrays so
  // that every tool in the flow - lint, elaboration, synthesis, the RAL model
  // and the reference model - resolves them the same way.
  //
  // Every argument carries an explicit direction. An argument that follows a
  // `ref` argument and states no direction of its own inherits `ref`, and a
  // caller then tries to write back into whatever constant it passed.
  function automatic int unsigned hmac_key_offset(input int unsigned idx);
    hmac_key_offset = HMAC_KEY_BASE_OFFSET + (4 * idx);
  endfunction

  function automatic int unsigned hmac_digest_offset(input int unsigned idx);
    hmac_digest_offset = HMAC_DIGEST_BASE_OFFSET + (4 * idx);
  endfunction

  // True when `off` is inside the message FIFO window.
  function automatic bit hmac_is_msg_fifo(input int unsigned off);
    hmac_is_msg_fifo = (off >= HMAC_MSG_FIFO_OFFSET) &&
                       (off <  HMAC_MSG_FIFO_OFFSET + HMAC_MSG_FIFO_SIZE);
  endfunction

endpackage : hmac_pkg

`endif  // HMAC_PKG_SV
