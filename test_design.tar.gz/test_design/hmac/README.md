# hmac

Top module: **`hmac_top`**. RTL: 60 files (16929 lines per the benchmark list),
copied from `/home/test/designs/hmac` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/hmac_top.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/hmac/inputs/hmac_top.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |


Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| PCLK | PCLK | 4.01 |

Minimum period: **4.01 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- **Top-level parameter overrides** (apply them in every tool; they are not defaults in the RTL): `APB_ADDR_WIDTH=16`, `APB_DATA_WIDTH=32`, `ADDR_DECODE_EN=1`, `RESET_POLARITY=0`, `RESET_SYNC_STAGES=2`.

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 39,371 | 4,942 | 63,783 | +0.149 | 0.000 | -15.569 | 40 s | 356 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 31,035 | 4,920 | 54,132 | +0.006 | 0.000 | +3.680 | 100 s | 465 MB |
