# ethmac

Top module: **`ethmac`**. RTL: 24 files (10349 lines per the benchmark list),
copied from `/home/test/designs/ethmac` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/ethmac.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/ethmac/inputs/ethmac.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |


Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| wb_clk_i | wb_clk_i | 1.58 |
| mtx_clk_pad_i | mtx_clk_pad_i | 40.0 |
| mrx_clk_pad_i | mrx_clk_pad_i | 40.0 |

Minimum period: **1.58 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- Read with the Yosys Verilog frontend (plain Verilog-2005).

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 42,930 | 10,546 | 90,787 | +0.552 | 0.000 | – | 23 s | 186 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 24,909 | 10,545 | 68,006 | +0.536 | 0.000 | – | 51 s | 386 MB |
