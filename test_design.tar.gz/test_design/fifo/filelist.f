// fifo: top fifo; paths relative to this directory
rtl/inputs/fifo.v
