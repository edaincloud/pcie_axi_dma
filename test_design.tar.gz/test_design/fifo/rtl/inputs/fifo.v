`timescale 1ns/1ns

module fifo #(parameter DATA_WIDTH = 8, ADDR_WIDTH = 5) (
    input wire clk,           // Write clock
    input wire rst_n,               // Active-low reset
    input wire wr_en,               // Write enable
    input wire rd_en,               // Read enable
    input wire [DATA_WIDTH-1:0] din, // Data input
    output wire [DATA_WIDTH-1:0] dout // Data output
);

    // FIFO depth and size
    localparam FIFO_DEPTH = 2**ADDR_WIDTH;

    // Write pointer and read pointer
    reg [ADDR_WIDTH-1:0] wr_ptr ;
    reg [ADDR_WIDTH-1:0] rd_ptr; 

    // FIFO memory
    reg [DATA_WIDTH-1:0] fifo_mem [0:FIFO_DEPTH-1];

    // FIFO status flags

    // Write data into FIFO
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            wr_ptr <= 0;
        else if (wr_en ) begin
            fifo_mem[wr_ptr] <= din;
            wr_ptr <= wr_ptr + 1;
        end
    end

    // Read data from FIFO
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            rd_ptr <= 0;
        else if (rd_en ) begin
            rd_ptr <= rd_ptr + 1;
        end
    end

    // Update FIFO status flags
    // Output data from FIFO
    assign dout = fifo_mem[rd_ptr];

    // Assign status flags to outputs
endmodule
