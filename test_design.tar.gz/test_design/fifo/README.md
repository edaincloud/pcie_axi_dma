# fifo

Top module: **`fifo`**. RTL: 1 files (48 lines per the benchmark list),
copied from `/home/test/designs/fifo` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/fifo.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/fifo/inputs/fifo.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |


Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| clk | clk | 0.71 |

Minimum period: **0.71 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- Read with the Yosys Verilog frontend (plain Verilog-2005).

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 928 | 266 | 2,158 | -0.083 | -0.663 | – | 1 s | 31 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 605 | 266 | 1,705 | +0.009 | 0.000 | – | 2 s | 99 MB |
