# usb3.0

Top module: **`usb3_device_controller`**. RTL: 19 files (6092 lines per the benchmark list),
copied from `/home/test/designs/usb3.0` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/usb3_device_controller.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/usb3.0/inputs/usb3_device_controller.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |


Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| aclk | aclk | 3.37 |
| pclk | pclk | 3.25 |

Minimum period: **3.25 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- **Top-level parameter overrides** (apply them in every tool; they are not defaults in the RTL): `AXI_DATA_WIDTH=64`, `AXI_ADDR_WIDTH=32`, `AXI_ID_WIDTH=4`, `T_LFPS_CYC=256`, `T_TS_CYC=8`.
- **Defines:** `SYNTHESIS`, `USB3_NUM_EP=8`, `USB3_MAX_PKT_SS=1024`, `USB3_EP_FIFO_DEP=512`, `USB3_APB_ADDR_W=12`, `USB3_NUM_RX_CREDIT=4` (also in filelist.f).
- Note: writable memories >= 2048 bits as black-box macros (mem_macro/prep_<d>.ys)

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 1,117,034 | 291,288 | 2,451,323 | +0.329 | 0.000 | -5.026 | 3352 s | 3747 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 561,920 | 291,263 | 1,670,464 | +0.329 | 0.000 | +2.712 | 3452 s | 6640 MB |
