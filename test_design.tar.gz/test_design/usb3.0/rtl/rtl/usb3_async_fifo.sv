// ============================================================================
// usb3_async_fifo.sv
// Part of the USB 3.0 SuperSpeed device controller CDC / storage primitive
// library. Reset convention: active-low, asynchronous assert, synchronous
// deassert.
// ============================================================================
`default_nettype none

// ----------------------------------------------------------------------------
// Asynchronous FIFO with Gray-coded pointers. Power-of-two depth.
// ----------------------------------------------------------------------------
module usb3_async_fifo #(
  parameter int unsigned WIDTH = 32,
  parameter int unsigned DEPTH = 512,
  // wr_almost_full asserts when AF_LVL or fewer entries are free.  The default
  // of 1 is the historical behaviour (almost-full one entry before full).  A
  // producer that commits to a whole multi-word packet on a single look at the
  // flag must set AF_LVL to that packet's length minus one, or the flag says
  // nothing about whether the packet fits - see usb3_endpoint.sv.
  parameter int unsigned AF_LVL = 1
) (
  input  wire              wr_clk,
  input  wire              wr_rst_n,
  input  wire              wr_en,
  input  wire  [WIDTH-1:0] wr_data,
  output logic             wr_full,
  output logic             wr_almost_full,
  // Write-side occupancy, in entries.  A producer that commits to a whole
  // multi-word packet on one decision needs the LEVEL, not a flag: a flag can
  // only ever encode one compile-time packet size, and the size that matters
  // is the one on the wire.  See usb3_protocol.sv OUT admission.
  output logic [$clog2(DEPTH):0] wr_level,
  input  wire              rd_clk,
  input  wire              rd_rst_n,
  input  wire              rd_en,
  output logic [WIDTH-1:0] rd_data,
  output logic             rd_empty,
  output logic             rd_almost_empty
);
  // ---- elaboration guards ---------------------------------------------
  if (WIDTH < 1) begin : g_chk_width_min
    $error("usb3_async_fifo: WIDTH must be >= 1 (got %0d)", WIDTH);
  end
  if (WIDTH > 1024) begin : g_chk_width_max
    $error("usb3_async_fifo: WIDTH must be <= 1024 (got %0d)", WIDTH);
  end
  // DEPTH < 4 makes AW < 2 and the full comparison indexes rd_gray_s[AW-2:0],
  // which is a negative range at AW = 1.
  if (DEPTH < 4) begin : g_chk_depth_min
    $error("usb3_async_fifo: DEPTH must be >= 4 (got %0d): the Gray full comparison indexes rd_gray_s[AW-2:0] and needs $clog2(DEPTH) >= 2",
           DEPTH);
  end
  if (DEPTH > 65536) begin : g_chk_depth_max
    $error("usb3_async_fifo: DEPTH must be <= 65536 (got %0d)", DEPTH);
  end
  if ((DEPTH & (DEPTH - 1)) != 0) begin : g_chk_depth_pow2
    $error("usb3_async_fifo: DEPTH must be a power of two (got %0d): the Gray pointers wrap on their own width",
           DEPTH);
  end
  if (AF_LVL < 1) begin : g_chk_af_min
    $error("usb3_async_fifo: AF_LVL must be >= 1 (got %0d)", AF_LVL);
  end
  if (AF_LVL >= DEPTH) begin : g_chk_af_max
    $error("usb3_async_fifo: AF_LVL must be < DEPTH (got AF_LVL=%0d DEPTH=%0d): wr_almost_full would be asserted at zero occupancy and the FIFO could never be written",
           AF_LVL, DEPTH);
  end

  localparam int unsigned AW = $clog2(DEPTH);

  logic [WIDTH-1:0] mem [DEPTH];

  logic [AW:0] wr_bin, wr_bin_nxt, wr_gray, wr_gray_nxt;
  logic [AW:0] rd_bin, rd_bin_nxt, rd_gray, rd_gray_nxt;
  logic [AW:0] wr_gray_s, rd_gray_s;

  assign wr_bin_nxt  = wr_bin + {{AW{1'b0}}, (wr_en && !wr_full)};
  assign wr_gray_nxt = (wr_bin_nxt >> 1) ^ wr_bin_nxt;
  always_ff @(posedge wr_clk or negedge wr_rst_n) begin
    if (!wr_rst_n) begin
      wr_bin  <= '0;
      wr_gray <= '0;
    end else begin
      wr_bin  <= wr_bin_nxt;
      wr_gray <= wr_gray_nxt;
    end
  end
  always_ff @(posedge wr_clk) begin
    if (wr_en && !wr_full) mem[wr_bin[AW-1:0]] <= wr_data;
  end

  assign rd_bin_nxt  = rd_bin + {{AW{1'b0}}, (rd_en && !rd_empty)};
  assign rd_gray_nxt = (rd_bin_nxt >> 1) ^ rd_bin_nxt;
  always_ff @(posedge rd_clk or negedge rd_rst_n) begin
    if (!rd_rst_n) begin
      rd_bin  <= '0;
      rd_gray <= '0;
    end else begin
      rd_bin  <= rd_bin_nxt;
      rd_gray <= rd_gray_nxt;
    end
  end
  assign rd_data = mem[rd_bin[AW-1:0]];

  usb3_bit_sync #(.WIDTH(AW+1)) u_wr2rd (
    .clk(rd_clk), .rst_n(rd_rst_n), .d_async(wr_gray), .q_sync(wr_gray_s));
  usb3_bit_sync #(.WIDTH(AW+1)) u_rd2wr (
    .clk(wr_clk), .rst_n(wr_rst_n), .d_async(rd_gray), .q_sync(rd_gray_s));

  // DEFECT FIX (audit finding D6).  wr_full MUST be derived from the
  // REGISTERED write pointer, not from wr_gray_nxt.
  //
  //   wr_bin_nxt = wr_bin + (wr_en && !wr_full)
  //   wr_full    = f(wr_gray_nxt)                <-- the original form
  //
  // is a combinational loop: wr_full feeds wr_en feeds wr_bin_nxt feeds
  // wr_full.  At the full boundary it is not merely unschedulable, it is
  // paradoxical - asserting full removes the write that made it full.  The
  // loop is closed OUTSIDE this module too, through usb3_dma (dma_in_full ->
  // in_wr_en_c) and through usb3_protocol (ep_out_space -> ep_out_wr_en); the
  // lint tool reports UNOPTFLAT on both of those paths.
  //
  // Comparing the registered wr_gray against the inverted read pointer is the
  // same predicate one cycle later: the write that fills the FIFO is accepted
  // (there was room for it) and the NEXT one is blocked.  That is the timing
  // Cummings' async FIFO gets by registering wfull, without the loop.
  assign wr_full  = (wr_gray == {~rd_gray_s[AW:AW-1], rd_gray_s[AW-2:0]});
  assign rd_empty = (rd_gray == wr_gray_s);

  logic [AW:0] rd_gray_s_bin, wr_gray_s_bin;
  always_comb begin
    rd_gray_s_bin[AW] = rd_gray_s[AW];
    wr_gray_s_bin[AW] = wr_gray_s[AW];
    for (int i = AW-1; i >= 0; i--) begin
      rd_gray_s_bin[i] = rd_gray_s_bin[i+1] ^ rd_gray_s[i];
      wr_gray_s_bin[i] = wr_gray_s_bin[i+1] ^ wr_gray_s[i];
    end
  end
  // DEFECT FIX (audit finding D3).  These two occupancy differences MUST be
  // evaluated in AW+1 bits.  Written as a bare comparison against a 32-bit
  // integer constant the whole expression is taken in 32 bits, both pointers
  // are zero-extended first, and the modular subtraction that makes a wrapping
  // pointer pair work is lost: once wr_bin has wrapped past rd_gray_s_bin the
  // 32-bit difference is a huge positive number instead of the small
  // occupancy, and wr_almost_full asserts permanently.  wr_almost_full drives
  // ep_out_space through usb3_endpoint, so the original form stalled OUT
  // traffic for good after the first wrap of the endpoint buffer.
  logic [AW:0] wr_occ, rd_occ;
  assign wr_occ = wr_bin - rd_gray_s_bin;
  assign rd_occ = wr_gray_s_bin - rd_bin;

  localparam logic [AW:0] AF_THRESH = (AW+1)'(DEPTH - AF_LVL);
  localparam logic [AW:0] AE_THRESH = (AW+1)'(1);

  assign wr_almost_full  = (wr_occ >= AF_THRESH);
  assign wr_level        = wr_occ;
  assign rd_almost_empty = (rd_occ <= AE_THRESH);
endmodule

`default_nettype wire
