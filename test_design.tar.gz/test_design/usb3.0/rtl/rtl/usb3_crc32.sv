// ============================================================================
// usb3_crc32.sv
// Purely combinational parallel (unrolled LFSR) CRC generator for the USB 3.0
// device controller.  Takes the *current* remainder plus a chunk of data and
// produces the *next* remainder, so instances chain combinationally.
//
// Bit ordering: data is consumed least-significant-bit first inside each chunk,
// the remainder shifts left (MSB out).  This matches the USB serialisation
// order for the little-endian PIPE byte packing used in this IP.
// ============================================================================
`default_nettype none

// ----------------------------------------------------------------------------
// CRC32 over DATA_W bits (data packet payload, one dword per clock).
// ----------------------------------------------------------------------------
module usb3_crc32 #(
  parameter int unsigned DATA_W = 32
) (
  input  wire  [31:0]       crc_in,
  input  wire  [DATA_W-1:0] data,
  output logic [31:0]       crc_out
);
  // ---- elaboration guards ---------------------------------------------
  if (DATA_W < 1) begin : g_chk_data_w_min
    $error("usb3_crc32: DATA_W must be >= 1 (got %0d)", DATA_W);
  end
  if (DATA_W > 1024) begin : g_chk_data_w_max
    $error("usb3_crc32: DATA_W must be <= 1024 (got %0d): the unrolled LFSR is a combinational chain of DATA_W stages",
           DATA_W);
  end

  localparam logic [31:0] POLY = 32'h04C1_1DB7;

  logic [31:0] c;
  logic        fb;

  always_comb begin
    c = crc_in;
    for (int unsigned i = 0; i < DATA_W; i++) begin
      fb = c[31] ^ data[i];
      c  = {c[30:0], 1'b0};
      if (fb) c = c ^ POLY;
    end
    crc_out = c;
  end
endmodule

`default_nettype wire
