// ============================================================================
// usb3_clk_gate.sv
// Part of the USB 3.0 SuperSpeed device controller CDC / storage primitive
// library. Reset convention: active-low, asynchronous assert, synchronous
// deassert.
// ============================================================================
`default_nettype none

// ----------------------------------------------------------------------------
// Integrated clock gate wrapper. Latch-based ICG behaviour is inferred by the
// synthesis tool from the enable; scan_mode forces the clock on for ATPG.
// ----------------------------------------------------------------------------
module usb3_clk_gate (
  input  wire clk_in,
  input  wire enable,
  input  wire scan_mode,
  output wire clk_out
);
  logic en_latch;
  always_latch begin
    if (!clk_in) en_latch = enable || scan_mode;
  end
  assign clk_out = clk_in & en_latch;
endmodule

`default_nettype wire
