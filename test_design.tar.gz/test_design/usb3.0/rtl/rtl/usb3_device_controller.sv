// ============================================================================
// usb3_device_controller.sv
// USB 3.0 SuperSpeed device controller top level.
//
//   PIPE 3.0 (32-bit, pclk 125 MHz)  <-> LTSSM + Link layer + Protocol layer
//   Endpoint async FIFOs (pclk/aclk) <-> Scatter-gather DMA -> AXI4 master
//   APB4 CSR (aclk)                  -> configuration / status / interrupts
//
// Clock domains
//   pclk : PIPE / link / protocol layers
//   aclk : CSR, DMA, AXI4 master
// All CDC is done with usb3_bit_sync (quasi-static levels), usb3_pulse_sync
// (events) and usb3_async_fifo (endpoint payload data).
// ============================================================================
`default_nettype none

module usb3_device_controller
  import usb3_pkg::*;
#(
  parameter int unsigned AXI_ADDR_WIDTH = AXI_ADDR_W,
  parameter int unsigned AXI_DATA_WIDTH = AXI_DATA_W,
  parameter int unsigned AXI_ID_WIDTH   = AXI_ID_W,
  // Shortened LTSSM timers for simulation; keep defaults for silicon.
  parameter int unsigned T_LFPS_CYC     = 1250,
  parameter int unsigned T_TS_CYC       = 32
) (
  // ---- Clocks and resets -------------------------------------------------
  input  wire                        aclk,        // system / AXI / APB clock
  input  wire                        arst_n,      // async, active-low
  input  wire                        pclk,        // 125 MHz PIPE clock
  input  wire                        prst_n,      // async, active-low
  // ---- DFT ---------------------------------------------------------------
  input  wire                        scan_mode,

  // ---- APB4 configuration slave (aclk) -----------------------------------
  input  wire                        psel,
  input  wire                        penable,
  input  wire                        pwrite,
  input  wire  [APB_ADDR_W-1:0]      paddr,
  input  wire  [31:0]                pwdata,
  input  wire  [3:0]                 pstrb,
  input  wire  [2:0]                 pprot,
  output logic [31:0]                prdata,
  output logic                       pready,
  output logic                       pslverr,

  // ---- AXI4 master (aclk) ------------------------------------------------
  output logic [AXI_ID_WIDTH-1:0]    awid,
  output logic [AXI_ADDR_WIDTH-1:0]  awaddr,
  output logic [7:0]                 awlen,
  output logic [2:0]                 awsize,
  output logic [1:0]                 awburst,
  output logic [2:0]                 awprot,
  output logic [3:0]                 awcache,
  output logic                       awvalid,
  input  wire                        awready,
  output logic [AXI_DATA_WIDTH-1:0]  wdata,
  output logic [AXI_DATA_WIDTH/8-1:0] wstrb,
  output logic                       wlast,
  output logic                       wvalid,
  input  wire                        wready,
  input  wire  [AXI_ID_WIDTH-1:0]    bid,
  input  wire  [1:0]                 bresp,
  input  wire                        bvalid,
  output logic                       bready,
  output logic [AXI_ID_WIDTH-1:0]    arid,
  output logic [AXI_ADDR_WIDTH-1:0]  araddr,
  output logic [7:0]                 arlen,
  output logic [2:0]                 arsize,
  output logic [1:0]                 arburst,
  output logic [2:0]                 arprot,
  output logic [3:0]                 arcache,
  output logic                       arvalid,
  input  wire                        arready,
  input  wire  [AXI_ID_WIDTH-1:0]    rid,
  input  wire  [AXI_DATA_WIDTH-1:0]  rdata,
  input  wire  [1:0]                 rresp,
  input  wire                        rlast,
  input  wire                        rvalid,
  output logic                       rready,

  // ---- PIPE 3.0 interface (pclk) -----------------------------------------
  input  wire  [PIPE_DATA_W-1:0]     pipe_rx_data,
  input  wire  [PIPE_K_W-1:0]        pipe_rx_datak,
  input  wire                        pipe_rx_valid,
  input  wire                        pipe_rx_elec_idle,
  input  wire                        pipe_phy_status,
  input  wire  [2:0]                 pipe_rx_status,
  output logic [PIPE_DATA_W-1:0]     pipe_tx_data,
  output logic [PIPE_K_W-1:0]        pipe_tx_datak,
  output logic                       pipe_tx_elec_idle,
  output logic                       pipe_tx_detrx_lpbk,
  output logic                       pipe_tx_oneszeros,
  output logic [1:0]                 pipe_powerdown,
  output logic                       pipe_rate,
  output logic                       pipe_rx_polarity,
  output logic                       pipe_reset_n,
  // LFPS wake request to the PHY: the device-initiated exit from U1/U2/U3.
  // See usb3_ltssm.sv (audit finding D19) - the wake is signalled during
  // electrical idle and the PHY owns the waveform (PHY/PIPE spec 10).
  output logic                       pipe_tx_lfps,

  // ---- SoC side band -----------------------------------------------------
  output logic                       irq,
  output logic                       wakeup_req,
  output logic                       suspended
);

  // ------------------------------------------------------------------------
  // Elaboration guards for the usb3_pkg geometry (rtl/usb3_param_check.sv).
  // Instantiated here so that no whole-design build can escape them; the
  // module has no ports and no logic, and disappears at synthesis.
  // ------------------------------------------------------------------------
  usb3_param_check u_param_check ();

  // ------------------------------------------------------------------------
  // Elaboration guards for the module-local parameters of THIS module.
  // ------------------------------------------------------------------------
  if (AXI_ADDR_WIDTH < 32) begin : g_chk_axi_aw_min
    $error("usb3_device_controller: AXI_ADDR_WIDTH must be >= 32 (got %0d): usb3_dma zero-extends 32-bit software addresses with ext32()",
           AXI_ADDR_WIDTH);
  end
  if (AXI_ADDR_WIDTH > 64) begin : g_chk_axi_aw_max
    $error("usb3_device_controller: AXI_ADDR_WIDTH must be <= 64 (got %0d): the descriptor carries a 64-bit buffer address",
           AXI_ADDR_WIDTH);
  end
  if (AXI_DATA_WIDTH < 32) begin : g_chk_axi_dw_min
    $error("usb3_device_controller: AXI_DATA_WIDTH must be >= 32 (got %0d): the endpoint FIFOs are 32 bits wide and usb3_dma moves whole words",
           AXI_DATA_WIDTH);
  end
  if (AXI_DATA_WIDTH > 256) begin : g_chk_axi_dw_max
    $error("usb3_device_controller: AXI_DATA_WIDTH must be <= 256 (got %0d): usb3_dma sizes its burst byte count in 13 bits",
           AXI_DATA_WIDTH);
  end
  if ((AXI_DATA_WIDTH & (AXI_DATA_WIDTH - 1)) != 0) begin : g_chk_axi_dw_pow2
    $error("usb3_device_controller: AXI_DATA_WIDTH must be a power of two (got %0d)",
           AXI_DATA_WIDTH);
  end
  if (AXI_ID_WIDTH < 1) begin : g_chk_axi_id_min
    $error("usb3_device_controller: AXI_ID_WIDTH must be >= 1 (got %0d)",
           AXI_ID_WIDTH);
  end
  if (AXI_ID_WIDTH > 16) begin : g_chk_axi_id_max
    $error("usb3_device_controller: AXI_ID_WIDTH must be <= 16 (got %0d): the DMA issues a single constant ID and a wider tag has no meaning here",
           AXI_ID_WIDTH);
  end

  // ------------------------------------------------------------------------
  // Reset synchronizers
  // ------------------------------------------------------------------------
  logic arst_n_s, prst_n_s;
  logic soft_rst_a, soft_rst_p;

  usb3_reset_sync #(.STAGES(3)) u_arst_sync (
    .clk(aclk), .arst_n(arst_n), .scan_mode(scan_mode), .rst_n(arst_n_s));
  usb3_reset_sync #(.STAGES(3)) u_prst_sync (
    .clk(pclk), .arst_n(prst_n), .scan_mode(scan_mode), .rst_n(prst_n_s));

  // Soft reset (CSR) is combined with the synchronized reset. Register
  // configuration lives in the aclk CSR block and is NOT cleared by soft
  // reset, per IRS section 10.
  logic prst_func_n, arst_func_n;
  assign prst_func_n = prst_n_s && !soft_rst_p;
  assign arst_func_n = arst_n_s;

  // ------------------------------------------------------------------------
  // CSR configuration (aclk domain)
  // ------------------------------------------------------------------------
  logic                       cfg_enable;
  logic                       cfg_phy_en;
  logic                       cfg_u1_en;
  logic                       cfg_u2_en;
  logic                       cfg_force_disable;
  logic                       cfg_loopback_en;
  logic                       cfg_compliance_en;
  logic                       cfg_hot_reset_req;
  logic                       cfg_remote_wake;
  logic [6:0]                 cfg_dev_addr;
  logic                       cfg_dev_addr_valid;
  logic                       cfg_dma_en;
  logic [31:0]                cfg_desc_base;
  logic                       cfg_sec_en;
  logic [31:0]                cfg_sec_base;
  logic [31:0]                cfg_sec_limit;
  logic [NUM_EP-1:0]          cfg_ep_en;
  logic [NUM_EP*2-1:0]        cfg_ep_type;
  logic [NUM_EP-1:0]          cfg_ep_dir_in;
  logic [NUM_EP*12-1:0]       cfg_ep_maxpkt;
  logic [NUM_EP*5-1:0]        cfg_ep_burst;
  logic [NUM_EP-1:0]          cfg_ep_stall;
  logic [NUM_EP-1:0]          cfg_ep_clr_stall; // pulse (aclk)
  logic [NUM_EP-1:0]          cfg_ep_flush;     // pulse (aclk)

  // Status back to CSR (already synchronized to aclk).
  logic [4:0]                 sts_ltssm;
  logic [1:0]                 sts_pwr_state;
  logic                       sts_link_up;
  logic [NUM_EP*2-1:0]        sts_ep_state;
  logic [NUM_EP-1:0]          sts_ep_in_rdy;
  logic [NUM_EP-1:0]          sts_ep_out_valid;
  logic [13:0]                sts_itp_cnt;
  logic [63:0]                sts_setup_data;
  logic [19:0]                sts_dma_bytes_left;
  logic                       sts_dma_busy;
  logic [31:0]                sts_desc_cur;
  logic [INT_WIDTH-1:0]       evt_a;   // event pulses in aclk domain
  logic [ERR_WIDTH-1:0]       err_a;   // error pulses in aclk domain

  usb3_apb_csr u_csr (
    .clk                (aclk),
    .rst_n              (arst_func_n),
    .psel               (psel),
    .penable            (penable),
    .pwrite             (pwrite),
    .paddr              (paddr),
    .pwdata             (pwdata),
    .pstrb              (pstrb),
    .pprot              (pprot),
    .prdata             (prdata),
    .pready             (pready),
    .pslverr            (pslverr),
    .cfg_enable         (cfg_enable),
    .cfg_soft_rst       (soft_rst_a),
    .cfg_phy_en         (cfg_phy_en),
    .cfg_u1_en          (cfg_u1_en),
    .cfg_u2_en          (cfg_u2_en),
    .cfg_force_disable  (cfg_force_disable),
    .cfg_loopback_en    (cfg_loopback_en),
    .cfg_compliance_en  (cfg_compliance_en),
    .cfg_hot_reset_req  (cfg_hot_reset_req),
    .cfg_remote_wake    (cfg_remote_wake),
    .cfg_dev_addr       (cfg_dev_addr),
    .cfg_dev_addr_valid (cfg_dev_addr_valid),
    .cfg_dma_en         (cfg_dma_en),
    .cfg_desc_base      (cfg_desc_base),
    .cfg_sec_en         (cfg_sec_en),
    .cfg_sec_base       (cfg_sec_base),
    .cfg_sec_limit      (cfg_sec_limit),
    .cfg_ep_en          (cfg_ep_en),
    .cfg_ep_type        (cfg_ep_type),
    .cfg_ep_dir_in      (cfg_ep_dir_in),
    .cfg_ep_maxpkt      (cfg_ep_maxpkt),
    .cfg_ep_burst       (cfg_ep_burst),
    .cfg_ep_stall       (cfg_ep_stall),
    .cfg_ep_clr_stall   (cfg_ep_clr_stall),
    .cfg_ep_flush       (cfg_ep_flush),
    .sts_ltssm          (sts_ltssm),
    .sts_pwr_state      (sts_pwr_state),
    .sts_link_up        (sts_link_up),
    .sts_ep_state       (sts_ep_state),
    .sts_ep_in_rdy      (sts_ep_in_rdy),
    .sts_ep_out_valid   (sts_ep_out_valid),
    .sts_itp_cnt        (sts_itp_cnt),
    .sts_setup_data     (sts_setup_data),
    .sts_dma_busy       (sts_dma_busy),
    .sts_dma_bytes_left (sts_dma_bytes_left),
    .sts_desc_cur       (sts_desc_cur),
    .evt_pulse          (evt_a),
    .err_pulse          (err_a),
    .irq                (irq)
  );

  // ------------------------------------------------------------------------
  // CDC: aclk configuration -> pclk
  // ------------------------------------------------------------------------
  logic                 p_enable, p_phy_en, p_u1_en, p_u2_en;
  logic                 p_force_disable, p_loopback_en, p_compliance_en;
  logic [6:0]           p_dev_addr;
  logic                 p_dev_addr_valid;
  logic [NUM_EP-1:0]    p_ep_en, p_ep_stall, p_ep_dir_in;
  logic [NUM_EP*2-1:0]  p_ep_type;
  logic [NUM_EP*12-1:0] p_ep_maxpkt;
  logic [NUM_EP*5-1:0]  p_ep_burst;

  usb3_bit_sync #(.WIDTH(7)) u_cfg_lvl_sync (
    .clk(pclk), .rst_n(prst_n_s),
    .d_async({cfg_enable, cfg_phy_en, cfg_u1_en, cfg_u2_en,
              cfg_force_disable, cfg_loopback_en, cfg_compliance_en}),
    .q_sync ({p_enable, p_phy_en, p_u1_en, p_u2_en,
              p_force_disable, p_loopback_en, p_compliance_en}));

  usb3_bit_sync #(.WIDTH(8)) u_addr_sync (
    .clk(pclk), .rst_n(prst_func_n),
    .d_async({cfg_dev_addr_valid, cfg_dev_addr}),
    .q_sync ({p_dev_addr_valid,   p_dev_addr}));

  usb3_bit_sync #(.WIDTH(NUM_EP*(3+2+12+5))) u_ep_cfg_sync (
    .clk(pclk), .rst_n(prst_func_n),
    .d_async({cfg_ep_en, cfg_ep_stall, cfg_ep_dir_in, cfg_ep_type,
              cfg_ep_maxpkt, cfg_ep_burst}),
    .q_sync ({p_ep_en,   p_ep_stall,   p_ep_dir_in,   p_ep_type,
              p_ep_maxpkt, p_ep_burst}));

  // Soft reset pulse -> pclk (held for a few cycles by a stretcher).
  logic soft_rst_pulse_p, soft_rst_busy;
  usb3_pulse_sync u_soft_rst_sync (
    .src_clk(aclk), .src_rst_n(arst_n_s), .src_pulse(soft_rst_a),
    .src_busy(soft_rst_busy),
    .dst_clk(pclk), .dst_rst_n(prst_n_s), .dst_pulse(soft_rst_pulse_p));

  logic [3:0] soft_rst_cnt;
  always_ff @(posedge pclk or negedge prst_n_s) begin
    if (!prst_n_s)                soft_rst_cnt <= '0;
    else if (soft_rst_pulse_p)    soft_rst_cnt <= 4'hF;
    else if (soft_rst_cnt != '0)  soft_rst_cnt <= soft_rst_cnt - 1'b1;
  end
  assign soft_rst_p = (soft_rst_cnt != '0);

  // Remote wake-up request pulse -> pclk.
  logic p_remote_wake, remote_wake_busy;
  usb3_pulse_sync u_wake_sync (
    .src_clk(aclk), .src_rst_n(arst_n_s), .src_pulse(cfg_remote_wake),
    .src_busy(remote_wake_busy),
    .dst_clk(pclk), .dst_rst_n(prst_func_n), .dst_pulse(p_remote_wake));

  // Hot reset request pulse -> pclk.
  logic p_hot_reset_req, hot_reset_busy;
  usb3_pulse_sync u_hotrst_sync (
    .src_clk(aclk), .src_rst_n(arst_n_s), .src_pulse(cfg_hot_reset_req),
    .src_busy(hot_reset_busy),
    .dst_clk(pclk), .dst_rst_n(prst_func_n), .dst_pulse(p_hot_reset_req));

  // Per-endpoint clear-stall pulses -> pclk.
  logic [NUM_EP-1:0] p_ep_clr_stall;
  logic [NUM_EP-1:0] clr_stall_busy;
  for (genvar e = 0; e < NUM_EP; e++) begin : g_clr_stall_cdc
    usb3_pulse_sync u_sync (
      .src_clk(aclk), .src_rst_n(arst_n_s), .src_pulse(cfg_ep_clr_stall[e]),
      .src_busy(clr_stall_busy[e]),
      .dst_clk(pclk), .dst_rst_n(prst_func_n), .dst_pulse(p_ep_clr_stall[e]));
  end

  // ------------------------------------------------------------------------
  // LTSSM (pclk)
  // ------------------------------------------------------------------------
  logic [4:0]            ltssm_state;
  logic [1:0]            ltssm_pwr;
  logic                  link_up;
  logic                  os_active;
  logic [PIPE_DATA_W-1:0] os_data;
  logic [PIPE_K_W-1:0]   os_datak;
  logic                  pm_tx_req, pm_tx_done, pm_rx_valid;
  logic [3:0]            pm_tx_cmd, pm_rx_cmd;
  logic [INT_WIDTH-1:0]  evt_p;
  logic [ERR_WIDTH-1:0]  err_p;
  logic                  ltssm_err_link;
  logic                  p_wakeup_req;

  usb3_ltssm #(
    .T_LFPS_CYC (T_LFPS_CYC),
    .T_TS_CYC   (T_TS_CYC)
  ) u_ltssm (
    .clk                (pclk),
    .rst_n              (prst_func_n),
    .cfg_enable         (p_enable),
    .cfg_phy_en         (p_phy_en),
    .cfg_u1_en          (p_u1_en),
    .cfg_u2_en          (p_u2_en),
    .cfg_force_disable  (p_force_disable),
    .cfg_loopback_en    (p_loopback_en),
    .cfg_compliance_en  (p_compliance_en),
    .hot_reset_req      (p_hot_reset_req),
    .remote_wake_req    (p_remote_wake),
    .pipe_rx_data       (pipe_rx_data),
    .pipe_rx_datak      (pipe_rx_datak),
    .pipe_rx_valid      (pipe_rx_valid),
    .pipe_rx_elec_idle  (pipe_rx_elec_idle),
    .pipe_phy_status    (pipe_phy_status),
    .pipe_rx_status     (pipe_rx_status),
    .pipe_tx_elec_idle  (pipe_tx_elec_idle),
    .pipe_tx_detrx_lpbk (pipe_tx_detrx_lpbk),
    .pipe_tx_oneszeros  (pipe_tx_oneszeros),
    .pipe_powerdown     (pipe_powerdown),
    .pipe_rate          (pipe_rate),
    .pipe_rx_polarity   (pipe_rx_polarity),
    .pipe_reset_n       (pipe_reset_n),
    .pipe_tx_lfps       (pipe_tx_lfps),
    .os_active          (os_active),
    .os_data            (os_data),
    .os_datak           (os_datak),
    .pm_tx_req          (pm_tx_req),
    .pm_tx_cmd          (pm_tx_cmd),
    .pm_tx_done         (pm_tx_done),
    .pm_rx_valid        (pm_rx_valid),
    .pm_rx_cmd          (pm_rx_cmd),
    .state              (ltssm_state),
    .pwr_state          (ltssm_pwr),
    .link_up            (link_up),
    .wakeup_req         (p_wakeup_req),
    .evt_link_up        (evt_p[INT_LINK_UP]),
    .evt_link_down      (evt_p[INT_LINK_DOWN]),
    .evt_hot_reset      (evt_p[INT_HOT_RESET]),
    .evt_suspend        (evt_p[INT_SUSPEND]),
    .evt_resume         (evt_p[INT_RESUME]),
    .err_link           (ltssm_err_link)
  );

  // ------------------------------------------------------------------------
  // Link layer (pclk)
  // ------------------------------------------------------------------------
  logic         rx_hp_valid;
  logic [95:0]  rx_hp_data;
  logic [4:0]   rx_hp_type;
  logic         rx_hp_crc_err;
  logic         rx_dp_valid, rx_dp_last, rx_dp_crc_err;
  logic [31:0]  rx_dp_data;
  logic         tx_hp_valid, tx_hp_ready;
  logic [95:0]  tx_hp_data;
  logic         tx_dp_valid, tx_dp_last, tx_dp_ready;
  logic [31:0]  tx_dp_data;
  logic         lnk_err_crc5, lnk_err_crc16, lnk_err_crc32;
  logic         lnk_err_protocol, lnk_err_link;

  // The link layer's framed transmit bus, before the electrical-idle gate
  // below.  The LTSSM owns pipe_tx_elec_idle and the link owns the data, and
  // nothing used to couple them, so whatever the framer had last registered
  // stayed on the pins after the transmitter was declared idle.
  logic [PIPE_DATA_W-1:0] lnk_tx_data;
  logic [PIPE_K_W-1:0]    lnk_tx_datak;

  usb3_link u_link (
    .clk              (pclk),
    .rst_n            (prst_func_n),
    .link_up          (link_up),
    .pipe_rx_data     (pipe_rx_data),
    .pipe_rx_datak    (pipe_rx_datak),
    .pipe_rx_valid    (pipe_rx_valid),
    .os_active        (os_active),
    .tx_elec_idle     (pipe_tx_elec_idle),
    .os_data          (os_data),
    .os_datak         (os_datak),
    .pipe_tx_data     (lnk_tx_data),
    .pipe_tx_datak    (lnk_tx_datak),
    .rx_hp_valid      (rx_hp_valid),
    .rx_hp_data       (rx_hp_data),
    .rx_hp_type       (rx_hp_type),
    .rx_hp_crc_err    (rx_hp_crc_err),
    .rx_dp_valid      (rx_dp_valid),
    .rx_dp_data       (rx_dp_data),
    .rx_dp_last       (rx_dp_last),
    .rx_dp_crc_err    (rx_dp_crc_err),
    .tx_hp_valid      (tx_hp_valid),
    .tx_hp_data       (tx_hp_data),
    .tx_hp_ready      (tx_hp_ready),
    .tx_dp_valid      (tx_dp_valid),
    .tx_dp_data       (tx_dp_data),
    .tx_dp_last       (tx_dp_last),
    .tx_dp_ready      (tx_dp_ready),
    .pm_tx_req        (pm_tx_req),
    .pm_tx_cmd        (pm_tx_cmd),
    .pm_tx_done       (pm_tx_done),
    .pm_rx_valid      (pm_rx_valid),
    .pm_rx_cmd        (pm_rx_cmd),
    .err_crc5         (lnk_err_crc5),
    .err_crc16        (lnk_err_crc16),
    .err_crc32        (lnk_err_crc32),
    .err_protocol     (lnk_err_protocol),
    .err_link         (lnk_err_link)
  );

  // ------------------------------------------------------------------------
  // Protocol layer (pclk) + endpoint buffer array
  // ------------------------------------------------------------------------
  logic [EP_ADDR_W-1:0] ep_sel;
  logic                 ep_in_rd_en, ep_in_rd_last;
  logic [31:0]          ep_in_rd_data;
  logic [NUM_EP-1:0]    ep_in_avail;
  logic                 ep_out_wr_en, ep_out_wr_last;
  logic [31:0]          ep_out_wr_data;
  logic [NUM_EP-1:0]    ep_out_space;
  logic [NUM_EP*EP_LVL_W-1:0] ep_out_free;
  logic [NUM_EP*2-1:0]  ep_state_p;
  logic [NUM_EP-1:0]    ep_stalled_p;
  logic                 prot_err_protocol, prot_err_timeout;
  logic                 prot_err_overflow, prot_err_underflow;
  logic                 setup_valid_p;
  logic [63:0]          setup_data_p;
  logic [13:0]          itp_cnt_p;
  logic                 evt_setup_p, evt_ep_in_p, evt_ep_out_p, evt_enum_p;

  usb3_protocol u_protocol (
    .clk               (pclk),
    .rst_n             (prst_func_n),
    .link_up           (link_up),
    .cfg_dev_addr      (p_dev_addr),
    .cfg_dev_addr_valid(p_dev_addr_valid),
    .cfg_ep_en         (p_ep_en),
    .cfg_ep_type       (p_ep_type),
    .cfg_ep_dir_in     (p_ep_dir_in),
    .cfg_ep_maxpkt     (p_ep_maxpkt),
    .cfg_ep_burst      (p_ep_burst),
    .cfg_ep_stall      (p_ep_stall),
    .cfg_ep_clr_stall  (p_ep_clr_stall),
    .rx_hp_valid       (rx_hp_valid),
    .rx_hp_data        (rx_hp_data),
    .rx_hp_type        (rx_hp_type),
    .rx_hp_crc_err     (rx_hp_crc_err),
    .rx_dp_valid       (rx_dp_valid),
    .rx_dp_data        (rx_dp_data),
    .rx_dp_last        (rx_dp_last),
    .rx_dp_crc_err     (rx_dp_crc_err),
    .tx_hp_valid       (tx_hp_valid),
    .tx_hp_data        (tx_hp_data),
    .tx_hp_ready       (tx_hp_ready),
    .tx_dp_valid       (tx_dp_valid),
    .tx_dp_data        (tx_dp_data),
    .tx_dp_last        (tx_dp_last),
    .tx_dp_ready       (tx_dp_ready),
    .ep_sel            (ep_sel),
    .ep_in_rd_en       (ep_in_rd_en),
    .ep_in_rd_data     (ep_in_rd_data),
    .ep_in_rd_last     (ep_in_rd_last),
    .ep_in_avail       (ep_in_avail),
    .ep_out_wr_en      (ep_out_wr_en),
    .ep_out_wr_data    (ep_out_wr_data),
    .ep_out_wr_last    (ep_out_wr_last),
    .ep_out_space      (ep_out_space),
    .ep_out_free       (ep_out_free),
    .ep_state          (ep_state_p),
    .ep_stalled        (ep_stalled_p),
    .setup_valid       (setup_valid_p),
    .setup_data        (setup_data_p),
    .itp_cnt           (itp_cnt_p),
    .evt_setup         (evt_setup_p),
    .evt_enum_done     (evt_enum_p),
    .evt_ep_in_done    (evt_ep_in_p),
    .evt_ep_out_done   (evt_ep_out_p),
    .err_protocol      (prot_err_protocol),
    .err_timeout       (prot_err_timeout),
    .err_overflow      (prot_err_overflow),
    .err_underflow     (prot_err_underflow)
  );

  // Endpoint buffers (async FIFO pairs, one per endpoint).
  logic [EP_ADDR_W-1:0] dma_ep_sel;
  logic                 dma_in_wr_en, dma_in_wr_last;
  logic [31:0]          dma_in_wr_data;
  logic [NUM_EP-1:0]    dma_in_full;
  logic                 dma_out_rd_en;
  logic [31:0]          dma_out_rd_data;
  logic                 dma_out_rd_last;
  logic [NUM_EP-1:0]    dma_out_empty;

  usb3_ep_array u_ep_array (
    .pclk            (pclk),
    .prst_n          (prst_func_n),
    .aclk            (aclk),
    .arst_n          (arst_func_n),
    .cfg_ep_flush_a  (cfg_ep_flush),
    .ep_sel          (ep_sel),
    .ep_in_rd_en     (ep_in_rd_en),
    .ep_in_rd_data   (ep_in_rd_data),
    .ep_in_rd_last   (ep_in_rd_last),
    .ep_in_avail     (ep_in_avail),
    .ep_out_wr_en    (ep_out_wr_en),
    .ep_out_wr_data  (ep_out_wr_data),
    .ep_out_wr_last  (ep_out_wr_last),
    .ep_out_space    (ep_out_space),
    .ep_out_free     (ep_out_free),
    .dma_ep_sel      (dma_ep_sel),
    .dma_in_wr_en    (dma_in_wr_en),
    .dma_in_wr_data  (dma_in_wr_data),
    .dma_in_wr_last  (dma_in_wr_last),
    .dma_in_full     (dma_in_full),
    .dma_out_rd_en   (dma_out_rd_en),
    .dma_out_rd_data (dma_out_rd_data),
    .dma_out_rd_last (dma_out_rd_last),
    .dma_out_empty   (dma_out_empty)
  );

  // ------------------------------------------------------------------------
  // Scatter-gather DMA + AXI4 master (aclk)
  // ------------------------------------------------------------------------
  logic dma_done_a, dma_err_axi, dma_err_sec;

  usb3_dma #(
    .AXI_ADDR_WIDTH (AXI_ADDR_WIDTH),
    .AXI_DATA_WIDTH (AXI_DATA_WIDTH),
    .AXI_ID_WIDTH   (AXI_ID_WIDTH)
  ) u_dma (
    .clk             (aclk),
    .rst_n           (arst_func_n),
    .cfg_dma_en      (cfg_dma_en),
    .cfg_desc_base   (cfg_desc_base),
    .cfg_sec_en      (cfg_sec_en),
    .cfg_sec_base    (cfg_sec_base),
    .cfg_sec_limit   (cfg_sec_limit),
    .awid            (awid),
    .awaddr          (awaddr),
    .awlen           (awlen),
    .awsize          (awsize),
    .awburst         (awburst),
    .awprot          (awprot),
    .awcache         (awcache),
    .awvalid         (awvalid),
    .awready         (awready),
    .wdata           (wdata),
    .wstrb           (wstrb),
    .wlast           (wlast),
    .wvalid          (wvalid),
    .wready          (wready),
    .bid             (bid),
    .bresp           (bresp),
    .bvalid          (bvalid),
    .bready          (bready),
    .arid            (arid),
    .araddr          (araddr),
    .arlen           (arlen),
    .arsize          (arsize),
    .arburst         (arburst),
    .arprot          (arprot),
    .arcache         (arcache),
    .arvalid         (arvalid),
    .arready         (arready),
    .rid             (rid),
    .rdata           (rdata),
    .rresp           (rresp),
    .rlast           (rlast),
    .rvalid          (rvalid),
    .rready          (rready),
    .dma_ep_sel      (dma_ep_sel),
    .dma_in_wr_en    (dma_in_wr_en),
    .dma_in_wr_data  (dma_in_wr_data),
    .dma_in_wr_last  (dma_in_wr_last),
    .dma_in_full     (dma_in_full),
    .dma_out_rd_en   (dma_out_rd_en),
    .dma_out_rd_data (dma_out_rd_data),
    .dma_out_rd_last (dma_out_rd_last),
    .dma_out_empty   (dma_out_empty),
    .dma_busy        (sts_dma_busy),
    .dma_bytes_left  (sts_dma_bytes_left),
    .desc_cur        (sts_desc_cur),
    .dma_done        (dma_done_a),
    .err_axi         (dma_err_axi),
    .err_sec         (dma_err_sec)
  );

  // ------------------------------------------------------------------------
  // PIPE transmit: nothing but logical idle while the line is idle
  // ------------------------------------------------------------------------
  // pipe_tx_elec_idle is combinational from the LTSSM's registered state, so
  // this gate adds no path from any APB input to the transmit data.  The
  // ordered-set states and the electrically-idle states are disjoint
  // (usb3_ltssm.sv: os_for_state vs. the pipe_tx_elec_idle list), so no
  // training set is ever suppressed here - the only thing this can blank is a
  // framer output that had no business being on the pins.
  assign pipe_tx_data  = pipe_tx_elec_idle ? '0 : lnk_tx_data;
  assign pipe_tx_datak = pipe_tx_elec_idle ? '0 : lnk_tx_datak;

  // ------------------------------------------------------------------------
  // CDC: pclk status/events -> aclk
  // ------------------------------------------------------------------------
  // ERR_CRC16 is sourced from the LINK ONLY.  usb3_link raises err_crc16 on
  // rx_hdr_bad, and usb3_protocol raises its own err_crc16 one cycle later on
  // the rx_hp_crc_err flag that is derived from the very same detection - so a
  // single corrupted header used to put TWO pulses, on consecutive pclk
  // cycles, onto one CDC channel.  usb3_pulse_sync drops a pulse raised while
  // the handshake is in flight, which is what a_err_not_busy caught.  The link
  // report is also the COMPLETE one: a bad header arriving while the protocol
  // layer is out of PS_IDLE is flagged by the link and by nothing else.  Audit
  // finding D16.
  assign err_p[ERR_CRC5]      = lnk_err_crc5;
  assign err_p[ERR_CRC16]     = lnk_err_crc16;
  assign err_p[ERR_CRC32]     = lnk_err_crc32;
  assign err_p[ERR_PROTOCOL]  = prot_err_protocol || lnk_err_protocol;
  assign err_p[ERR_TIMEOUT]   = prot_err_timeout;
  assign err_p[ERR_LINK]      = ltssm_err_link || lnk_err_link;
  assign err_p[ERR_OVERFLOW]  = prot_err_overflow;
  assign err_p[ERR_UNDERFLOW] = prot_err_underflow;
  assign err_p[ERR_DMA_AXI]   = 1'b0; // aclk sourced
  assign err_p[ERR_SEC_VIOL]  = 1'b0; // aclk sourced

  assign evt_p[INT_SETUP]     = evt_setup_p;
  assign evt_p[INT_ENUM_DONE] = evt_enum_p;
  assign evt_p[INT_EP_IN]     = evt_ep_in_p;
  assign evt_p[INT_EP_OUT]    = evt_ep_out_p;
  assign evt_p[INT_DMA_DONE]  = 1'b0; // aclk sourced
  assign evt_p[INT_ERR]       = 1'b0; // derived in the CSR block

  // Event pulses (pclk -> aclk).
  logic [INT_WIDTH-1:0] evt_p2a;
  logic [INT_WIDTH-1:0] evt_busy;
  for (genvar i = 0; i < INT_WIDTH; i++) begin : g_evt_cdc
    usb3_pulse_sync u_sync (
      .src_clk(pclk), .src_rst_n(prst_n_s), .src_pulse(evt_p[i]),
      .src_busy(evt_busy[i]),
      .dst_clk(aclk), .dst_rst_n(arst_n_s), .dst_pulse(evt_p2a[i]));
  end

  // Error pulses (pclk -> aclk).
  logic [ERR_WIDTH-1:0] err_p2a;
  logic [ERR_WIDTH-1:0] err_busy;
  for (genvar i = 0; i < ERR_WIDTH; i++) begin : g_err_cdc
    usb3_pulse_sync u_sync (
      .src_clk(pclk), .src_rst_n(prst_n_s), .src_pulse(err_p[i]),
      .src_busy(err_busy[i]),
      .dst_clk(aclk), .dst_rst_n(arst_n_s), .dst_pulse(err_p2a[i]));
  end

  always_comb begin
    evt_a                 = evt_p2a;
    evt_a[INT_DMA_DONE]   = dma_done_a;
    err_a                 = err_p2a;
    err_a[ERR_DMA_AXI]    = dma_err_axi;
    err_a[ERR_SEC_VIOL]   = dma_err_sec;
  end

  // Quasi-static status levels (pclk -> aclk).
  usb3_bit_sync #(.WIDTH(8)) u_link_sts_sync (
    .clk(aclk), .rst_n(arst_n_s),
    .d_async({ltssm_state, ltssm_pwr, link_up}),
    .q_sync ({sts_ltssm,   sts_pwr_state, sts_link_up}));

  usb3_bit_sync #(.WIDTH(NUM_EP*2)) u_ep_state_sync (
    .clk(aclk), .rst_n(arst_n_s),
    .d_async(ep_state_p), .q_sync(sts_ep_state));

  // dma_in_full / dma_out_empty are already aclk-domain FIFO flags, so no
  // synchronizer is required (and none must be inserted, to keep the CSR view
  // coherent with what the DMA engine sees).
  assign sts_ep_in_rdy    = ~dma_in_full;
  assign sts_ep_out_valid = ~dma_out_empty;

  usb3_bit_sync #(.WIDTH(14)) u_itp_sync (
    .clk(aclk), .rst_n(arst_n_s),
    .d_async(itp_cnt_p), .q_sync(sts_itp_cnt));

  // SETUP payload: data is stable while the SETUP event pulse crosses, so a
  // simple data + qualifier handshake is safe (data settles before the pulse).
  logic [63:0] setup_data_hold;
  always_ff @(posedge pclk or negedge prst_func_n) begin
    if (!prst_func_n)      setup_data_hold <= '0;
    else if (setup_valid_p) setup_data_hold <= setup_data_p;
  end
  always_ff @(posedge aclk or negedge arst_n_s) begin
    if (!arst_n_s)                    sts_setup_data <= '0;
    else if (evt_p2a[INT_SETUP])      sts_setup_data <= setup_data_hold;
  end

  // Wake-up / suspend side band (aclk observable).
  usb3_bit_sync #(.WIDTH(2)) u_sb_sync (
    .clk(aclk), .rst_n(arst_n_s),
    .d_async({p_wakeup_req, (ltssm_pwr == PWR_U3)}),
    .q_sync ({wakeup_req,   suspended}));

  // ------------------------------------------------------------------------
  // Intentionally unused observability signals collected into one sink so
  // that lint reports a single, reviewed waiver point.
  //   - *_busy from usb3_pulse_sync: all CDC pulse sources here are either
  //     software writes (rate limited by the APB) or hardware events that are
  //     guaranteed to be spaced by more than the handshake latency.
  //   - ep_stalled_p is mirrored to software through sts_ep_state.
  // ------------------------------------------------------------------------
  logic unused_sink;
  assign unused_sink = soft_rst_busy | remote_wake_busy | hot_reset_busy |
                       (|clr_stall_busy) | (|evt_busy) | (|err_busy) |
                       (|ep_stalled_p);

endmodule

`default_nettype wire
