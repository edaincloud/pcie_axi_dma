// ============================================================================
// usb3_bit_sync.sv
// Part of the USB 3.0 SuperSpeed device controller CDC / storage primitive
// library. Reset convention: active-low, asynchronous assert, synchronous
// deassert.
// ============================================================================
`default_nettype none

// ----------------------------------------------------------------------------
// Level synchronizer (2FF default). Single-bit or quasi-static buses only.
// ----------------------------------------------------------------------------
module usb3_bit_sync #(
  parameter int unsigned WIDTH  = 1,
  parameter int unsigned STAGES = 2
) (
  input  wire              clk,
  input  wire              rst_n,
  input  wire  [WIDTH-1:0] d_async,
  output logic [WIDTH-1:0] q_sync
);
  // ---- elaboration guards ---------------------------------------------
  if (WIDTH < 1) begin : g_chk_width_min
    $error("usb3_bit_sync: WIDTH must be >= 1 (got %0d)", WIDTH);
  end
  if (WIDTH > 1024) begin : g_chk_width_max
    $error("usb3_bit_sync: WIDTH must be <= 1024 (got %0d)", WIDTH);
  end
  if (STAGES < 2) begin : g_chk_stages_min
    $error("usb3_bit_sync: STAGES must be >= 2 (got %0d): a single flop is not a synchroniser",
           STAGES);
  end
  if (STAGES > 8) begin : g_chk_stages_max
    $error("usb3_bit_sync: STAGES must be <= 8 (got %0d)", STAGES);
  end

  (* async_reg = "true" *) logic [STAGES-1:0][WIDTH-1:0] sync_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) sync_q <= '0;
    else begin
      sync_q[0] <= d_async;
      for (int unsigned s = 1; s < STAGES; s++)
        sync_q[s] <= sync_q[s-1];
    end
  end
  assign q_sync = sync_q[STAGES-1];
endmodule

`default_nettype wire
