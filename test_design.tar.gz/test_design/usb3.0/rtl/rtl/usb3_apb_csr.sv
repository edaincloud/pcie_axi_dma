// ============================================================================
// usb3_apb_csr.sv
// APB4 configuration / status / interrupt register block for the USB 3.0
// SuperSpeed device controller.  Runs entirely in the aclk (system) domain.
//
// APB4 behaviour
//   - Zero wait states: pready is driven high whenever the slave is selected,
//     so every transfer completes in the ACCESS phase (psel & penable).
//   - Writes are committed on the ACCESS phase only (psel & penable & pwrite),
//     which guarantees a single commit per APB transfer.
//   - pstrb selects the byte lanes that are updated for writes.
//   - pslverr is asserted (in the ACCESS phase only) for
//       * unmapped / misaligned addresses,
//       * writes to read-only registers,
//       * non-secure (pprot[1] == 1) or unprivileged (pprot[0] == 0) accesses
//         while secure-only mode (REG_SEC_CTRL[0]) is enabled,
//       * instruction accesses (pprot[2] == 1), which are never legal on this
//         data-only register interface.
//     An errored write has no side effect; an errored read returns 0.
//
// Register map: see usb3_pkg (REG_*, EP_BASE/EP_STRIDE/EP_*_OFF, INT_*, ERR_*).
//
// Notes / documented deviations
//   - REG_CTRL[3] (mode_select) selects device mode (0).  Host / DRD mode is
//     NOT implemented by this IP: writing 1 is ignored (the field always reads
//     back 0) and the write is flagged with pslverr so that software can
//     detect the unsupported request.
//   - REG_DESC_BASE_H exists and is fully readable / writable but is RESERVED
//     while AXI_ADDR_W == 32 (the DMA only consumes cfg_desc_base, the low
//     word).  It is provided for forward compatibility with 64-bit builds.
//   - The INT_ERR interrupt source is the OR of all error events; the per
//     error masking is done by software reading REG_ERR_STS.  INT_ERR itself
//     is masked with REG_INT_EN[INT_ERR].
//   - REG_DESC_BASE_L is written with the head of the descriptor list; while
//     the DMA is busy it reads back the live descriptor pointer (desc_cur),
//     and it reads back the programmed value while the DMA is idle.
//   - EP_XFER_OFF reports the DMA residual byte count (a single-channel DMA is
//     implemented, so there is one residual counter shared by all endpoints).
// ============================================================================
`default_nettype none

module usb3_apb_csr
  import usb3_pkg::*;
(
  input  wire                     clk,
  input  wire                     rst_n,

  // ---- APB4 slave --------------------------------------------------------
  input  wire                     psel,
  input  wire                     penable,
  input  wire                     pwrite,
  input  wire  [APB_ADDR_W-1:0]   paddr,
  input  wire  [31:0]             pwdata,
  input  wire  [3:0]              pstrb,
  input  wire  [2:0]              pprot,
  output logic [31:0]             prdata,
  output logic                    pready,
  output logic                    pslverr,

  // ---- Global configuration ---------------------------------------------
  output logic                    cfg_enable,
  output logic                    cfg_soft_rst,       // 1-cycle pulse
  output logic                    cfg_phy_en,
  output logic                    cfg_u1_en,
  output logic                    cfg_u2_en,
  output logic                    cfg_force_disable,
  output logic                    cfg_loopback_en,
  output logic                    cfg_compliance_en,
  output logic                    cfg_hot_reset_req,  // 1-cycle pulse
  output logic                    cfg_remote_wake,    // 1-cycle pulse
  output logic [6:0]              cfg_dev_addr,
  output logic                    cfg_dev_addr_valid,

  // ---- DMA / security configuration -------------------------------------
  output logic                    cfg_dma_en,
  output logic [31:0]             cfg_desc_base,
  output logic                    cfg_sec_en,
  output logic [31:0]             cfg_sec_base,
  output logic [31:0]             cfg_sec_limit,

  // ---- Per-endpoint configuration ---------------------------------------
  output logic [NUM_EP-1:0]       cfg_ep_en,
  output logic [NUM_EP*2-1:0]     cfg_ep_type,
  output logic [NUM_EP-1:0]       cfg_ep_dir_in,
  output logic [NUM_EP*12-1:0]    cfg_ep_maxpkt,
  output logic [NUM_EP*5-1:0]     cfg_ep_burst,
  output logic [NUM_EP-1:0]       cfg_ep_stall,
  output logic [NUM_EP-1:0]       cfg_ep_clr_stall,   // 1-cycle pulses
  output logic [NUM_EP-1:0]       cfg_ep_flush,       // 1-cycle pulses

  // ---- Status (already synchronized into aclk) ---------------------------
  input  wire  [4:0]              sts_ltssm,
  input  wire  [1:0]              sts_pwr_state,
  input  wire                     sts_link_up,
  input  wire  [NUM_EP*2-1:0]     sts_ep_state,
  input  wire  [NUM_EP-1:0]       sts_ep_in_rdy,
  input  wire  [NUM_EP-1:0]       sts_ep_out_valid,
  input  wire  [13:0]             sts_itp_cnt,
  input  wire  [63:0]             sts_setup_data,
  input  wire                     sts_dma_busy,
  input  wire  [19:0]             sts_dma_bytes_left,
  input  wire  [31:0]             sts_desc_cur,

  // ---- Event / error pulses (aclk) --------------------------------------
  input  wire  [INT_WIDTH-1:0]    evt_pulse,
  input  wire  [ERR_WIDTH-1:0]    err_pulse,
  output logic                    irq
);

  localparam logic [31:0] ID_VALUE = 32'h5533_0100; // "U3" rev 1.0

  // ------------------------------------------------------------------------
  // Register storage
  // ------------------------------------------------------------------------
  logic [10:0]            ctrl_q;      // persistent REG_CTRL bits
  logic [31:0]            link_ctrl_q;
  logic [7:0]             dev_addr_q;
  logic [INT_WIDTH-1:0]   int_sts_q;
  logic [INT_WIDTH-1:0]   int_en_q;
  logic [ERR_WIDTH-1:0]   err_sts_q;
  logic [1:0]             sec_ctrl_q;
  logic                   dma_ctrl_q;
  logic [31:0]            desc_base_l_q;
  logic [31:0]            desc_base_h_q;
  logic [31:0]            sec_base_q;
  logic [31:0]            sec_limit_q;

  logic [NUM_EP-1:0]      ep_en_q;
  logic [1:0]             ep_type_q   [NUM_EP];
  logic [NUM_EP-1:0]      ep_dir_in_q;
  logic [11:0]            ep_maxpkt_q [NUM_EP];
  logic [4:0]             ep_burst_q  [NUM_EP];
  logic [NUM_EP-1:0]      ep_stall_q;

  // ------------------------------------------------------------------------
  // Address decode (combinational, pure function of paddr)
  // ------------------------------------------------------------------------
  localparam logic [11:0] EP_TOP = EP_BASE + 12'(NUM_EP * EP_STRIDE);

  logic                   addr_aligned;
  logic                   in_ep_region;
  logic [EP_ADDR_W-1:0]   ep_idx;
  logic [3:0]             ep_off;
  logic                   hit_glb;   // mapped global register
  logic                   hit_ep;    // mapped endpoint register
  logic                   is_ro;     // mapped and read-only
  logic [31:0]            rdata_glb;
  logic [31:0]            rdata_ep;

  // The register map is a 4 KB block and the decode is `case (paddr[11:0])`.
  // With APB_ADDR_W > 12 the upper bits MUST take part in the decode, or the
  // block answers at every 4 KB alias of its window (defect D7).  Comparing
  // against APB_ADDR_W-wide copies of the offsets keeps the comparison in one
  // width instead of promoting both sides to 32 bits.
  localparam logic [APB_ADDR_W-1:0] EP_BASE_A = APB_ADDR_W'(EP_BASE);
  localparam logic [APB_ADDR_W-1:0] EP_TOP_A  = APB_ADDR_W'(EP_TOP);

  logic hi_zero;
  generate
    if (APB_ADDR_W > 12) begin : g_hi_decode
      assign hi_zero = (paddr[APB_ADDR_W-1:12] == '0);
    end else begin : g_no_hi_decode
      assign hi_zero = 1'b1;
    end
  endgenerate

  assign addr_aligned = (paddr[1:0] == 2'b00) && hi_zero;
  assign in_ep_region = (paddr >= EP_BASE_A) && (paddr < EP_TOP_A) && hi_zero;
  assign ep_idx       = paddr[4+EP_ADDR_W-1:4];
  assign ep_off       = paddr[3:0];

  // ---- global register read mux / decode ---------------------------------
  always_comb begin
    rdata_glb = 32'h0;
    hit_glb   = 1'b1;
    is_ro     = 1'b0;
    case (paddr[11:0])
      REG_ID: begin
        rdata_glb = ID_VALUE;
        is_ro     = 1'b1;
      end
      REG_CTRL:      rdata_glb = {21'h0, ctrl_q};
      REG_STATUS: begin
        rdata_glb = {14'h0,
                     |err_sts_q,          // [17] error sticky summary
                     sts_dma_busy,        // [16] DMA busy
                     3'h0,
                     sts_pwr_state,       // [12:11] power state
                     sts_ltssm,           // [10:6]  LTSSM state
                     3'h0,
                     dev_addr_q[7],       // [2] device address valid
                     1'b0,                // [1] host mode (not implemented)
                     sts_link_up};        // [0] link up
        is_ro     = 1'b1;
      end
      REG_LINK_CTRL: rdata_glb = link_ctrl_q;
      REG_LINK_STS: begin
        rdata_glb = {25'h0, sts_pwr_state, sts_ltssm};
        is_ro     = 1'b1;
      end
      REG_DEV_ADDR:  rdata_glb = {24'h0, dev_addr_q};
      REG_INT_STS:   rdata_glb = {{(32-INT_WIDTH){1'b0}}, int_sts_q};
      REG_INT_EN:    rdata_glb = {{(32-INT_WIDTH){1'b0}}, int_en_q};
      REG_ERR_STS:   rdata_glb = {{(32-ERR_WIDTH){1'b0}}, err_sts_q};
      REG_SEC_CTRL:  rdata_glb = {30'h0, sec_ctrl_q};
      REG_DMA_CTRL:  rdata_glb = {31'h0, dma_ctrl_q};
      REG_DMA_STS: begin
        rdata_glb = {11'h0, sts_dma_bytes_left, sts_dma_busy};
        is_ro     = 1'b1;
      end
      // Reads return the live descriptor pointer while the engine walks the
      // list, and the programmed head-of-list address when idle.
      REG_DESC_BASE_L: rdata_glb = sts_dma_busy ? sts_desc_cur : desc_base_l_q;
      REG_DESC_BASE_H: rdata_glb = desc_base_h_q; // RESERVED when AXI_ADDR_W==32
      REG_SEC_BASE:    rdata_glb = sec_base_q;
      REG_SEC_LIMIT:   rdata_glb = sec_limit_q;
      REG_ITP_CNT: begin
        rdata_glb = {18'h0, sts_itp_cnt};
        is_ro     = 1'b1;
      end
      REG_SETUP_L: begin
        rdata_glb = sts_setup_data[31:0];
        is_ro     = 1'b1;
      end
      REG_SETUP_H: begin
        rdata_glb = sts_setup_data[63:32];
        is_ro     = 1'b1;
      end
      default: begin
        rdata_glb = 32'h0;
        hit_glb   = 1'b0;
      end
    endcase
  end

  // ---- endpoint register read mux ----------------------------------------
  always_comb begin
    rdata_ep = 32'h0;
    hit_ep   = 1'b0;
    if (in_ep_region && addr_aligned) begin
      case (ep_off)
        EP_CFG_OFF[3:0]: begin
          hit_ep   = 1'b1;
          rdata_ep = {11'h0,
                      ep_burst_q[ep_idx],           // [20:16]
                      ep_maxpkt_q[ep_idx],          // [15:4]
                      ~ep_dir_in_q[ep_idx],         // [3] OUT
                      ep_dir_in_q[ep_idx],          // [2] IN
                      ep_type_q[ep_idx]};           // [1:0]
        end
        EP_CTRL_OFF[3:0]: begin
          hit_ep   = 1'b1;
          // [4:2] are write-only self-clearing controls and read back 0.
          rdata_ep = {27'h0, 3'h0, ep_stall_q[ep_idx], ep_en_q[ep_idx]};
        end
        EP_STS_OFF[3:0]: begin
          hit_ep   = 1'b1;
          rdata_ep = {16'h0,
                      // [15:8] endpoint-enable bitmap.  Written as
                      // {{(8-NUM_EP){1'b0}}, ep_en_q} the replication count
                      // underflows to 2**32-8 at the maximum legal NUM_EP=16
                      // (defect D8); a size cast zero-extends below 8
                      // endpoints and truncates to the low 8 above, which is
                      // what an 8-bit field can report.
                      8'(ep_en_q),
                      3'h0,
                      sts_ep_out_valid[ep_idx],      // [4]
                      sts_ep_in_rdy[ep_idx],         // [3]
                      ep_stall_q[ep_idx],            // [2]
                      sts_ep_state[ep_idx*2 +: 2]};  // [1:0]
        end
        EP_XFER_OFF[3:0]: begin
          hit_ep   = 1'b1;
          rdata_ep = {12'h0, sts_dma_bytes_left};
        end
        default: begin
          hit_ep   = 1'b0;
          rdata_ep = 32'h0;
        end
      endcase
    end
  end

  // EP_STS_OFF and EP_XFER_OFF are read-only.
  logic ep_is_ro;
  assign ep_is_ro = hit_ep && ((ep_off == EP_STS_OFF[3:0]) ||
                               (ep_off == EP_XFER_OFF[3:0]));

  // ------------------------------------------------------------------------
  // Byte-lane merge helper
  // ------------------------------------------------------------------------
  function automatic logic [31:0] wr_merge(input logic [31:0] old_v,
                                           input logic [31:0] new_v,
                                           input logic [3:0]  strb);
    logic [31:0] res;
    res = old_v;
    for (int unsigned b = 0; b < 4; b++) begin
      if (strb[b]) res[b*8 +: 8] = new_v[b*8 +: 8];
    end
    return res;
  endfunction

  // Each merged word is declared at exactly the width the register occupies,
  // so an unread upper bit is a real finding rather than an artefact of the
  // 32-bit helper.
  logic [10:0]           wdata_ctrl;
  logic [7:0]            wdata_dev;
  logic [20:0]           wdata_ep_cfg;
  logic [1:0]            wdata_ep_ctrl;
  logic [INT_WIDTH-1:0]  wdata_int_en;
  logic [1:0]            wdata_sec_ctrl;
  logic                  wdata_dma_ctrl;
  logic [31:0]           wdata_link;

  assign wdata_ctrl     = 11'(wr_merge({21'h0, ctrl_q}, pwdata, pstrb));
  assign wdata_dev      = 8'(wr_merge({24'h0, dev_addr_q}, pwdata, pstrb));
  assign wdata_int_en   = INT_WIDTH'(wr_merge({{(32-INT_WIDTH){1'b0}},
                                               int_en_q}, pwdata, pstrb));
  assign wdata_sec_ctrl = 2'(wr_merge({30'h0, sec_ctrl_q}, pwdata, pstrb));
  assign wdata_dma_ctrl = 1'(wr_merge({31'h0, dma_ctrl_q}, pwdata, pstrb));
  assign wdata_link     = wr_merge(link_ctrl_q, pwdata, pstrb);
  assign wdata_ep_cfg   = 21'(wr_merge({11'h0, ep_burst_q[ep_idx],
                                        ep_maxpkt_q[ep_idx],
                                        ~ep_dir_in_q[ep_idx],
                                        ep_dir_in_q[ep_idx],
                                        ep_type_q[ep_idx]}, pwdata, pstrb));
  assign wdata_ep_ctrl  = 2'(wr_merge({30'h0, ep_stall_q[ep_idx],
                                       ep_en_q[ep_idx]}, pwdata, pstrb));

  // ------------------------------------------------------------------------
  // APB handshake / error generation
  // ------------------------------------------------------------------------
  logic mapped;
  logic sec_viol;
  logic access;      // ACCESS phase of a valid transfer
  logic wr_ok;       // committed write
  logic err_any;

  assign mapped   = addr_aligned && (hit_glb || hit_ep);
  // Secure-only mode (REG_SEC_CTRL[0]) requires a secure (pprot[1]==0) and
  // privileged (pprot[0]==1) access. Instruction fetches (pprot[2]) are never
  // legal on this data-only register interface.
  assign sec_viol = (sec_ctrl_q[0] && (pprot[1] || !pprot[0])) || pprot[2];
  assign access   = psel && penable;

  // REG_CTRL[3] mode_select == 1 (host/DRD) is unsupported -> flag it.
  // Taken from the merged write word rather than from pwdata directly: ctrl_q[3]
  // is permanently zero, so wdata_ctrl[3] is exactly pstrb[0] && pwdata[3], and
  // reading it here means every bit of the merged word has a consumer.
  logic mode_req_err;
  assign mode_req_err = pwrite && (paddr[11:0] == REG_CTRL) && wdata_ctrl[3];

  assign err_any = !mapped || sec_viol ||
                   (pwrite && (is_ro || ep_is_ro)) || mode_req_err;

  assign pready  = psel;                       // zero wait states
  assign pslverr = access && err_any;
  assign wr_ok   = access && pwrite && mapped && !sec_viol &&
                   !is_ro && !ep_is_ro;

  assign prdata = (access && !pwrite && !err_any) ? (hit_ep ? rdata_ep
                                                            : rdata_glb)
                                                  : 32'h0;


  // ------------------------------------------------------------------------
  // Global register write / pulse generation
  // ------------------------------------------------------------------------
  logic soft_rst_pulse, remote_wake_pulse, hot_reset_pulse;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ctrl_q            <= 11'h0;
      link_ctrl_q       <= 32'h0;
      dev_addr_q        <= 8'h0;
      int_en_q          <= '0;
      sec_ctrl_q        <= 2'h0;
      dma_ctrl_q        <= 1'b0;
      desc_base_l_q     <= 32'h0;
      desc_base_h_q     <= 32'h0;
      sec_base_q        <= 32'h0;
      sec_limit_q       <= 32'hFFFF_FFFF;
      soft_rst_pulse    <= 1'b0;
      remote_wake_pulse <= 1'b0;
      hot_reset_pulse   <= 1'b0;
    end else begin
      soft_rst_pulse    <= 1'b0;
      remote_wake_pulse <= 1'b0;
      hot_reset_pulse   <= 1'b0;

      if (wr_ok && hit_glb) begin
        case (paddr[11:0])
          REG_CTRL: begin
            // Self-clearing pulse bits are never stored.
            ctrl_q[0]         <= wdata_ctrl[0];   // enable
            ctrl_q[1]         <= 1'b0;            // soft reset (pulse)
            ctrl_q[2]         <= wdata_ctrl[2];   // phy enable
            ctrl_q[3]         <= 1'b0;            // mode: device only
            ctrl_q[8:4]       <= wdata_ctrl[8:4]; // u1/u2/fdis/lpbk/compl
            ctrl_q[9]         <= 1'b0;            // remote wake (pulse)
            ctrl_q[10]        <= 1'b0;            // hot reset  (pulse)
            soft_rst_pulse    <= wdata_ctrl[1];
            remote_wake_pulse <= wdata_ctrl[9];
            hot_reset_pulse   <= wdata_ctrl[10];
          end
          REG_LINK_CTRL:   link_ctrl_q   <= wdata_link;
          REG_DEV_ADDR:    dev_addr_q    <= wdata_dev[7:0];
          REG_INT_EN:      int_en_q      <= wdata_int_en[INT_WIDTH-1:0];
          REG_SEC_CTRL:    sec_ctrl_q    <= wdata_sec_ctrl[1:0];
          REG_DMA_CTRL:    dma_ctrl_q    <= wdata_dma_ctrl;
          REG_DESC_BASE_L: desc_base_l_q <= wr_merge(desc_base_l_q, pwdata,
                                                     pstrb);
          REG_DESC_BASE_H: desc_base_h_q <= wr_merge(desc_base_h_q, pwdata,
                                                     pstrb);
          REG_SEC_BASE:    sec_base_q    <= wr_merge(sec_base_q, pwdata, pstrb);
          REG_SEC_LIMIT:   sec_limit_q   <= wr_merge(sec_limit_q, pwdata,
                                                     pstrb);
          default: ; // RO registers: already filtered by wr_ok
        endcase
      end
    end
  end

  // ------------------------------------------------------------------------
  // Interrupt status (sticky, W1C) and error status (sticky, W1C)
  // ------------------------------------------------------------------------
  logic [INT_WIDTH-1:0] int_w1c;
  logic [ERR_WIDTH-1:0] err_w1c;
  logic [ERR_WIDTH-1:0] err_set;

  assign int_w1c = (wr_ok && hit_glb && (paddr[11:0] == REG_INT_STS))
                   ? wr_merge('0, pwdata, pstrb)[INT_WIDTH-1:0] : '0;
  assign err_w1c = (wr_ok && hit_glb && (paddr[11:0] == REG_ERR_STS))
                   ? wr_merge('0, pwdata, pstrb)[ERR_WIDTH-1:0] : '0;
  assign err_set = err_pulse;

  logic [INT_WIDTH-1:0] int_set;
  always_comb begin
    int_set           = evt_pulse;
    int_set[INT_ERR]  = evt_pulse[INT_ERR] | (|err_set);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      int_sts_q <= '0;
      err_sts_q <= '0;
    end else begin
      int_sts_q <= (int_sts_q & ~int_w1c) | int_set;
      err_sts_q <= (err_sts_q & ~err_w1c) | err_set;
    end
  end

  assign irq = |(int_sts_q & int_en_q);

  // ------------------------------------------------------------------------
  // Endpoint register writes
  // ------------------------------------------------------------------------
  logic ep_cfg_wr, ep_ctrl_wr;
  assign ep_cfg_wr  = wr_ok && hit_ep && (ep_off == EP_CFG_OFF[3:0]);
  assign ep_ctrl_wr = wr_ok && hit_ep && (ep_off == EP_CTRL_OFF[3:0]);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ep_en_q     <= {{(NUM_EP-1){1'b0}}, 1'b1}; // EP0 always enabled
      ep_dir_in_q <= '0;
      ep_stall_q  <= '0;
      for (int unsigned e = 0; e < NUM_EP; e++) begin
        ep_type_q[e]   <= (e == 0) ? EP_CONTROL : EP_BULK;
        ep_maxpkt_q[e] <= 12'd512;
        ep_burst_q[e]  <= 5'd0;
      end
    end else begin
      if (ep_cfg_wr) begin
        // EP0 is hard-wired to the control type and cannot be re-typed.
        ep_type_q[ep_idx]   <= (ep_idx == '0) ? EP_CONTROL
                                              : ep_type_e'(wdata_ep_cfg[1:0]);
        ep_dir_in_q[ep_idx] <= wdata_ep_cfg[2];
        ep_maxpkt_q[ep_idx] <= wdata_ep_cfg[15:4];
        ep_burst_q[ep_idx]  <= wdata_ep_cfg[20:16];
      end
      if (ep_ctrl_wr) begin
        // EP0 cannot be disabled.
        ep_en_q[ep_idx]    <= (ep_idx == '0) ? 1'b1 : wdata_ep_ctrl[0];
        // Stall is set by bit[1]; a write-1 to bit[3] clears it.
        ep_stall_q[ep_idx] <= wdata_ep_ctrl[1] & ~(pwdata[3] & pstrb[0]);
      end
    end
  end

  // Single-cycle clear-stall / flush pulses (bits 3 and 2 of EP_CTRL_OFF).
  logic [NUM_EP-1:0] ep_clr_stall_q, ep_flush_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ep_clr_stall_q <= '0;
      ep_flush_q     <= '0;
    end else begin
      ep_clr_stall_q <= '0;
      ep_flush_q     <= '0;
      if (ep_ctrl_wr && pstrb[0]) begin
        ep_clr_stall_q[ep_idx] <= pwdata[3];
        ep_flush_q[ep_idx]     <= pwdata[2];
      end
    end
  end

  // ------------------------------------------------------------------------
  // Output mapping
  // ------------------------------------------------------------------------
  assign cfg_enable         = ctrl_q[0];
  assign cfg_soft_rst       = soft_rst_pulse;
  assign cfg_phy_en         = ctrl_q[2];
  assign cfg_u1_en          = ctrl_q[4];
  assign cfg_u2_en          = ctrl_q[5];
  assign cfg_force_disable  = ctrl_q[6];
  assign cfg_loopback_en    = ctrl_q[7];
  assign cfg_compliance_en  = ctrl_q[8];
  assign cfg_remote_wake    = remote_wake_pulse;
  assign cfg_hot_reset_req  = hot_reset_pulse;
  assign cfg_dev_addr       = dev_addr_q[6:0];
  assign cfg_dev_addr_valid = dev_addr_q[7];

  assign cfg_dma_en         = dma_ctrl_q;
  assign cfg_desc_base      = desc_base_l_q;
  assign cfg_sec_en         = sec_ctrl_q[1];
  assign cfg_sec_base       = sec_base_q;
  assign cfg_sec_limit      = sec_limit_q;

  assign cfg_ep_en          = ep_en_q;
  assign cfg_ep_dir_in      = ep_dir_in_q;
  assign cfg_ep_stall       = ep_stall_q;
  assign cfg_ep_clr_stall   = ep_clr_stall_q;
  assign cfg_ep_flush       = ep_flush_q;

  always_comb begin
    cfg_ep_type   = '0;
    cfg_ep_maxpkt = '0;
    cfg_ep_burst  = '0;
    for (int unsigned e = 0; e < NUM_EP; e++) begin
      cfg_ep_type[e*2 +: 2]    = ep_type_q[e];
      cfg_ep_maxpkt[e*12 +: 12] = ep_maxpkt_q[e];
      cfg_ep_burst[e*5 +: 5]   = ep_burst_q[e];
    end
  end

  // ------------------------------------------------------------------------
  // Deliberately unconsumed write-data bit, named so that -Wall reports one
  // reviewed sink instead of hiding the next real one.
  //
  //   wdata_ep_cfg[3]  EP_CFG[3] is the OUT-direction MIRROR of EP_CFG[2]: the
  //                    register reads back {~in, in} so software can read the
  //                    direction either way round, but the direction is stored
  //                    from bit 2 only.  A write to bit 3 is ignored by
  //                    construction, and the spec's "reserved bits ignore
  //                    writes" rule applies.
  // ------------------------------------------------------------------------
  logic unused_wr_bits;
  assign unused_wr_bits = wdata_ep_cfg[3];


endmodule

`default_nettype wire
