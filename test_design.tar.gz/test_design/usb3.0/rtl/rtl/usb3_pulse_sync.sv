// ============================================================================
// usb3_pulse_sync.sv
// Part of the USB 3.0 SuperSpeed device controller CDC / storage primitive
// library. Reset convention: active-low, asynchronous assert, synchronous
// deassert.
// ============================================================================
`default_nettype none

// ----------------------------------------------------------------------------
// Pulse handshake synchronizer: 1-cycle src pulse -> 1-cycle dst pulse.
// src_busy must be observed: new pulses are dropped while busy.
// ----------------------------------------------------------------------------
module usb3_pulse_sync (
  input  wire  src_clk,
  input  wire  src_rst_n,
  input  wire  src_pulse,
  output logic src_busy,
  input  wire  dst_clk,
  input  wire  dst_rst_n,
  output logic dst_pulse
);
  logic src_toggle;
  always_ff @(posedge src_clk or negedge src_rst_n) begin
    if (!src_rst_n)                  src_toggle <= 1'b0;
    else if (src_pulse && !src_busy) src_toggle <= ~src_toggle;
  end

  (* async_reg = "true" *) logic [1:0] dst_sync;
  always_ff @(posedge dst_clk or negedge dst_rst_n) begin
    if (!dst_rst_n) dst_sync <= 2'b00;
    else            dst_sync <= {dst_sync[0], src_toggle};
  end
  assign dst_pulse = dst_sync[0] ^ dst_sync[1];

  logic dst_toggle_q;
  always_ff @(posedge dst_clk or negedge dst_rst_n) begin
    if (!dst_rst_n)     dst_toggle_q <= 1'b0;
    else if (dst_pulse) dst_toggle_q <= ~dst_toggle_q;
  end
  (* async_reg = "true" *) logic [1:0] back_sync;
  always_ff @(posedge src_clk or negedge src_rst_n) begin
    if (!src_rst_n) back_sync <= 2'b00;
    else            back_sync <= {back_sync[0], dst_toggle_q};
  end
  assign src_busy = (src_toggle ^ back_sync[1]);
endmodule

`default_nettype wire
