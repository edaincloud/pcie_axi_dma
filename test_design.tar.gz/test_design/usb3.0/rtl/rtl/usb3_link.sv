// ============================================================================
// usb3_link.sv
// USB 3.0 SuperSpeed device link layer: PIPE symbol framing / de-framing,
// header-packet and data-packet CRC generation and checking, link commands,
// header sequence numbers and the receive header credit (flow control) scheme.
//
// ---------------------------------------------------------------------------
// Framing used on the 32-bit PIPE interface (byte 0 = pipe_*_data[7:0]):
//
//   Header packet (HP)
//     beat 0 : K_SHP  K_SHP  K_SHP  K_SHP          (datak = 4'b1111)
//     beat 1 : header dword 0                      (hp_data[31:0])
//     beat 2 : header dword 1                      (hp_data[63:32])
//     beat 3 : header dword 2                      (hp_data[95:64])
//     beat 4 : {crc16[15:0], link_control[15:0]}
//     beat 5 : K_END  K_END  K_END  K_END
//
//     link_control[15:11] = CRC5 over link_control[10:0]
//     link_control[2:0]   = header sequence number
//
//   Data packet payload (DP)
//     beat 0 : K_SDP  K_SDP  K_SDP  K_SDP
//     beat n : payload dwords (little endian)
//     beat p : CRC32 over all payload dwords
//     beat q : K_END x4 (good) or K_EDB x4 (nullified payload)
//
//   Link command (LC)
//     beat 0 : K_SLC  K_SLC  K_SLC  K_SLC
//     beat 1 : {lcw_copy2[15:0], lcw_copy1[15:0]}
//              lcw[10:7] = link_cmd_e class, lcw[6:0] = command parameter,
//              lcw[15:11] = CRC5 over lcw[10:0].  The word is replicated twice
//              and both copies must match.
//
// When os_active is asserted the LTSSM ordered-set stream has absolute
// priority on the transmit bus and the transmit FSM is frozen, so ordered sets
// never corrupt a packet in flight.
// ============================================================================
`default_nettype none

module usb3_link
  import usb3_pkg::*;
(
  input  wire                    clk,
  input  wire                    rst_n,
  input  wire                    link_up,

  // ---- PIPE receive ------------------------------------------------------
  input  wire  [PIPE_DATA_W-1:0] pipe_rx_data,
  input  wire  [PIPE_K_W-1:0]    pipe_rx_datak,
  input  wire                    pipe_rx_valid,

  // ---- Ordered-set stream from the LTSSM (highest transmit priority) ------
  input  wire                    os_active,
  // The LTSSM has the transmitter in electrical idle.  The framer is frozen
  // and holds logical idle while this is asserted - see tx_run below.
  input  wire                    tx_elec_idle,
  input  wire  [PIPE_DATA_W-1:0] os_data,
  input  wire  [PIPE_K_W-1:0]    os_datak,

  // ---- PIPE transmit -----------------------------------------------------
  output logic [PIPE_DATA_W-1:0] pipe_tx_data,
  output logic [PIPE_K_W-1:0]    pipe_tx_datak,

  // ---- Receive header / payload to the protocol layer ---------------------
  output logic                   rx_hp_valid,
  output logic [95:0]            rx_hp_data,
  output logic [4:0]             rx_hp_type,
  output logic                   rx_hp_crc_err,
  output logic                   rx_dp_valid,
  output logic [31:0]            rx_dp_data,
  output logic                   rx_dp_last,
  output logic                   rx_dp_crc_err,

  // ---- Transmit header / payload from the protocol layer ------------------
  input  wire                    tx_hp_valid,
  input  wire  [95:0]            tx_hp_data,
  output logic                   tx_hp_ready,
  input  wire                    tx_dp_valid,
  input  wire  [31:0]            tx_dp_data,
  input  wire                    tx_dp_last,
  output logic                   tx_dp_ready,

  // ---- Power-management link-command channel (LTSSM) ----------------------
  input  wire                    pm_tx_req,
  input  wire  [3:0]             pm_tx_cmd,
  output logic                   pm_tx_done,
  output logic                   pm_rx_valid,
  output logic [3:0]             pm_rx_cmd,

  // ---- Error pulses ------------------------------------------------------
  output logic                   err_crc5,
  output logic                   err_crc16,
  output logic                   err_crc32,
  output logic                   err_protocol,
  output logic                   err_link
);

  // ------------------------------------------------------------------------
  // Local constants
  // ------------------------------------------------------------------------
  localparam logic [15:0] CRC16_INIT = 16'hFFFF;
  localparam logic [31:0] CRC32_INIT = 32'hFFFF_FFFF;
  localparam int unsigned LC_FIFO_DEPTH = 8;
  localparam int unsigned DP_FIFO_DEPTH = 16;
  localparam int unsigned LC_W          = 11; // {cmd[3:0], param[6:0]}
  // THIS port's receive header credit counter, sized from THIS port's buffer
  // count.
  localparam int unsigned CRED_W        = unsigned'($clog2(NUM_RX_CREDIT + 1));
  // The REMOTE port's header buffer count, which is what the transmit credit
  // counter tracks.  It is a SEPARATE number: USB 3.0 gives every port four Rx
  // header buffers (LCRD_A..LCRD_D), so a device built with a small local
  // receive buffer may still have four headers outstanding towards the host.
  //
  // Both the reset value and the saturation ceiling of tx_cred_q used to be
  // NUM_RX_CREDIT.  In the `min` regression build (NUM_RX_CREDIT = 1) that
  // capped the device at ONE outstanding transmit header, so the second data
  // packet header of a two-packet IN burst stalled in TXS_IDLE waiting for an
  // LCRD, and usb3_dma_test failed in that build and only that build.
  localparam int unsigned TX_CRED_W     = unsigned'($clog2(NUM_TX_CREDIT + 1));

  // ------------------------------------------------------------------------
  // Receive symbol classification
  // ------------------------------------------------------------------------
  logic rx_is_shp, rx_is_sdp, rx_is_slc, rx_is_end, rx_is_edb;

  always_comb begin
    rx_is_shp = pipe_rx_valid && pipe_rx_datak[0] && (pipe_rx_data[7:0] == K_SHP);
    rx_is_sdp = pipe_rx_valid && pipe_rx_datak[0] && (pipe_rx_data[7:0] == K_SDP);
    rx_is_slc = pipe_rx_valid && pipe_rx_datak[0] && (pipe_rx_data[7:0] == K_SLC);
    rx_is_end = pipe_rx_valid && pipe_rx_datak[0] && (pipe_rx_data[7:0] == K_END);
    rx_is_edb = pipe_rx_valid && pipe_rx_datak[0] && (pipe_rx_data[7:0] == K_EDB);
  end

  // ------------------------------------------------------------------------
  // Receive FSM
  // ------------------------------------------------------------------------
  typedef enum logic [2:0] {
    RXS_IDLE   = 3'd0,
    RXS_HP     = 3'd1,
    RXS_HP_LC  = 3'd2,
    RXS_DP     = 3'd3,
    RXS_LC     = 3'd4
  } rx_state_e;

  rx_state_e   rx_state_q;
  logic [95:0] rx_hdr_q;
  logic [1:0]  rx_hdr_cnt_q;

  // Header CRC16 over the three received header dwords.
  logic [15:0] rx_c16_0, rx_c16_1, rx_c16_2;
  usb3_crc16 #(.DATA_W(32)) u_rx_c16_0 (
    .crc_in(CRC16_INIT), .data(rx_hdr_q[31:0]),  .crc_out(rx_c16_0));
  usb3_crc16 #(.DATA_W(32)) u_rx_c16_1 (
    .crc_in(rx_c16_0),   .data(rx_hdr_q[63:32]), .crc_out(rx_c16_1));
  usb3_crc16 #(.DATA_W(32)) u_rx_c16_2 (
    .crc_in(rx_c16_1),   .data(rx_hdr_q[95:64]), .crc_out(rx_c16_2));

  // CRC5 over bits [10:0] of the current receive beat.  The same generator
  // serves the header link-control field and the link-command word, both of
  // which place their 11 protected bits in the low half of the dword.
  logic [4:0]  rx_lc5;
  logic [10:0] rx_lc_word;
  assign rx_lc_word = pipe_rx_data[10:0];
  usb3_crc5 #(.DATA_W(11)) u_rx_lc5 (
    .crc_in(5'h1F), .data(rx_lc_word), .crc_out(rx_lc5));

  // Data payload CRC32 accumulation.
  logic [31:0] rx_crc32_q, rx_crc32_nxt;
  logic [31:0] rx_dp_h0_q, rx_dp_h1_q;
  logic [1:0]  rx_dp_cnt_q;
  usb3_crc32 #(.DATA_W(32)) u_rx_c32 (
    .crc_in(rx_crc32_q), .data(rx_dp_h0_q), .crc_out(rx_crc32_nxt));

  // Receive header sequence / credit bookkeeping.
  logic [2:0]        rx_seq_exp_q;
  logic [CRED_W-1:0] rx_cred_q;
  logic [1:0]        rx_cred_idx_q;

  // Internally generated link commands (towards the transmit FIFO).
  logic             int_push;
  logic [LC_W-1:0]  int_word;
  logic             lcrd_pend_q;
  logic             rx_hdr_good, rx_seq_err;
  logic             rx_hdr_c16_bad, rx_hdr_c5_bad;
  wire              rx_hdr_bad;

  // Decoded received link command.
  logic            rx_lc_ok;
  logic [3:0]      rx_lc_cmd;
  logic [6:0]      rx_lc_param;
  logic            rx_lc_stb;

  always_comb begin
    rx_lc_cmd   = pipe_rx_data[10:7];
    rx_lc_param = pipe_rx_data[6:0];
    // Both replicated copies must match and the CRC5 must check.
    rx_lc_ok    = (pipe_rx_data[26:16] == pipe_rx_data[10:0])
                  && (pipe_rx_data[31:27] == pipe_rx_data[15:11])
                  && (pipe_rx_data[15:11] == rx_lc5);
    rx_lc_stb   = (rx_state_q == RXS_LC) && pipe_rx_valid;
  end

  // Transmit-side credit / retry state driven from received link commands.
  // Sized from the REMOTE port's header buffer count, not this port's.
  logic [TX_CRED_W-1:0] tx_cred_q;
  logic              tx_retry_q;
  logic              lbad_rx, lcrd_rx, lgood_rx, lrty_rx;

  assign lbad_rx  = rx_lc_stb && rx_lc_ok && (rx_lc_cmd == LC_LBAD);
  assign lcrd_rx  = rx_lc_stb && rx_lc_ok && (rx_lc_cmd == LC_LCRD);
  assign lgood_rx = rx_lc_stb && rx_lc_ok && (rx_lc_cmd == LC_LGOOD);
  assign lrty_rx  = rx_lc_stb && rx_lc_ok && (rx_lc_cmd == LC_LRTY);

  // The two header CRCs are checked separately so that ERROR_STATUS.CRC_ERR
  // can say WHICH one failed.  Reporting both bits for either failure - which
  // is what the protocol layer used to do from the merged rx_hp_crc_err flag -
  // makes the two status bits indistinguishable and tells software nothing.
  always_comb begin
    rx_hdr_good   = 1'b0;
    rx_hdr_c16_bad = 1'b0;
    rx_hdr_c5_bad  = 1'b0;
    rx_seq_err    = 1'b0;
    if ((rx_state_q == RXS_HP_LC) && pipe_rx_valid) begin
      rx_hdr_c16_bad = (pipe_rx_data[31:16] != rx_c16_2);
      rx_hdr_c5_bad  = (pipe_rx_data[15:11] != rx_lc5);
      if (!(rx_hdr_c16_bad || rx_hdr_c5_bad)) begin
        rx_hdr_good = 1'b1;
        rx_seq_err  = (pipe_rx_data[2:0] != rx_seq_exp_q);
      end
    end
  end

  // A header is unusable if either CRC failed.  Everything downstream that
  // only needs "drop this header" uses this.
  assign rx_hdr_bad = rx_hdr_c16_bad || rx_hdr_c5_bad;

  // Internal link-command generation: LGOOD_n / LBAD immediately, the matching
  // LCRD_x one cycle later (header buffer freed by the protocol layer).
  always_comb begin
    int_push = 1'b0;
    int_word = '0;
    if (rx_hdr_good) begin
      int_push = 1'b1;
      int_word = {LC_LGOOD, 4'h0, rx_seq_exp_q};
    end else if (rx_hdr_bad) begin
      int_push = 1'b1;
      int_word = {LC_LBAD, 7'h00};
    end else if (lbad_rx) begin
      int_push = 1'b1;
      int_word = {LC_LRTY, 7'h00};
    end else if (lcrd_pend_q) begin
      int_push = 1'b1;
      int_word = {LC_LCRD, 5'h00, rx_cred_idx_q};
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rx_state_q    <= RXS_IDLE;
      rx_hdr_q      <= '0;
      rx_hdr_cnt_q  <= 2'd0;
      rx_hp_valid   <= 1'b0;
      rx_hp_data    <= '0;
      rx_hp_type    <= 5'd0;
      rx_hp_crc_err <= 1'b0;
      rx_dp_valid   <= 1'b0;
      rx_dp_data    <= '0;
      rx_dp_last    <= 1'b0;
      rx_dp_crc_err <= 1'b0;
      rx_dp_h0_q    <= '0;
      rx_dp_h1_q    <= '0;
      rx_dp_cnt_q   <= 2'd0;
      rx_crc32_q    <= CRC32_INIT;
      rx_seq_exp_q  <= 3'd0;
      rx_cred_q     <= CRED_W'(NUM_RX_CREDIT);
      rx_cred_idx_q <= 2'd0;
      lcrd_pend_q   <= 1'b0;
      pm_rx_valid   <= 1'b0;
      pm_rx_cmd     <= LC_NONE;
    end else begin
      rx_hp_valid <= 1'b0;
      rx_dp_valid <= 1'b0;
      rx_dp_last  <= 1'b0;
      pm_rx_valid <= 1'b0;
      lcrd_pend_q <= 1'b0;
      // The two CRC verdicts are qualified strobes like the valids they travel
      // with, and were the only members of this group that were not defaulted:
      // each held its last value until the next packet ended, so the link
      // presented a stale "this packet failed its CRC" outside any valid word.
      // Every consumer happens to qualify with the matching valid, so nothing
      // acted on it - but a_rx_dp_crc_only_on_last is the property that says
      // the verdict belongs to the final word, and it was false between
      // packets.  Audit finding D18.
      rx_hp_crc_err <= 1'b0;
      rx_dp_crc_err <= 1'b0;

      // Header buffer credit accounting: one buffer is consumed on reception
      // and released again when the LCRD_x is generated.
      if (rx_hdr_good && (rx_cred_q != '0)) rx_cred_q <= rx_cred_q - CRED_W'(1'b1);
      else if (lcrd_pend_q && (rx_cred_q != CRED_W'(NUM_RX_CREDIT)))
                                            rx_cred_q <= rx_cred_q + CRED_W'(1'b1);

      case (rx_state_q)
        RXS_IDLE: begin
          if (rx_is_shp) begin
            rx_state_q   <= RXS_HP;
            rx_hdr_cnt_q <= 2'd0;
          end else if (rx_is_sdp) begin
            rx_state_q  <= RXS_DP;
            rx_dp_cnt_q <= 2'd0;
            rx_crc32_q  <= CRC32_INIT;
          end else if (rx_is_slc) begin
            rx_state_q <= RXS_LC;
          end
        end

        RXS_HP: begin
          if (pipe_rx_valid) begin
            case (rx_hdr_cnt_q)
              2'd0: rx_hdr_q[31:0]  <= pipe_rx_data;
              2'd1: rx_hdr_q[63:32] <= pipe_rx_data;
              default: rx_hdr_q[95:64] <= pipe_rx_data;
            endcase
            if (rx_hdr_cnt_q == 2'd2) rx_state_q   <= RXS_HP_LC;
            else                      rx_hdr_cnt_q <= rx_hdr_cnt_q + 2'd1;
          end
        end

        RXS_HP_LC: begin
          if (pipe_rx_valid) begin
            rx_state_q    <= RXS_IDLE;
            rx_hp_valid   <= 1'b1;
            rx_hp_data    <= rx_hdr_q;
            rx_hp_type    <= rx_hdr_q[4:0];
            rx_hp_crc_err <= rx_hdr_bad;
            if (rx_hdr_good && !rx_seq_err) begin
              rx_seq_exp_q  <= rx_seq_exp_q + 3'd1;
              rx_cred_idx_q <= rx_cred_idx_q + 2'd1;
              lcrd_pend_q   <= 1'b1;
            end
          end
        end

        RXS_DP: begin
          if (rx_is_end || rx_is_edb) begin
            rx_state_q <= RXS_IDLE;
            if (rx_dp_cnt_q == 2'd2) begin
              rx_dp_valid   <= 1'b1;
              rx_dp_data    <= rx_dp_h0_q;
              rx_dp_last    <= 1'b1;
              rx_dp_crc_err <= rx_is_edb || (rx_crc32_nxt != rx_dp_h1_q);
            end
          end else if (pipe_rx_valid && (pipe_rx_datak == '0)) begin
            if (rx_dp_cnt_q == 2'd0) begin
              rx_dp_h1_q  <= pipe_rx_data;
              rx_dp_cnt_q <= 2'd1;
            end else if (rx_dp_cnt_q == 2'd1) begin
              rx_dp_h0_q  <= rx_dp_h1_q;
              rx_dp_h1_q  <= pipe_rx_data;
              rx_dp_cnt_q <= 2'd2;
            end else begin
              rx_dp_valid   <= 1'b1;
              rx_dp_data    <= rx_dp_h0_q;
              rx_dp_last    <= 1'b0;
              rx_dp_crc_err <= 1'b0;
              rx_crc32_q    <= rx_crc32_nxt;
              rx_dp_h0_q    <= rx_dp_h1_q;
              rx_dp_h1_q    <= pipe_rx_data;
            end
          end else if (pipe_rx_valid) begin
            // Unexpected control symbol inside a payload: abort the packet.
            rx_state_q <= RXS_IDLE;
          end
        end

        RXS_LC: begin
          if (pipe_rx_valid) begin
            rx_state_q <= RXS_IDLE;
            if (rx_lc_ok) begin
              case (link_cmd_e'(rx_lc_cmd))
                LC_LGO_U1, LC_LGO_U2, LC_LGO_U3,
                LC_LAU, LC_LXU, LC_LPMA, LC_LUP, LC_LDN: begin
                  pm_rx_valid <= 1'b1;
                  pm_rx_cmd   <= rx_lc_cmd;
                end
                default: begin
                  pm_rx_valid <= 1'b0;
                end
              endcase
            end
          end
        end

        default: rx_state_q <= RXS_IDLE;
      endcase
    end
  end

  // ------------------------------------------------------------------------
  // Link-command transmit FIFO (internal flow-control commands + LTSSM PM)
  // ------------------------------------------------------------------------
  logic                lc_push, lc_pop, lc_full, lc_empty;
  logic [LC_W-1:0]     lc_wr_data, lc_rd_data;
  logic                lc_af, lc_ae, lc_of, lc_uf;
  logic [$clog2(LC_FIFO_DEPTH):0] lc_level;
  logic                pm_accept;

  // Set when a PM link command has been pushed and not yet transmitted; the
  // generating always_ff is below the transmit FSM, because "transmitted" is
  // not knowable until the framer has drained.
  logic pm_pend_q;

  // pm_accept must be a ONE-CYCLE push.  pm_tx_req is a level that persists
  // for the whole PMS_REQ state, so without the !pm_pend_q term the same PM
  // link command is pushed into the FIFO on every cycle of that state - and
  // pm_tx_done is no longer the cycle after the accept, so the state now lasts
  // as long as the framer takes to drain.
  assign pm_accept  = pm_tx_req && !pm_pend_q && !int_push && !lc_full;
  assign lc_push    = (int_push && !lc_full) || pm_accept;
  assign lc_wr_data = int_push ? int_word : {pm_tx_cmd, 7'h00};

  usb3_sync_fifo #(
    .WIDTH  (LC_W),
    .DEPTH  (LC_FIFO_DEPTH),
    .AF_LVL (2),
    .AE_LVL (1)
  ) u_lc_fifo (
    .clk          (clk),
    .rst_n        (rst_n),
    .push         (lc_push),
    .wr_data      (lc_wr_data),
    .full         (lc_full),
    .almost_full  (lc_af),
    .pop          (lc_pop),
    .rd_data      (lc_rd_data),
    .empty        (lc_empty),
    .almost_empty (lc_ae),
    .level        (lc_level),
    .overflow     (lc_of),
    .underflow    (lc_uf)
  );

  // pm_tx_done is generated after the transmit FSM below, because it means
  // "the power-management link command has LEFT the transmitter", which cannot
  // be known until the framer has drained.  See there.

  // ------------------------------------------------------------------------
  // Transmit payload FIFO (decouples the protocol layer from the framer)
  // ------------------------------------------------------------------------
  logic        dp_push, dp_pop, dp_full, dp_empty;
  logic [32:0] dp_wr_data, dp_rd_data;
  logic        dp_af, dp_ae, dp_of, dp_uf;
  logic [$clog2(DP_FIFO_DEPTH):0] dp_level;

  assign dp_push    = tx_dp_valid && !dp_full;
  assign dp_wr_data = {tx_dp_last, tx_dp_data};
  assign tx_dp_ready = !dp_full;

  usb3_sync_fifo #(
    .WIDTH  (33),
    .DEPTH  (DP_FIFO_DEPTH),
    .AF_LVL (2),
    .AE_LVL (1)
  ) u_dp_fifo (
    .clk          (clk),
    .rst_n        (rst_n),
    .push         (dp_push),
    .wr_data      (dp_wr_data),
    .full         (dp_full),
    .almost_full  (dp_af),
    .pop          (dp_pop),
    .rd_data      (dp_rd_data),
    .empty        (dp_empty),
    .almost_empty (dp_ae),
    .level        (dp_level),
    .overflow     (dp_of),
    .underflow    (dp_uf)
  );

  // ------------------------------------------------------------------------
  // Transmit header hold register (+ copy for LRTY retransmission)
  // ------------------------------------------------------------------------
  logic        hp_hold_v_q;
  logic [95:0] hp_hold_q, hp_last_q;
  logic [2:0]  tx_seq_q;
  // The header sequence number that was transmitted WITH hp_last_q.  A header
  // sequence number is a property of the packet, not of the transmit counter's
  // current value: functional spec 16 advances the sequence "according to
  // protocol rules" and 17 requires replay to "locate packet by sequence" and
  // "reconstruct required transmission", while packet spec 11 advances the
  // sequence state only on ACK processing.  Retransmitting under a NEW number
  // is un-receivable by this design's own receiver, which raises rx_seq_err on
  // anything that is not rx_seq_exp_q.  Audit finding D15.
  logic [2:0]  hp_last_seq_q;

  assign tx_hp_ready = !hp_hold_v_q;

  // Header CRC16 (three chained dword stages over the held header).
  logic [15:0] tx_c16_0, tx_c16_1, tx_c16_2;
  usb3_crc16 #(.DATA_W(32)) u_tx_c16_0 (
    .crc_in(CRC16_INIT), .data(hp_hold_q[31:0]),  .crc_out(tx_c16_0));
  usb3_crc16 #(.DATA_W(32)) u_tx_c16_1 (
    .crc_in(tx_c16_0),   .data(hp_hold_q[63:32]), .crc_out(tx_c16_1));
  usb3_crc16 #(.DATA_W(32)) u_tx_c16_2 (
    .crc_in(tx_c16_1),   .data(hp_hold_q[95:64]), .crc_out(tx_c16_2));

  // Header link-control field CRC5.
  logic [10:0] tx_lc_word;
  logic [4:0]  tx_lc5;
  assign tx_lc_word = {8'h00, tx_seq_q};
  usb3_crc5 #(.DATA_W(11)) u_tx_lc5 (
    .crc_in(5'h1F), .data(tx_lc_word), .crc_out(tx_lc5));

  // Link-command word CRC5 (over the FIFO head).
  logic [4:0] tx_cmd5;
  usb3_crc5 #(.DATA_W(11)) u_tx_cmd5 (
    .crc_in(5'h1F), .data(lc_rd_data), .crc_out(tx_cmd5));

  logic [15:0] tx_cmd16;
  assign tx_cmd16 = {tx_cmd5, lc_rd_data};

  // Payload CRC32 accumulation.
  logic [31:0] tx_crc32_q, tx_crc32_nxt;
  usb3_crc32 #(.DATA_W(32)) u_tx_c32 (
    .crc_in(tx_crc32_q), .data(dp_rd_data[31:0]), .crc_out(tx_crc32_nxt));

  // ------------------------------------------------------------------------
  // Transmit FSM
  // ------------------------------------------------------------------------
  typedef enum logic [3:0] {
    TXS_IDLE = 4'd0,
    TXS_LC0  = 4'd1,
    TXS_LC1  = 4'd2,
    TXS_HP0  = 4'd3,
    TXS_HP1  = 4'd4,
    TXS_HP2  = 4'd5,
    TXS_HP3  = 4'd6,
    TXS_HP4  = 4'd7,
    TXS_HP5  = 4'd8,
    TXS_DP0  = 4'd9,
    TXS_DP1  = 4'd10,
    TXS_DP2  = 4'd11,
    TXS_DP3  = 4'd12
  } tx_state_e;

  tx_state_e   tx_state_q;
  logic [31:0] tx_data_q;
  logic [3:0]  tx_datak_q;
  logic        tx_is_dph_q;
  logic        tx_run;

  // The framer advances only when the LTSSM is neither streaming an ordered
  // set nor holding the transmitter in electrical idle.  Without the second
  // term the link kept framing link commands onto pins the LTSSM had already
  // declared idle: the LAU on U1 entry and, on the way out, the LUP the wake
  // handshake depends on, both of which the host would never see.  Audit
  // finding D14.  The ordered-set states and the electrically-idle states are
  // disjoint, so this never delays a training set.
  assign tx_run = !os_active && !tx_elec_idle;
  assign lc_pop = (tx_state_q == TXS_LC1) && tx_run;
  assign dp_pop = (tx_state_q == TXS_DP1) && tx_run && !dp_empty;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      tx_state_q  <= TXS_IDLE;
      tx_data_q   <= '0;
      tx_datak_q  <= '0;
      hp_hold_v_q <= 1'b0;
      hp_hold_q   <= '0;
      hp_last_q     <= '0;
      hp_last_seq_q <= 3'd0;
      tx_seq_q      <= 3'd0;
      tx_crc32_q  <= CRC32_INIT;
      tx_is_dph_q <= 1'b0;
      tx_cred_q   <= TX_CRED_W'(NUM_TX_CREDIT);
      tx_retry_q  <= 1'b0;
    end else begin
      // ---- Header accept / retry management ------------------------------
      if (lbad_rx) begin
        // Host reported a bad header: re-arm the last header for LRTY resend,
        // and REWIND the transmit sequence counter to the number that header
        // originally carried.  Without the rewind the retry goes out one
        // number ahead of what the far end is waiting for, it raises a
        // sequence error on it, and the retry can never succeed.
        hp_hold_q   <= hp_last_q;
        hp_hold_v_q <= 1'b1;
        tx_retry_q  <= 1'b1;
        tx_seq_q    <= hp_last_seq_q;
      end else if (tx_hp_valid && !hp_hold_v_q) begin
        hp_hold_q   <= tx_hp_data;
        hp_hold_v_q <= 1'b1;
      end

      if (lgood_rx) tx_retry_q <= 1'b0;

      // ---- Transmit header credits ---------------------------------------
      if (lcrd_rx && (tx_cred_q != TX_CRED_W'(NUM_TX_CREDIT)))
        tx_cred_q <= tx_cred_q + TX_CRED_W'(1'b1);
      else if ((tx_state_q == TXS_HP0) && tx_run && (tx_cred_q != '0))
        tx_cred_q <= tx_cred_q - TX_CRED_W'(1'b1);

      // Frozen by electrical idle: hold logical idle rather than the last
      // symbol the framer happened to register.  os_active freezes the FSM
      // too, but there the transmit mux overrides the pins with the ordered
      // set, so the held value is not observable and is deliberately kept.
      if (tx_elec_idle) begin
        tx_data_q  <= '0;
        tx_datak_q <= '0;
      end

      if (tx_run) begin
        // Default transmit symbol is logical idle.
        tx_data_q  <= '0;
        tx_datak_q <= '0;

        case (tx_state_q)
          TXS_IDLE: begin
            if (!lc_empty) begin
              tx_state_q <= TXS_LC0;
            end else if (link_up && hp_hold_v_q && (tx_cred_q != '0)) begin
              tx_is_dph_q <= (hp_hold_q[4:0] == HP_DPH);
              tx_state_q  <= TXS_HP0;
            end
          end

          TXS_LC0: begin
            tx_data_q  <= {4{K_SLC}};
            tx_datak_q <= 4'b1111;
            tx_state_q <= TXS_LC1;
          end
          TXS_LC1: begin
            tx_data_q  <= {tx_cmd16, tx_cmd16};
            tx_datak_q <= 4'b0000;
            tx_state_q <= TXS_IDLE;
          end

          TXS_HP0: begin
            tx_data_q  <= {4{K_SHP}};
            tx_datak_q <= 4'b1111;
            tx_state_q <= TXS_HP1;
          end
          TXS_HP1: begin
            tx_data_q  <= hp_hold_q[31:0];
            tx_state_q <= TXS_HP2;
          end
          TXS_HP2: begin
            tx_data_q  <= hp_hold_q[63:32];
            tx_state_q <= TXS_HP3;
          end
          TXS_HP3: begin
            tx_data_q  <= hp_hold_q[95:64];
            tx_state_q <= TXS_HP4;
          end
          TXS_HP4: begin
            tx_data_q  <= {tx_c16_2, tx_lc5, tx_lc_word};
            tx_state_q <= TXS_HP5;
          end
          TXS_HP5: begin
            tx_data_q   <= {4{K_END}};
            tx_datak_q  <= 4'b1111;
            tx_state_q  <= tx_is_dph_q ? TXS_DP0 : TXS_IDLE;
            // An LBAD arriving in this same cycle has already re-armed the
            // retry above.  Retiring the header now going out would cancel
            // that re-arm and drop the retry request, so the completion
            // bookkeeping - including the sequence advance and the capture of
            // the number this header carried - defers to it.
            if (!lbad_rx) begin
              hp_hold_v_q   <= 1'b0;
              hp_last_q     <= hp_hold_q;
              hp_last_seq_q <= tx_seq_q;
              tx_seq_q      <= tx_seq_q + 3'd1;
            end
          end

          TXS_DP0: begin
            tx_data_q  <= {4{K_SDP}};
            tx_datak_q <= 4'b1111;
            tx_crc32_q <= CRC32_INIT;
            tx_state_q <= TXS_DP1;
          end
          TXS_DP1: begin
            if (!dp_empty) begin
              tx_data_q  <= dp_rd_data[31:0];
              tx_crc32_q <= tx_crc32_nxt;
              if (dp_rd_data[32]) tx_state_q <= TXS_DP2;
            end
          end
          TXS_DP2: begin
            tx_data_q  <= tx_crc32_q;
            tx_state_q <= TXS_DP3;
          end
          TXS_DP3: begin
            tx_data_q  <= {4{K_END}};
            tx_datak_q <= 4'b1111;
            tx_state_q <= TXS_IDLE;
          end

          default: begin
            tx_state_q <= TXS_IDLE;
            tx_data_q  <= '0;
            tx_datak_q <= '0;
          end
        endcase
      end
    end
  end

  // ------------------------------------------------------------------------
  // Transmit mux: LTSSM ordered sets have absolute priority
  // ------------------------------------------------------------------------
  always_comb begin
    pipe_tx_data  = os_active ? os_data  : tx_data_q;
    pipe_tx_datak = os_active ? os_datak : tx_datak_q;
  end

  // ------------------------------------------------------------------------
  // Power-management handshake completion
  // ------------------------------------------------------------------------
  // pm_tx_done used to be `pm_accept` delayed one cycle - that is the cycle the
  // LAU / LXU / LUP was pushed into the link-command FIFO, NOT the cycle it was
  // transmitted.  The LTSSM takes pm_tx_done as permission to enter U1/U2/U3,
  // and entering a Ux state asserts pipe_tx_elec_idle, so the link command the
  // handshake depends on was still being framed onto the PIPE transmit bus at
  // the moment the transmitter was declared electrically idle.  On a real PHY
  // the host never sees the accept and the low-power handshake cannot complete;
  // in simulation it is a_no_data_in_elec_idle that catches it.  Audit finding
  // D14.
  //
  // The command has left the transmitter when the link-command FIFO is empty
  // AND the framer is back in TXS_IDLE.  Because pm_tx_done is registered, the
  // LTSSM sees it a cycle after that, by which time TXS_IDLE's default has
  // already driven tx_data_q back to logical idle.  A header held for want of
  // credit leaves the framer in TXS_IDLE, so this cannot deadlock.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pm_pend_q  <= 1'b0;
      pm_tx_done <= 1'b0;
    end else begin
      pm_tx_done <= 1'b0;
      if (pm_accept) begin
        pm_pend_q <= 1'b1;
      end else if (pm_pend_q && lc_empty && (tx_state_q == TXS_IDLE)) begin
        pm_pend_q  <= 1'b0;
        pm_tx_done <= 1'b1;
      end
    end
  end

  // ------------------------------------------------------------------------
  // Error reporting (registered single-cycle pulses)
  // ------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      err_crc5     <= 1'b0;
      err_crc16    <= 1'b0;
      err_crc32    <= 1'b0;
      err_protocol <= 1'b0;
      err_link     <= 1'b0;
    end else begin
      err_crc5     <= rx_hdr_c5_bad;
      err_crc16    <= rx_hdr_c16_bad;
      err_crc32    <= (rx_state_q == RXS_DP) && (rx_is_end || rx_is_edb)
                      && (rx_dp_cnt_q == 2'd2)
                      && (rx_is_edb || (rx_crc32_nxt != rx_dp_h1_q));
      err_protocol <= rx_seq_err || (rx_hdr_good && (rx_cred_q == '0));
      err_link     <= rx_seq_err || lbad_rx || lrty_rx
                      || (rx_lc_stb && !rx_lc_ok)
                      || lc_of || lc_uf || dp_of || dp_uf
                      || (rx_hdr_good && (rx_cred_q == '0));
    end
  end

  // ------------------------------------------------------------------------
  // Flags that carry no functional meaning in this configuration are folded
  // into a single lint-visible term (fill levels / almost flags of the small
  // staging FIFOs).
  // ------------------------------------------------------------------------
  //
  //   rx_lc_param  is the 7-bit parameter of a RECEIVED link command: the
  //                header sequence number in LGOOD_n and the credit index in
  //                LCRD_x.  This implementation acts on the command CLASS
  //                only and never checks the parameter, so an out-of-order
  //                LGOOD_n or LCRD_x is accepted silently.  That is audit
  //                finding P1 (partial), not an accident of coding, and it is
  //                named here so the gap is visible from the RTL.
  // ------------------------------------------------------------------------
  logic fifo_flags_unused;
  assign fifo_flags_unused = lc_af | lc_ae | dp_af | dp_ae
                             | (|lc_level) | (|dp_level) | tx_retry_q
                             | (|rx_lc_param);

endmodule

`default_nettype wire
