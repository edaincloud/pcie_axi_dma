// ============================================================================
// usb3_dma.sv
// Single-channel scatter-gather DMA engine with an AXI4 master port for the
// USB 3.0 SuperSpeed device controller. Runs entirely in the aclk domain.
//
// Descriptor (16 bytes, must be 16-byte aligned, layout from usb3_pkg)
//   W0 : buffer address [31:0]
//   W1 : buffer address [63:32]  (ignored when AXI_ADDR_WIDTH == 32)
//   W2 : {ctrl[31:24], ep[23:20], length[19:0]}
//   W3 : next descriptor address [31:0], 0 => end of list
//   ctrl bits : DCTRL_OWN (7), DCTRL_DIR (2), DCTRL_LAST (1), DCTRL_IOC (0)
//
// Operation
//   Software programs REG_DESC_BASE_L with the head of the list and sets
//   REG_DMA_CTRL[0]. The engine walks the list, and for every descriptor it
//   owns (OWN == 1) it moves `length` bytes between system memory and the
//   endpoint FIFO selected by the descriptor ep field:
//     DIR == 1 (IN)  : AXI read  -> endpoint IN  FIFO (memory to USB)
//     DIR == 0 (OUT) : endpoint OUT FIFO -> AXI write (USB to memory)
//   Each descriptor is closed by a write-back of W2 with OWN cleared and the
//   actually transferred byte count in the length field.
//
// Documented implementation choices / restrictions
//   * SINGLE OUTSTANDING transaction per direction. Address and data phases of
//     a burst are not overlapped with the next burst; this keeps the design
//     small and is sufficient for the required >90% DMA efficiency at 64-bit
//     x aclk. No re-ordering support is needed, so rid/bid are not used
//     (single ID, AXI_ID constant 0).
//   * INCR bursts only. All bursts are issued with the beat-aligned base
//     address (awaddr/araddr aligned to AXI_DATA_WIDTH/8) and byte-lane
//     granularity is expressed with wstrb, so unaligned start and end bytes
//     are fully supported without relying on AXI unaligned-start behaviour.
//   * Buffer addresses must be 32-bit word aligned (addr[1:0] == 0) because
//     the endpoint FIFOs are 32 bits wide. Byte-granular *lengths* are
//     supported: the final (partial) word is written with a 1..3 byte wstrb.
//   * Bursts never cross a 4 KB boundary and awlen/arlen <= 15 (16 beats).
//   * awprot/arprot = 3'b011 : privileged, NON-secure, data access. The engine
//     is a device DMA that operates on non-secure driver buffers; when secure
//     operation is required the address filter (cfg_sec_en) confines it to the
//     window [cfg_sec_base, cfg_sec_limit].
//   * awcache/arcache = 4'b0011 : normal, non-cacheable, bufferable.
//   * A slave error (SLVERR/DECERR) on any channel pulses err_axi, drains the
//     outstanding burst and returns the FSM to IDLE with the channel disarmed.
//   * A security-filter violation pulses err_sec, blocks the access (no AXI
//     command is issued) and aborts the descriptor.
//   * The engine is armed by a rising edge of cfg_dma_en (REG_DMA_CTRL[0]) and
//     disarms itself when the list ends, when a non-owned descriptor is found
//     or on any error, so software re-triggers by clearing and setting the bit.
//   * The descriptor ep field is 4 bits wide; only the low $clog2(NUM_EP) bits
//     select the endpoint FIFO, the remaining bits are reserved.
//   * dma_out_rd_last is honoured: if the endpoint reports the end of an OUT
//     packet before `length` bytes were consumed, the remaining beats of the
//     current burst are completed with all-zero wstrb (legal AXI, no memory
//     side effect) and the descriptor is closed with the short byte count.
// ============================================================================
`default_nettype none

module usb3_dma
  import usb3_pkg::*;
#(
  parameter int unsigned AXI_ADDR_WIDTH = AXI_ADDR_W,
  parameter int unsigned AXI_DATA_WIDTH = AXI_DATA_W,
  parameter int unsigned AXI_ID_WIDTH   = AXI_ID_W
) (
  input  wire                          clk,
  input  wire                          rst_n,

  // ---- Configuration -----------------------------------------------------
  input  wire                          cfg_dma_en,
  input  wire  [31:0]                  cfg_desc_base,
  input  wire                          cfg_sec_en,
  input  wire  [31:0]                  cfg_sec_base,
  input  wire  [31:0]                  cfg_sec_limit,

  // ---- AXI4 master : write address ---------------------------------------
  output logic [AXI_ID_WIDTH-1:0]      awid,
  output logic [AXI_ADDR_WIDTH-1:0]    awaddr,
  output logic [7:0]                   awlen,
  output logic [2:0]                   awsize,
  output logic [1:0]                   awburst,
  output logic [2:0]                   awprot,
  output logic [3:0]                   awcache,
  output logic                         awvalid,
  input  wire                          awready,
  // ---- AXI4 master : write data ------------------------------------------
  output logic [AXI_DATA_WIDTH-1:0]    wdata,
  output logic [AXI_DATA_WIDTH/8-1:0]  wstrb,
  output logic                         wlast,
  output logic                         wvalid,
  input  wire                          wready,
  // ---- AXI4 master : write response --------------------------------------
  input  wire  [AXI_ID_WIDTH-1:0]      bid,
  input  wire  [1:0]                   bresp,
  input  wire                          bvalid,
  output logic                         bready,
  // ---- AXI4 master : read address ----------------------------------------
  output logic [AXI_ID_WIDTH-1:0]      arid,
  output logic [AXI_ADDR_WIDTH-1:0]    araddr,
  output logic [7:0]                   arlen,
  output logic [2:0]                   arsize,
  output logic [1:0]                   arburst,
  output logic [2:0]                   arprot,
  output logic [3:0]                   arcache,
  output logic                         arvalid,
  input  wire                          arready,
  // ---- AXI4 master : read data -------------------------------------------
  input  wire  [AXI_ID_WIDTH-1:0]      rid,
  input  wire  [AXI_DATA_WIDTH-1:0]    rdata,
  input  wire  [1:0]                   rresp,
  input  wire                          rlast,
  input  wire                          rvalid,
  output logic                         rready,

  // ---- Endpoint FIFO interface (aclk side of usb3_ep_array) --------------
  output logic [EP_ADDR_W-1:0]         dma_ep_sel,
  output logic                         dma_in_wr_en,
  output logic [31:0]                  dma_in_wr_data,
  output logic                         dma_in_wr_last,
  input  wire  [NUM_EP-1:0]            dma_in_full,
  output logic                         dma_out_rd_en,
  input  wire  [31:0]                  dma_out_rd_data,
  input  wire                          dma_out_rd_last,
  input  wire  [NUM_EP-1:0]            dma_out_empty,

  // ---- Status ------------------------------------------------------------
  output logic                         dma_busy,
  output logic [19:0]                  dma_bytes_left,
  output logic [31:0]                  desc_cur,
  output logic                         dma_done,   // 1-cycle pulse
  output logic                         err_axi,    // 1-cycle pulse
  output logic                         err_sec     // 1-cycle pulse
);

  // ------------------------------------------------------------------------
  // Elaboration guards.  usb3_device_controller carries its own copies with
  // its own messages, so a rejection can always be attributed to the level
  // that owns the parameter; these fire when usb3_dma is elaborated alone.
  // ------------------------------------------------------------------------
  if (AXI_ADDR_WIDTH < 32) begin : g_chk_dma_aw_min
    $error("usb3_dma: AXI_ADDR_WIDTH must be >= 32 (got %0d): ext32() assigns r[31:0]",
           AXI_ADDR_WIDTH);
  end
  if (AXI_ADDR_WIDTH > 64) begin : g_chk_dma_aw_max
    $error("usb3_dma: AXI_ADDR_WIDTH must be <= 64 (got %0d)", AXI_ADDR_WIDTH);
  end
  if (AXI_DATA_WIDTH < 32) begin : g_chk_dma_dw_min
    $error("usb3_dma: AXI_DATA_WIDTH must be >= 32 (got %0d): a beat must hold at least one endpoint word",
           AXI_DATA_WIDTH);
  end
  if (AXI_DATA_WIDTH > 256) begin : g_chk_dma_dw_max
    $error("usb3_dma: AXI_DATA_WIDTH must be <= 256 (got %0d): burst_bytes_c is 13 bits",
           AXI_DATA_WIDTH);
  end
  if ((AXI_DATA_WIDTH & (AXI_DATA_WIDTH - 1)) != 0) begin : g_chk_dma_dw_pow2
    $error("usb3_dma: AXI_DATA_WIDTH must be a power of two (got %0d)",
           AXI_DATA_WIDTH);
  end
  if (AXI_ID_WIDTH < 1) begin : g_chk_dma_id_min
    $error("usb3_dma: AXI_ID_WIDTH must be >= 1 (got %0d)", AXI_ID_WIDTH);
  end
  if (AXI_ID_WIDTH > 16) begin : g_chk_dma_id_max
    $error("usb3_dma: AXI_ID_WIDTH must be <= 16 (got %0d)", AXI_ID_WIDTH);
  end

  // ------------------------------------------------------------------------
  // Derived geometry
  // ------------------------------------------------------------------------
  localparam int unsigned BPB        = AXI_DATA_WIDTH / 8;        // bytes/beat
  localparam int unsigned WPB        = AXI_DATA_WIDTH / 32;       // words/beat
  localparam int unsigned SIZE_LOG   = unsigned'($clog2(BPB));               // awsize
  localparam int unsigned LANE_W     = (WPB > 1) ? unsigned'($clog2(WPB)) : 32'd1;
  localparam int unsigned DESC_BEATS = (DESC_BYTES + BPB - 1) / BPB;
  localparam int unsigned AW         = AXI_ADDR_WIDTH;
  localparam int unsigned MAX_BEATS  = 16;                        // arlen <= 15

  localparam logic [31:0] BPB_MASK32 = BPB - 1;
  localparam logic [31:0] WPB_MASK32 = WPB - 1;
  localparam logic [LANE_W-1:0] LANE_ONE = LANE_W'(1);
  localparam logic [LANE_W-1:0] LANE_MAX = LANE_W'(WPB - 1);

  localparam logic [2:0]  AXI_PROT   = 3'b011; // privileged, non-secure, data
  localparam logic [3:0]  AXI_CACHE  = 4'b0011; // non-cacheable bufferable

  // ------------------------------------------------------------------------
  // FSM
  // ------------------------------------------------------------------------
  typedef enum logic [3:0] {
    S_IDLE       = 4'd0,
    S_DESC_AR    = 4'd1,
    S_DESC_R     = 4'd2,
    S_CHECK_OWN  = 4'd3,
    S_BURST      = 4'd4,
    S_RD_AR      = 4'd5,
    S_RD_R       = 4'd6,
    S_RD_PUSH    = 4'd7,
    S_WR_AW      = 4'd8,
    S_WR_PACK    = 4'd9,
    S_WR_W       = 4'd10,
    S_WR_B       = 4'd11,
    S_WB_AW      = 4'd12,
    S_WB_W       = 4'd13,
    S_WB_B       = 4'd14,
    S_DRAIN      = 4'd15
  } dma_state_e;

  dma_state_e state_q;

  // ------------------------------------------------------------------------
  // Registered AXI outputs
  // ------------------------------------------------------------------------
  logic [AW-1:0]             awaddr_q, araddr_q;
  logic [7:0]                awlen_q,  arlen_q;
  logic                      awvalid_q, arvalid_q;
  logic [AXI_DATA_WIDTH-1:0] wdata_q;
  logic [BPB-1:0]            wstrb_q;
  logic                      wlast_q, wvalid_q;
  logic                      bready_q, rready_q;

  // ------------------------------------------------------------------------
  // Engine state
  // ------------------------------------------------------------------------
  logic [31:0]        desc_ptr_q;      // current descriptor address
  logic [31:0]        desc_word_q [4]; // fetched descriptor
  logic [2:0]         desc_widx_q;     // descriptor word fill index
  logic [AW-1:0]      cur_addr_q;      // current buffer address
  logic [19:0]        bytes_left_q;
  logic [19:0]        desc_len_q;
  logic [EP_ADDR_W-1:0] ep_q;
  logic               dir_in_q;        // 1 = memory -> USB
  logic               ioc_q, last_q;
  logic [4:0]         beats_rem_q;     // beats left in the current burst
  logic [LANE_W-1:0]  lane_q;          // word lane inside the current beat
  logic [AXI_DATA_WIDTH-1:0] beat_q;   // read/write beat buffer
  logic [BPB-1:0]     beat_strb_q;
  logic               armed_q;         // channel armed by cfg_dma_en
  logic               dma_en_d1_q;
  logic               out_last_q;      // OUT packet terminated early
  logic               done_pulse_q, err_axi_q, err_sec_q;
  logic               abort_q;         // drain-then-abort

  // Response qualification: the engine uses a single constant ID, so any
  // response carrying a different ID (or a non-OKAY code) is an error.
  logic rd_bad_c, wr_bad_c;

  // Endpoint FIFO handshake (combinational, one word per cycle)
  logic               in_wr_en_c, out_rd_en_c;
  logic [31:0]        in_wr_data_c;
  logic               in_wr_last_c;

  // ------------------------------------------------------------------------
  // Helper functions
  // ------------------------------------------------------------------------
  // Zero-extend a 32-bit software address to the AXI address width.
  function automatic logic [AW-1:0] ext32(input logic [31:0] a);
    logic [AW-1:0] r;
    r        = '0;
    r[31:0]  = a;
    return r;
  endfunction

  // Beat-aligned base address of `a`.
  function automatic logic [AW-1:0] beat_base(input logic [AW-1:0] a);
    return a & ~ext32(BPB_MASK32);
  endfunction

  // Word lane of `a` inside its beat.
  function automatic logic [LANE_W-1:0] lane_of(input logic [AW-1:0] a);
    return LANE_W'((a >> 2) & ext32(WPB_MASK32));
  endfunction

  // Security filter: base <= addr && addr+len <= limit (33-bit arithmetic on
  // the low 32 bits; addresses above 4 GiB are always rejected when filtering
  // is enabled because the filter registers are 32-bit).
  function automatic logic sec_ok(input logic [AW-1:0]   a,
                                  input logic [12:0]     len,
                                  input logic            en,
                                  input logic [31:0]     lo,
                                  input logic [31:0]     hi);
    logic [32:0] a32, end32;
    if (!en) return 1'b1;
    if ((a >> 32) != '0) return 1'b0;
    a32   = {1'b0, a[31:0]};
    end32 = a32 + 33'(len);
    return (a32 >= {1'b0, lo}) && (end32 <= {1'b0, hi});
  endfunction

  // ------------------------------------------------------------------------
  // Burst sizing (combinational, used in S_BURST)
  // ------------------------------------------------------------------------
  logic [AW-1:0]     burst_base_c;
  logic [LANE_W-1:0] burst_lane_c;
  logic [20:0]       words_left_c;
  logic [21:0]       words_first_c, words_rest_c;
  logic [21:0]       beats_need_c;
  logic [21:0]       page_beats_c;
  logic [4:0]        burst_beats_c;
  logic [12:0]       burst_bytes_c;

  always_comb begin
    burst_base_c  = beat_base(cur_addr_q);
    burst_lane_c  = lane_of(cur_addr_q);
    words_left_c  = (21'(bytes_left_q) + 21'd3) >> 2;
    words_first_c = 22'(WPB) - 22'(burst_lane_c);
    if (22'(words_left_c) <= words_first_c) begin
      beats_need_c = 22'd1;
      words_rest_c = 22'd0;
    end else begin
      words_rest_c = 22'(words_left_c) - words_first_c;
      beats_need_c = 22'd1 + ((words_rest_c + 22'(WPB) - 22'd1) / 22'(WPB));
    end
    // Beats available before the next 4 KB boundary.
    page_beats_c = (22'd4096 - 22'(burst_base_c[11:0])) >> SIZE_LOG;

    burst_beats_c = 5'(MAX_BEATS);
    if (beats_need_c < 22'(burst_beats_c)) burst_beats_c = 5'(beats_need_c);
    if (page_beats_c < 22'(burst_beats_c)) burst_beats_c = 5'(page_beats_c);
    burst_bytes_c = 13'(burst_beats_c) << SIZE_LOG;
  end

  assign rd_bad_c = (rresp != 2'b00) || (rid != '0);
  assign wr_bad_c = (bresp != 2'b00) || (bid != '0);

  // Byte count contributed by the word currently being moved.
  logic [2:0] word_bytes_c;
  always_comb begin
    word_bytes_c = (bytes_left_q >= 20'd4) ? 3'd4 : 3'(bytes_left_q[1:0]);
  end

  // Byte strobes for a partial word inside a beat lane.
  function automatic logic [3:0] word_strb(input logic [2:0] nbytes);
    case (nbytes)
      3'd0:    return 4'b0000;
      3'd1:    return 4'b0001;
      3'd2:    return 4'b0011;
      3'd3:    return 4'b0111;
      default: return 4'b1111;
    endcase
  endfunction

  // Packed write beat including the word currently popped from the OUT FIFO.
  logic [AXI_DATA_WIDTH-1:0] pack_data_c;
  logic [BPB-1:0]            pack_strb_c;
  always_comb begin
    pack_data_c                       = beat_q;
    pack_data_c[32*int'(lane_q) +: 32] = dma_out_rd_data;
    pack_strb_c                       = beat_strb_q;
    pack_strb_c[4*int'(lane_q) +: 4]  = word_strb(word_bytes_c);
  end

  // Write-back value of descriptor word 2: OWN cleared, transferred length.
  logic [31:0] wb_word_c;
  always_comb begin
    wb_word_c = desc_word_q[2];
    wb_word_c[DESC_CTRL_LSB + DCTRL_OWN] = 1'b0;
    wb_word_c[DESC_LEN_W-1:0]            = desc_len_q - bytes_left_q;
  end

  // ------------------------------------------------------------------------
  // Main sequential FSM (all AXI outputs registered)
  // ------------------------------------------------------------------------
  logic [AW-1:0] wb_addr_c;
  logic [LANE_W-1:0] wb_lane_c;
  assign wb_addr_c = beat_base(ext32(desc_ptr_q + 32'd8));
  assign wb_lane_c = lane_of(ext32(desc_ptr_q + 32'd8));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state_q      <= S_IDLE;
      awaddr_q     <= '0;
      awlen_q      <= '0;
      awvalid_q    <= 1'b0;
      araddr_q     <= '0;
      arlen_q      <= '0;
      arvalid_q    <= 1'b0;
      wdata_q      <= '0;
      wstrb_q      <= '0;
      wlast_q      <= 1'b0;
      wvalid_q     <= 1'b0;
      bready_q     <= 1'b0;
      rready_q     <= 1'b0;
      desc_ptr_q   <= '0;
      desc_widx_q  <= '0;
      cur_addr_q   <= '0;
      bytes_left_q <= '0;
      desc_len_q   <= '0;
      ep_q         <= '0;
      dir_in_q     <= 1'b0;
      ioc_q        <= 1'b0;
      last_q       <= 1'b0;
      beats_rem_q  <= '0;
      lane_q       <= '0;
      beat_q       <= '0;
      beat_strb_q  <= '0;
      armed_q      <= 1'b0;
      dma_en_d1_q  <= 1'b0;
      out_last_q   <= 1'b0;
      done_pulse_q <= 1'b0;
      err_axi_q    <= 1'b0;
      err_sec_q    <= 1'b0;
      abort_q      <= 1'b0;
      for (int unsigned i = 0; i < 4; i++) desc_word_q[i] <= '0;
    end else begin
      // Default: pulses are single cycle.
      done_pulse_q <= 1'b0;
      err_axi_q    <= 1'b0;
      err_sec_q    <= 1'b0;

      // Arm on a rising edge of cfg_dma_en.
      dma_en_d1_q <= cfg_dma_en;
      if (cfg_dma_en && !dma_en_d1_q) armed_q <= 1'b1;
      if (!cfg_dma_en)                armed_q <= 1'b0;

      case (state_q)
        // ------------------------------------------------------------------
        S_IDLE: begin
          if (armed_q && cfg_dma_en && (cfg_desc_base != 32'h0)) begin
            desc_ptr_q  <= cfg_desc_base;
            desc_widx_q <= '0;
            state_q     <= S_DESC_AR;
          end
        end

        // ---- descriptor fetch --------------------------------------------
        S_DESC_AR: begin
          if (!sec_ok(ext32(desc_ptr_q), 13'(DESC_BYTES), cfg_sec_en,
                      cfg_sec_base, cfg_sec_limit)) begin
            err_sec_q <= 1'b1;
            armed_q   <= 1'b0;
            state_q   <= S_IDLE;
          end else if (!arvalid_q) begin
            araddr_q  <= beat_base(ext32(desc_ptr_q));
            arlen_q   <= 8'(DESC_BEATS - 1);
            arvalid_q <= 1'b1;
          end else if (arready) begin
            arvalid_q   <= 1'b0;
            rready_q    <= 1'b1;
            desc_widx_q <= '0;
            state_q     <= S_DESC_R;
          end
        end

        S_DESC_R: begin
          if (rvalid && rready_q) begin
            for (int unsigned k = 0; k < WPB; k++) begin
              // The 3-bit sum is range-checked before it is used, so the
              // 2-bit array index is an explicit cast rather than an implicit
              // truncation.
              if ((desc_widx_q + 3'(k)) < 3'd4)
                desc_word_q[2'(desc_widx_q + 3'(k))] <= rdata[k*32 +: 32];
            end
            desc_widx_q <= desc_widx_q + 3'(WPB);
            // err_axi is ONE cycle per failed transaction, not one per
            // erroring beat: a descriptor fetch is a burst, and a slave that
            // returns SLVERR on consecutive beats used to re-pulse it on
            // consecutive cycles, contradicting the port's documented
            // single-cycle contract.  abort_q, set with the first report,
            // is the "already reported" flag.  Audit finding D17.
            if (rd_bad_c) begin
              if (!abort_q) err_axi_q <= 1'b1;
              abort_q <= 1'b1;
            end
            if (rlast) begin
              rready_q <= 1'b0;
              if ((rd_bad_c) || abort_q) begin
                abort_q <= 1'b0;
                armed_q <= 1'b0;
                state_q <= S_IDLE;
              end else begin
                state_q <= S_CHECK_OWN;
              end
            end
          end
        end

        S_CHECK_OWN: begin
          if (!desc_word_q[2][DESC_CTRL_LSB + DCTRL_OWN]) begin
            // Descriptor not owned by hardware: stop and wait for software.
            armed_q <= 1'b0;
            state_q <= S_IDLE;
          end else begin
            cur_addr_q   <= ext32(desc_word_q[0]);
            bytes_left_q <= desc_word_q[2][DESC_LEN_W-1:0];
            desc_len_q   <= desc_word_q[2][DESC_LEN_W-1:0];
            ep_q         <= desc_word_q[2][DESC_EP_LSB +: EP_ADDR_W];
            dir_in_q     <= desc_word_q[2][DESC_CTRL_LSB + DCTRL_DIR];
            ioc_q        <= desc_word_q[2][DESC_CTRL_LSB + DCTRL_IOC];
            last_q       <= desc_word_q[2][DESC_CTRL_LSB + DCTRL_LAST];
            out_last_q   <= 1'b0;
            if (desc_word_q[2][DESC_LEN_W-1:0] == '0) state_q <= S_WB_AW;
            else                                      state_q <= S_BURST;
          end
        end

        // ---- burst set-up -------------------------------------------------
        S_BURST: begin
          if (!sec_ok(burst_base_c, burst_bytes_c, cfg_sec_en,
                      cfg_sec_base, cfg_sec_limit)) begin
            err_sec_q <= 1'b1;
            state_q   <= S_WB_AW; // close descriptor with the short count
          end else begin
            beats_rem_q <= burst_beats_c;
            lane_q      <= burst_lane_c;
            if (dir_in_q) begin
              araddr_q  <= burst_base_c;
              arlen_q   <= 8'(burst_beats_c - 5'd1);
              arvalid_q <= 1'b1;
              state_q   <= S_RD_AR;
            end else begin
              awaddr_q  <= burst_base_c;
              awlen_q   <= 8'(burst_beats_c - 5'd1);
              awvalid_q <= 1'b1;
              state_q   <= S_WR_AW;
            end
          end
        end

        // ---- IN direction: AXI read -> endpoint IN FIFO -------------------
        S_RD_AR: begin
          if (arready) begin
            arvalid_q <= 1'b0;
            rready_q  <= 1'b1;
            state_q   <= S_RD_R;
          end
        end

        S_RD_R: begin
          if (rvalid && rready_q) begin
            rready_q <= 1'b0;               // one beat at a time
            beat_q   <= rdata;
            if (rd_bad_c) begin
              if (!abort_q) err_axi_q <= 1'b1;   // see S_DESC_R: one per burst
              if (rlast) begin
                armed_q <= 1'b0;
                state_q <= S_IDLE;
              end else begin
                abort_q  <= 1'b1;
                rready_q <= 1'b1;
                state_q  <= S_DRAIN;
              end
            end else begin
              state_q <= S_RD_PUSH;
            end
          end
        end

        S_RD_PUSH: begin
          if (!dma_in_full[ep_q]) begin
            bytes_left_q <= bytes_left_q - 20'(word_bytes_c);
            cur_addr_q   <= cur_addr_q + ext32(32'(word_bytes_c));
            if (bytes_left_q <= 20'(word_bytes_c)) begin
              // Last word of the descriptor.
              state_q <= S_WB_AW;
            end else if (lane_q == LANE_MAX) begin
              // Beat consumed: fetch the next beat of the burst.
              lane_q <= '0;
              if (beats_rem_q > 5'd1) begin
                beats_rem_q <= beats_rem_q - 5'd1;
                rready_q    <= 1'b1;
                state_q     <= S_RD_R;
              end else begin
                state_q <= S_BURST;
              end
            end else begin
              lane_q <= lane_q + LANE_ONE;
            end
          end
        end

        // ---- OUT direction: endpoint OUT FIFO -> AXI write ----------------
        S_WR_AW: begin
          if (awready) begin
            awvalid_q   <= 1'b0;
            beat_q      <= '0;
            beat_strb_q <= '0;
            state_q     <= S_WR_PACK;
          end
        end

        S_WR_PACK: begin
          if ((bytes_left_q == '0) || out_last_q) begin
            // Pad the remaining promised beats with null strobes.
            wdata_q  <= beat_q;
            wstrb_q  <= beat_strb_q;
            wlast_q  <= (beats_rem_q == 5'd1);
            wvalid_q <= 1'b1;
            state_q  <= S_WR_W;
          end else if (!dma_out_empty[ep_q]) begin
            beat_q       <= pack_data_c;
            beat_strb_q  <= pack_strb_c;
            bytes_left_q <= bytes_left_q - 20'(word_bytes_c);
            cur_addr_q   <= cur_addr_q + ext32(32'(word_bytes_c));
            if (dma_out_rd_last) out_last_q <= 1'b1;
            if ((bytes_left_q <= 20'(word_bytes_c)) || dma_out_rd_last ||
                (lane_q == LANE_MAX)) begin
              // Beat complete (or data exhausted): launch it.
              wdata_q  <= pack_data_c;
              wstrb_q  <= pack_strb_c;
              wlast_q  <= (beats_rem_q == 5'd1);
              wvalid_q <= 1'b1;
              state_q  <= S_WR_W;
            end else begin
              lane_q <= lane_q + LANE_ONE;
            end
          end
        end

        S_WR_W: begin
          if (wready) begin
            wvalid_q <= 1'b0;
            wlast_q  <= 1'b0;
            if (beats_rem_q > 5'd1) begin
              beats_rem_q <= beats_rem_q - 5'd1;
              lane_q      <= '0;
              beat_q      <= '0;
              beat_strb_q <= '0;
              state_q     <= S_WR_PACK;
            end else begin
              bready_q <= 1'b1;
              state_q  <= S_WR_B;
            end
          end
        end

        S_WR_B: begin
          if (bvalid && bready_q) begin
            bready_q <= 1'b0;
            if (wr_bad_c) begin
              err_axi_q <= 1'b1;
              armed_q   <= 1'b0;
              state_q   <= S_IDLE;
            end else if ((bytes_left_q == '0) || out_last_q) begin
              state_q <= S_WB_AW;
            end else begin
              lane_q  <= '0;
              state_q <= S_BURST;
            end
          end
        end

        // ---- descriptor write-back (W2: OWN cleared + byte count) ---------
        S_WB_AW: begin
          if (!sec_ok(wb_addr_c, 13'(BPB), cfg_sec_en,
                      cfg_sec_base, cfg_sec_limit)) begin
            err_sec_q <= 1'b1;
            armed_q   <= 1'b0;
            state_q   <= S_IDLE;
          end else if (!awvalid_q) begin
            awaddr_q  <= wb_addr_c;
            awlen_q   <= 8'd0;
            awvalid_q <= 1'b1;
          end else if (awready) begin
            awvalid_q                     <= 1'b0;
            wdata_q                       <= '0;
            wdata_q[32*int'(wb_lane_c) +: 32]   <= wb_word_c;
            wstrb_q                       <= '0;
            wstrb_q[4*int'(wb_lane_c) +: 4]     <= 4'b1111;
            wlast_q                       <= 1'b1;
            wvalid_q                      <= 1'b1;
            state_q                       <= S_WB_W;
          end
        end

        S_WB_W: begin
          if (wready) begin
            wvalid_q <= 1'b0;
            wlast_q  <= 1'b0;
            bready_q <= 1'b1;
            state_q  <= S_WB_B;
          end
        end

        S_WB_B: begin
          if (bvalid && bready_q) begin
            bready_q <= 1'b0;
            if (wr_bad_c) begin
              err_axi_q <= 1'b1;
              armed_q   <= 1'b0;
              state_q   <= S_IDLE;
            end else begin
              if (ioc_q) done_pulse_q <= 1'b1;
              if (last_q || (desc_word_q[3] == 32'h0)) begin
                done_pulse_q <= 1'b1;
                armed_q      <= 1'b0;
                state_q      <= S_IDLE;
              end else begin
                desc_ptr_q  <= desc_word_q[3];
                desc_widx_q <= '0;
                state_q     <= S_DESC_AR;
              end
            end
          end
        end

        // ---- error drain --------------------------------------------------
        S_DRAIN: begin
          if (rvalid && rready_q && rlast) begin
            rready_q <= 1'b0;
            abort_q  <= 1'b0;
            armed_q  <= 1'b0;
            state_q  <= S_IDLE;
          end
        end

        default: begin
          // Unreachable: recover safely.
          state_q   <= S_IDLE;
          arvalid_q <= 1'b0;
          awvalid_q <= 1'b0;
          wvalid_q  <= 1'b0;
          rready_q  <= 1'b0;
          bready_q  <= 1'b0;
          armed_q   <= 1'b0;
        end
      endcase
    end
  end

  // ------------------------------------------------------------------------
  // Endpoint FIFO handshakes
  // ------------------------------------------------------------------------
  always_comb begin
    in_wr_en_c   = (state_q == S_RD_PUSH) && !dma_in_full[ep_q];
    in_wr_data_c = beat_q[32*int'(lane_q) +: 32];
    in_wr_last_c = in_wr_en_c && (bytes_left_q <= 20'(word_bytes_c));
    out_rd_en_c  = (state_q == S_WR_PACK) && !dma_out_empty[ep_q] &&
                   (bytes_left_q != '0) && !out_last_q;
  end

  assign dma_ep_sel     = ep_q;
  assign dma_in_wr_en   = in_wr_en_c;
  assign dma_in_wr_data = in_wr_data_c;
  assign dma_in_wr_last = in_wr_last_c;
  assign dma_out_rd_en  = out_rd_en_c;

  // ------------------------------------------------------------------------
  // AXI output mapping (constant / registered)
  // ------------------------------------------------------------------------
  assign awid     = '0;
  assign arid     = '0;
  assign awaddr   = awaddr_q;
  assign araddr   = araddr_q;
  assign awlen    = awlen_q;
  assign arlen    = arlen_q;
  assign awsize   = 3'(SIZE_LOG);
  assign arsize   = 3'(SIZE_LOG);
  assign awburst  = 2'b01;  // INCR
  assign arburst  = 2'b01;  // INCR
  assign awprot   = AXI_PROT;
  assign arprot   = AXI_PROT;
  assign awcache  = AXI_CACHE;
  assign arcache  = AXI_CACHE;
  assign awvalid  = awvalid_q;
  assign arvalid  = arvalid_q;
  assign wdata    = wdata_q;
  assign wstrb    = wstrb_q;
  assign wlast    = wlast_q;
  assign wvalid   = wvalid_q;
  assign bready   = bready_q;
  assign rready   = rready_q;

  // ------------------------------------------------------------------------
  // Status outputs
  // ------------------------------------------------------------------------
  assign dma_busy       = (state_q != S_IDLE);
  assign dma_bytes_left = bytes_left_q;
  assign desc_cur       = desc_ptr_q;
  assign dma_done       = done_pulse_q;
  assign err_axi        = err_axi_q;
  assign err_sec        = err_sec_q;


endmodule

`default_nettype wire
