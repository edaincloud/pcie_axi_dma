// ============================================================================
// usb3_pkg.sv
// Shared parameters, enumerations and register-map offsets for the USB 3.0
// SuperSpeed device controller IP.
//
// Conventions
//   - All resets are active-low, asynchronously asserted, synchronously
//     deasserted through usb3_reset_sync.
//   - PIPE domain  : pclk  (125 MHz, 32-bit PIPE interface)
//   - System domain: aclk  (AXI4 master + APB CSR)
//
// ---------------------------------------------------------------------------
// HOW THIS IP IS PARAMETERISED - READ BEFORE ADDING A KNOB
// ---------------------------------------------------------------------------
// The endpoint count, the APB address width and the endpoint FIFO geometry
// appear in the PORT LISTS of nearly every module (`input wire [NUM_EP-1:0]
// cfg_ep_en`, `input wire [APB_ADDR_W-1:0] paddr`, ...).  A port width must be
// known before the module that would own the parameter is elaborated, so those
// constants CANNOT be module parameters of usb3_device_controller.  They live
// here as package constants whose defaults are overridable with
//     +define+USB3_<NAME>=<value>
// and that is what run/Makefile's TOP_CFGS sweep drives.  `-G` is NOT usable
// for them; it IS used for the genuinely module-local parameters (the AXI
// widths, the LTSSM timers, the FIFO DEPTH of a leaf instance).
//
// EVERY constraint on either kind is enforced by an elaboration guard in
// rtl/usb3_param_check.sv (geometry) or in the owning module (module-local),
// and run/scripts/elab_check.sh drives each guard from both directions.
// ============================================================================
`default_nettype none

// ---------------------------------------------------------------------------
// Overridable build-time geometry.  Defaults are the shipped configuration.
// ---------------------------------------------------------------------------
`ifndef USB3_NUM_EP
  `define USB3_NUM_EP 8
`endif
`ifndef USB3_MAX_PKT_SS
  `define USB3_MAX_PKT_SS 1024
`endif
`ifndef USB3_EP_FIFO_DEP
  `define USB3_EP_FIFO_DEP 512
`endif
`ifndef USB3_APB_ADDR_W
  `define USB3_APB_ADDR_W 12
`endif
`ifndef USB3_NUM_RX_CREDIT
  `define USB3_NUM_RX_CREDIT 4
`endif
`ifndef USB3_AXI_DATA_W
  `define USB3_AXI_DATA_W 64
`endif
`ifndef USB3_AXI_ADDR_W
  `define USB3_AXI_ADDR_W 32
`endif
`ifndef USB3_AXI_ID_W
  `define USB3_AXI_ID_W 4
`endif

// ---------------------------------------------------------------------------
// The 8b/10b special-symbol table.  THESE ARE NOT KNOBS.
//
// They are overridable for exactly one reason: an elaboration guard that cannot
// be driven from outside the source cannot be TESTED, and an untested guard is
// indistinguishable from a guard that never fires (.skills/tapeout_grade_rtl/
// rtl.md, "Elaboration Guards").  run/scripts/elab_check.sh overrides each one
// in turn and requires usb3_param_check to reject it by that symbol's OWN
// message.
//
// Every value other than the one below is rejected at elaboration.  There is no
// legal alternative table.
// ---------------------------------------------------------------------------
`ifndef USB3_K_SKP
  `define USB3_K_SKP 8'h3C
`endif
`ifndef USB3_K_SDP
  `define USB3_K_SDP 8'h5C
`endif
`ifndef USB3_K_EDB
  `define USB3_K_EDB 8'h7C
`endif
`ifndef USB3_K_COM
  `define USB3_K_COM 8'hBC
`endif
`ifndef USB3_K_END
  `define USB3_K_END 8'hFD
`endif
`ifndef USB3_K_SLC
  `define USB3_K_SLC 8'hFE
`endif
`ifndef USB3_K_SHP
  `define USB3_K_SHP 8'hFB
`endif

package usb3_pkg;

  // ------------------------------------------------------------------------
  // Build-time configuration
  // ------------------------------------------------------------------------
  localparam int unsigned NUM_EP        = `USB3_NUM_EP;      // EP0 + data EPs
  localparam int unsigned EP_ADDR_W     = $clog2(NUM_EP);
  localparam int unsigned MAX_PKT_SS    = `USB3_MAX_PKT_SS;  // SS bulk max pkt
  localparam int unsigned PIPE_DATA_W   = 32;   // 32-bit PIPE mode (fixed)
  localparam int unsigned PIPE_K_W      = PIPE_DATA_W/8;
  localparam int unsigned AXI_DATA_W    = `USB3_AXI_DATA_W;
  localparam int unsigned AXI_ADDR_W    = `USB3_AXI_ADDR_W;
  localparam int unsigned AXI_ID_W      = `USB3_AXI_ID_W;
  localparam int unsigned APB_ADDR_W    = `USB3_APB_ADDR_W;
  localparam int unsigned EP_FIFO_DEP   = `USB3_EP_FIFO_DEP; // AXI_DATA_W ents
  // Width of an endpoint-buffer occupancy/free count, in bits.  One wider than
  // the address so DEPTH itself is representable.
  localparam int unsigned EP_LVL_W      = $clog2(EP_FIFO_DEP) + 1;

  // ------------------------------------------------------------------------
  // PIPE 3.0 8b/10b control (K) characters used by the link layer.
  //
  // THESE ARE THE USB 3.0 SPECIAL-SYMBOL ASSIGNMENTS, and four of them were
  // wrong until audit finding D5 was closed.  The 8b/10b encoding of a control
  // character Kx.y is {y[2:0], x[4:0]}, so K28.n = {n[2:0], 5'b11100}; the
  // arithmetic below is therefore checkable by inspection, and the name -> Kx.y
  // assignment is the USB 3.0 special-symbol table:
  //
  //   name  Kx.y    value  what changed
  //   SKP   K28.1   8'h3C  was 8'h1C (K28.0)  - D5
  //   SDP   K28.2   8'h5C  unchanged
  //   EDB   K28.3   8'h7C  was 8'hFE (K30.7)  - D5
  //   COM   K28.5   8'hBC  unchanged
  //   END   K29.7   8'hFD  was 8'hF7 (K23.7, which is EPF, a different symbol)
  //   SLC   K30.7   8'hFE  was 8'h3C (K28.1, which is SKP)  - D5
  //   SHP   K27.7   8'hFB  unchanged
  //
  // The old table was mutually distinct, so the link layer framed and de-framed
  // itself perfectly and every internal test passed while no real host would
  // have interoperated.  A table that is only self-consistent cannot be graded
  // by a testbench that imports the same table, so the values are pinned by
  // elaboration guards against the LITERAL specification values in
  // usb3_param_check.sv (g_chk_ksym_*).  That guard is the only thing standing
  // between this table and a silent regression - do not delete it.
  //
  // K28.4 (8'h9C, "SUB") and K23.7 (8'hF7, "EPF") are defined by USB 3.0 but
  // are not framed or decoded by this implementation, so they are deliberately
  // not declared here: an unused package constant is dead code and `make lint`
  // reports it as such.
  // ------------------------------------------------------------------------
  localparam logic [7:0] K_SKP  = `USB3_K_SKP; // K28.1 - skip ordered set
  localparam logic [7:0] K_SDP  = `USB3_K_SDP; // K28.2 - start data packet
  localparam logic [7:0] K_EDB  = `USB3_K_EDB; // K28.3 - end bad
  localparam logic [7:0] K_COM  = `USB3_K_COM; // K28.5 - comma
  localparam logic [7:0] K_END  = `USB3_K_END; // K29.7 - end
  localparam logic [7:0] K_SLC  = `USB3_K_SLC; // K30.7 - start link command
  localparam logic [7:0] K_SHP  = `USB3_K_SHP; // K27.7 - start header packet

  // ------------------------------------------------------------------------
  // LTSSM states. Sequential encoding; illegal encodings fall back to
  // LT_DETECT_RESET for safe recovery.
  // ------------------------------------------------------------------------
  typedef enum logic [4:0] {
    LT_DETECT_RESET    = 5'd0,
    LT_DETECT_ACTIVE   = 5'd1,
    LT_DETECT_QUIET    = 5'd2,
    LT_POLLING_LFPS    = 5'd3,
    LT_POLLING_RXEQ    = 5'd4,
    LT_POLLING_ACTIVE  = 5'd5,
    LT_POLLING_CFG     = 5'd6,
    LT_POLLING_IDLE    = 5'd7,
    LT_U0              = 5'd8,
    LT_U1              = 5'd9,
    LT_U2              = 5'd10,
    LT_U3              = 5'd11,
    LT_RECOVERY_ACTIVE = 5'd12,
    LT_RECOVERY_CFG    = 5'd13,
    LT_RECOVERY_IDLE   = 5'd14,
    LT_HOT_RESET       = 5'd15,
    LT_LOOPBACK        = 5'd16,
    LT_COMPLIANCE      = 5'd17,
    LT_SS_DISABLED     = 5'd18,
    LT_SS_INACTIVE     = 5'd19
  } ltssm_state_e;

  // Link power state reported to software / CSR.
  typedef enum logic [1:0] {
    PWR_U0 = 2'd0,
    PWR_U1 = 2'd1,
    PWR_U2 = 2'd2,
    PWR_U3 = 2'd3
  } link_pwr_e;

  // ------------------------------------------------------------------------
  // Link commands (11-bit link command word, class/type/subtype encoded)
  // ------------------------------------------------------------------------
  typedef enum logic [3:0] {
    LC_LGOOD  = 4'h0,
    LC_LCRD   = 4'h1,
    LC_LRTY   = 4'h2,
    LC_LBAD   = 4'h3,
    LC_LGO_U1 = 4'h4,
    LC_LGO_U2 = 4'h5,
    LC_LGO_U3 = 4'h6,
    LC_LAU    = 4'h7,
    LC_LXU    = 4'h8,
    LC_LPMA   = 4'h9,
    LC_LUP    = 4'hA,
    LC_LDN    = 4'hB,
    LC_NONE   = 4'hF
  } link_cmd_e;

  // THIS DEVICE's Rx header buffer credits A..D: how many received header
  // packets it can hold before it must stop advertising credit.  It is a
  // property of THIS port's buffering and is configurable so that credit
  // exhaustion is reachable in a short simulation.
  localparam int unsigned NUM_RX_CREDIT = `USB3_NUM_RX_CREDIT;

  // The REMOTE port's Rx header buffer count, which is what bounds how many
  // headers this device may have outstanding on the transmit side.  USB 3.0
  // fixes it at four for every port - the credit tags are exactly LCRD_A,
  // LCRD_B, LCRD_C and LCRD_D - so it is a constant, NOT a copy of this
  // device's own NUM_RX_CREDIT.
  //
  // It used to be exactly that copy (usb3_link.sv reset and saturation of
  // tx_cred_q), which meant a build with a small local receive buffer silently
  // throttled the TRANSMIT path: at NUM_RX_CREDIT=1 the device could not emit
  // the two data packet headers of a two-packet IN burst without an LCRD in
  // between, and usb3_dma_test failed in the `min` build only.  Functional
  // spec 18 lists "advertise receive capacity" and "consume credits on
  // transmission" as two separate functions; they are two separate numbers.
  localparam int unsigned NUM_TX_CREDIT = 4;

  // ------------------------------------------------------------------------
  // Packet / header types (Type field of a SuperSpeed header packet)
  // ------------------------------------------------------------------------
  typedef enum logic [4:0] {
    HP_LMP = 5'h00, // Link Management Packet
    HP_TP  = 5'h04, // Transaction Packet
    HP_DPH = 5'h08, // Data Packet Header
    HP_ITP = 5'h0C  // Isochronous Timestamp Packet
  } hp_type_e;

  // Transaction packet sub-types.
  typedef enum logic [3:0] {
    TP_ACK        = 4'h1,
    TP_NRDY       = 4'h2,
    TP_ERDY       = 4'h3,
    TP_STATUS     = 4'h4,
    TP_STALL      = 4'h5,
    TP_DEV_NOTIF  = 4'h6,
    TP_PING       = 4'h7,
    TP_PING_RSP   = 4'h8
  } tp_subtype_e;

  // ------------------------------------------------------------------------
  // Endpoint transfer types
  // ------------------------------------------------------------------------
  typedef enum logic [1:0] {
    EP_CONTROL = 2'd0,
    EP_ISO     = 2'd1,
    EP_BULK    = 2'd2,
    EP_INTR    = 2'd3
  } ep_type_e;

  typedef enum logic [1:0] {
    EPS_DISABLED = 2'd0,
    EPS_RUNNING  = 2'd1,
    EPS_HALTED   = 2'd2,
    EPS_ERROR    = 2'd3
  } ep_state_e;

  // ------------------------------------------------------------------------
  // Scatter-gather DMA descriptor (4 x 32-bit words, 16-byte aligned)
  //   W0 : buffer address [31:0]
  //   W1 : buffer address [63:32] (upper bits ignored when AXI_ADDR_W==32)
  //   W2 : {ctrl[7:0], ep[3:0], length[19:0]}
  //   W3 : next descriptor address [31:0] (0 => end of list)
  // ------------------------------------------------------------------------
  localparam int unsigned DESC_BYTES    = 16;
  localparam int unsigned DESC_LEN_W    = 20;
  localparam int unsigned DESC_EP_LSB   = 20;
  localparam int unsigned DESC_CTRL_LSB = 24;
  localparam int unsigned DCTRL_IOC    = 0; // interrupt on completion
  localparam int unsigned DCTRL_LAST   = 1; // last descriptor of transfer
  localparam int unsigned DCTRL_DIR    = 2; // 1 = mem->USB (IN), 0 = USB->mem
  localparam int unsigned DCTRL_OWN    = 7; // 1 = owned by hardware

  // ------------------------------------------------------------------------
  // APB register map (byte offsets)
  // ------------------------------------------------------------------------
  localparam logic [11:0] REG_ID          = 12'h000; // RO  IP identification
  localparam logic [11:0] REG_CTRL        = 12'h004; // RW  global control
  localparam logic [11:0] REG_STATUS      = 12'h008; // RO  global status
  localparam logic [11:0] REG_LINK_CTRL   = 12'h00C; // RW  link control
  localparam logic [11:0] REG_LINK_STS    = 12'h010; // RO  LTSSM / power state
  localparam logic [11:0] REG_DEV_ADDR    = 12'h014; // RW  device address
  localparam logic [11:0] REG_INT_STS     = 12'h018; // W1C interrupt status
  localparam logic [11:0] REG_INT_EN      = 12'h01C; // RW  interrupt enable
  localparam logic [11:0] REG_ERR_STS     = 12'h020; // W1C error status
  localparam logic [11:0] REG_SEC_CTRL    = 12'h024; // RW  security control
  localparam logic [11:0] REG_DMA_CTRL    = 12'h028; // RW  DMA control
  localparam logic [11:0] REG_DMA_STS     = 12'h02C; // RO  DMA status
  localparam logic [11:0] REG_DESC_BASE_L = 12'h030; // RW  descriptor base lo
  localparam logic [11:0] REG_DESC_BASE_H = 12'h034; // RW  descriptor base hi
  localparam logic [11:0] REG_SEC_BASE    = 12'h038; // RW  DMA filter base
  localparam logic [11:0] REG_SEC_LIMIT   = 12'h03C; // RW  DMA filter limit
  localparam logic [11:0] REG_ITP_CNT     = 12'h040; // RO  isoch timestamp
  localparam logic [11:0] REG_SETUP_L     = 12'h044; // RO  SETUP data [31:0]
  localparam logic [11:0] REG_SETUP_H     = 12'h048; // RO  SETUP data [63:32]

  // Per-endpoint block: EP_BASE + ep*EP_STRIDE
  localparam logic [11:0] EP_BASE      = 12'h100;
  localparam logic [11:0] EP_STRIDE    = 12'h010;
  localparam logic [11:0] EP_CFG_OFF   = 12'h000; // [1:0]type [2]in [3]out
                                                  // [15:4]maxpkt [20:16]burst
  localparam logic [11:0] EP_CTRL_OFF  = 12'h004; // [0]en [1]stall [2]flush
                                                  // [3]clr_stall [4] reserved
  localparam logic [11:0] EP_STS_OFF   = 12'h008; // [1:0]state [2]stalled
                                                  // [3]in_rdy [4]out_valid
                                                  // [15:8]credits
  localparam logic [11:0] EP_XFER_OFF  = 12'h00C; // [19:0] remaining bytes

  // Byte address one past the last endpoint register.  The APB address width
  // must be able to span this; usb3_param_check enforces it.
  localparam int unsigned EP_REGION_TOP = int'(EP_BASE) + int'(NUM_EP) *
                                          int'(EP_STRIDE);

  // ------------------------------------------------------------------------
  // Interrupt bit positions (REG_INT_STS / REG_INT_EN)
  // ------------------------------------------------------------------------
  localparam int unsigned INT_LINK_UP    = 0;  // LTSSM entered U0
  localparam int unsigned INT_LINK_DOWN  = 1;  // LTSSM left U0 to SS.Inactive
  localparam int unsigned INT_HOT_RESET  = 2;
  localparam int unsigned INT_SUSPEND    = 3;  // entered U3
  localparam int unsigned INT_RESUME     = 4;  // exit from U1/U2/U3
  localparam int unsigned INT_SETUP      = 5;  // SETUP packet received
  localparam int unsigned INT_ENUM_DONE  = 6;  // address assigned/configured
  localparam int unsigned INT_EP_IN      = 7;  // OR of per-EP IN complete
  localparam int unsigned INT_EP_OUT     = 8;  // OR of per-EP OUT complete
  localparam int unsigned INT_DMA_DONE   = 9;
  localparam int unsigned INT_ERR        = 10; // OR of REG_ERR_STS
  localparam int unsigned INT_WIDTH      = 11;

  // ------------------------------------------------------------------------
  // Error status bit positions (REG_ERR_STS)
  // ------------------------------------------------------------------------
  localparam int unsigned ERR_CRC5       = 0;
  localparam int unsigned ERR_CRC16      = 1;
  localparam int unsigned ERR_CRC32      = 2;
  localparam int unsigned ERR_PROTOCOL   = 3;
  localparam int unsigned ERR_TIMEOUT    = 4;
  localparam int unsigned ERR_LINK       = 5;
  localparam int unsigned ERR_OVERFLOW   = 6;
  localparam int unsigned ERR_UNDERFLOW  = 7;
  localparam int unsigned ERR_DMA_AXI    = 8;
  localparam int unsigned ERR_SEC_VIOL   = 9;
  localparam int unsigned ERR_WIDTH      = 10;

  // Timeout (in pclk cycles) for an outstanding transaction.  Evaluated in a
  // 32-bit type: a width-derived expression must never be evaluated in a type
  // whose size is the value under test.
  localparam int unsigned TP_TIMEOUT_CYC = 32'd50000;

endpackage

`default_nettype wire
