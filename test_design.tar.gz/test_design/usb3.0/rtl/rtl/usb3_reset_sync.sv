// ============================================================================
// usb3_reset_sync.sv
// Part of the USB 3.0 SuperSpeed device controller CDC / storage primitive
// library. Reset convention: active-low, asynchronous assert, synchronous
// deassert.
// ============================================================================
`default_nettype none

// ----------------------------------------------------------------------------
// Reset synchronizer: asynchronous assert, synchronous deassert.
// DFT: scan_mode bypasses the synchronizer so ATPG controls reset directly.
// ----------------------------------------------------------------------------
module usb3_reset_sync #(
  parameter int unsigned STAGES = 3
) (
  input  wire clk,
  input  wire arst_n,     // async, active-low source reset
  input  wire scan_mode,  // DFT: 1 => bypass synchronizer
  output wire rst_n
);
  // ---- elaboration guards ---------------------------------------------
  // STAGES = 1 makes sync_q[STAGES-2:0] a negative range, so this guard must
  // be shown to report rather than be pre-empted by the range error - that is
  // exactly what run/scripts/elab_check.sh matches by message.
  if (STAGES < 2) begin : g_chk_stages_min
    $error("usb3_reset_sync: STAGES must be >= 2 (got %0d): a single flop cannot synchronise reset deassertion",
           STAGES);
  end
  if (STAGES > 8) begin : g_chk_stages_max
    $error("usb3_reset_sync: STAGES must be <= 8 (got %0d)", STAGES);
  end

  (* async_reg = "true" *) logic [STAGES-1:0] sync_q;
  always_ff @(posedge clk or negedge arst_n) begin
    if (!arst_n) sync_q <= '0;
    else         sync_q <= {sync_q[STAGES-2:0], 1'b1};
  end
  assign rst_n = scan_mode ? arst_n : sync_q[STAGES-1];
endmodule

`default_nettype wire
