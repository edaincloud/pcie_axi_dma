// ============================================================================
// usb3_ltssm.sv
// USB 3.0 SuperSpeed device Link Training and Status State Machine (LTSSM).
//
// Implements section 13 of the IRS:
//   Detect.Reset / Detect.Active / Detect.Quiet
//   Polling.LFPS / Polling.RxEQ / Polling.Active / Polling.Config / Polling.Idle
//   U0 / U1 / U2 / U3
//   Recovery.Active / Recovery.Config / Recovery.Idle
//   Hot Reset, Loopback, Compliance, SS.Disabled, SS.Inactive
//
// Responsibilities
//   - PIPE 3.0 control side band (PowerDown, TxElecIdle, TxDetectRx/Loopback,
//     Rate, RxPolarity, TxOnesZeros, PHY reset).
//   - TS1 / TS2 / SKP ordered-set generation on the os_* stream, which the link
//     layer muxes onto the PIPE transmit data bus with highest priority.
//   - Link power management: LGO_U1/U2/U3 acceptance (LAU) or rejection (LXU),
//     LFPS / remote-wake based exit (LUP) and the wakeup_req side band.
//   - Single-cycle event pulses for the interrupt controller.
//
// Timing is parameterised: T_LFPS_CYC is the LFPS / Detect dwell time in pclk
// cycles, T_TS_CYC the number of ordered sets sent or required per training
// substate.  Both are shortened for simulation by the top level.
// ============================================================================
`default_nettype none

module usb3_ltssm
  import usb3_pkg::*;
#(
  parameter int unsigned T_LFPS_CYC = 1250,
  parameter int unsigned T_TS_CYC   = 32
) (
  input  wire                    clk,
  input  wire                    rst_n,

  // ---- Configuration (already synchronised to clk) ------------------------
  input  wire                    cfg_enable,
  input  wire                    cfg_phy_en,
  input  wire                    cfg_u1_en,
  input  wire                    cfg_u2_en,
  input  wire                    cfg_force_disable,
  input  wire                    cfg_loopback_en,
  input  wire                    cfg_compliance_en,
  input  wire                    hot_reset_req,      // pulse
  input  wire                    remote_wake_req,    // pulse

  // ---- PIPE receive ------------------------------------------------------
  input  wire  [PIPE_DATA_W-1:0] pipe_rx_data,
  input  wire  [PIPE_K_W-1:0]    pipe_rx_datak,
  input  wire                    pipe_rx_valid,
  input  wire                    pipe_rx_elec_idle,
  input  wire                    pipe_phy_status,
  input  wire  [2:0]             pipe_rx_status,

  // ---- PIPE control ------------------------------------------------------
  output logic                   pipe_tx_elec_idle,
  output logic                   pipe_tx_detrx_lpbk,
  output logic                   pipe_tx_oneszeros,
  output logic [1:0]             pipe_powerdown,
  output logic                   pipe_rate,
  output logic                   pipe_rx_polarity,
  output logic                   pipe_reset_n,

  // LFPS TRANSMIT REQUEST - the device-initiated Ux exit path.
  //
  // A device asks the far end to leave U1/U2/U3 with LOW FREQUENCY PERIODIC
  // SIGNALLING, not with a framed link command: LFPS is signalled while the
  // transmitter is electrically idle, which is precisely the condition a Ux
  // state holds it in.  PHY/PIPE spec 10 puts the waveform on the PHY side of
  // the boundary - "LFPS generation/detection is primarily PHY functionality
  // [...] The PHY shall own electrical waveform generation and compliance" -
  // and leaves the controller an ABSTRACT INDICATION, which is what this is:
  // a level that means "signal a wake burst now", asserted while a latched
  // remote-wake request is pending in a low-power state.
  //
  // Routing the wake through the framed transmitter instead is audit finding
  // D19: pipe_tx_elec_idle is asserted in U1 (below), the link layer's framer
  // is gated on !tx_elec_idle (usb3_link.sv), so a link command queued for the
  // wake can never be transmitted and a wake that waits for it never
  // completes.
  output logic                   pipe_tx_lfps,

  // ---- Ordered-set stream to the link layer transmit mux ------------------
  output logic                   os_active,
  output logic [PIPE_DATA_W-1:0] os_data,
  output logic [PIPE_K_W-1:0]    os_datak,

  // ---- Link-command channel (through the link layer) ----------------------
  output logic                   pm_tx_req,
  output logic [3:0]             pm_tx_cmd,
  input  wire                    pm_tx_done,
  input  wire                    pm_rx_valid,
  input  wire  [3:0]             pm_rx_cmd,

  // ---- Status / events ---------------------------------------------------
  output logic [4:0]             state,
  output logic [1:0]             pwr_state,
  output logic                   link_up,
  output logic                   wakeup_req,
  output logic                   evt_link_up,
  output logic                   evt_link_down,
  output logic                   evt_hot_reset,
  output logic                   evt_suspend,
  output logic                   evt_resume,
  output logic                   err_link
);

  // ------------------------------------------------------------------------
  // Elaboration guards
  // ------------------------------------------------------------------------
  if (T_LFPS_CYC < 4) begin : g_chk_lfps_min
    $error("usb3_ltssm: T_LFPS_CYC must be >= 4 (got %0d): the Detect and Polling dwell timers need room to be observed before the state is left",
           T_LFPS_CYC);
  end
  if (T_LFPS_CYC > 1_000_000) begin : g_chk_lfps_max
    $error("usb3_ltssm: T_LFPS_CYC must be <= 1000000 (got %0d): the dwell timer would exceed a practical LFPS interval at 125 MHz",
           T_LFPS_CYC);
  end
  if (T_TS_CYC < 1) begin : g_chk_ts_min
    $error("usb3_ltssm: T_TS_CYC must be >= 1 (got %0d): at zero no training ordered set is ever sent and Polling can never complete",
           T_TS_CYC);
  end
  if (T_TS_CYC > 65535) begin : g_chk_ts_max
    $error("usb3_ltssm: T_TS_CYC must be <= 65535 (got %0d)", T_TS_CYC);
  end

  // ------------------------------------------------------------------------
  // Local parameters / timer sizing
  // ------------------------------------------------------------------------
  localparam int unsigned TMR_MAX = (T_LFPS_CYC > T_TS_CYC) ? T_LFPS_CYC
                                                            : T_TS_CYC;
  localparam int unsigned TMR_W   = unsigned'($clog2(TMR_MAX + 2) + 1);
  localparam int unsigned SET_W   = unsigned'($clog2(T_TS_CYC + 2) + 1);

  // TS1 / TS2 training-sequence data symbols.
  localparam logic [7:0] TS1_SYM = 8'h4A;
  localparam logic [7:0] TS2_SYM = 8'h45;

  // SKP ordered set insertion interval in U0 (dwords).
  localparam int unsigned SKP_INTERVAL = 354;
  localparam int unsigned SKP_W        = unsigned'($clog2(SKP_INTERVAL + 1));

  // ------------------------------------------------------------------------
  // Ordered-set generator
  // ------------------------------------------------------------------------
  typedef enum logic [1:0] {
    OS_NONE = 2'd0,
    OS_TS1  = 2'd1,
    OS_TS2  = 2'd2,
    OS_SKP  = 2'd3
  } os_sel_e;

  // ---- Which ordered set a state transmits --------------------------------
  // THE SELECTION IS A FUNCTION OF THE STATE, AND IS REGISTERED FROM state_d.
  //
  // It used to be a combinational output of the next-state case indexed by
  // state_q, registered into os_sel_q.  That put the ordered-set stream one
  // cycle BEHIND the state, so in the first cycle of the state after an
  // ordered-set-emitting state the generator was still driving the previous
  // selection and one stray beat went out - at the start of Polling.Idle, of
  // Detect.Active after a Polling timeout and of SS.Inactive after a Recovery
  // failure, the last two INTO ELECTRICAL IDLE.  That is audit finding D10,
  // and a_os_only_where_expected fired on it at 3.004 us of the first
  // usb3_linkup_test run.
  //
  // Registering os_for_state(state_d) instead makes os_sel_q agree with
  // state_q in every cycle: the generator starts on the first cycle of the
  // state and stops on the first cycle of the next one.  It stays REGISTERED,
  // so os_active - which freezes the link layer's transmit FSM - does not
  // acquire a combinational path from state_q.
  function automatic os_sel_e os_for_state(input ltssm_state_e s,
                                           input logic         skp_pend);
    case (s)
      LT_POLLING_RXEQ,
      LT_POLLING_ACTIVE,
      LT_RECOVERY_ACTIVE: return OS_TS1;
      LT_POLLING_CFG,
      LT_RECOVERY_CFG,
      LT_HOT_RESET:       return OS_TS2;
      LT_U0:              return skp_pend ? OS_SKP : OS_NONE;
      default:            return OS_NONE;
    endcase
  endfunction

  os_sel_e         os_sel_q, os_sel_d;
  logic [1:0]      os_beat_q;
  logic [SET_W-1:0] os_set_cnt;
  logic            os_last_beat;
  logic            os_sets_done;

  assign os_last_beat = (os_sel_q == OS_SKP) ? 1'b1 : (os_beat_q == 2'd3);
  assign os_sets_done = (os_set_cnt >= SET_W'(T_TS_CYC));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      os_sel_q   <= OS_NONE;
      os_beat_q  <= 2'd0;
      os_set_cnt <= '0;
    end else begin
      os_sel_q <= os_sel_d;
      if (os_sel_d == OS_NONE) begin
        os_beat_q  <= 2'd0;
        os_set_cnt <= '0;
      end else if (os_sel_d != os_sel_q) begin
        os_beat_q  <= 2'd0;
        os_set_cnt <= '0;
      end else if (os_last_beat) begin
        os_beat_q <= 2'd0;
        if (!os_sets_done) os_set_cnt <= os_set_cnt + SET_W'(1'b1);
      end else begin
        os_beat_q <= os_beat_q + 2'd1;
      end
    end
  end

  // Ordered-set symbol decode (combinational decode of registered state).
  always_comb begin
    os_active = (os_sel_q != OS_NONE);
    os_data   = '0;
    os_datak  = '0;
    case (os_sel_q)
      OS_TS1: begin
        if (os_beat_q == 2'd0) begin
          os_data  = {8'h00, 8'h00, 8'h00, K_COM};
          os_datak = 4'b0001;
        end else begin
          os_data  = {4{TS1_SYM}};
          os_datak = 4'b0000;
        end
      end
      OS_TS2: begin
        if (os_beat_q == 2'd0) begin
          os_data  = {8'h00, 8'h00, 8'h00, K_COM};
          os_datak = 4'b0001;
        end else begin
          os_data  = {4{TS2_SYM}};
          os_datak = 4'b0000;
        end
      end
      OS_SKP: begin
        os_data  = {4{K_SKP}};
        os_datak = 4'b1111;
      end
      default: begin
        os_data  = '0;
        os_datak = '0;
      end
    endcase
  end

  // ------------------------------------------------------------------------
  // Received ordered-set detection (COM followed by TS1 / TS2 symbols)
  // ------------------------------------------------------------------------
  logic       rx_com_q;
  logic       rx_ts1_hit, rx_ts2_hit;
  logic [3:0] ts1_cnt, ts2_cnt;
  logic       rx_phy_err;

  assign rx_ts1_hit = pipe_rx_valid && rx_com_q && (pipe_rx_datak == 4'b0000)
                      && (pipe_rx_data == {4{TS1_SYM}});
  assign rx_ts2_hit = pipe_rx_valid && rx_com_q && (pipe_rx_datak == 4'b0000)
                      && (pipe_rx_data == {4{TS2_SYM}});
  // PIPE RxStatus: bit 2 set covers every error encoding (3'b100 8b/10b decode
  // error, 3'b101/3'b110 elastic buffer over/underflow, 3'b111 disparity
  // error), so testing bit 2 alone is complete for ERROR detection.
  assign rx_phy_err = pipe_rx_valid && (pipe_rx_status[2] == 1'b1);

  // ------------------------------------------------------------------------
  // Receiver-detect result  (PHY/PIPE spec 8, LTSSM spec 9)
  // ------------------------------------------------------------------------
  // PIPE 3.0 returns the receiver-detect RESULT on RxStatus in the cycle the
  // PhyStatus completion pulse is asserted:
  //
  //   3'b011  RXSTAT_RX_DETECTED  a far-end receiver is present
  //   3'b1xx                      a PHY error (decode / elastic buffer /
  //                               disparity), i.e. detect_error
  //   anything else               no receiver
  //
  // "The result shall be sampled synchronously into the LTSSM domain"
  // (PHY/PIPE spec 8) and "Detection result shall be latched" (LTSSM spec 9),
  // so the answer is registered here rather than only being consumed
  // combinationally: det_res_q / det_valid_q survive into Detect.Quiet and are
  // what a debug read would report.
  logic       det_present;    // this cycle's answer says "receiver present"
  logic [2:0] det_res_q;      // latched RxStatus of the last completed detect
  logic       det_valid_q;    // a detect has completed at least once
  logic [7:0] det_fail_cnt_q; // consecutive unsuccessful attempts, saturating

  assign det_present = (pipe_rx_status == 3'b011);

  // OBSERVABILITY SINK, and what is still missing.  det_res_q, det_valid_q and
  // det_fail_cnt_q are the latched detection state LTSSM spec 9 requires; they
  // are graded by a_detect_result_latched / a_detect_fail_counts in
  // rtl/sva/usb3_ltssm_sva.sv and witnessed by c_detect_* there.  No
  // SYNTHESIZABLE logic reads them, because putting them in a register would be
  // a register-map change and this IP's register map is already a recorded
  // conformance departure (audit finding C1) - so that decision is deferred
  // rather than taken here, and the signals are named in this sink so the gap
  // is visible from the RTL rather than only from -Wall.
  logic det_dbg_unused;
  assign det_dbg_unused = det_valid_q | (|det_res_q) | (|det_fail_cnt_q);

  // ------------------------------------------------------------------------
  // Main state machine
  // ------------------------------------------------------------------------
  ltssm_state_e     state_q, state_d;
  logic [TMR_W-1:0] tmr_q;
  logic             illegal_state;
  logic             tmr_lfps_done, tmr_idle_done;
  logic [SKP_W-1:0] skp_cnt_q;
  logic             skp_pend_q;
  logic             polarity_q;
  logic             phy_rst_n_q;
  logic             wake_q;
  logic             wake_d;
  // Electrical idle must have been OBSERVED in a Ux state before its REMOVAL
  // can be read as the far end waking the link.  Entering Ux is a handshake -
  // the device gets there as soon as its accept has been transmitted, and the
  // far end stops driving a little later - so on the first cycles of U1/U2/U3
  // the receiver is legitimately still seeing logical idle, not electrical
  // idle.  Without this qualifier the device enters the low-power state and
  // leaves it again on the very next cycle, straight into Recovery, and U1/U2/
  // U3 are unreachable in practice: c_st_u1 was hit exactly ONCE, for one
  // cycle, against 257 cycles of Recovery.Active and 2606 of SS.Inactive.
  // Audit finding D14.
  logic             ux_idle_seen_q;
  logic             hot_reset_pend_q;
  logic [7:0]       phy_err_cnt_q;
  // "A device-initiated wake was taken out of U1, and the LUP that announces it
  // has not been sent yet."  LUP is a U0 link command - the framer is held in
  // electrical idle everywhere else - so the request is REMEMBERED across the
  // wake and the recovery that follows it, and issued when the link is back in
  // U0 and can actually transmit.  Audit finding D19.
  logic             lup_pend_q;

  assign tmr_lfps_done = (tmr_q >= TMR_W'(T_LFPS_CYC));
  assign tmr_idle_done = (tmr_q >= TMR_W'(T_TS_CYC));

  // ---- Power-management link-command sub-FSM ------------------------------
  typedef enum logic [1:0] {
    PMS_IDLE = 2'd0,
    PMS_REQ  = 2'd1,
    PMS_WAIT = 2'd2
  } pm_state_e;

  pm_state_e  pm_state_q;
  logic [3:0] pm_cmd_q;
  logic [1:0] pm_target_q;   // 0 = stay in U0, 1/2/3 = requested U state
  logic       pm_go_q;       // 1-cycle: accepted Ux entry may proceed

  assign pm_tx_req = (pm_state_q == PMS_REQ);
  assign pm_tx_cmd = pm_cmd_q;

  logic       pm_lgo_hit;
  logic [1:0] pm_lgo_target;
  logic       pm_lgo_accept;

  always_comb begin
    pm_lgo_hit    = 1'b0;
    pm_lgo_target = 2'd0;
    pm_lgo_accept = 1'b0;
    if (pm_rx_valid) begin
      case (link_cmd_e'(pm_rx_cmd))
        LC_LGO_U1: begin
          pm_lgo_hit    = 1'b1;
          pm_lgo_target = 2'd1;
          pm_lgo_accept = cfg_u1_en;
        end
        LC_LGO_U2: begin
          pm_lgo_hit    = 1'b1;
          pm_lgo_target = 2'd2;
          pm_lgo_accept = cfg_u2_en;
        end
        LC_LGO_U3: begin
          pm_lgo_hit    = 1'b1;
          pm_lgo_target = 2'd3;
          pm_lgo_accept = 1'b1;   // U3 (suspend) is always accepted
        end
        default: begin
          pm_lgo_hit    = 1'b0;
          pm_lgo_target = 2'd0;
          pm_lgo_accept = 1'b0;
        end
      endcase
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pm_state_q  <= PMS_IDLE;
      pm_cmd_q    <= LC_NONE;
      pm_target_q <= 2'd0;
      pm_go_q     <= 1'b0;
    end else begin
      pm_go_q <= 1'b0;
      case (pm_state_q)
        PMS_IDLE: begin
          if ((state_q == LT_U0) && pm_lgo_hit) begin
            pm_state_q  <= PMS_REQ;
            pm_cmd_q    <= pm_lgo_accept ? LC_LAU : LC_LXU;
            pm_target_q <= pm_lgo_accept ? pm_lgo_target : 2'd0;
          end else if ((state_q == LT_U0) && lup_pend_q) begin
            // THE LUP IS ISSUED FROM U0, NOT FROM U1.  It used to be requested
            // in U1, where the transmitter is electrically idle by definition
            // of the state and the framer is frozen, so the command was queued
            // and never sent - and the U1 exit below waited on it, which is the
            // deadlock of audit finding D19.  The wake itself is now signalled
            // with LFPS (pipe_tx_lfps) and needs no link command at all; the
            // LUP is the ANNOUNCEMENT that follows, and U0 is the only state in
            // which this device frames link commands.
            pm_state_q  <= PMS_REQ;
            pm_cmd_q    <= LC_LUP;
            pm_target_q <= 2'd0;
          end
        end
        PMS_REQ: begin
          if (pm_tx_done) begin
            pm_state_q <= PMS_WAIT;
            pm_go_q    <= 1'b1;
          end
        end
        PMS_WAIT: begin
          pm_state_q  <= PMS_IDLE;
          pm_cmd_q    <= LC_NONE;
          pm_target_q <= 2'd0;
        end
        default: begin
          pm_state_q  <= PMS_IDLE;
          pm_cmd_q    <= LC_NONE;
          pm_target_q <= 2'd0;
        end
      endcase
    end
  end

  // ---- Next-state logic ---------------------------------------------------
  always_comb begin
    state_d       = state_q;
    illegal_state = 1'b0;

    case (state_q)
      // ---------------- Detect ----------------
      LT_DETECT_RESET: begin
        if (cfg_enable && cfg_phy_en && tmr_lfps_done) state_d = LT_DETECT_ACTIVE;
      end
      // Detect.Active leaves FORWARD only on a detection result that says a
      // far-end receiver is present.  PIPE 3.0 carries the receiver-detect
      // RESULT on RxStatus (3'b011 = receiver detected) alongside the
      // PhyStatus completion pulse, and LTSSM spec 9 requires the result to be
      // classified: "On success, proceed to Polling.  On failure, retry
      // according to the specification-defined policy."
      //
      // This used to be `if (pipe_phy_status)` alone, so a "receiver absent"
      // answer was read as "receiver present" and Detect could never fail -
      // audit finding D1.  The retry policy for an UPSTREAM (device) port is
      // the Detect.Quiet / Detect.Active loop, which is what a failed or
      // errored result now falls into; det_fail_cnt_q counts the attempts so
      // the retry is observable rather than silent.
      LT_DETECT_ACTIVE: begin
        if (pipe_phy_status) begin
          state_d = det_present ? LT_POLLING_LFPS : LT_DETECT_QUIET;
        end else if (tmr_lfps_done) begin
          state_d = LT_DETECT_QUIET;
        end
      end
      LT_DETECT_QUIET: begin
        if (tmr_lfps_done) state_d = LT_DETECT_ACTIVE;
      end

      // ---------------- Polling ----------------
      LT_POLLING_LFPS: begin
        if (cfg_compliance_en)          state_d = LT_COMPLIANCE;
        else if (!pipe_rx_elec_idle)    state_d = LT_POLLING_RXEQ;
        else if (tmr_lfps_done)         state_d = LT_DETECT_ACTIVE;
      end
      LT_POLLING_RXEQ: begin
        if (os_sets_done) state_d = LT_POLLING_ACTIVE;
      end
      LT_POLLING_ACTIVE: begin
        if (ts1_cnt >= 4'd8 || ts2_cnt >= 4'd8) state_d = LT_POLLING_CFG;
        else if (tmr_lfps_done)                 state_d = LT_DETECT_ACTIVE;
      end
      LT_POLLING_CFG: begin
        if ((ts2_cnt >= 4'd8) && os_sets_done) state_d = LT_POLLING_IDLE;
        else if (tmr_lfps_done)                state_d = LT_DETECT_ACTIVE;
      end
      LT_POLLING_IDLE: begin
        if (cfg_loopback_en)   state_d = LT_LOOPBACK;
        else if (tmr_idle_done) state_d = LT_U0;
      end

      // ---------------- Operational ----------------
      LT_U0: begin
        // An ACCEPTED low-power entry outranks the electrical-idle Recovery
        // path.  pm_go_q pulses only after the LAU has actually left the
        // transmitter, so by the time it is seen the far end has been told
        // "accepted, going to Ux" - and the electrical idle that follows IS
        // that low-power state, not a link failure.  Ranked the other way
        // round the device answers LAU and then treats its peer's agreed
        // silence as a broken link, which is how it reached SS.Inactive
        // instead of U1.  Audit finding D14.
        //
        // This was masked while pm_go_q pulsed on the cycle the LAU was pushed
        // into the transmit FIFO: it then always arrived before the far end
        // could stop driving, so the ordering was never exercised.
        // ...and the peer's electrical idle is not read as a link failure
        // while a low-power handshake is still in flight.  pm_state_q leaves
        // PMS_IDLE when the LGO is decoded and returns to it only after the
        // accept has been transmitted and pm_go_q taken, so this covers the
        // whole window in which the far end may legitimately stop driving.
        // Without it the ranking above is a race the design loses by a few
        // cycles: the far end stops driving the moment it sees the LAU, and
        // pm_go_q lands after the framer has drained.
        if (hot_reset_req || hot_reset_pend_q)       state_d = LT_HOT_RESET;
        else if (pm_go_q && (pm_target_q == 2'd1))   state_d = LT_U1;
        else if (pm_go_q && (pm_target_q == 2'd2))   state_d = LT_U2;
        else if (pm_go_q && (pm_target_q == 2'd3))   state_d = LT_U3;
        else if (pipe_rx_elec_idle && tmr_lfps_done &&
                 (pm_state_q == PMS_IDLE))           state_d = LT_RECOVERY_ACTIVE;
        else if (phy_err_cnt_q >= 8'd16)             state_d = LT_RECOVERY_ACTIVE;
      end
      // THE DEVICE-INITIATED EXIT FROM U1 DOES NOT WAIT ON THE TRANSMITTER.
      //
      // This arm used to read `wake_q && (pm_state_q == PMS_WAIT)`, and
      // PMS_WAIT is only reached on pm_tx_done, which since audit finding D14
      // means "the link command has actually LEFT the transmitter".  But
      // pipe_tx_elec_idle is asserted in U1 (see the PIPE side band below) and
      // usb3_link gates its framer on !tx_elec_idle, so nothing can leave the
      // transmitter while the link is in U1.  The device therefore had to
      // transmit in order to leave U1 and could not transmit while in U1: the
      // LUP was queued for ever, wakeup_req stayed asserted, and a
      // device-initiated remote wake could never complete.  Only the HOST's
      // exit - the ux_idle_seen_q arm above - still worked.  Audit finding D19.
      //
      // A real device does not signal this wake with a link command at all.
      // USB 3.x exits U1/U2/U3 with LFPS, which is signalled DURING electrical
      // idle and is the PHY's to generate (PHY/PIPE spec 10); pipe_tx_lfps
      // carries the request, and the LTSSM then does what LTSSM spec 21 says
      // for `U1 | wake`: take the recovery path.  That is exactly what U2 and
      // U3 below have always done, and they were never affected.
      LT_U1: begin
        if (ux_idle_seen_q && !pipe_rx_elec_idle)     state_d = LT_RECOVERY_ACTIVE;
        else if (wake_q)                              state_d = LT_RECOVERY_ACTIVE;
        else if (pm_rx_valid && (pm_rx_cmd == LC_LGO_U2)) state_d = LT_U2;
      end
      LT_U2: begin
        if (ux_idle_seen_q && !pipe_rx_elec_idle) state_d = LT_RECOVERY_ACTIVE;
        else if (wake_q)                          state_d = LT_RECOVERY_ACTIVE;
      end
      LT_U3: begin
        if (ux_idle_seen_q && !pipe_rx_elec_idle) state_d = LT_RECOVERY_ACTIVE;
        else if (wake_q)                          state_d = LT_RECOVERY_ACTIVE;
      end

      // ---------------- Recovery ----------------
      LT_RECOVERY_ACTIVE: begin
        if (ts1_cnt >= 4'd8 || ts2_cnt >= 4'd8) state_d = LT_RECOVERY_CFG;
        else if (tmr_lfps_done)                 state_d = LT_SS_INACTIVE;
      end
      LT_RECOVERY_CFG: begin
        if (hot_reset_req || hot_reset_pend_q)      state_d = LT_HOT_RESET;
        else if ((ts2_cnt >= 4'd8) && os_sets_done) state_d = LT_RECOVERY_IDLE;
        else if (tmr_lfps_done)                     state_d = LT_SS_INACTIVE;
      end
      LT_RECOVERY_IDLE: begin
        if (tmr_idle_done) state_d = LT_U0;
      end

      // ---------------- Special ----------------
      LT_HOT_RESET: begin
        if (os_sets_done) state_d = LT_U0;
      end
      LT_LOOPBACK: begin
        if (!cfg_loopback_en) state_d = LT_DETECT_RESET;
      end
      LT_COMPLIANCE: begin
        if (!cfg_compliance_en) state_d = LT_DETECT_RESET;
      end
      LT_SS_DISABLED: begin
        if (!cfg_force_disable) state_d = LT_DETECT_RESET;
      end
      LT_SS_INACTIVE: begin
        if (hot_reset_req || hot_reset_pend_q) state_d = LT_DETECT_RESET;
      end

      // ---------------- Illegal state recovery ----------------
      default: begin
        state_d       = LT_DETECT_RESET;
        illegal_state = 1'b1;
      end
    endcase

    // Global overrides (highest priority last).
    if (cfg_force_disable && (state_q != LT_SS_DISABLED)) begin
      state_d = LT_SS_DISABLED;
    end
    if ((!cfg_enable || !cfg_phy_en) && (state_q != LT_DETECT_RESET)) begin
      state_d = LT_DETECT_RESET;
    end

    // The remote-wake latch's next value, factored out of the sequential block
    // for the same reason os_sel_d is: a side band derived from state_q is one
    // cycle BEHIND the state it describes.  wakeup_req said "still waking" in
    // the first cycle of U0, where the link is by definition already up, and
    // a_wakeup_only_out_of_u0 (rtl/sva/usb3_device_controller_sva.sv) fires on
    // it.  Unreachable until D19 was fixed, because before that a
    // device-initiated wake never reached U0 at all.  Audit finding D19a.
    wake_d = wake_q;
    if (remote_wake_req && (state_q inside {LT_U1, LT_U2, LT_U3})) wake_d = 1'b1;
    else if (state_q == LT_U0)                                    wake_d = 1'b0;

    // The ordered-set selection is a function of the state the design will BE
    // IN next cycle, and is registered, so os_sel_q always agrees with state_q.
    // Deriving it from state_d rather than state_q is what closes D10: the
    // three global-override arms above cannot be forgotten here, and no beat
    // survives into the state after an ordered-set state.
    os_sel_d = os_for_state(state_d, skp_pend_q);
  end

  // ---- Sequential state, timers, flags ------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      state_q          <= LT_DETECT_RESET;
      tmr_q            <= '0;
      rx_com_q         <= 1'b0;
      ts1_cnt          <= 4'd0;
      ts2_cnt          <= 4'd0;
      skp_cnt_q        <= '0;
      skp_pend_q       <= 1'b0;
      polarity_q       <= 1'b0;
      phy_rst_n_q      <= 1'b0;
      wake_q           <= 1'b0;
      lup_pend_q       <= 1'b0;
      ux_idle_seen_q   <= 1'b0;
      hot_reset_pend_q <= 1'b0;
      phy_err_cnt_q    <= 8'd0;
      det_res_q        <= 3'b000;
      det_valid_q      <= 1'b0;
      det_fail_cnt_q   <= 8'd0;
    end else begin
      state_q <= state_d;

      // Receiver-detect result latch (LTSSM spec 9: "Detection result shall be
      // latched").  The attempt counter saturates rather than wrapping, so a
      // long-running failure reads as "many" and not as "a few".
      if ((state_q == LT_DETECT_ACTIVE) && pipe_phy_status) begin
        det_res_q   <= pipe_rx_status;
        det_valid_q <= 1'b1;
        if (det_present)                       det_fail_cnt_q <= 8'd0;
        else if (det_fail_cnt_q != 8'hFF)      det_fail_cnt_q <= det_fail_cnt_q + 8'd1;
      end

      // State dwell timer.
      if (state_d != state_q) tmr_q <= '0;
      else if (!tmr_lfps_done) tmr_q <= tmr_q + TMR_W'(1'b1);

      // Ordered-set receive tracking.
      rx_com_q <= pipe_rx_valid && pipe_rx_datak[0]
                  && (pipe_rx_data[7:0] == K_COM);
      if (state_d != state_q) begin
        ts1_cnt <= 4'd0;
        ts2_cnt <= 4'd0;
      end else begin
        if (rx_ts1_hit && (ts1_cnt != 4'd15)) ts1_cnt <= ts1_cnt + 4'd1;
        if (rx_ts2_hit && (ts2_cnt != 4'd15)) ts2_cnt <= ts2_cnt + 4'd1;
      end

      // "Electrical idle has been seen in this Ux state."  Cleared outside the
      // Ux states so it can never carry over into the next visit.
      if (!(state_q inside {LT_U1, LT_U2, LT_U3})) ux_idle_seen_q <= 1'b0;
      else if (pipe_rx_elec_idle)                  ux_idle_seen_q <= 1'b1;

      // PHY receive-error accumulation (drives Recovery when persistent).
      if (state_q != LT_U0)                     phy_err_cnt_q <= 8'd0;
      else if (rx_phy_err && (phy_err_cnt_q != 8'hFF))
                                                phy_err_cnt_q <= phy_err_cnt_q + 8'd1;

      // Periodic SKP insertion while in U0.
      if (state_q != LT_U0) begin
        skp_cnt_q  <= '0;
        skp_pend_q <= 1'b0;
      end else if (skp_cnt_q >= SKP_W'(SKP_INTERVAL - 1)) begin
        skp_cnt_q  <= '0;
        skp_pend_q <= 1'b1;
      end else begin
        skp_cnt_q <= skp_cnt_q + SKP_W'(1'b1);
        if (os_sel_q == OS_SKP) skp_pend_q <= 1'b0;
      end

      // Receiver polarity inversion retry when Polling fails.
      if ((state_q == LT_POLLING_ACTIVE) && (state_d == LT_DETECT_ACTIVE))
        polarity_q <= ~polarity_q;

      // PHY reset is released once the PHY is enabled and Detect.Reset is left.
      phy_rst_n_q <= cfg_phy_en && (state_d != LT_DETECT_RESET);

      // Remote wake-up request latch.  The next value is computed in the
      // combinational block above so that the wakeup_req side band can be
      // registered from it and from state_d, and therefore agrees with the
      // state in the SAME cycle.
      wake_q <= wake_d;

      // The LUP that ANNOUNCES a device-initiated exit from U1, remembered
      // until the link is back in U0 and the framer can send it.  Only U1 is
      // armed, which is the scope the LUP has always had here; U2 and U3 wake
      // through the same LFPS path but send no link command.  Cleared when the
      // request is taken by the sub-FSM above, and in Detect.Reset so a wake
      // that ended in SS.Inactive rather than U0 cannot leak a LUP into the
      // next link.
      if (remote_wake_req && (state_q == LT_U1))          lup_pend_q <= 1'b1;
      else if (state_q == LT_DETECT_RESET)                lup_pend_q <= 1'b0;
      else if ((state_q == LT_U0) && (pm_state_q == PMS_IDLE) && !pm_lgo_hit)
                                                          lup_pend_q <= 1'b0;

      // Hot-reset request latch (serviced from U0 / Recovery / SS.Inactive).
      if (hot_reset_req)                 hot_reset_pend_q <= 1'b1;
      else if (state_q == LT_HOT_RESET)  hot_reset_pend_q <= 1'b0;
    end
  end

  // ------------------------------------------------------------------------
  // Registered event pulses
  // ------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      evt_link_up   <= 1'b0;
      evt_link_down <= 1'b0;
      evt_hot_reset <= 1'b0;
      evt_suspend   <= 1'b0;
      evt_resume    <= 1'b0;
      err_link      <= 1'b0;
    end else begin
      evt_link_up   <= (state_d == LT_U0) && (state_q != LT_U0);
      evt_link_down <= (state_d == LT_SS_INACTIVE) && (state_q != LT_SS_INACTIVE);
      evt_hot_reset <= (state_d == LT_HOT_RESET) && (state_q != LT_HOT_RESET);
      evt_suspend   <= (state_d == LT_U3) && (state_q != LT_U3);
      evt_resume    <= (state_q inside {LT_U1, LT_U2, LT_U3})
                       && (state_d inside {LT_U0, LT_RECOVERY_ACTIVE});
      err_link      <= illegal_state
                       || ((state_d == LT_SS_INACTIVE) && (state_q != LT_SS_INACTIVE));
    end
  end

  // ------------------------------------------------------------------------
  // PIPE control side band
  // ------------------------------------------------------------------------
  always_comb begin
    case (state_q)
      LT_U1:   pipe_powerdown = 2'b01; // P0s
      LT_U2:   pipe_powerdown = 2'b10; // P1
      // DETECT.ACTIVE IS P1, NOT P2.  PIPE 3.0 defines the receiver-detect
      // sequence as TxDetectRx/Loopback asserted with the PHY in P1; a real
      // PHY need not answer a detect request made from P2, and this design
      // asserts pipe_tx_detrx_lpbk for the whole of Detect.Active.  It drove
      // P2 here until audit finding D2 was closed.  The surrounding Detect
      // states stay in P2, which is the deepest state the PHY may sit in while
      // nothing is attached.
      LT_DETECT_ACTIVE: pipe_powerdown = 2'b10; // P1 - receiver detect
      LT_U3,
      LT_DETECT_RESET,
      LT_DETECT_QUIET,
      LT_SS_DISABLED,
      LT_SS_INACTIVE: pipe_powerdown = 2'b11; // P2
      default: pipe_powerdown = 2'b00;        // P0
    endcase
  end

  always_comb begin
    pipe_tx_elec_idle = (state_q inside {LT_DETECT_RESET, LT_DETECT_ACTIVE,
                                         LT_DETECT_QUIET, LT_POLLING_LFPS,
                                         LT_U1, LT_U2, LT_U3,
                                         LT_SS_DISABLED, LT_SS_INACTIVE});
  end

  // THE WAKE IS SIGNALLED, NOT ONLY LATCHED.  While a remote-wake request is
  // pending in a low-power state the controller asks the PHY for an LFPS burst.
  // pipe_tx_elec_idle stays asserted throughout - that is the whole point of
  // LFPS and the reason this path works where the framed one cannot - so the
  // transmit data bus is untouched and every property that forbids symbols in
  // electrical idle is unaffected.  Both terms are registered state, so the
  // request carries no combinational path out of the next-state logic.
  assign pipe_tx_lfps       = wake_q && (state_q inside {LT_U1, LT_U2, LT_U3});

  assign pipe_tx_detrx_lpbk = (state_q == LT_DETECT_ACTIVE)
                              || (state_q == LT_LOOPBACK);
  assign pipe_tx_oneszeros  = (state_q == LT_COMPLIANCE);
  assign pipe_rate          = 1'b1;              // 5 Gbps SuperSpeed only
  assign pipe_rx_polarity   = polarity_q;
  assign pipe_reset_n       = phy_rst_n_q;

  // ------------------------------------------------------------------------
  // Status outputs
  // ------------------------------------------------------------------------
  assign state   = state_q;
  assign link_up = (state_q == LT_U0);

  always_comb begin
    case (state_q)
      LT_U1:   pwr_state = PWR_U1;
      LT_U2:   pwr_state = PWR_U2;
      LT_U3:   pwr_state = PWR_U3;
      default: pwr_state = PWR_U0;
    endcase
  end

  // REGISTERED FROM THE NEXT STATE, not from the current one.  Written as
  // `else if (state_q == LT_U0) wakeup_req <= 0; else wakeup_req <= wake_q;`
  // the side band deasserts one cycle AFTER the link reaches U0, so the first
  // cycle of U0 carries a wake request for a link that is already up.  It
  // stays a real register, so the aclk-side synchroniser still samples a flop
  // output.  Audit finding D19a.
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) wakeup_req <= 1'b0;
    else        wakeup_req <= wake_d && (state_d != LT_U0);
  end

endmodule

`default_nettype wire
