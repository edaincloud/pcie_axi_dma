// ============================================================================
// usb3_protocol.sv
// USB 3.0 SuperSpeed device protocol / transaction layer (pclk domain).
//
// Responsibilities
//   * Decode received header packets (TP / DPH / ITP / LMP) delivered by the
//     link layer as a 96-bit {DW2,DW1,DW0} word plus a decoded type field.
//   * Device address filtering (address 0 before enumeration).
//   * IN transfers : on an ACK TP that requests data, drain the endpoint IN
//     FIFO into a packet staging FIFO, emit a DPH with the exact payload
//     length and stream the payload. Bursts of up to min(NumP, bMaxBurst+1)
//     packets are transmitted back to back.
//   * OUT transfers: capture DPH + payload into the endpoint OUT FIFO and
//     answer with ACK (next sequence number, NumP = remaining burst credit),
//     NRDY when there is no room and ERDY once room appears.
//   * EP0 control transfers: SETUP DP detection/latching, STATUS handshake and
//     the enumeration-complete event.
//   * STALL on halted endpoints, PING -> PING_RESPONSE, ITP capture.
//   * Per-transaction timeout and the full error pulse set.
//
// ---------------------------------------------------------------------------
// Header packet field map used by this implementation (must match usb3_link)
// ---------------------------------------------------------------------------
//  All packets  DW0[4:0]   = Type (hp_type_e)
//               DW0[24:5]  = Route String (ignored by a device)
//               DW0[31:25] = Device Address
//
//  TP           DW1[3:0]   = SubType (tp_subtype_e)
//               DW1[5:4]   = reserved (rty)
//               DW1[6]     = Direction (1 = IN, device -> host)
//               DW1[7]     = reserved (Host Error)
//               DW1[11:8]  = Endpoint Number
//               DW1[15:12] = reserved (pp / bei)
//               DW1[20:16] = NumP
//               DW1[25:21] = Sequence Number
//               DW1[31:26] = reserved
//               DW2[15:0]  = Stream ID
//
//  DPH          DW1[3:0]   = reserved (0)
//               DW1[6]     = Direction (1 = IN, device -> host)
//               DW1[11:8]  = Endpoint Number
//               DW1[20:16] = Sequence Number
//               DW1[21]    = End Of Burst
//               DW1[22]    = Setup flag (EP0 SETUP data packet)
//               DW1[23]    = Last Packet Flag
//               DW2[15:0]  = Data Length in bytes
//
//  ITP          DW1[13:0]  = Bus Interval Counter
//
// ---------------------------------------------------------------------------
// Assumptions
//   * Payload transfers are DWORD granular: the DMA pads a packet to a whole
//     number of 32-bit words and marks the final word with "last". The DPH
//     length field is therefore emitted as (words * 4).
//   * The host grants an entire burst with a single ACK TP (NumP); the device
//     streams that many packets before returning to idle. Per-packet ACK
//     bookkeeping is handled by the link layer retry mechanism.
//   * cfg_ep_* inputs are quasi-static (synchronised levels from the CSR).
// ============================================================================
`default_nettype none

module usb3_protocol
  import usb3_pkg::*;
(
  input  wire                    clk,
  input  wire                    rst_n,
  input  wire                    link_up,

  // ---- configuration (pclk synchronised levels) --------------------------
  input  wire  [6:0]             cfg_dev_addr,
  input  wire                    cfg_dev_addr_valid,
  input  wire  [NUM_EP-1:0]      cfg_ep_en,
  input  wire  [NUM_EP*2-1:0]    cfg_ep_type,
  input  wire  [NUM_EP-1:0]      cfg_ep_dir_in,
  input  wire  [NUM_EP*12-1:0]   cfg_ep_maxpkt,
  input  wire  [NUM_EP*5-1:0]    cfg_ep_burst,
  input  wire  [NUM_EP-1:0]      cfg_ep_stall,
  input  wire  [NUM_EP-1:0]      cfg_ep_clr_stall, // pclk pulses

  // ---- receive from link layer -------------------------------------------
  input  wire                    rx_hp_valid,
  input  wire  [95:0]            rx_hp_data,
  input  wire  [4:0]             rx_hp_type,
  input  wire                    rx_hp_crc_err,
  input  wire                    rx_dp_valid,
  input  wire  [31:0]            rx_dp_data,
  input  wire                    rx_dp_last,
  input  wire                    rx_dp_crc_err,

  // ---- transmit to link layer --------------------------------------------
  output logic                   tx_hp_valid,
  output logic [95:0]            tx_hp_data,
  input  wire                    tx_hp_ready,
  output logic                   tx_dp_valid,
  output logic [31:0]            tx_dp_data,
  output logic                   tx_dp_last,
  input  wire                    tx_dp_ready,

  // ---- endpoint buffer array ---------------------------------------------
  output logic [EP_ADDR_W-1:0]   ep_sel,
  output logic                   ep_in_rd_en,
  input  wire  [31:0]            ep_in_rd_data,
  input  wire                    ep_in_rd_last,
  input  wire  [NUM_EP-1:0]      ep_in_avail,
  output logic                   ep_out_wr_en,
  output logic [31:0]            ep_out_wr_data,
  output logic                   ep_out_wr_last,
  input  wire  [NUM_EP-1:0]      ep_out_space,
  // Free OUT-buffer entries per endpoint, flattened.  Used to admit a whole
  // OUT packet on the LENGTH IN ITS DPH rather than on a compile-time
  // worst case - see the admission test below.  Audit finding D11.
  input  wire  [NUM_EP*EP_LVL_W-1:0] ep_out_free,

  // ---- status / events ---------------------------------------------------
  output logic [NUM_EP*2-1:0]    ep_state,
  output logic [NUM_EP-1:0]      ep_stalled,
  output logic                   setup_valid,
  output logic [63:0]            setup_data,
  output logic [13:0]            itp_cnt,
  output logic                   evt_setup,
  output logic                   evt_enum_done,
  output logic                   evt_ep_in_done,
  output logic                   evt_ep_out_done,
  output logic                   err_protocol,
  output logic                   err_timeout,
  output logic                   err_overflow,
  output logic                   err_underflow
);

  // ------------------------------------------------------------------------
  // Local parameters
  // ------------------------------------------------------------------------
  // Largest packet in DWORDs, and the staging FIFO depth. The FIFO is twice
  // the maximum packet so the almost-full backpressure used during the fetch
  // phase can never truncate a legal packet.
  localparam int unsigned MAX_WORDS   = MAX_PKT_SS / 4;      // 256 DWORDs
  localparam int unsigned STAGE_DEPTH = 2 * MAX_WORDS;       // 512 entries
  localparam int unsigned STAGE_LW    = $clog2(STAGE_DEPTH) + 1;
  localparam int unsigned CNT_W       = $clog2(MAX_WORDS) + 2; // 0..MAX_WORDS
  localparam int unsigned TO_W        = $clog2(TP_TIMEOUT_CYC + 1);
  localparam int unsigned IDLE_W      = 6;                   // IN underrun win
  localparam logic [IDLE_W-1:0] IDLE_MAX = {IDLE_W{1'b1}};

  // ------------------------------------------------------------------------
  // Header build helpers
  // ------------------------------------------------------------------------
  function automatic logic [95:0] mk_tp (
    input logic [3:0]  subtype,
    input logic [3:0]  epn,
    input logic        dir,
    input logic [4:0]  seq,
    input logic [4:0]  nump,
    input logic [15:0] stream
  );
    logic [31:0] dw0, dw1, dw2;
    dw0 = {cfg_dev_addr, 20'd0, HP_TP};
    dw1 = {6'd0, seq, nump, 4'd0, epn, 1'b0, dir, 2'd0, subtype};
    dw2 = {16'd0, stream};
    return {dw2, dw1, dw0};
  endfunction

  function automatic logic [95:0] mk_dph (
    input logic [3:0]  epn,
    input logic [4:0]  seq,
    input logic        eob,
    input logic        lpf,
    input logic [15:0] len
  );
    logic [31:0] dw0, dw1, dw2;
    dw0 = {cfg_dev_addr, 20'd0, HP_DPH};
    dw1 = {8'd0, lpf, 1'b0, eob, seq, 4'd0, epn, 1'b0, 1'b1, 2'd0, 4'd0};
    dw2 = {16'd0, len};
    return {dw2, dw1, dw0};
  endfunction

  // ------------------------------------------------------------------------
  // Received header decode (combinational)
  // ------------------------------------------------------------------------
  logic [6:0]  rx_addr;
  logic [3:0]  rx_sub;
  logic        rx_dir;
  logic [3:0]  rx_epn;
  logic [4:0]  rx_nump;
  logic [4:0]  rx_seq_tp;
  logic [4:0]  rx_seq_dph;
  logic        rx_eob;
  logic        rx_setup;
  logic [15:0] rx_dw2_lo;   // DPH length / TP stream ID
  logic [13:0] rx_itp;
  logic        rx_addr_ok;
  logic        rx_ep_ok;

  always_comb begin
    rx_addr    = rx_hp_data[31:25];
    rx_sub     = rx_hp_data[35:32];
    rx_dir     = rx_hp_data[38];
    rx_epn     = rx_hp_data[43:40];
    rx_nump    = rx_hp_data[52:48];
    rx_seq_tp  = rx_hp_data[57:53];
    rx_seq_dph = rx_hp_data[52:48];
    rx_eob     = rx_hp_data[53];
    rx_setup   = rx_hp_data[54];
    rx_dw2_lo  = rx_hp_data[79:64];
    rx_itp     = rx_hp_data[45:32];
    rx_addr_ok = cfg_dev_addr_valid ? (rx_addr == cfg_dev_addr)
                                    : (rx_addr == 7'd0);
    // DEFECT FIX (audit finding D4).  Written as `rx_epn < 4'(NUM_EP)` the
    // bound is cast into the SAME four bits as the field it is testing, so at
    // the maximum legal NUM_EP = 16 the bound becomes 4'd0 and rx_ep_ok is
    // false for every endpoint - the device would answer nothing at all. The
    // comparison is taken in 5 bits so it can express the bound.
    rx_ep_ok   = ({1'b0, rx_epn} < 5'(NUM_EP));
  end

  logic [EP_ADDR_W-1:0] rx_ep_idx;
  assign rx_ep_idx = rx_epn[EP_ADDR_W-1:0];

  // ------------------------------------------------------------------------
  // Per-endpoint state
  // ------------------------------------------------------------------------
  logic [4:0]        seq_in_q  [NUM_EP];
  logic [4:0]        seq_out_q [NUM_EP];
  logic [NUM_EP-1:0] halt_q;
  logic [NUM_EP-1:0] eperr_q;
  logic [NUM_EP-1:0] erdy_pend_q;
  logic [NUM_EP-1:0] erdy_dir_q;   // 1 = waiting for IN data, 0 = OUT space

  logic [NUM_EP-1:0] halt_eff;
  logic [NUM_EP-1:0] ep_iso;
  always_comb begin
    for (int unsigned e = 0; e < NUM_EP; e++) begin
      halt_eff[e] = halt_q[e] || cfg_ep_stall[e];
      ep_iso[e]   = (cfg_ep_type[e*2 +: 2] == 2'(EP_ISO));
    end
  end

  // ------------------------------------------------------------------------
  // Transaction context registers
  // ------------------------------------------------------------------------
  typedef enum logic [2:0] {
    PS_IDLE     = 3'd0,
    PS_RX_DATA  = 3'd1,
    PS_TX_HP    = 3'd2,
    PS_IN_FETCH = 3'd3,
    PS_IN_DPH   = 3'd4,
    PS_IN_DATA  = 3'd5,
    PS_IN_END   = 3'd6
  } prot_state_e;

  prot_state_e          st_q;
  logic [EP_ADDR_W-1:0] ep_q;
  logic [95:0]          tx_hp_q;
  logic [15:0]          stream_q;
  logic [5:0]           burst_left_q;
  logic [5:0]           nump_left_q;
  logic [CNT_W-1:0]     fetch_cnt_q;
  logic                 fetch_done_q;
  logic [IDLE_W-1:0]    in_idle_q;
  logic                 out_accept_q;
  logic                 out_setup_q;
  logic [1:0]           out_word_q;
  logic                 ack_out_done_q;
  logic                 ack_in_done_q;
  logic [TO_W-1:0]      to_cnt_q;
  logic [EP_ADDR_W-1:0] rr_ptr_q;
  logic                 addr_valid_q;
  logic [63:0]          setup_data_q;

  // Per-endpoint configuration slices for the selected endpoint.
  logic [11:0] maxpkt_sel;
  logic [4:0]  burst_sel;
  logic [9:0]  words_limit;
  logic [5:0]  burst_pkts;

  // The DPH's length in DWORDs, rounded up, saturated to the buffer width.  A
  // packet is admitted only if THIS many entries are free in the target
  // endpoint's OUT buffer: the protocol layer commits to the whole payload at
  // DPH time and streams it in, so a decision taken on anything less is a
  // promise it cannot keep.  Admitting on a compile-time worst case instead
  // (MAX_PKT_SS) is sound but refuses a short packet that would have fitted,
  // which at EP_FIFO_DEP == MAX_PKT_SS/4 means only one packet in flight ever.
  logic [EP_LVL_W-1:0] rx_out_words;
  always_comb begin
    // ROUND UP TO WHOLE DWORDS WITH A SHIFT, not with a part select.  Written
    // as `w[16:2]` the low two bits of the sum are never read and -Wall reports
    // UNUSEDSIGNAL on them, which failed all 27 whole-design lint
    // configurations.  The shift consumes the whole vector and computes the
    // same ceiling.
    automatic logic [16:0] w  = {1'b0, rx_dw2_lo} + 17'd3;
    automatic logic [16:0] wq = w >> 2;
    rx_out_words = (wq > 17'(EP_FIFO_DEP)) ? EP_LVL_W'(EP_FIFO_DEP)
                                           : EP_LVL_W'(wq);
  end

  always_comb begin
    maxpkt_sel  = cfg_ep_maxpkt[int'(ep_q)*12 +: 12];
    burst_sel   = cfg_ep_burst [int'(ep_q)*5  +:  5];
    burst_pkts  = {1'b0, burst_sel} + 6'd1;
    if (maxpkt_sel[11:2] == 10'd0)            words_limit = 10'd1;
    else if (maxpkt_sel[11:2] > 10'(MAX_WORDS)) words_limit = 10'(MAX_WORDS);
    else                                      words_limit = maxpkt_sel[11:2];
  end

  // ------------------------------------------------------------------------
  // IN packet staging FIFO (exactly one USB packet, DWORD granular)
  // ------------------------------------------------------------------------
  logic                  stage_full, stage_af, stage_empty, stage_ae;
  logic [STAGE_LW-1:0]   stage_level;
  logic                  stage_ovf, stage_unf;
  logic [32:0]           stage_rd;

  assign ep_in_rd_en = (st_q == PS_IN_FETCH) && !fetch_done_q
                       && ep_in_avail[ep_q] && !stage_full && !stage_af;

  usb3_sync_fifo #(
    .WIDTH  (33),
    .DEPTH  (STAGE_DEPTH),
    .AF_LVL (1),
    .AE_LVL (1)
  ) u_stage (
    .clk          (clk),
    .rst_n        (rst_n),
    .push         (ep_in_rd_en),
    .wr_data      ({ep_in_rd_last, ep_in_rd_data}),
    .full         (stage_full),
    .almost_full  (stage_af),
    .pop          (tx_dp_valid && tx_dp_ready),
    .rd_data      (stage_rd),
    .empty        (stage_empty),
    .almost_empty (stage_ae),
    .level        (stage_level),
    .overflow     (stage_ovf),
    .underflow    (stage_unf)
  );

  // ------------------------------------------------------------------------
  // Datapath outputs (combinational off registered state)
  // ------------------------------------------------------------------------
  assign ep_sel         = ep_q;

  assign tx_hp_valid    = (st_q == PS_TX_HP) || (st_q == PS_IN_DPH);
  assign tx_hp_data     = tx_hp_q;

  assign tx_dp_valid    = (st_q == PS_IN_DATA) && !stage_empty;
  assign tx_dp_data     = stage_rd[31:0];
  assign tx_dp_last     = (st_q == PS_IN_DATA) && (stage_level == STAGE_LW'(1));

  assign ep_out_wr_en   = (st_q == PS_RX_DATA) && rx_dp_valid && out_accept_q;
  assign ep_out_wr_data = rx_dp_data;
  assign ep_out_wr_last = rx_dp_last;

  assign setup_data     = setup_data_q;
  assign ep_stalled     = halt_eff;

  always_comb begin
    for (int unsigned e = 0; e < NUM_EP; e++) begin
      if (!cfg_ep_en[e])     ep_state[e*2 +: 2] = 2'(EPS_DISABLED);
      else if (halt_eff[e])  ep_state[e*2 +: 2] = 2'(EPS_HALTED);
      else if (eperr_q[e])   ep_state[e*2 +: 2] = 2'(EPS_ERROR);
      else                   ep_state[e*2 +: 2] = 2'(EPS_RUNNING);
    end
  end

  // ------------------------------------------------------------------------
  // Round-robin selection of the endpoint that needs an ERDY
  // ------------------------------------------------------------------------
  logic [NUM_EP-1:0]    erdy_rdy;
  logic                 erdy_hit;
  logic [EP_ADDR_W-1:0] erdy_ep;

  always_comb begin
    for (int unsigned e = 0; e < NUM_EP; e++) begin
      erdy_rdy[e] = erdy_pend_q[e] && cfg_ep_en[e] && !halt_eff[e]
                    && (erdy_dir_q[e] ? ep_in_avail[e] : ep_out_space[e]);
    end
    erdy_hit = 1'b0;
    erdy_ep  = '0;
    for (int unsigned i = 0; i < NUM_EP; i++) begin
      automatic logic [EP_ADDR_W-1:0] idx = rr_ptr_q + EP_ADDR_W'(i);
      if (!erdy_hit && erdy_rdy[idx]) begin
        erdy_hit = 1'b1;
        erdy_ep  = idx;
      end
    end
  end

  // Space-based NumP granted to the host in an ACK/ERDY TP.
  logic [4:0] grant_nump;
  always_comb begin
    grant_nump = ep_out_space[ep_q] ? burst_sel + 5'd1 : 5'd0;
  end

  // ------------------------------------------------------------------------
  // Main sequential transaction engine
  // ------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q           <= PS_IDLE;
      ep_q           <= '0;
      tx_hp_q        <= '0;
      stream_q       <= '0;
      burst_left_q   <= '0;
      nump_left_q    <= '0;
      fetch_cnt_q    <= '0;
      fetch_done_q   <= 1'b0;
      in_idle_q      <= '0;
      out_accept_q   <= 1'b0;
      out_setup_q    <= 1'b0;
      out_word_q     <= '0;
      ack_out_done_q <= 1'b0;
      ack_in_done_q  <= 1'b0;
      to_cnt_q       <= '0;
      rr_ptr_q       <= '0;
      addr_valid_q   <= 1'b0;
      setup_data_q   <= '0;
      itp_cnt        <= '0;
      halt_q         <= '0;
      eperr_q        <= '0;
      erdy_pend_q    <= '0;
      erdy_dir_q     <= '0;
      setup_valid    <= 1'b0;
      evt_setup      <= 1'b0;
      evt_enum_done  <= 1'b0;
      evt_ep_in_done <= 1'b0;
      evt_ep_out_done<= 1'b0;
      err_protocol   <= 1'b0;
      err_timeout    <= 1'b0;
      err_overflow   <= 1'b0;
      err_underflow  <= 1'b0;
      for (int unsigned e = 0; e < NUM_EP; e++) begin
        seq_in_q[e]  <= '0;
        seq_out_q[e] <= '0;
      end
    end else begin
      // ---- single-cycle pulse defaults ----------------------------------
      setup_valid     <= 1'b0;
      evt_setup       <= 1'b0;
      evt_enum_done   <= 1'b0;
      evt_ep_in_done  <= 1'b0;
      evt_ep_out_done <= 1'b0;
      err_protocol    <= 1'b0;
      err_timeout     <= 1'b0;
      err_overflow    <= 1'b0;
      err_underflow   <= 1'b0;

      // ---- enumeration complete (address assigned) ----------------------
      addr_valid_q <= cfg_dev_addr_valid;
      if (cfg_dev_addr_valid && !addr_valid_q) evt_enum_done <= 1'b1;

      // ---- halt / error bookkeeping -------------------------------------
      for (int unsigned e = 0; e < NUM_EP; e++) begin
        if (cfg_ep_clr_stall[e]) begin
          halt_q[e]  <= 1'b0;
          eperr_q[e] <= 1'b0;
        end
      end
      if (stage_ovf || stage_unf) begin
        err_protocol <= 1'b1;
        halt_q[ep_q] <= 1'b1;
        eperr_q[ep_q]<= 1'b1;
      end

      // ---- ERDY clear when the endpoint can no longer serve -------------
      for (int unsigned e = 0; e < NUM_EP; e++) begin
        if (!cfg_ep_en[e]) erdy_pend_q[e] <= 1'b0;
      end

      // ---- per-transaction timeout --------------------------------------
      if (st_q == PS_IDLE) begin
        to_cnt_q <= '0;
      end else if (to_cnt_q >= TO_W'(TP_TIMEOUT_CYC - 1)) begin
        to_cnt_q     <= '0;
        err_timeout  <= 1'b1;
        st_q         <= PS_IDLE;
        fetch_done_q <= 1'b0;
        fetch_cnt_q  <= '0;
        out_accept_q <= 1'b0;
        out_setup_q  <= 1'b0;
      end else begin
        to_cnt_q <= to_cnt_q + 1'b1;
      end

      // ---- link down aborts everything ----------------------------------
      if (!link_up) begin
        st_q         <= PS_IDLE;
        fetch_done_q <= 1'b0;
        fetch_cnt_q  <= '0;
        out_accept_q <= 1'b0;
        out_setup_q  <= 1'b0;
        erdy_pend_q  <= '0;
        to_cnt_q     <= '0;
      end else begin
        case (st_q)

          // ================================================================
          // Idle: decode an incoming header, otherwise look for an ERDY
          // ================================================================
          PS_IDLE: begin
            if (rx_hp_valid) begin
              if (rx_hp_crc_err) begin
                // Header CRC failure, already reported on ERR_CRC16 by the
                // LINK layer that computed both CRCs (usb3_link.sv err_crc16
                // <= rx_hdr_bad).  Re-reporting it here put a second pulse on
                // the same CDC channel one cycle behind the first and the
                // handshake dropped it - audit finding D16.  What is reported
                // here is the link-control-word CRC-5 bit only; the packet is
                // dropped either way.
                if (hp_type_e'(rx_hp_type) == HP_DPH) begin
                  // Payload still follows and must be consumed and dropped.
                  out_accept_q <= 1'b0;
                  out_setup_q  <= 1'b0;
                  out_word_q   <= '0;
                  st_q         <= PS_RX_DATA;
                end
              end else if (!rx_addr_ok) begin
                // Not addressed to this device: silently ignore.
                if (hp_type_e'(rx_hp_type) == HP_DPH) begin
                  out_accept_q <= 1'b0;
                  out_setup_q  <= 1'b0;
                  out_word_q   <= '0;
                  st_q         <= PS_RX_DATA;
                end
              end else begin
                case (hp_type_e'(rx_hp_type))

                  // ---- Isochronous Timestamp Packet --------------------
                  HP_ITP: begin
                    itp_cnt <= rx_itp;
                  end

                  // ---- Link Management Packet (handled by link layer) --
                  HP_LMP: begin
                    // no protocol-layer action
                  end

                  // ---- Transaction Packet ------------------------------
                  HP_TP: begin
                    if (!rx_ep_ok) begin
                      err_protocol <= 1'b1;
                    end else begin
                      ep_q     <= rx_ep_idx;
                      stream_q <= rx_dw2_lo;
                      case (tp_subtype_e'(rx_sub))
                        TP_PING: begin
                          tx_hp_q <= mk_tp(4'(TP_PING_RSP), rx_epn, rx_dir,
                                           5'd0, 5'd0, rx_dw2_lo);
                          st_q    <= PS_TX_HP;
                        end
                        TP_ACK: begin
                          if (!rx_dir) begin
                            // ACK for an OUT transfer: bookkeeping only.
                            err_protocol <= 1'b1;
                          end else if (halt_eff[rx_ep_idx]) begin
                            tx_hp_q <= mk_tp(4'(TP_STALL), rx_epn, 1'b1,
                                             5'd0, 5'd0, rx_dw2_lo);
                            st_q    <= PS_TX_HP;
                          end else if (!cfg_ep_en[rx_ep_idx]
                                       || !cfg_ep_dir_in[rx_ep_idx]) begin
                            err_protocol    <= 1'b1;
                            eperr_q[rx_ep_idx] <= 1'b1;
                          end else if (rx_seq_tp != seq_in_q[rx_ep_idx]) begin
                            // Sequence number mismatch -> protocol error.
                            err_protocol    <= 1'b1;
                            eperr_q[rx_ep_idx] <= 1'b1;
                          end else if (rx_nump == 5'd0) begin
                            // No credit: nothing to do.
                            err_protocol <= 1'b1;
                          end else if (ep_in_avail[rx_ep_idx]) begin
                            burst_left_q <= ({1'b0, rx_nump} < burst_pkts)
                                            ? {1'b0, rx_nump} : burst_pkts;
                            nump_left_q  <= {1'b0, rx_nump};
                            fetch_cnt_q  <= '0;
                            fetch_done_q <= 1'b0;
                            in_idle_q    <= '0;
                            st_q         <= PS_IN_FETCH;
                          end else if (!ep_iso[rx_ep_idx]) begin
                            tx_hp_q <= mk_tp(4'(TP_NRDY), rx_epn, 1'b1,
                                             seq_in_q[rx_ep_idx], 5'd0,
                                             rx_dw2_lo);
                            erdy_pend_q[rx_ep_idx] <= 1'b1;
                            erdy_dir_q [rx_ep_idx] <= 1'b1;
                            st_q    <= PS_TX_HP;
                          end
                        end
                        TP_STATUS: begin
                          // EP0 status stage: acknowledge immediately.
                          if (rx_ep_idx == '0) begin
                            tx_hp_q <= mk_tp(4'(TP_ACK), rx_epn, rx_dir,
                                             seq_in_q[0], 5'd1, rx_dw2_lo);
                            st_q    <= PS_TX_HP;
                          end else begin
                            err_protocol <= 1'b1;
                          end
                        end
                        TP_NRDY, TP_ERDY, TP_STALL,
                        TP_DEV_NOTIF, TP_PING_RSP: begin
                          // Host-sourced informational TPs: no action.
                        end
                        default: begin
                          err_protocol <= 1'b1;
                        end
                      endcase
                    end
                  end

                  // ---- Data Packet Header (OUT data) -------------------
                  HP_DPH: begin
                    out_word_q <= '0;
                    st_q       <= PS_RX_DATA;
                    if (!rx_ep_ok) begin
                      err_protocol <= 1'b1;
                      out_accept_q <= 1'b0;
                      out_setup_q  <= 1'b0;
                      tx_hp_q      <= mk_tp(4'(TP_ACK), rx_epn, 1'b0,
                                            5'd0, 5'd0, rx_dw2_lo);
                      ack_out_done_q <= 1'b0;
                    end else begin
                      ep_q     <= rx_ep_idx;
                      stream_q <= rx_dw2_lo;
                      if (rx_dir) begin
                        // A device never receives an IN direction DPH.
                        err_protocol   <= 1'b1;
                        out_accept_q   <= 1'b0;
                        out_setup_q    <= 1'b0;
                        ack_out_done_q <= 1'b0;
                        tx_hp_q        <= mk_tp(4'(TP_ACK), rx_epn, 1'b0,
                                                seq_out_q[rx_ep_idx], 5'd0,
                                                rx_dw2_lo);
                      end else if (halt_eff[rx_ep_idx]) begin
                        out_accept_q   <= 1'b0;
                        out_setup_q    <= 1'b0;
                        ack_out_done_q <= 1'b0;
                        tx_hp_q        <= mk_tp(4'(TP_STALL), rx_epn, 1'b0,
                                                5'd0, 5'd0, rx_dw2_lo);
                      end else if (!cfg_ep_en[rx_ep_idx]) begin
                        err_protocol   <= 1'b1;
                        out_accept_q   <= 1'b0;
                        out_setup_q    <= 1'b0;
                        ack_out_done_q <= 1'b0;
                        tx_hp_q        <= mk_tp(4'(TP_ACK), rx_epn, 1'b0,
                                                seq_out_q[rx_ep_idx], 5'd0,
                                                rx_dw2_lo);
                      end else if (rx_out_words > ep_out_free[int'(rx_ep_idx)*EP_LVL_W +: EP_LVL_W]) begin
                        // No room: drop the payload, ask the host to retry.
                        err_overflow   <= 1'b1;
                        out_accept_q   <= 1'b0;
                        out_setup_q    <= 1'b0;
                        ack_out_done_q <= 1'b0;
                        erdy_pend_q[rx_ep_idx] <= !ep_iso[rx_ep_idx];
                        erdy_dir_q [rx_ep_idx] <= 1'b0;
                        tx_hp_q        <= mk_tp(4'(TP_NRDY), rx_epn, 1'b0,
                                                seq_out_q[rx_ep_idx], 5'd0,
                                                rx_dw2_lo);
                      end else if (rx_seq_dph != seq_out_q[rx_ep_idx]) begin
                        err_protocol      <= 1'b1;
                        eperr_q[rx_ep_idx]<= 1'b1;
                        out_accept_q      <= 1'b0;
                        out_setup_q       <= 1'b0;
                        ack_out_done_q    <= 1'b0;
                        tx_hp_q           <= mk_tp(4'(TP_ACK), rx_epn, 1'b0,
                                                   seq_out_q[rx_ep_idx], 5'd1,
                                                   rx_dw2_lo);
                      end else begin
                        out_accept_q   <= 1'b1;
                        out_setup_q    <= rx_setup && (rx_ep_idx == '0);
                        ack_out_done_q <= 1'b1;
                      end
                    end
                    if (rx_eob) begin
                      // End-of-burst marker is informational for a device.
                      erdy_dir_q[rx_ep_idx] <= 1'b0;
                    end
                  end

                  default: begin
                    err_protocol <= 1'b1;
                  end
                endcase
              end
            end else if (erdy_hit) begin
              // Flow control resumed: notify the host with an ERDY TP.
              ep_q     <= erdy_ep;
              rr_ptr_q <= erdy_ep + 1'b1;
              erdy_pend_q[erdy_ep] <= 1'b0;
              tx_hp_q  <= mk_tp(4'(TP_ERDY), 4'(erdy_ep), erdy_dir_q[erdy_ep],
                                erdy_dir_q[erdy_ep] ? seq_in_q [erdy_ep]
                                                    : seq_out_q[erdy_ep],
                                erdy_dir_q[erdy_ep] ? 5'd1 : 5'd1,
                                stream_q);
              st_q     <= PS_TX_HP;
            end
          end

          // ================================================================
          // Receive OUT payload
          // ================================================================
          PS_RX_DATA: begin
            if (rx_dp_valid) begin
              if (out_setup_q && (out_word_q < 2'd2)) begin
                out_word_q <= out_word_q + 2'd1;
                if (out_word_q == 2'd0) setup_data_q[31:0]  <= rx_dp_data;
                else                    setup_data_q[63:32] <= rx_dp_data;
              end
              if (rx_dp_last) begin
                st_q         <= PS_TX_HP;
                out_accept_q <= 1'b0;
                if (rx_dp_crc_err) begin
                  // Payload CRC-32 failure: do not advance the sequence
                  // number so the host retries the packet.  The CRC-32 failure
                  // ITSELF is reported by the link layer, which computed it -
                  // raising it again here put a second pulse on the ERR_CRC32
                  // CDC channel one cycle behind the link's and the handshake
                  // dropped it (audit finding D16, same shape as ERR_CRC16).
                  // The PROTOCOL consequence is this layer's to report.
                  err_protocol   <= 1'b1;
                  ack_out_done_q <= 1'b0;
                  tx_hp_q        <= mk_tp(4'(TP_ACK), 4'(ep_q), 1'b0,
                                          seq_out_q[ep_q], grant_nump,
                                          stream_q);
                end else if (out_accept_q) begin
                  seq_out_q[ep_q] <= seq_out_q[ep_q] + 5'd1;
                  tx_hp_q         <= mk_tp(4'(TP_ACK), 4'(ep_q), 1'b0,
                                           seq_out_q[ep_q] + 5'd1, grant_nump,
                                           stream_q);
                  if (grant_nump == 5'd0) begin
                    erdy_pend_q[ep_q] <= !ep_iso[ep_q];
                    erdy_dir_q [ep_q] <= 1'b0;
                  end
                  if (out_setup_q) begin
                    setup_valid <= 1'b1;
                    evt_setup   <= 1'b1;
                  end
                end
                out_setup_q <= 1'b0;
              end
            end
          end

          // ================================================================
          // Transmit a prepared header packet (TP)
          // ================================================================
          PS_TX_HP: begin
            if (tx_hp_ready) begin
              st_q <= PS_IDLE;
              if (ack_out_done_q) evt_ep_out_done <= 1'b1;
              ack_out_done_q <= 1'b0;
            end
          end

          // ================================================================
          // Drain one IN packet from the endpoint FIFO into the staging FIFO
          // ================================================================
          PS_IN_FETCH: begin
            if (ep_in_rd_en) begin
              in_idle_q   <= '0;
              fetch_cnt_q <= fetch_cnt_q + 1'b1;
              // CNT_W shrinks with MAX_PKT_SS while words_limit stays 10 bits,
              // so the comparison is taken in the wider of the two.
              if (ep_in_rd_last
                  || ((10'(fetch_cnt_q) + 10'd1) == words_limit)) begin
                fetch_done_q <= 1'b1;
                tx_hp_q <= mk_dph(4'(ep_q), seq_in_q[ep_q],
                                  (burst_left_q <= 6'd1) || (nump_left_q <= 6'd1),
                                  ep_in_rd_last,
                                  16'({fetch_cnt_q + 1'b1, 2'b00}));
                st_q    <= PS_IN_DPH;
              end
            end else if (!ep_in_avail[ep_q]) begin
              if (in_idle_q == IDLE_MAX) begin
                in_idle_q     <= '0;
                err_underflow <= 1'b1;
                if (fetch_cnt_q != '0) begin
                  // Truncate the packet at what we already have.
                  fetch_done_q <= 1'b1;
                  tx_hp_q <= mk_dph(4'(ep_q), seq_in_q[ep_q], 1'b1, 1'b1,
                                    16'({fetch_cnt_q, 2'b00}));
                  st_q    <= PS_IN_DPH;
                end else begin
                  // Nothing at all: fall back to flow control.
                  erdy_pend_q[ep_q] <= !ep_iso[ep_q];
                  erdy_dir_q [ep_q] <= 1'b1;
                  tx_hp_q <= mk_tp(4'(TP_NRDY), 4'(ep_q), 1'b1,
                                   seq_in_q[ep_q], 5'd0, stream_q);
                  st_q    <= PS_TX_HP;
                end
              end else begin
                in_idle_q <= in_idle_q + 1'b1;
              end
            end
          end

          // ================================================================
          // Transmit the DPH, then its payload
          // ================================================================
          PS_IN_DPH: begin
            if (tx_hp_ready) st_q <= PS_IN_DATA;
          end

          PS_IN_DATA: begin
            if (tx_dp_valid && tx_dp_ready && tx_dp_last) st_q <= PS_IN_END;
          end

          // ================================================================
          // Close the packet and decide whether the burst continues
          // ================================================================
          PS_IN_END: begin
            seq_in_q[ep_q] <= seq_in_q[ep_q] + 5'd1;
            burst_left_q   <= (burst_left_q != '0) ? burst_left_q - 6'd1 : '0;
            nump_left_q    <= (nump_left_q  != '0) ? nump_left_q  - 6'd1 : '0;
            if ((burst_left_q > 6'd1) && (nump_left_q > 6'd1)
                && ep_in_avail[ep_q] && !halt_eff[ep_q]) begin
              fetch_cnt_q  <= '0;
              fetch_done_q <= 1'b0;
              in_idle_q    <= '0;
              st_q         <= PS_IN_FETCH;
            end else begin
              ack_in_done_q  <= 1'b0;
              evt_ep_in_done <= 1'b1;
              st_q           <= PS_IDLE;
            end
          end

          default: begin
            // Safe recovery from an illegal encoding.
            st_q         <= PS_IDLE;
            fetch_done_q <= 1'b0;
            fetch_cnt_q  <= '0;
            out_accept_q <= 1'b0;
            out_setup_q  <= 1'b0;
            err_protocol <= 1'b1;
          end
        endcase
      end
    end
  end

  // ------------------------------------------------------------------------
  // Deliberately unconsumed inputs and flags, named one by one so that -Wall
  // reports a single reviewed sink rather than a scatter of UNUSEDSIGNAL
  // warnings that would hide the next real one.  Each entry is a statement
  // about the design, and each is recorded in doc/usb3_conformance_audit.md.
  //
  //   rx_hp_data[24:0]   DW0 Type + Route String.  The Type is delivered
  //                      separately on rx_hp_type; a DEVICE ignores the route
  //                      string (it is a hub field).                    [ok]
  //   rx_hp_data[47:46]  DW1[15:14], the pp / bei attribute bits.  NOT checked
  //                      against their reserved encodings - audit finding P3.
  //   rx_hp_data[63:58]  DW1[31:26] reserved.  NOT checked - finding P3.
  //   rx_hp_data[95:80]  DW2[31:16] reserved.   NOT checked - finding P3.
  //   maxpkt_sel[1:0]    payload transfers are DWORD granular (see the header
  //                      of this file), so a maximum packet size that is not a
  //                      multiple of 4 is rounded DOWN.  Documented
  //                      assumption, not an oversight.
  //   stage_ae/stage_rd[32]  the staging FIFO is sized and terminated from
  //                      stage_level, so its almost-empty flag and the
  //                      replicated per-word "last" bit are redundant here.
  //   ack_in_done_q      reserved bookkeeping for future per-packet IN
  //                      acknowledge tracking.
  //   cfg_ep_dir_in      consulted only for IN endpoints on the ACK path; the
  //                      OUT path derives direction from the DPH.
  // ------------------------------------------------------------------------
  logic unused_ok;
  assign unused_ok = ack_in_done_q | (|cfg_ep_dir_in)
                     | stage_ae | stage_rd[32]
                     | (|maxpkt_sel[1:0])
                     | (|rx_hp_data[24:0])  | (|rx_hp_data[47:46])
                     | (|rx_hp_data[63:58]) | (|rx_hp_data[95:80]);

endmodule

`default_nettype wire
