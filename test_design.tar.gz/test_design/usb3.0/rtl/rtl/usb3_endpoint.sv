// ============================================================================
// usb3_endpoint.sv
// One USB 3.0 device endpoint buffer: an IN (device->host) and an OUT
// (host->device) asynchronous FIFO pair plus flush control.
//
//   IN  FIFO : write side aclk (scatter-gather DMA), read side pclk (protocol)
//   OUT FIFO : write side pclk (protocol),           read side aclk (DMA)
//   WIDTH    = 33  -> {last, data[31:0]}, "last" marks the final DWORD of a
//                     USB packet so the protocol layer can size a DPH and the
//                     DMA can close a descriptor.
//   DEPTH    = EP_FIFO_DEP entries (power of two).
//
// Flush
//   cfg_ep_flush_a is a single-cycle aclk pulse. It is transported into pclk
//   with usb3_pulse_sync and stretched by a 4-bit down counter in EACH clock
//   domain. While a domain's stretcher is active the corresponding FIFO reset
//   input is forced low, which clears that FIFO's pointers.  Because the two
//   stretchers are not phase aligned the FIFO pointers are only guaranteed to
//   be coherent after both windows have expired.
//
//   ASSUMPTION (documented contract with software): an endpoint is only
//   flushed while it is DISABLED (EP_CTRL.en = 0), i.e. no protocol-layer or
//   DMA traffic is in flight for this endpoint.  Under that condition the
//   staggered per-domain reset windows cannot corrupt live data, and both
//   FIFOs are empty and coherent once the longer of the two windows (16 aclk
//   / 16 pclk cycles plus the CDC latency) has elapsed.
// ============================================================================
`default_nettype none

module usb3_endpoint
  import usb3_pkg::*;
#(
  parameter int unsigned DEPTH   = EP_FIFO_DEP,
  parameter int unsigned FLUSH_W = 4          // stretcher width (2**W-1 cycles)
) (
  // ---- clocks / resets ---------------------------------------------------
  input  wire        pclk,
  input  wire        prst_n,
  input  wire        aclk,
  input  wire        arst_n,

  // ---- flush (aclk pulse) ------------------------------------------------
  input  wire        cfg_ep_flush_a,

  // ---- IN FIFO : DMA write side (aclk) -----------------------------------
  input  wire        dma_in_wr_en,
  input  wire [31:0] dma_in_wr_data,
  input  wire        dma_in_wr_last,
  output wire        dma_in_full,

  // ---- IN FIFO : protocol read side (pclk) -------------------------------
  input  wire        ep_in_rd_en,
  output wire [31:0] ep_in_rd_data,
  output wire        ep_in_rd_last,
  output wire        ep_in_avail,      // IN FIFO not empty

  // ---- OUT FIFO : protocol write side (pclk) -----------------------------
  input  wire        ep_out_wr_en,
  input  wire [31:0] ep_out_wr_data,
  input  wire        ep_out_wr_last,
  output wire        ep_out_space,     // OUT FIFO not almost-full
  // Free entries in the OUT FIFO, write side.  The protocol layer admits a
  // whole OUT packet on one look, so it needs to compare the LENGTH ON THE
  // WIRE against this - a flag can only ever encode one compile-time packet
  // size, and the size that matters is the one in the DPH.
  output wire [$clog2(DEPTH):0] ep_out_free,

  // ---- OUT FIFO : DMA read side (aclk) -----------------------------------
  input  wire        dma_out_rd_en,
  output wire [31:0] dma_out_rd_data,
  output wire        dma_out_rd_last,
  output wire        dma_out_empty
);

  // ---- elaboration guards ---------------------------------------------
  // DEPTH is passed straight to two usb3_async_fifo instances, which carry
  // their own range and power-of-two guards; this one exists so a wrong DEPTH
  // is attributed to the endpoint rather than to a primitive two levels down.
  if (DEPTH < 4) begin : g_chk_depth_min
    $error("usb3_endpoint: DEPTH must be >= 4 (got %0d)", DEPTH);
  end
  if ((DEPTH & (DEPTH - 1)) != 0) begin : g_chk_depth_pow2
    $error("usb3_endpoint: DEPTH must be a power of two (got %0d)", DEPTH);
  end
  if (FLUSH_W < 2) begin : g_chk_flush_min
    $error("usb3_endpoint: FLUSH_W must be >= 2 (got %0d): the flush window must outlast the CDC handshake latency",
           FLUSH_W);
  end
  if (FLUSH_W > 16) begin : g_chk_flush_max
    $error("usb3_endpoint: FLUSH_W must be <= 16 (got %0d)", FLUSH_W);
  end

  localparam int unsigned FW = 33; // {last, data[31:0]}

  // ------------------------------------------------------------------------
  // Flush pulse CDC (aclk -> pclk) and per-domain stretchers
  // ------------------------------------------------------------------------
  logic flush_p_pulse;
  logic flush_src_busy;

  usb3_pulse_sync u_flush_sync (
    .src_clk   (aclk),
    .src_rst_n (arst_n),
    .src_pulse (cfg_ep_flush_a),
    .src_busy  (flush_src_busy),
    .dst_clk   (pclk),
    .dst_rst_n (prst_n),
    .dst_pulse (flush_p_pulse)
  );

  // A flush request arriving while the previous one is still crossing is
  // dropped (src_busy); software must not issue back-to-back flushes.
  logic flush_dropped_q;
  always_ff @(posedge aclk or negedge arst_n) begin
    if (!arst_n) flush_dropped_q <= 1'b0;
    else         flush_dropped_q <= cfg_ep_flush_a && flush_src_busy;
  end

  logic [FLUSH_W-1:0] flush_cnt_a;
  always_ff @(posedge aclk or negedge arst_n) begin
    if (!arst_n)                   flush_cnt_a <= '0;
    else if (cfg_ep_flush_a)       flush_cnt_a <= {FLUSH_W{1'b1}};
    else if (flush_cnt_a != '0)    flush_cnt_a <= flush_cnt_a - 1'b1;
  end
  wire flush_act_a = (flush_cnt_a != '0);

  logic [FLUSH_W-1:0] flush_cnt_p;
  always_ff @(posedge pclk or negedge prst_n) begin
    if (!prst_n)                   flush_cnt_p <= '0;
    else if (flush_p_pulse)        flush_cnt_p <= {FLUSH_W{1'b1}};
    else if (flush_cnt_p != '0)    flush_cnt_p <= flush_cnt_p - 1'b1;
  end
  wire flush_act_p = (flush_cnt_p != '0);

  // Gated FIFO resets (synchronous assert, synchronous deassert on top of the
  // asynchronous system reset).
  wire arst_fifo_n = arst_n && !flush_act_a;
  wire prst_fifo_n = prst_n && !flush_act_p;

  // ------------------------------------------------------------------------
  // IN FIFO : aclk (write) -> pclk (read)
  // ------------------------------------------------------------------------
  wire [FW-1:0] in_rd_word;
  wire          in_rd_empty;
  wire          in_rd_ae;
  wire          in_wr_af;
  wire [$clog2(DEPTH):0] in_wr_level;

  usb3_async_fifo #(.WIDTH(FW), .DEPTH(DEPTH)) u_fifo_in (
    .wr_clk          (aclk),
    .wr_rst_n        (arst_fifo_n),
    .wr_en           (dma_in_wr_en),
    .wr_data         ({dma_in_wr_last, dma_in_wr_data}),
    .wr_full         (dma_in_full),
    .wr_almost_full  (in_wr_af),
    .wr_level        (in_wr_level),
    .rd_clk          (pclk),
    .rd_rst_n        (prst_fifo_n),
    .rd_en           (ep_in_rd_en),
    .rd_data         (in_rd_word),
    .rd_empty        (in_rd_empty),
    .rd_almost_empty (in_rd_ae)
  );

  assign ep_in_rd_data = in_rd_word[31:0];
  assign ep_in_rd_last = in_rd_word[32];
  assign ep_in_avail   = !in_rd_empty;

  // ------------------------------------------------------------------------
  // OUT FIFO : pclk (write) -> aclk (read)
  // ------------------------------------------------------------------------
  wire [FW-1:0] out_rd_word;
  wire          out_wr_full;
  wire          out_wr_af;
  wire [$clog2(DEPTH):0] out_wr_level;
  wire          out_rd_ae;

  // ep_out_space is a coarse "there is room for something" hint, used for the
  // ERDY/NumP heuristics.  It is NOT what admits an OUT packet: the protocol
  // layer commits to a whole payload at DPH time, and the only sound test for
  // that is the packet's own length against ep_out_free.  Audit finding D11 -
  // before it, admission was taken on this flag, which guaranteed two free
  // entries while the layer reading it wrote up to MAX_PKT_SS/4 DWORDs, so the
  // buffer overflowed part way through an accepted packet and the tail was
  // silently discarded at wr_full while the host was told the packet arrived.
  usb3_async_fifo #(.WIDTH(FW), .DEPTH(DEPTH)) u_fifo_out (
    .wr_clk          (pclk),
    .wr_rst_n        (prst_fifo_n),
    .wr_en           (ep_out_wr_en),
    .wr_data         ({ep_out_wr_last, ep_out_wr_data}),
    .wr_full         (out_wr_full),
    .wr_almost_full  (out_wr_af),
    .wr_level        (out_wr_level),
    .rd_clk          (aclk),
    .rd_rst_n        (arst_fifo_n),
    .rd_en           (dma_out_rd_en),
    .rd_data         (out_rd_word),
    .rd_empty        (dma_out_empty),
    .rd_almost_empty (out_rd_ae)
  );

  assign dma_out_rd_data = out_rd_word[31:0];
  assign dma_out_rd_last = out_rd_word[32];

  // "Space" is an ADMISSION flag, taken from the almost-full level configured
  // above: true means a whole maximum-size packet fits.  It necessarily goes
  // away as the packet it admitted is written in, so it is not a per-beat
  // flag - the per-beat invariant is !out_wr_full, asserted in
  // rtl/sva/usb3_endpoint_sva.sv.
  assign ep_out_space = !(out_wr_af || out_wr_full);
  assign ep_out_free  = ($clog2(DEPTH)+1)'(DEPTH) - out_wr_level;

  // ------------------------------------------------------------------------
  // Observability of otherwise unused FIFO flags (kept for debug/lint).
  // ------------------------------------------------------------------------
  wire unused_ok;
  assign unused_ok = in_wr_af | in_rd_ae | out_rd_ae | flush_dropped_q | (|in_wr_level);

endmodule

`default_nettype wire
