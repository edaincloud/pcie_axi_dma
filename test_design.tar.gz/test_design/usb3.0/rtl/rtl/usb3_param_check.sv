// ---------------------------------------------------------------------------
// usb3_param_check : the elaboration guards for every usb3_pkg geometry
//                    constant.
//
// WHY THIS IS A MODULE OF ITS OWN
//   The USB3 geometry lives in usb3_pkg because it appears in the PORT LISTS of
//   most modules (see the header of usb3_pkg.sv). A package cannot contain an
//   elaboration-time check, so the guards live here, and
//   usb3_device_controller instantiates this module so that no whole-design
//   build can escape them.
//
//   Keeping them in a module with NO other content is deliberate. An illegal
//   geometry provokes width, range and replication errors all over the design
//   at the same time, and a tool that stops at the first one would never reach
//   the guard. Driving the negative-elaboration test at THIS module as the top
//   means the guard's own message is the only thing that can be reported, so
//   "rejected" and "rejected by the guard under test" cannot be confused.
//   run/scripts/elab_check.sh checks BOTH: the guard fires here, and
//   usb3_device_controller is rejected too.
//
// EVERY MESSAGE IS UNIQUE. That is a hard requirement, not a style point: the
// negative test greps for the specific text, and two guards sharing a message
// would let one of them never fire while the test stayed green.
//
// PARAMETER ARITHMETIC
//   Every span comparison below is evaluated in a 64-bit context
//   (`longint unsigned`), per .skills/tapeout_grade_rtl/rtl.md: a shift or a
//   product evaluated in the width of the parameter under test silently yields
//   zero and turns a guard into a no-op.
// ---------------------------------------------------------------------------
`ifndef USB3_PARAM_CHECK_SV
`define USB3_PARAM_CHECK_SV
`default_nettype none

module usb3_param_check
  import usb3_pkg::*;
();

  // 64-bit copies, so no comparison is ever evaluated in the width of the
  // constant it is testing.
  localparam longint unsigned L_NUM_EP      = longint'(NUM_EP);
  localparam longint unsigned L_MAX_PKT_SS  = longint'(MAX_PKT_SS);
  localparam longint unsigned L_EP_FIFO_DEP = longint'(EP_FIFO_DEP);
  localparam longint unsigned L_APB_ADDR_W  = longint'(APB_ADDR_W);
  localparam longint unsigned L_RX_CREDIT   = longint'(NUM_RX_CREDIT);
  localparam longint unsigned L_EP_TOP      = longint'(EP_REGION_TOP);

  // DWORDs in the largest packet the protocol layer must stage.
  localparam longint unsigned L_MAX_WORDS   = L_MAX_PKT_SS / 64'd4;

  // ------------------------------------------------------------- endpoints
  // NUM_EP = 1 makes EP_ADDR_W = $clog2(1) = 0, so ep_sel, dma_ep_sel and
  // every one-hot decode in usb3_ep_array collapse to zero width.
  if (L_NUM_EP < 2) begin : g_chk_num_ep_min
    $error("usb3_param_check: NUM_EP must be >= 2 (got %0d): $clog2(1) is 0 and every endpoint-index port would be zero width",
           NUM_EP);
  end
  // The Endpoint Number field of a SuperSpeed header packet is 4 bits
  // (usb3_protocol.sv, DW1[11:8]), so 16 endpoints is the protocol maximum.
  if (L_NUM_EP > 16) begin : g_chk_num_ep_max
    $error("usb3_param_check: NUM_EP must be <= 16 (got %0d): the header-packet Endpoint Number field is 4 bits",
           NUM_EP);
  end
  // usb3_ep_array decodes ep_sel with a flat one-hot over EP_ADDR_W bits, and
  // usb3_apb_csr slices ep_idx out of paddr[4 +: EP_ADDR_W]; a non-power-of-two
  // count leaves aliased and undecodable indices in both.
  if ((L_NUM_EP & (L_NUM_EP - 1)) != 0) begin : g_chk_num_ep_pow2
    $error("usb3_param_check: NUM_EP must be a power of two (got %0d)",
           NUM_EP);
  end

  // --------------------------------------------------------- max packet size
  if (L_MAX_PKT_SS < 64) begin : g_chk_maxpkt_min
    $error("usb3_param_check: MAX_PKT_SS must be >= 64 (got %0d): a SuperSpeed control endpoint has a 512-byte maximum packet and the staging FIFO must hold at least one packet",
           MAX_PKT_SS);
  end
  // USB 3.0 fixes the SuperSpeed bulk maximum packet size at 1024 bytes.
  if (L_MAX_PKT_SS > 1024) begin : g_chk_maxpkt_max
    $error("usb3_param_check: MAX_PKT_SS must be <= 1024 (got %0d): USB 3.0 fixes the SuperSpeed bulk maximum packet size at 1024 bytes",
           MAX_PKT_SS);
  end
  if ((L_MAX_PKT_SS & (L_MAX_PKT_SS - 1)) != 0) begin : g_chk_maxpkt_pow2
    $error("usb3_param_check: MAX_PKT_SS must be a power of two (got %0d)",
           MAX_PKT_SS);
  end

  // ------------------------------------------------------ endpoint FIFO depth
  if (L_EP_FIFO_DEP < 4) begin : g_chk_fifo_min
    $error("usb3_param_check: EP_FIFO_DEP must be >= 4 (got %0d): usb3_async_fifo needs $clog2(DEPTH) >= 2 for its Gray pointer comparison",
           EP_FIFO_DEP);
  end
  if (L_EP_FIFO_DEP > 4096) begin : g_chk_fifo_max
    $error("usb3_param_check: EP_FIFO_DEP must be <= 4096 (got %0d): the per-endpoint buffer pair is instantiated NUM_EP times and is intended for flops or a small SRAM",
           EP_FIFO_DEP);
  end
  if ((L_EP_FIFO_DEP & (L_EP_FIFO_DEP - 1)) != 0) begin : g_chk_fifo_pow2
    $error("usb3_param_check: EP_FIFO_DEP must be a power of two (got %0d)",
           EP_FIFO_DEP);
  end
  // Cross-constraint: an endpoint buffer smaller than one maximum-size packet
  // cannot hold a whole IN packet, so usb3_protocol's fetch phase would stall
  // and truncate every packet through its underrun path.
  if (L_EP_FIFO_DEP < L_MAX_WORDS) begin : g_chk_fifo_holds_packet
    $error("usb3_param_check: EP_FIFO_DEP=%0d cannot hold one MAX_PKT_SS=%0d packet (needs >= %0d entries of 32 bits)",
           EP_FIFO_DEP, MAX_PKT_SS, int'(L_MAX_WORDS));
  end

  // ------------------------------------------------------------ APB address
  // usb3_apb_csr decodes with `case (paddr[11:0])`, so paddr must have at
  // least 12 bits regardless of how few endpoints are built.
  if (L_APB_ADDR_W < 12) begin : g_chk_apb_min
    $error("usb3_param_check: APB_ADDR_W must be >= 12 (got %0d): usb3_apb_csr decodes paddr[11:0]",
           APB_ADDR_W);
  end
  if (L_APB_ADDR_W > 32) begin : g_chk_apb_max
    $error("usb3_param_check: APB_ADDR_W must be <= 32 (got %0d): APB4 defines a 32-bit address bus",
           APB_ADDR_W);
  end
  // The register map itself must fit.  EP_REGION_TOP is EP_BASE + NUM_EP *
  // EP_STRIDE and grows with the endpoint count.  Evaluated in 64 bits so the
  // shift is never taken in the width of the parameter under test.
  if ((64'd1 << L_APB_ADDR_W) < L_EP_TOP) begin : g_chk_apb_spans_map
    $error("usb3_param_check: APB_ADDR_W=%0d cannot span the register map (needs to reach byte %0d)",
           APB_ADDR_W, int'(L_EP_TOP));
  end
  // EP_BASE/EP_STRIDE are 12-bit constants, so the endpoint window must stay
  // inside 4 KB however many endpoints are built.
  if (L_EP_TOP > 4096) begin : g_chk_ep_window
    $error("usb3_param_check: the endpoint register window ends at byte %0d, past the 4096-byte block EP_BASE/EP_STRIDE are declared in",
           int'(L_EP_TOP));
  end

  // ---------------------------------------------------- rx header credits
  if (L_RX_CREDIT < 1) begin : g_chk_cred_min
    $error("usb3_param_check: NUM_RX_CREDIT must be >= 1 (got %0d): with no header buffer the link can never accept a header packet",
           NUM_RX_CREDIT);
  end
  // rx_cred_idx_q in usb3_link.sv is the 2-bit LCRD_A..LCRD_D index.
  if (L_RX_CREDIT > 4) begin : g_chk_cred_max
    $error("usb3_param_check: NUM_RX_CREDIT must be <= 4 (got %0d): the LCRD_x credit index is 2 bits (A..D)",
           NUM_RX_CREDIT);
  end

  // ------------------------------------------------------- 8b/10b K symbols
  // WHY THE SYMBOL TABLE IS GUARDED HERE AND NOT ONLY IN A TESTBENCH.
  //
  // The K-symbol values in usb3_pkg are imported by BOTH the design and the
  // PIPE agent, so the framer and the de-framer agree with each other for any
  // mutually-distinct table at all.  Every packet test passes on a table that
  // no real host would interoperate with, and that is exactly what happened:
  // four of the seven were wrong (audit finding D5) and 49 regression jobs
  // said nothing.  A checker that derives its expectation from the thing under
  // test cannot fail, so the expectation is written here as LITERALS.
  //
  // The literals are the USB 3.0 special-symbol assignment.  8b/10b encodes a
  // control character Kx.y as {y[2:0], x[4:0]}, so each value below is
  // arithmetically checkable against the Kx.y name in its message.
  //
  // Each guard carries a UNIQUE message so run/scripts/elab_check.sh can grep
  // for the specific one, and so a negative test cannot pass because some
  // OTHER guard fired.
  if (K_SKP !== 8'h3C) begin : g_chk_ksym_skp
    $error("usb3_param_check: K_SKP must be 8'h3C (K28.1), got 8'h%02h: SKP is the USB 3.0 skip ordered set symbol",
           K_SKP);
  end
  if (K_SDP !== 8'h5C) begin : g_chk_ksym_sdp
    $error("usb3_param_check: K_SDP must be 8'h5C (K28.2), got 8'h%02h: SDP is the USB 3.0 start-data-packet symbol",
           K_SDP);
  end
  if (K_EDB !== 8'h7C) begin : g_chk_ksym_edb
    $error("usb3_param_check: K_EDB must be 8'h7C (K28.3), got 8'h%02h: EDB is the USB 3.0 end-bad symbol",
           K_EDB);
  end
  if (K_COM !== 8'hBC) begin : g_chk_ksym_com
    $error("usb3_param_check: K_COM must be 8'hBC (K28.5), got 8'h%02h: COM is the USB 3.0 comma / ordered-set start symbol",
           K_COM);
  end
  if (K_END !== 8'hFD) begin : g_chk_ksym_end
    $error("usb3_param_check: K_END must be 8'hFD (K29.7), got 8'h%02h: END is the USB 3.0 end-of-packet symbol, and 8'hF7 is K23.7 (EPF), a different symbol",
           K_END);
  end
  if (K_SLC !== 8'hFE) begin : g_chk_ksym_slc
    $error("usb3_param_check: K_SLC must be 8'hFE (K30.7), got 8'h%02h: SLC is the USB 3.0 start-link-command symbol",
           K_SLC);
  end
  if (K_SHP !== 8'hFB) begin : g_chk_ksym_shp
    $error("usb3_param_check: K_SHP must be 8'hFB (K27.7), got 8'h%02h: SHP is the USB 3.0 start-header-packet symbol",
           K_SHP);
  end
  // Distinctness is implied by the seven guards above, but it is the property
  // the FRAMER depends on, so it is stated separately: a future edit that
  // relaxes one of the guards must still not be able to alias two symbols.
  if ((K_SKP == K_SDP) || (K_SKP == K_EDB) || (K_SKP == K_COM) ||
      (K_SKP == K_END) || (K_SKP == K_SLC) || (K_SKP == K_SHP) ||
      (K_SDP == K_EDB) || (K_SDP == K_COM) || (K_SDP == K_END) ||
      (K_SDP == K_SLC) || (K_SDP == K_SHP) || (K_EDB == K_COM) ||
      (K_EDB == K_END) || (K_EDB == K_SLC) || (K_EDB == K_SHP) ||
      (K_COM == K_END) || (K_COM == K_SLC) || (K_COM == K_SHP) ||
      (K_END == K_SLC) || (K_END == K_SHP) || (K_SLC == K_SHP))
  begin : g_chk_ksym_distinct
    $error("usb3_param_check: the K-symbol table has a duplicate value: the link framer classifies a beat by its symbol alone, so two identical symbols make two frame types indistinguishable");
  end

  // ------------------------------------------------------ tx header credits
  // NUM_TX_CREDIT is the REMOTE port's Rx header buffer count, fixed at four by
  // USB 3.0 (the credit tags are LCRD_A..LCRD_D).  It is a constant rather than
  // a knob, and the guard is here so that a future edit which turns it back
  // into a copy of NUM_RX_CREDIT is rejected instead of silently throttling the
  // transmit path again.
  if (NUM_TX_CREDIT != 4) begin : g_chk_tx_cred
    $error("usb3_param_check: NUM_TX_CREDIT must be 4 (got %0d): USB 3.0 gives every port exactly four Rx header buffers, advertised as LCRD_A..LCRD_D, and this is the REMOTE port's count - not this device's NUM_RX_CREDIT",
           NUM_TX_CREDIT);
  end

endmodule

`default_nettype wire
`endif  // USB3_PARAM_CHECK_SV
