// ============================================================================
// usb3_sync_fifo.sv
// Part of the USB 3.0 SuperSpeed device controller CDC / storage primitive
// library. Reset convention: active-low, asynchronous assert, synchronous
// deassert.
// ============================================================================
`default_nettype none

// ----------------------------------------------------------------------------
// Synchronous FIFO with almost-full / almost-empty flags. Power-of-two depth.
// Low power: memory write enable is qualified by push so idle traffic does not
// toggle the array.
// ----------------------------------------------------------------------------
module usb3_sync_fifo #(
  parameter int unsigned WIDTH  = 8,
  parameter int unsigned DEPTH  = 16,
  parameter int unsigned AF_LVL = 2,
  parameter int unsigned AE_LVL = 2
) (
  input  wire              clk,
  input  wire              rst_n,
  input  wire              push,
  input  wire  [WIDTH-1:0] wr_data,
  output logic             full,
  output logic             almost_full,
  input  wire              pop,
  output logic [WIDTH-1:0] rd_data,
  output logic             empty,
  output logic             almost_empty,
  output logic [$clog2(DEPTH):0] level,
  output logic             overflow,
  output logic             underflow
);
  // ---- elaboration guards ---------------------------------------------
  if (WIDTH < 1) begin : g_chk_width_min
    $error("usb3_sync_fifo: WIDTH must be >= 1 (got %0d)", WIDTH);
  end
  if (WIDTH > 1024) begin : g_chk_width_max
    $error("usb3_sync_fifo: WIDTH must be <= 1024 (got %0d)", WIDTH);
  end
  if (DEPTH < 2) begin : g_chk_depth_min
    $error("usb3_sync_fifo: DEPTH must be >= 2 (got %0d): $clog2(1) is 0 and the pointers would be zero width",
           DEPTH);
  end
  if (DEPTH > 65536) begin : g_chk_depth_max
    $error("usb3_sync_fifo: DEPTH must be <= 65536 (got %0d)", DEPTH);
  end
  if ((DEPTH & (DEPTH - 1)) != 0) begin : g_chk_depth_pow2
    $error("usb3_sync_fifo: DEPTH must be a power of two (got %0d): the pointers wrap on their own width",
           DEPTH);
  end
  // Strictly less than DEPTH, not <=: at AF_LVL == DEPTH the threshold
  // comparison becomes `cnt >= 0`, which is constant-true for an unsigned
  // count, and the flag is permanently asserted rather than being a threshold
  // at all.  The same argument applies to AE_LVL.
  if (AF_LVL >= DEPTH) begin : g_chk_af_lvl
    $error("usb3_sync_fifo: AF_LVL=%0d must be < DEPTH=%0d, otherwise almost_full is asserted permanently",
           AF_LVL, DEPTH);
  end
  if (AE_LVL >= DEPTH) begin : g_chk_ae_lvl
    $error("usb3_sync_fifo: AE_LVL=%0d must be < DEPTH=%0d, otherwise almost_empty is asserted permanently",
           AE_LVL, DEPTH);
  end

  localparam int unsigned AW = $clog2(DEPTH);

  logic [WIDTH-1:0] mem [DEPTH];
  logic [AW-1:0]    wr_ptr, rd_ptr;
  logic [AW:0]      cnt;
  logic             do_push, do_pop;

  assign do_push = push && !full;
  assign do_pop  = pop  && !empty;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wr_ptr <= '0;
      rd_ptr <= '0;
      cnt    <= '0;
    end else begin
      if (do_push) wr_ptr <= wr_ptr + 1'b1;
      if (do_pop)  rd_ptr <= rd_ptr + 1'b1;
      cnt <= cnt + {{AW{1'b0}}, do_push} - {{AW{1'b0}}, do_pop};
    end
  end

  always_ff @(posedge clk) begin
    if (do_push) mem[wr_ptr] <= wr_data;
  end

  assign rd_data      = mem[rd_ptr];
  assign level        = cnt;
  assign empty        = (cnt == '0);
  assign full         = (cnt == DEPTH[AW:0]);
  assign almost_full  = (cnt >= (DEPTH[AW:0] - AF_LVL[AW:0]));
  assign almost_empty = (cnt <= AE_LVL[AW:0]);
  assign overflow     = push && full;
  assign underflow    = pop  && empty;
endmodule

`default_nettype wire
