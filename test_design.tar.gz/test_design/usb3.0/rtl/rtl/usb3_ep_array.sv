// ============================================================================
// usb3_ep_array.sv
// Array of NUM_EP endpoint buffers (usb3_endpoint) with the protocol-side
// (pclk) and DMA-side (aclk) access muxing.
//
//   protocol side (pclk) : ep_sel selects the endpoint that is read (IN) or
//                          written (OUT) by the transaction layer.
//   DMA side (aclk)      : dma_ep_sel selects the endpoint that is written
//                          (IN) or read (OUT) by the scatter-gather DMA.
//
// Only one endpoint is accessed per side per cycle: the enables are fanned out
// with a one-hot decode of the select and the read data is muxed back with a
// flat NUM_EP:1 mux (NUM_EP is small, so this is a single balanced mux, not a
// priority chain).
// ============================================================================
`default_nettype none

module usb3_ep_array
  import usb3_pkg::*;
#(
  parameter int unsigned DEPTH = EP_FIFO_DEP
) (
  // ---- clocks / resets ---------------------------------------------------
  input  wire                    pclk,
  input  wire                    prst_n,
  input  wire                    aclk,
  input  wire                    arst_n,

  // ---- per-endpoint flush pulses (aclk) ----------------------------------
  input  wire  [NUM_EP-1:0]      cfg_ep_flush_a,

  // ---- protocol layer side (pclk) ----------------------------------------
  input  wire  [EP_ADDR_W-1:0]   ep_sel,
  input  wire                    ep_in_rd_en,
  output logic [31:0]            ep_in_rd_data,
  output logic                   ep_in_rd_last,
  output logic [NUM_EP-1:0]      ep_in_avail,
  input  wire                    ep_out_wr_en,
  input  wire  [31:0]            ep_out_wr_data,
  input  wire                    ep_out_wr_last,
  output logic [NUM_EP-1:0]      ep_out_space,
  // Free OUT-buffer entries, one count per endpoint, flattened.  The protocol
  // layer selects with ep_sel and compares against the DPH length.
  // WIDTH DERIVED FROM DEPTH, NOT FROM THE PACKAGE.  usb3_endpoint declares
  // ep_out_free as [$clog2(DEPTH):0]; taking this array's slice width from the
  // package's EP_LVL_W instead made the two disagree in every leaf-lint
  // configuration where DEPTH is overridden away from EP_FIFO_DEP, which is
  // three of them.  At the whole-design default DEPTH == EP_FIFO_DEP and the
  // two expressions are identical, so nothing else changes.
  output logic [NUM_EP*(unsigned'($clog2(DEPTH))+1)-1:0] ep_out_free,

  // ---- DMA side (aclk) ---------------------------------------------------
  input  wire  [EP_ADDR_W-1:0]   dma_ep_sel,
  input  wire                    dma_in_wr_en,
  input  wire  [31:0]            dma_in_wr_data,
  input  wire                    dma_in_wr_last,
  output logic [NUM_EP-1:0]      dma_in_full,
  input  wire                    dma_out_rd_en,
  output logic [31:0]            dma_out_rd_data,
  output logic                   dma_out_rd_last,
  output logic [NUM_EP-1:0]      dma_out_empty
);

  // ---- elaboration guard ------------------------------------------------
  if (DEPTH < 4) begin : g_chk_depth_min
    $error("usb3_ep_array: DEPTH must be >= 4 (got %0d)", DEPTH);
  end
  if ((DEPTH & (DEPTH - 1)) != 0) begin : g_chk_depth_pow2
    $error("usb3_ep_array: DEPTH must be a power of two (got %0d)", DEPTH);
  end

  // ------------------------------------------------------------------------
  // Per-endpoint nets
  // ------------------------------------------------------------------------
  logic [NUM_EP-1:0]       ep_in_rd_en_v;
  logic [31:0]             ep_in_rd_data_v [NUM_EP];
  logic [NUM_EP-1:0]       ep_in_rd_last_v;
  logic [NUM_EP-1:0]       ep_out_wr_en_v;
  logic [NUM_EP-1:0]       dma_in_wr_en_v;
  logic [NUM_EP-1:0]       dma_out_rd_en_v;
  logic [31:0]             dma_out_rd_data_v [NUM_EP];
  logic [NUM_EP-1:0]       dma_out_rd_last_v;

  // One-hot selects (pclk / aclk sides are independent).
  logic [NUM_EP-1:0] p_onehot;
  logic [NUM_EP-1:0] a_onehot;

  always_comb begin
    p_onehot = '0;
    a_onehot = '0;
    p_onehot[ep_sel]     = 1'b1;
    a_onehot[dma_ep_sel] = 1'b1;
  end

  assign ep_in_rd_en_v   = p_onehot & {NUM_EP{ep_in_rd_en}};
  assign ep_out_wr_en_v  = p_onehot & {NUM_EP{ep_out_wr_en}};
  assign dma_in_wr_en_v  = a_onehot & {NUM_EP{dma_in_wr_en}};
  assign dma_out_rd_en_v = a_onehot & {NUM_EP{dma_out_rd_en}};

  localparam int unsigned LVL_W = unsigned'($clog2(DEPTH)) + 1;

  // ------------------------------------------------------------------------
  // Endpoint instances
  // ------------------------------------------------------------------------
  for (genvar e = 0; e < int'(NUM_EP); e++) begin : g_ep
    usb3_endpoint #(.DEPTH(DEPTH)) u_ep (
      .pclk            (pclk),
      .prst_n          (prst_n),
      .aclk            (aclk),
      .arst_n          (arst_n),
      .cfg_ep_flush_a  (cfg_ep_flush_a[e]),
      .dma_in_wr_en    (dma_in_wr_en_v[e]),
      .dma_in_wr_data  (dma_in_wr_data),
      .dma_in_wr_last  (dma_in_wr_last),
      .dma_in_full     (dma_in_full[e]),
      .ep_in_rd_en     (ep_in_rd_en_v[e]),
      .ep_in_rd_data   (ep_in_rd_data_v[e]),
      .ep_in_rd_last   (ep_in_rd_last_v[e]),
      .ep_in_avail     (ep_in_avail[e]),
      .ep_out_wr_en    (ep_out_wr_en_v[e]),
      .ep_out_wr_data  (ep_out_wr_data),
      .ep_out_wr_last  (ep_out_wr_last),
      .ep_out_space    (ep_out_space[e]),
      .ep_out_free     (ep_out_free[e*LVL_W +: LVL_W]),
      .dma_out_rd_en   (dma_out_rd_en_v[e]),
      .dma_out_rd_data (dma_out_rd_data_v[e]),
      .dma_out_rd_last (dma_out_rd_last_v[e]),
      .dma_out_empty   (dma_out_empty[e])
    );
  end : g_ep

  // ------------------------------------------------------------------------
  // Read-data muxes
  // ------------------------------------------------------------------------
  always_comb begin
    ep_in_rd_data   = ep_in_rd_data_v[ep_sel];
    ep_in_rd_last   = ep_in_rd_last_v[ep_sel];
    dma_out_rd_data = dma_out_rd_data_v[dma_ep_sel];
    dma_out_rd_last = dma_out_rd_last_v[dma_ep_sel];
  end

endmodule

`default_nettype wire
