# orsoc_gfx

Top module: **`gfx_top`**. RTL: 20 files (4832 lines per the benchmark list),
copied from `/home/test/designs/orsoc_gfx` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/orsoc_gfx.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/orsoc_gfx/inputs/orsoc_gfx.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |


Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| wb_clk_i | wb_clk_i | 3.0 |

Minimum period: **3.0 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- **`--allow-use-before-declare`** (yosys-slang): the RTL uses identifiers before their declaration (tool leniency needed).
- **`--ignore-timing`** (yosys-slang): timing controls (#delays) in the RTL are ignored.
- Note: slang flags from sdc_xv/config/slang_flags.txt: div_uu.v has '<= #1' sim delays, gfx_transform.v/gfx_rasterizer.v use signals before declaration; 1024x40 instruction FIFO kept as flops (macros false, as in the SDC flow)
- Note: user-chosen 3 ns; timing at 3 ns NOT verified (last verified 4 ns met, +0.733 ns)

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 293,856 | 47,989 | 525,558 | +0.112 | 0.000 | – | 1861 s | 1154 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 173,266 | 47,977 | 371,066 | +0.004 | 0.000 | – | 571 s | 1807 MB |
