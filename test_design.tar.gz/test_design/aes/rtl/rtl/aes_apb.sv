//=============================================================================
// File        : aes_apb.sv
// Description : Top level of the APB4-programmed AES IP.
//
//               Structure
//               ---------
//
//   PCLK/PRESETn -> aes_reset_sync (x3, one per reset the core takes)
//
//                +-----------------------+        +---------------------+
//     APB4 ----->| aes_apb_to_tlul       | tl_h2d |  aes (VENDORED)     |
//                |  FSM + cmd_intg_gen   |=======>|  OpenTitan AES core |
//                |      + rsp_intg_chk   |<=======|  ECB/CBC/CFB/OFB/   |
//                +-----------------------+ tl_d2h |  CTR/GCM, 128/192/  |
//                                                 |  256, masked or not |
//                                                 +----------+----------+
//                                                            |
//        flat sideband  <--------------------------------- structs
//        (EDN, keymgr sideload, life cycle, idle, alerts)
//
//               THE DIVISION OF LABOUR IS THE POINT.  Everything inside
//               rtl/core/ is OpenTitan's AES, vendored byte-for-byte and
//               pre-verified upstream (see rtl/core/PROVENANCE.txt).  The
//               original work in this IP is the layer around it: this file,
//               aes_apb_to_tlul.sv, aes_reset_sync.sv, aes_apb_pkg.sv, the
//               assertions in rtl/sva/, and everything under verif/, run/ and
//               doc/.  No line of the cipher is rewritten here.
//
//               WHAT THIS WRAPPER ADDS
//               ----------------------
//               1. An APB4 subordinate interface, with TL-UL integrity
//                  generated and checked (see aes_apb_to_tlul.sv - without it
//                  the core answers PSLVERR on every access).
//               2. Reset conditioning: configurable polarity, and async
//                  assert / sync de-assert on all three reset domains.
//               3. A FLAT port list.  The core's sideband interfaces are
//                  OpenTitan packed structs (edn_pkg, keymgr_pkg,
//                  lc_ctrl_pkg, prim_mubi_pkg, prim_alert_pkg); an integrator
//                  who does not compile those packages cannot connect them.
//                  Every one is presented here as plain vectors.
//               4. Elaboration guards, including a set that compares this
//                  IP's register map against the vendored core's, so a core
//                  refresh that moves a register is a COMPILE ERROR rather
//                  than a silent wrong-address access.
//
//               NOTHING IS TIED OFF SILENTLY.  Every sideband the core needs
//               is a port of this module.  Section "Integration obligations"
//               below states what each one must be driven with, and what is
//               lost if it is driven with a constant instead.  The one thing
//               that IS fixed is SecStartTriggerDelay, which is an
//               SCA-measurement aid and is held at 0; see the parameter list.
//
//               CLOCKING.  Two clock domains: PCLK for everything, and
//               clk_edn for the entropy interface.  The crossing is inside
//               the vendored core (prim_sync_reqack_data in aes_prng_*), not
//               here.  There are no generated and no gated clocks.
//
// Integration obligations
// -----------------------
//   rst_shadowed_n   A SECOND reset for the shadowed configuration registers.
//                    It must be released with, but generated independently
//                    of, PRESETn.  Tying it to PRESETn is legal and the IP
//                    works, but it defeats the shadow-reset countermeasure
//                    (a single fault can then reset both copies together).
//                    Say so in the integration report if you do it.
//
//   EDN interface    Real entropy.  The core requests entropy to reseed its
//                    clearing PRNG (always) and its masking PRNG (when
//                    SEC_MASKING=1).  If edn_ack_i never arrives, a
//                    PRNG_RESEED trigger never completes and STATUS.IDLE
//                    stays 0 - the IP looks hung.  A constant edn_ack_i with
//                    a constant edn_bus_i "works" and reduces the clearing
//                    and masking PRNGs to fixed sequences; that is a
//                    side-channel decision, not a wiring decision.
//
//   lc_escalate_en_i lc_ctrl_pkg::lc_tx_t.  4'b1010 (Off) is the normal
//                    value; 4'b0101 (On) wipes the key and latches a fatal
//                    alert.  ANY OTHER VALUE is treated as On by the core's
//                    strict decoder, so this port must not be left floating
//                    or tied to zero.
//
//   sideload_key_*   The keymgr sideload key, two shares.  Used only when
//                    CTRL_SHADOWED.SIDELOAD=1.  With valid=0 the core
//                    refuses to start in sideload mode.
//
//   alert_rx_i       prim_alert_pkg::alert_rx_t per alert.  An integrator
//                    with no alert handler drives the idle value
//                    {ping_p,ping_n,ack_p,ack_n} = {0,1,0,1}, exported as
//                    aes_apb_pkg::AES_ALERT_RX_IDLE_*.  Tying all four to
//                    zero makes the differential decoder see a permanent
//                    signal-integrity error.
//=============================================================================

`default_nettype none

module aes_apb
  import aes_apb_pkg::*;
#(
    // ---- bus geometry ------------------------------------------------------
    // APB address bus width.  Must span the register region (0x8C bytes).
    parameter int unsigned APB_ADDR_WIDTH = 12,
    // APB data bus width.  >= 32 and a multiple of 8.  Registers always sit
    // on the low 32 lanes; see aes_apb_to_tlul.sv.
    parameter int unsigned APB_DATA_WIDTH = 32,

    // ---- reset -------------------------------------------------------------
    // 1'b0 : PRESETn / rst_shadowed_n / rst_edn_n are active LOW (APB standard)
    // 1'b1 : all three are active HIGH
    parameter bit          RESET_POLARITY = 1'b0,
    // Reset synchroniser depth (asynchronous assert, synchronous de-assert).
    parameter int unsigned RESET_SYNC_STAGES = 2,

    // ---- core feature selection -------------------------------------------
    // AES-192 support.  0 removes the 192-bit key schedule; KEY_LEN=010 then
    // reads back as the widest supported length instead.
    parameter bit          AES192_ENABLE = 1'b1,
    // Galois/Counter Mode support.  0 removes the GHASH block and makes
    // CTRL_GCM_SHADOWED read-only at GCM_INIT.
    parameter bit          AES_GCM_ENABLE = 1'b1,

    // ---- side-channel countermeasures --------------------------------------
    // First-order masking of the cipher core.  Requires a masked S-Box.
    parameter bit          SEC_MASKING = 1'b0,
    // S-Box implementation, aes_apb_pkg::AES_SBOX_*.  An int rather than
    // aes_pkg::sbox_impl_e so it can be supplied by -G from a Makefile or a
    // synthesis script, neither of which can name an enumerator.
    parameter int unsigned SEC_SBOX_IMPL = AES_SBOX_LUT,
    // Allow CTRL_AUX_SHADOWED.FORCE_MASKS to freeze the masking PRNG.  SCA
    // evaluation only - it removes the masking it is measuring.
    parameter bit          SEC_ALLOW_FORCING_MASKS = 1'b0,
    // Skip PRNG reseed requests entirely.  SCA evaluation only.
    parameter bit          SEC_SKIP_PRNG_RESEEDING = 1'b0
) (
    // ------------------------------------------------------------- clock/reset
    input  wire                          PCLK,
    input  wire                          PRESETn,
    // Independent reset for the shadowed configuration registers; see
    // "Integration obligations" above.
    input  wire                          rst_shadowed_n,

    // ------------------------------------------------------------------- APB4
    input  wire                          PSEL,
    input  wire                          PENABLE,
    input  wire                          PWRITE,
    input  wire  [APB_ADDR_WIDTH-1:0]    PADDR,
    input  wire  [APB_DATA_WIDTH-1:0]    PWDATA,
    input  wire  [APB_DATA_WIDTH/8-1:0]  PSTRB,

    output logic [APB_DATA_WIDTH-1:0]    PRDATA,
    output logic                         PREADY,
    output logic                         PSLVERR,

    // -------------------------------------------------- entropy (EDN) domain
    input  wire                          clk_edn,
    input  wire                          rst_edn_n,
    output logic                         edn_req_o,
    input  wire                          edn_ack_i,
    input  wire                          edn_fips_i,
    input  wire  [AES_EDN_BUS_WIDTH-1:0] edn_bus_i,

    // ------------------------------------------------- keymgr sideload key
    input  wire                          sideload_key_valid_i,
    input  wire  [AES_KEY_BITS_MAX-1:0]  sideload_key_share0_i,
    input  wire  [AES_KEY_BITS_MAX-1:0]  sideload_key_share1_i,

    // ------------------------------------------------------------ life cycle
    // lc_ctrl_pkg::lc_tx_t.  4'b1010 = Off (normal), 4'b0101 = On (escalate).
    input  wire  [AES_MUBI4_WIDTH-1:0]   lc_escalate_en_i,

    // ------------------------------------------------------------------ idle
    // prim_mubi_pkg::mubi4_t, for a clock manager.  `idle_o` is the strict
    // decode of it, for integrators that want one bit.
    output logic [AES_MUBI4_WIDTH-1:0]   idle_mubi_o,
    output logic                         idle_o,

    // ---------------------------------------------------------------- alerts
    // Index 0 = recoverable control-update error, 1 = fatal fault.
    output logic [AES_NUM_ALERTS-1:0]    alert_tx_p_o,
    output logic [AES_NUM_ALERTS-1:0]    alert_tx_n_o,
    input  wire  [AES_NUM_ALERTS-1:0]    alert_rx_ping_p_i,
    input  wire  [AES_NUM_ALERTS-1:0]    alert_rx_ping_n_i,
    input  wire  [AES_NUM_ALERTS-1:0]    alert_rx_ack_p_i,
    input  wire  [AES_NUM_ALERTS-1:0]    alert_rx_ack_n_i
);

  //---------------------------------------------------------------------------
  // Elaboration guards - bus geometry
  //---------------------------------------------------------------------------
  if (APB_DATA_WIDTH < 32) begin : gen_chk_dw_min
    $error("aes_apb: APB_DATA_WIDTH must be >= 32 (got %0d)", APB_DATA_WIDTH);
  end
  if ((APB_DATA_WIDTH % 8) != 0) begin : gen_chk_dw_mod
    $error("aes_apb: APB_DATA_WIDTH must be a multiple of 8 (got %0d)",
           APB_DATA_WIDTH);
  end
  if (APB_ADDR_WIDTH > 32) begin : gen_chk_aw_max
    $error("aes_apb: APB_ADDR_WIDTH must be <= 32 (got %0d)", APB_ADDR_WIDTH);
  end
  // The whole register region must be addressable.  The shift is evaluated in
  // 64 bits on purpose: `32'(1) << 32` is zero in a 32-bit context, which
  // would make this guard reject APB_ADDR_WIDTH == 32 - a value the guard
  // above explicitly permits, and the natural choice on a 32-bit APB.
  if ((64'(1) << APB_ADDR_WIDTH) < 64'(AES_ADDR_REGION_END)) begin : gen_chk_aw_span
    $error("aes_apb: APB_ADDR_WIDTH=%0d cannot span the 0x%0h byte register region",
           APB_ADDR_WIDTH, AES_ADDR_REGION_END);
  end
  if (RESET_SYNC_STAGES < 2) begin : gen_chk_rss_min
    $error("aes_apb: RESET_SYNC_STAGES must be >= 2 (got %0d)",
           RESET_SYNC_STAGES);
  end

  //---------------------------------------------------------------------------
  // Elaboration guards - core feature selection
  //---------------------------------------------------------------------------
  if (SEC_SBOX_IMPL > AES_SBOX_MAX) begin : gen_chk_sbox_range
    $error("aes_apb: SEC_SBOX_IMPL must be <= %0d (got %0d)",
           AES_SBOX_MAX, SEC_SBOX_IMPL);
  end
  // The cipher core asserts this internally with `ASSERT_INIT, which is
  // compiled out whenever assertions are off - and a synthesis run has them
  // off.  Repeated here as a real elaboration guard.
  if (SEC_MASKING && !aes_sbox_is_masked(SEC_SBOX_IMPL)) begin : gen_chk_mask_sbox
    $error("aes_apb: SEC_MASKING=1 requires a masked SEC_SBOX_IMPL (2, 3 or 4), got %0d",
           SEC_SBOX_IMPL);
  end
  if (!SEC_MASKING && aes_sbox_is_masked(SEC_SBOX_IMPL)) begin : gen_chk_nomask_sbox
    $error("aes_apb: SEC_MASKING=0 requires an unmasked SEC_SBOX_IMPL (0 or 1), got %0d",
           SEC_SBOX_IMPL);
  end
  // FORCE_MASKS freezes the masking PRNG.  With no masking there is no PRNG to
  // freeze, so the combination is a configuration mistake rather than a
  // weaker configuration.
  if (SEC_ALLOW_FORCING_MASKS && !SEC_MASKING) begin : gen_chk_force_masks
    $error("aes_apb: SEC_ALLOW_FORCING_MASKS=1 requires SEC_MASKING=1");
  end

  //---------------------------------------------------------------------------
  // Elaboration guards - register-map agreement with the vendored core
  //
  // aes_apb_pkg restates OpenTitan's register map so that verification code,
  // the RAL model and the documentation never have to import the vendored
  // package.  A restatement can DRIFT, and a drifted offset is a silent
  // wrong-address access that every test still passes because the model and
  // the stimulus drifted together.  These guards make it a compile error.
  //---------------------------------------------------------------------------
  if (AES_OFF_ALERT_TEST !=
      32'(aes_reg_pkg::AES_ALERT_TEST_OFFSET)) begin : gen_chk_off_alert_test
    $error("aes_apb: ALERT_TEST offset disagrees with the vendored core");
  end
  if (AES_OFF_KEY_SHARE0_BASE !=
      32'(aes_reg_pkg::AES_KEY_SHARE0_0_OFFSET)) begin : gen_chk_off_key0
    $error("aes_apb: KEY_SHARE0 base offset disagrees with the vendored core");
  end
  if (AES_OFF_KEY_SHARE1_BASE !=
      32'(aes_reg_pkg::AES_KEY_SHARE1_0_OFFSET)) begin : gen_chk_off_key1
    $error("aes_apb: KEY_SHARE1 base offset disagrees with the vendored core");
  end
  if (AES_OFF_IV_BASE !=
      32'(aes_reg_pkg::AES_IV_0_OFFSET)) begin : gen_chk_off_iv
    $error("aes_apb: IV base offset disagrees with the vendored core");
  end
  if (AES_OFF_DATA_IN_BASE !=
      32'(aes_reg_pkg::AES_DATA_IN_0_OFFSET)) begin : gen_chk_off_din
    $error("aes_apb: DATA_IN base offset disagrees with the vendored core");
  end
  if (AES_OFF_DATA_OUT_BASE !=
      32'(aes_reg_pkg::AES_DATA_OUT_0_OFFSET)) begin : gen_chk_off_dout
    $error("aes_apb: DATA_OUT base offset disagrees with the vendored core");
  end
  if (AES_OFF_CTRL_SHADOWED !=
      32'(aes_reg_pkg::AES_CTRL_SHADOWED_OFFSET)) begin : gen_chk_off_ctrl
    $error("aes_apb: CTRL_SHADOWED offset disagrees with the vendored core");
  end
  if (AES_OFF_CTRL_AUX_SHADOWED !=
      32'(aes_reg_pkg::AES_CTRL_AUX_SHADOWED_OFFSET)) begin : gen_chk_off_aux
    $error("aes_apb: CTRL_AUX_SHADOWED offset disagrees with the vendored core");
  end
  if (AES_OFF_CTRL_AUX_REGWEN !=
      32'(aes_reg_pkg::AES_CTRL_AUX_REGWEN_OFFSET)) begin : gen_chk_off_regwen
    $error("aes_apb: CTRL_AUX_REGWEN offset disagrees with the vendored core");
  end
  if (AES_OFF_TRIGGER !=
      32'(aes_reg_pkg::AES_TRIGGER_OFFSET)) begin : gen_chk_off_trigger
    $error("aes_apb: TRIGGER offset disagrees with the vendored core");
  end
  if (AES_OFF_STATUS !=
      32'(aes_reg_pkg::AES_STATUS_OFFSET)) begin : gen_chk_off_status
    $error("aes_apb: STATUS offset disagrees with the vendored core");
  end
  if (AES_OFF_CTRL_GCM_SHADOWED !=
      32'(aes_reg_pkg::AES_CTRL_GCM_SHADOWED_OFFSET)) begin : gen_chk_off_gcm
    $error("aes_apb: CTRL_GCM_SHADOWED offset disagrees with the vendored core");
  end
  if (AES_NUM_KEY_REGS != aes_reg_pkg::NumRegsKey) begin : gen_chk_nkey
    $error("aes_apb: NumRegsKey disagrees with the vendored core");
  end
  if (AES_NUM_IV_REGS != aes_reg_pkg::NumRegsIv) begin : gen_chk_niv
    $error("aes_apb: NumRegsIv disagrees with the vendored core");
  end
  if (AES_NUM_DATA_REGS != aes_reg_pkg::NumRegsData) begin : gen_chk_ndata
    $error("aes_apb: NumRegsData disagrees with the vendored core");
  end
  if (AES_NUM_ALERTS != aes_reg_pkg::NumAlerts) begin : gen_chk_nalerts
    $error("aes_apb: NumAlerts disagrees with the vendored core");
  end
  if (AES_BLOCK_AW != aes_reg_pkg::BlockAw) begin : gen_chk_blockaw
    $error("aes_apb: BlockAw disagrees with the vendored core");
  end
  // The int-to-enum mapping this IP promises for SEC_SBOX_IMPL.
  if (AES_SBOX_LUT != int'(aes_pkg::SBoxImplLut)) begin : gen_chk_sbox_lut
    $error("aes_apb: SBoxImplLut ordinal disagrees with the vendored core");
  end
  if (AES_SBOX_DOM != int'(aes_pkg::SBoxImplDom)) begin : gen_chk_sbox_dom
    $error("aes_apb: SBoxImplDom ordinal disagrees with the vendored core");
  end
  if (AES_SBOX_CANRIGHT != int'(aes_pkg::SBoxImplCanright)) begin : gen_chk_sbox_canright
    $error("aes_apb: SBoxImplCanright ordinal disagrees with the vendored core");
  end
  if (AES_SBOX_CANRIGHT_MASKED !=
      int'(aes_pkg::SBoxImplCanrightMasked)) begin : gen_chk_sbox_cm
    $error("aes_apb: SBoxImplCanrightMasked ordinal disagrees with the vendored core");
  end
  if (AES_SBOX_CANRIGHT_MASKED_NOREUSE !=
      int'(aes_pkg::SBoxImplCanrightMaskedNoreuse)) begin : gen_chk_sbox_cmn
    $error("aes_apb: SBoxImplCanrightMaskedNoreuse ordinal disagrees with the vendored core");
  end
  // The block is four 32-bit registers wide, in both directions.
  if (AES_BLOCK_BITS != 32 * AES_NUM_DATA_REGS) begin : gen_chk_block_bits
    $error("aes_apb: AES_BLOCK_BITS disagrees with NumRegsData * 32");
  end
  // The sideload key port geometry this module's port list promises.
  if (AES_SIDELOAD_SHARES != keymgr_pkg::Shares) begin : gen_chk_shares
    $error("aes_apb: sideload share count disagrees with the vendored keymgr package");
  end
  if (AES_KEY_BITS_MAX != keymgr_pkg::KeyWidth) begin : gen_chk_keywidth
    $error("aes_apb: sideload key width disagrees with the vendored keymgr package");
  end
  if (AES_EDN_BUS_WIDTH !=
      edn_pkg::ENDPOINT_BUS_WIDTH) begin : gen_chk_edn_width
    $error("aes_apb: EDN bus width disagrees with the vendored edn package");
  end
  // The flat mubi/lc encodings this IP's port list documents.
  if (AES_MUBI4_TRUE !=
      4'(prim_mubi_pkg::MuBi4True)) begin : gen_chk_mubi_true
    $error("aes_apb: MuBi4True encoding disagrees with the vendored core");
  end
  if (AES_MUBI4_FALSE !=
      4'(prim_mubi_pkg::MuBi4False)) begin : gen_chk_mubi_false
    $error("aes_apb: MuBi4False encoding disagrees with the vendored core");
  end
  // The alert-receiver idle value this module's header tells an integrator to
  // drive.  Getting it wrong makes the differential decoder report a permanent
  // signal-integrity error, which looks like a broken alert channel.
  if (AES_ALERT_RX_IDLE_PING_P !=
      prim_alert_pkg::ALERT_RX_DEFAULT.ping_p) begin : gen_chk_alert_ping_p
    $error("aes_apb: documented alert_rx idle ping_p disagrees with ALERT_RX_DEFAULT");
  end
  if (AES_ALERT_RX_IDLE_PING_N !=
      prim_alert_pkg::ALERT_RX_DEFAULT.ping_n) begin : gen_chk_alert_ping_n
    $error("aes_apb: documented alert_rx idle ping_n disagrees with ALERT_RX_DEFAULT");
  end
  if (AES_ALERT_RX_IDLE_ACK_P !=
      prim_alert_pkg::ALERT_RX_DEFAULT.ack_p) begin : gen_chk_alert_ack_p
    $error("aes_apb: documented alert_rx idle ack_p disagrees with ALERT_RX_DEFAULT");
  end
  if (AES_ALERT_RX_IDLE_ACK_N !=
      prim_alert_pkg::ALERT_RX_DEFAULT.ack_n) begin : gen_chk_alert_ack_n
    $error("aes_apb: documented alert_rx idle ack_n disagrees with ALERT_RX_DEFAULT");
  end
  // NOTE: CTRL_AUX_SHADOWED's reset value is NOT cross-checked here, because
  // the vendored aes_reg_pkg does not publish one - reggen emits no *_RESVAL
  // parameter for a shadowed hwext register, since the reset value lives in
  // the shadow register instance rather than in the package.  The documented
  // value (aes_apb_pkg::AES_CTRL_AUX_RESET_VALUE = 0x1, KEY_TOUCH_FORCES_
  // RESEED set) is therefore checked in SIMULATION instead, by the cover
  // property c_aux_at_reset_value in rtl/sva/aes_apb_sva.sv and by the RAL
  // reset check in verif/.  Recorded here so the asymmetry is deliberate
  // rather than an omission.

  //---------------------------------------------------------------------------
  // Reset conditioning
  //
  //   1. Normalise the configured polarity to internal active-low async resets.
  //   2. Synchronise each de-assertion to its own clock, removing the
  //      recovery/removal hazard.
  //
  // Three synchronisers, not one: the main reset and the shadow reset are
  // deliberately independent (that is what the shadow-reset countermeasure
  // means), and the EDN reset belongs to a different clock.
  //---------------------------------------------------------------------------
  logic rst_async_n, rst_shadowed_async_n, rst_edn_async_n;
  assign rst_async_n          = RESET_POLARITY ? ~PRESETn        : PRESETn;
  assign rst_shadowed_async_n = RESET_POLARITY ? ~rst_shadowed_n : rst_shadowed_n;
  assign rst_edn_async_n      = RESET_POLARITY ? ~rst_edn_n      : rst_edn_n;

  logic rst_n, rst_shadowed_sync_n, rst_edn_sync_n;

  aes_reset_sync #(.STAGES (RESET_SYNC_STAGES)) u_reset_sync (
      .clk       (PCLK),
      .rst_in_n  (rst_async_n),
      .rst_out_n (rst_n)
  );

  aes_reset_sync #(.STAGES (RESET_SYNC_STAGES)) u_reset_sync_shadowed (
      .clk       (PCLK),
      .rst_in_n  (rst_shadowed_async_n),
      .rst_out_n (rst_shadowed_sync_n)
  );

  aes_reset_sync #(.STAGES (RESET_SYNC_STAGES)) u_reset_sync_edn (
      .clk       (clk_edn),
      .rst_in_n  (rst_edn_async_n),
      .rst_out_n (rst_edn_sync_n)
  );

  //---------------------------------------------------------------------------
  // APB4 -> TileLink-UL
  //---------------------------------------------------------------------------
  tlul_pkg::tl_h2d_t tl_h2d;
  tlul_pkg::tl_d2h_t tl_d2h;

  aes_apb_to_tlul #(
      .APB_ADDR_WIDTH (APB_ADDR_WIDTH),
      .APB_DATA_WIDTH (APB_DATA_WIDTH)
  ) u_apb_to_tlul (
      .clk       (PCLK),
      .rst_n     (rst_n),
      .paddr_i   (PADDR),
      .psel_i    (PSEL),
      .penable_i (PENABLE),
      .pwrite_i  (PWRITE),
      .pwdata_i  (PWDATA),
      .pstrb_i   (PSTRB),
      .prdata_o  (PRDATA),
      .pready_o  (PREADY),
      .pslverr_o (PSLVERR),
      .tl_o      (tl_h2d),
      .tl_i      (tl_d2h)
  );

  //---------------------------------------------------------------------------
  // Flat sideband <-> OpenTitan structs
  //
  // Assembled here, in the wrapper, rather than at the core's port list, so
  // that every conversion is in one place and each one can be read against the
  // "Integration obligations" note at the top of this file.
  //---------------------------------------------------------------------------
  edn_pkg::edn_req_t         edn_req;
  edn_pkg::edn_rsp_t         edn_rsp;
  keymgr_pkg::hw_key_req_t   keymgr_key;
  prim_mubi_pkg::mubi4_t     idle_mubi;
  prim_alert_pkg::alert_rx_t [AES_NUM_ALERTS-1:0] alert_rx;
  prim_alert_pkg::alert_tx_t [AES_NUM_ALERTS-1:0] alert_tx;

  assign edn_req_o        = edn_req.edn_req;
  assign edn_rsp.edn_ack  = edn_ack_i;
  assign edn_rsp.edn_fips = edn_fips_i;
  assign edn_rsp.edn_bus  = edn_bus_i;

  assign keymgr_key.valid  = sideload_key_valid_i;
  assign keymgr_key.key[0] = sideload_key_share0_i;
  assign keymgr_key.key[1] = sideload_key_share1_i;

  assign idle_mubi_o = AES_MUBI4_WIDTH'(idle_mubi);
  // Strict decode: anything that is not exactly MuBi4True reads as busy.  A
  // corrupted mubi must never be reported as idle, because "idle" is what a
  // clock manager uses to decide it may stop the clock.
  assign idle_o = (AES_MUBI4_WIDTH'(idle_mubi) == AES_MUBI4_TRUE);

  for (genvar a = 0; a < AES_NUM_ALERTS; a++) begin : gen_alert_flat
    assign alert_rx[a].ping_p = alert_rx_ping_p_i[a];
    assign alert_rx[a].ping_n = alert_rx_ping_n_i[a];
    assign alert_rx[a].ack_p  = alert_rx_ack_p_i[a];
    assign alert_rx[a].ack_n  = alert_rx_ack_n_i[a];
    assign alert_tx_p_o[a]    = alert_tx[a].alert_p;
    assign alert_tx_n_o[a]    = alert_tx[a].alert_n;
  end

  //---------------------------------------------------------------------------
  // The vendored core
  //
  // Parameters not exposed by this wrapper, and why:
  //
  //   AlertAsyncOn             left at all-ones: this IP's alert senders must
  //                            work whether or not the receiver shares PCLK,
  //                            and the asynchronous form is correct in both
  //                            cases.
  //   AlertSkewCycles          left at 1, the upstream default.
  //   SecStartTriggerDelay     left at 0.  A non-zero value delays every
  //                            manual start so a processor can enter sleep
  //                            before the AES runs - an SCA measurement aid
  //                            that changes the programming model's timing.
  //                            Exposing it would put a knob in the datasheet
  //                            that no regression build exercises.
  //   RndCnst*                 left at the upstream defaults.  These are the
  //                            LFSR seeds and permutations; overriding them
  //                            is a per-tapeout secret-generation step, done
  //                            by the integrating project, not by this IP.
  //---------------------------------------------------------------------------
  aes #(
      .AES192Enable             (AES192_ENABLE),
      .AESGCMEnable             (AES_GCM_ENABLE),
      .SecMasking               (SEC_MASKING),
      .SecSBoxImpl              (aes_pkg::sbox_impl_e'(SEC_SBOX_IMPL)),
      .SecStartTriggerDelay     (0),
      .SecAllowForcingMasks     (SEC_ALLOW_FORCING_MASKS),
      .SecSkipPRNGReseeding     (SEC_SKIP_PRNG_RESEEDING)
  ) u_aes (
      .clk_i             (PCLK),
      .rst_ni            (rst_n),
      .rst_shadowed_ni   (rst_shadowed_sync_n),

      .idle_o            (idle_mubi),

      .lc_escalate_en_i  (lc_ctrl_pkg::lc_tx_t'(lc_escalate_en_i)),

      .clk_edn_i         (clk_edn),
      .rst_edn_ni        (rst_edn_sync_n),
      .edn_o             (edn_req),
      .edn_i             (edn_rsp),

      .keymgr_key_i      (keymgr_key),

      .tl_i              (tl_h2d),
      .tl_o              (tl_d2h),

      .alert_rx_i        (alert_rx),
      .alert_tx_o        (alert_tx)
  );

endmodule : aes_apb

`default_nettype wire
