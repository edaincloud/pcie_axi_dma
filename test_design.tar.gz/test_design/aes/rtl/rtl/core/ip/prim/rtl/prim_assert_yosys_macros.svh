// Copyright lowRISC contributors (OpenTitan project).
// Licensed under the Apache License, Version 2.0, see LICENSE for details.
// SPDX-License-Identifier: Apache-2.0

// Macro bodies included by prim_assert.sv for formal verification with Yosys. See prim_assert.sv
// for documentation for each of the macros.

`ifndef ASSERT_I
`define ASSERT_I(__name, __prop)    \
  always_comb begin : __name        \
    assert (__prop);                \
  end
`endif

`ifndef ASSERT_INIT
`define ASSERT_INIT(__name, __prop)    \
  initial begin : __name               \
    assert (__prop);                   \
  end
`endif

`ifndef ASSERT_INIT_NET
`define ASSERT_INIT_NET(__name, __prop) \
  initial begin : __name                \
    #1ps assert (__prop);               \
  end
`endif

// This doesn't make much sense for a formal tool (we never get to the final block!)
`ifndef ASSERT_FINAL
`define ASSERT_FINAL(__name, __prop)
`endif

// This needs sampling just before reset assertion and thus requires an event scheduler, which Yosys
// may or may not implement, so we leave it blank for the time being.
`ifndef ASSERT_AT_RESET
`define ASSERT_AT_RESET(__name, __prop, __rst = `ASSERT_DEFAULT_RST)
`endif

`ifndef ASSERT_AT_RESET_AND_FINAL
`define ASSERT_AT_RESET_AND_FINAL(__name, __prop, __rst = `ASSERT_DEFAULT_RST) \
  `ASSERT_AT_RESET(AtReset_``__name``, __prop, __rst)                          \
  `ASSERT_FINAL(Final_``__name``, __prop)
`endif

`ifndef ASSERT
`define ASSERT(__name, __prop, __clk = `ASSERT_DEFAULT_CLK, __rst = `ASSERT_DEFAULT_RST) \
  always_ff @(posedge __clk) begin                                                       \
    if (! (__rst !== '0)) __name: assert (__prop);                                       \
  end
`endif

`ifndef ASSERT_NEVER
`define ASSERT_NEVER(__name, __prop, __clk = `ASSERT_DEFAULT_CLK, __rst = `ASSERT_DEFAULT_RST) \
  always_ff @(posedge __clk) begin                                                             \
    if (! (__rst !== '0)) __name: assert (! (__prop));                                         \
  end
`endif

// Yosys uses 2-state logic, so this doesn't make sense here
`ifndef ASSERT_KNOWN
`define ASSERT_KNOWN(__name, __sig, __clk = `ASSERT_DEFAULT_CLK, __rst = `ASSERT_DEFAULT_RST)
`endif

`ifndef COVER
`define COVER(__name, __prop, __clk = `ASSERT_DEFAULT_CLK, __rst = `ASSERT_DEFAULT_RST) \
  always_ff @(posedge __clk) begin : __name                                             \
    cover ((! (__rst !== '0)) && (__prop));                                             \
  end
`endif

`ifndef ASSUME
`define ASSUME(__name, __prop, __clk = `ASSERT_DEFAULT_CLK, __rst = `ASSERT_DEFAULT_RST) \
  always_ff @(posedge __clk) begin                                                       \
    if (! (__rst !== '0)) __name: assume (__prop);                                       \
  end
`endif

`ifndef ASSUME_I
`define ASSUME_I(__name, __prop)              \
  always_comb begin : __name                  \
    assume (__prop);                          \
  end
`endif
