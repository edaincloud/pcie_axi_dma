// Copyright lowRISC contributors (OpenTitan project).
// Licensed under the Apache License, Version 2.0, see LICENSE for details.
// SPDX-License-Identifier: Apache-2.0

// Macro bodies included by prim_assert.sv for tools that don't support assertions. See
// prim_assert.sv for documentation for each of the macros.

`ifndef ASSERT_I
`define ASSERT_I(__name, __prop)
`endif
`ifndef ASSERT_INIT
`define ASSERT_INIT(__name, __prop)
`endif
`ifndef ASSERT_INIT_NET
`define ASSERT_INIT_NET(__name, __prop)
`endif
`ifndef ASSERT_FINAL
`define ASSERT_FINAL(__name, __prop)
`endif
`ifndef ASSERT_AT_RESET
`define ASSERT_AT_RESET(__name, __prop, __rst = `ASSERT_DEFAULT_RST)
`endif
`ifndef ASSERT_AT_RESET_AND_FINAL
`define ASSERT_AT_RESET_AND_FINAL(__name, __prop, __rst = `ASSERT_DEFAULT_RST)
`endif
`ifndef ASSERT
`define ASSERT(__name, __prop, __clk = `ASSERT_DEFAULT_CLK, __rst = `ASSERT_DEFAULT_RST)
`endif
`ifndef ASSERT_NEVER
`define ASSERT_NEVER(__name, __prop, __clk = `ASSERT_DEFAULT_CLK, __rst = `ASSERT_DEFAULT_RST)
`endif
`ifndef ASSERT_KNOWN
`define ASSERT_KNOWN(__name, __sig, __clk = `ASSERT_DEFAULT_CLK, __rst = `ASSERT_DEFAULT_RST)
`endif
`ifndef COVER
`define COVER(__name, __prop, __clk = `ASSERT_DEFAULT_CLK, __rst = `ASSERT_DEFAULT_RST)
`endif
`ifndef ASSUME
`define ASSUME(__name, __prop, __clk = `ASSERT_DEFAULT_CLK, __rst = `ASSERT_DEFAULT_RST)
`endif
`ifndef ASSUME_I
`define ASSUME_I(__name, __prop)
`endif
