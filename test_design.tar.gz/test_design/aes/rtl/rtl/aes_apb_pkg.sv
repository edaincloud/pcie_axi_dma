//=============================================================================
// File        : aes_apb_pkg.sv
// Description : The single definition of the AES IP's programming model.
//
//               Every byte offset, field position and encoding used by this
//               IP lives here: the RTL, the SVA, the RAL model, the reference
//               model and the documentation all derive from this file, so an
//               address or field change is made in ONE place.
//
//               The values are NOT invented here. They are the OpenTitan AES
//               register map (rtl/core/ip/aes/rtl/aes_reg_pkg.sv and
//               data/aes.hjson), restated in a package this IP owns so that
//               verification code never has to import the vendored package -
//               and, more importantly, so that a drift between the two is a
//               COMPILE ERROR rather than a silent wrong-address access.
//               aes_apb.sv carries one elaboration guard per offset comparing
//               this package against aes_reg_pkg; run/scripts/elab_check.sh
//               proves those guards fire.
//
// Register map (byte offsets from the IP base address, all 32 bits wide)
// ---------------------------------------------------------------------
//   0x000  ALERT_TEST          wo   write 1 to a bit to fire that alert
//   0x004  KEY_SHARE0_0..7     wo   0x004..0x020  initial key, share 0
//   0x024  KEY_SHARE1_0..7     wo   0x024..0x040  initial key, share 1
//   0x044  IV_0..3             rw   0x044..0x050  initial vector / counter
//   0x054  DATA_IN_0..3        wo   0x054..0x060  input block
//   0x064  DATA_OUT_0..3       ro   0x064..0x070  output block (read clears)
//   0x074  CTRL_SHADOWED       rw   shadowed: two identical writes to update
//   0x078  CTRL_AUX_SHADOWED   rw   shadowed
//   0x07C  CTRL_AUX_REGWEN     rw0c lock for CTRL_AUX_SHADOWED
//   0x080  TRIGGER             wo   self-clearing command bits
//   0x084  STATUS              ro
//   0x088  CTRL_GCM_SHADOWED   rw   shadowed (present only when GCM enabled)
//
//               The KEY is supplied as TWO SHARES which are XORed inside the
//               core: key = KEY_SHARE0 ^ KEY_SHARE1. Software that does not
//               care about masking writes the key to share 0 and zeros to
//               share 1. Writing only one share leaves the other at whatever
//               it held, which is the single most common integration mistake
//               against this IP - see doc/aes_design_spec.md.
//=============================================================================

`default_nettype none

package aes_apb_pkg;

  //---------------------------------------------------------------------------
  // Geometry
  //---------------------------------------------------------------------------
  // The core's own register block address width. Every offset below fits in
  // this many bits, and APB_ADDR_WIDTH must be at least this wide.
  localparam int unsigned AES_BLOCK_AW      = 8;
  // One past the last byte of the register region.
  localparam int unsigned AES_ADDR_REGION_END = 32'h8C;

  localparam int unsigned AES_NUM_KEY_REGS  = 8;   // per share
  localparam int unsigned AES_NUM_IV_REGS   = 4;
  localparam int unsigned AES_NUM_DATA_REGS = 4;
  localparam int unsigned AES_NUM_ALERTS    = 2;
  localparam int unsigned AES_BLOCK_BITS    = 128;
  localparam int unsigned AES_KEY_BITS_MAX  = 256;

  //---------------------------------------------------------------------------
  // Byte offsets
  //---------------------------------------------------------------------------
  localparam logic [31:0] AES_OFF_ALERT_TEST        = 32'h00;
  localparam logic [31:0] AES_OFF_KEY_SHARE0_BASE   = 32'h04;
  localparam logic [31:0] AES_OFF_KEY_SHARE1_BASE   = 32'h24;
  localparam logic [31:0] AES_OFF_IV_BASE           = 32'h44;
  localparam logic [31:0] AES_OFF_DATA_IN_BASE      = 32'h54;
  localparam logic [31:0] AES_OFF_DATA_OUT_BASE     = 32'h64;
  localparam logic [31:0] AES_OFF_CTRL_SHADOWED     = 32'h74;
  localparam logic [31:0] AES_OFF_CTRL_AUX_SHADOWED = 32'h78;
  localparam logic [31:0] AES_OFF_CTRL_AUX_REGWEN   = 32'h7C;
  localparam logic [31:0] AES_OFF_TRIGGER           = 32'h80;
  localparam logic [31:0] AES_OFF_STATUS            = 32'h84;
  localparam logic [31:0] AES_OFF_CTRL_GCM_SHADOWED = 32'h88;

  localparam logic [31:0] AES_REG_STRIDE            = 32'h04;

  //---------------------------------------------------------------------------
  // CTRL_SHADOWED (0x74)
  //
  //   [1:0]   OPERATION          one-hot, 01 = encrypt, 10 = decrypt
  //   [7:2]   MODE               one-hot, see aes_mode_e
  //   [10:8]  KEY_LEN            one-hot, 001 = 128, 010 = 192, 100 = 256
  //   [11]    SIDELOAD           1 = take the key from the keymgr interface
  //   [14:12] PRNG_RESEED_RATE   one-hot, block count between auto reseeds
  //   [15]    MANUAL_OPERATION   1 = software triggers each block via TRIGGER
  //
  // Every one-hot field maps an ILLEGAL encoding to a defined safe value in
  // hardware rather than rejecting the write: OPERATION -> encrypt, MODE ->
  // AES_NONE, KEY_LEN -> the widest supported. The reference model reproduces
  // that mapping, so a test may legitimately write nonsense here.
  //---------------------------------------------------------------------------
  localparam int unsigned AES_CTRL_OPERATION_LSB = 0;
  localparam int unsigned AES_CTRL_OPERATION_W   = 2;
  localparam int unsigned AES_CTRL_MODE_LSB      = 2;
  localparam int unsigned AES_CTRL_MODE_W        = 6;
  localparam int unsigned AES_CTRL_KEY_LEN_LSB   = 8;
  localparam int unsigned AES_CTRL_KEY_LEN_W     = 3;
  localparam int unsigned AES_CTRL_SIDELOAD_BIT  = 11;
  localparam int unsigned AES_CTRL_RESEED_RATE_LSB = 12;
  localparam int unsigned AES_CTRL_RESEED_RATE_W   = 3;
  localparam int unsigned AES_CTRL_MANUAL_OP_BIT   = 15;
  localparam int unsigned AES_CTRL_WIDTH           = 16;

  typedef enum logic [1:0] {
    AES_OP_ENC = 2'b01,
    AES_OP_DEC = 2'b10
  } aes_op_e;

  typedef enum logic [5:0] {
    AES_MODE_ECB  = 6'b00_0001,
    AES_MODE_CBC  = 6'b00_0010,
    AES_MODE_CFB  = 6'b00_0100,
    AES_MODE_OFB  = 6'b00_1000,
    AES_MODE_CTR  = 6'b01_0000,
    AES_MODE_GCM  = 6'b10_0000,
    AES_MODE_NONE = 6'b11_1111
  } aes_mode_e;

  typedef enum logic [2:0] {
    AES_KEY_128 = 3'b001,
    AES_KEY_192 = 3'b010,
    AES_KEY_256 = 3'b100
  } aes_key_len_e;

  // PRNG_RESEED_RATE: blocks between automatic reseeds of the masking PRNG.
  typedef enum logic [2:0] {
    AES_RESEED_PER_1  = 3'b001,
    AES_RESEED_PER_64 = 3'b010,
    AES_RESEED_PER_8K = 3'b100
  } aes_reseed_rate_e;

  //---------------------------------------------------------------------------
  // CTRL_AUX_SHADOWED (0x78)
  //---------------------------------------------------------------------------
  localparam int unsigned AES_CTRL_AUX_KEY_TOUCH_RESEED_BIT = 0;
  localparam int unsigned AES_CTRL_AUX_FORCE_MASKS_BIT      = 1;
  localparam logic [31:0] AES_CTRL_AUX_RESET_VALUE          = 32'h1;

  //---------------------------------------------------------------------------
  // TRIGGER (0x80) - write-only, hardware clears each bit as it executes it.
  //---------------------------------------------------------------------------
  localparam int unsigned AES_TRIG_START_BIT                = 0;
  localparam int unsigned AES_TRIG_KEY_IV_DATA_IN_CLEAR_BIT = 1;
  localparam int unsigned AES_TRIG_DATA_OUT_CLEAR_BIT       = 2;
  localparam int unsigned AES_TRIG_PRNG_RESEED_BIT          = 3;
  localparam int unsigned AES_TRIGGER_WIDTH                 = 4;

  //---------------------------------------------------------------------------
  // STATUS (0x84) - read-only.
  //---------------------------------------------------------------------------
  localparam int unsigned AES_ST_IDLE_BIT          = 0;
  localparam int unsigned AES_ST_STALL_BIT         = 1;
  localparam int unsigned AES_ST_OUTPUT_LOST_BIT   = 2;
  localparam int unsigned AES_ST_OUTPUT_VALID_BIT  = 3;
  localparam int unsigned AES_ST_INPUT_READY_BIT   = 4;
  localparam int unsigned AES_ST_ALERT_RECOV_BIT   = 5;
  localparam int unsigned AES_ST_ALERT_FATAL_BIT   = 6;
  localparam int unsigned AES_STATUS_WIDTH         = 7;

  //---------------------------------------------------------------------------
  // CTRL_GCM_SHADOWED (0x88)
  //   [5:0]  PHASE       one-hot, see aes_gcm_phase_e
  //   [10:6] NUM_VALID_BYTES  1..16, valid bytes in the final partial block
  //---------------------------------------------------------------------------
  localparam int unsigned AES_GCM_PHASE_LSB = 0;
  localparam int unsigned AES_GCM_PHASE_W   = 6;
  localparam int unsigned AES_GCM_NVB_LSB   = 6;
  localparam int unsigned AES_GCM_NVB_W     = 5;

  typedef enum logic [5:0] {
    AES_GCM_INIT    = 6'b00_0001,
    AES_GCM_RESTORE = 6'b00_0010,
    AES_GCM_AAD     = 6'b00_0100,
    AES_GCM_TEXT    = 6'b00_1000,
    AES_GCM_SAVE    = 6'b01_0000,
    AES_GCM_TAG     = 6'b10_0000
  } aes_gcm_phase_e;

  //---------------------------------------------------------------------------
  // ALERT_TEST (0x00)
  //---------------------------------------------------------------------------
  localparam int unsigned AES_ALERT_RECOV_CTRL_UPDATE_ERR_IDX = 0;
  localparam int unsigned AES_ALERT_FATAL_FAULT_IDX           = 1;

  //---------------------------------------------------------------------------
  // Sideband widths.  The core takes these as OpenTitan structs; this IP
  // presents them flat, because a struct port cannot be connected by an
  // integrator who does not compile OpenTitan's packages.
  //---------------------------------------------------------------------------
  localparam int unsigned AES_EDN_BUS_WIDTH   = 32;
  localparam int unsigned AES_SIDELOAD_SHARES = 2;
  localparam int unsigned AES_MUBI4_WIDTH     = 4;

  // prim_mubi_pkg::MuBi4True / MuBi4False, restated so the flat ports have a
  // documented meaning without importing the vendored package.
  localparam logic [3:0] AES_MUBI4_TRUE  = 4'h6;
  localparam logic [3:0] AES_MUBI4_FALSE = 4'h9;

  // prim_alert_pkg::ALERT_RX_DEFAULT, the quiescent value an integrator that
  // has no alert handler must drive. Fields, MSB..LSB: ping_p, ping_n, ack_p,
  // ack_n -> 1'b0, 1'b1, 1'b0, 1'b1.
  localparam logic AES_ALERT_RX_IDLE_PING_P = 1'b0;
  localparam logic AES_ALERT_RX_IDLE_PING_N = 1'b1;
  localparam logic AES_ALERT_RX_IDLE_ACK_P  = 1'b0;
  localparam logic AES_ALERT_RX_IDLE_ACK_N  = 1'b1;

  //---------------------------------------------------------------------------
  // S-Box implementation selector.
  //
  // The core takes an enum (aes_pkg::sbox_impl_e); this IP takes an int so the
  // value can be supplied by `-G` from a shell, a Makefile or a synthesis
  // script, none of which can name an enumerator. The numbering is the
  // enumerator ORDER in aes_pkg.sv and aes_apb.sv guards it.
  //---------------------------------------------------------------------------
  localparam int unsigned AES_SBOX_LUT                    = 0;
  localparam int unsigned AES_SBOX_CANRIGHT               = 1;
  localparam int unsigned AES_SBOX_CANRIGHT_MASKED        = 2;
  localparam int unsigned AES_SBOX_CANRIGHT_MASKED_NOREUSE = 3;
  localparam int unsigned AES_SBOX_DOM                    = 4;
  localparam int unsigned AES_SBOX_MAX                    = 4;

  // A masked cipher core requires a masked S-Box and vice versa; the core
  // asserts it internally with `ASSERT_INIT, which is compiled out whenever
  // assertions are off. aes_apb.sv repeats it as an elaboration guard.
  function automatic bit aes_sbox_is_masked(int unsigned impl);
    return (impl == AES_SBOX_CANRIGHT_MASKED)
        || (impl == AES_SBOX_CANRIGHT_MASKED_NOREUSE)
        || (impl == AES_SBOX_DOM);
  endfunction

  //---------------------------------------------------------------------------
  // Address helpers, shared by the RTL, the SVA and the verification code.
  //---------------------------------------------------------------------------
  // True when `off` names a register this IP implements.
  function automatic bit aes_offset_is_mapped(logic [31:0] off);
    return (off < AES_ADDR_REGION_END) && (off[1:0] == 2'b00);
  endfunction

  function automatic logic [31:0] aes_key_share0_off(int unsigned i);
    return AES_OFF_KEY_SHARE0_BASE + (AES_REG_STRIDE * 32'(i));
  endfunction
  function automatic logic [31:0] aes_key_share1_off(int unsigned i);
    return AES_OFF_KEY_SHARE1_BASE + (AES_REG_STRIDE * 32'(i));
  endfunction
  function automatic logic [31:0] aes_iv_off(int unsigned i);
    return AES_OFF_IV_BASE + (AES_REG_STRIDE * 32'(i));
  endfunction
  function automatic logic [31:0] aes_data_in_off(int unsigned i);
    return AES_OFF_DATA_IN_BASE + (AES_REG_STRIDE * 32'(i));
  endfunction
  function automatic logic [31:0] aes_data_out_off(int unsigned i);
    return AES_OFF_DATA_OUT_BASE + (AES_REG_STRIDE * 32'(i));
  endfunction

  // Number of key bits for a KEY_LEN encoding, 0 for an illegal one.
  function automatic int unsigned aes_key_len_bits(logic [2:0] key_len);
    case (key_len)
      3'b001:  return 128;
      3'b010:  return 192;
      3'b100:  return 256;
      default: return 0;
    endcase
  endfunction

endpackage : aes_apb_pkg

`default_nettype wire
