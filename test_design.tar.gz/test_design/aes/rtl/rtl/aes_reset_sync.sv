//=============================================================================
// File        : aes_reset_sync.sv
// Description : Reset synchronizer.  Asserts asynchronously, de-asserts
//               synchronously to the destination clock.
//
//               The house default is async assert / sync de-assert, and this
//               cell is what makes the de-assertion legal: it removes the
//               reset recovery/removal timing hazard and keeps the design RDC
//               clean.
//
// Notes       : - No combinational logic in the reset path other than the
//                 optional polarity inversion done by the parent.
//               - The flops reset to 0 and shift in a constant 1, so the
//                 output can only leave reset after STAGES rising clock edges
//                 with the input reset released.
//               - DFT: ordinary flops, scan replaceable.  Reset control during
//                 scan is an SoC-level concern, handled by driving `rst_in_n`
//                 from the test reset.
//               - This IP instantiates THREE of these, one per reset the
//                 vendored core takes: the main reset, the shadow reset, and
//                 the EDN-domain reset.  They are separate cells because they
//                 are separate resets: collapsing them would defeat the
//                 shadow-reset countermeasure the core relies on.
//=============================================================================

`default_nettype none

module aes_reset_sync #(
    // Number of synchronizer stages.  Two is the industry minimum; three is
    // used for very high frequency or high-MTBF requirements.
    parameter int unsigned STAGES = 2
) (
    input  wire  clk,       // Destination clock
    input  wire  rst_in_n,  // Asynchronous active-low reset input
    output wire  rst_out_n  // Synchronously de-asserted active-low reset
);

  if (STAGES < 2) begin : gen_chk_stages
    $error("aes_reset_sync: STAGES must be >= 2 (got %0d)", STAGES);
  end

  // A reset synchroniser is by construction a chain whose flops are reset
  // asynchronously and clocked synchronously; the SYNCASYNCNET check fires on
  // every correct implementation of this cell and is waived here only.
  /* verilator lint_off SYNCASYNCNET */
  logic [STAGES-1:0] sync_q;
  /* verilator lint_on SYNCASYNCNET */

  always_ff @(posedge clk or negedge rst_in_n) begin
    if (!rst_in_n) begin
      sync_q <= '0;
    end else begin
      sync_q <= {sync_q[STAGES-2:0], 1'b1};
    end
  end

  assign rst_out_n = sync_q[STAGES-1];

endmodule : aes_reset_sync

`default_nettype wire
