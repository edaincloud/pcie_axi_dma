//=============================================================================
// File        : aes_apb_to_tlul.sv
// Description : APB4 subordinate -> TileLink-UL host bridge.
//
// WHY THIS EXISTS
// ---------------
// The house bus is APB4.  The vendored AES core's register interface is
// TileLink-UL, carried as a packed struct pair (tlul_pkg::tl_h2d_t /
// tl_d2h_t).  This module is the whole of the translation, and it is the only
// file in this IP that knows both protocols.
//
// PROVENANCE
// ----------
// The transaction FSM is a house-style restatement of the proven bridge at
// soc_gen/dev_v2/data/ip_rtl/socgen_apb_tlul/socgen_apb_to_tlul.sv, which has
// been in service against eight OpenTitan blocks.  Two behaviours are carried
// over verbatim because each cost real debugging time to establish:
//
//   1. THE REQUEST IS ISSUED ON THE ACCESS PHASE (psel && penable), not on
//      psel alone.  Issuing on SETUP puts a transaction on the bus a cycle
//      early and then repeats it when penable rises.
//
//   2. A READ STILL PRESENTS A MASK.  TL-UL uses a_mask on a Get to say which
//      lanes it wants back; an all-zero mask returns nothing.  A partial WRITE
//      is expressed by the mask with the size unchanged - a smaller a_size on
//      a full-width beat reads as a bus error, not as a narrow access.
//
// AND ONE THING THE ORIGINAL DELIBERATELY DID NOT DO
// --------------------------------------------------
// tlul_pkg::TL_H2D_DEFAULT leaves a_user.cmd_intg and a_user.data_intg at
// ALL-ONES.  That is a deliberately INVALID checksum, not a "no checking"
// encoding.  The AES core's aes_reg_top runs tlul_cmd_intg_chk
// UNCONDITIONALLY and answers d_error on EVERY access, however well formed,
// if the checksum does not verify - so a bridge that skips integrity
// generation produces an AES that returns PSLVERR on every register access
// and looks completely dead.
//
// So the command is routed through tlul_cmd_intg_gen with
// EnableDataIntgGen(1): this bridge is the host, and the host is the last
// point that still sees the whole command.  The response is checked
// symmetrically by tlul_rsp_intg_chk, whose result joins d_error on PSLVERR -
// APB has exactly one error bit, and handing back data that failed its own
// integrity check while reporting success would be worse than reporting the
// error.
//
// TRANSACTION MODEL: ONE OUTSTANDING.  APB is two-phase and cannot overlap
// accesses, so there is never a second request to track and a queue here
// would only be testing itself.
//
// DATA WIDTH.  TL-UL to the core is fixed at 32 bits (top_pkg::TL_DW) and
// every AES register is 32 bits on a 4-byte stride.  When APB_DATA_WIDTH is
// wider, the register is carried on the LOW 32 lanes at every address: the
// upper PWDATA bits are ignored, the upper PRDATA bits read zero, and strobe
// lanes above 3 never reach a register.  That is stated here because it is a
// programming-model fact, not an implementation detail.
//=============================================================================

`default_nettype none

module aes_apb_to_tlul
  import tlul_pkg::*;
#(
    // APB address bus width.
    parameter int unsigned APB_ADDR_WIDTH = 12,
    // APB data bus width.  >= 32 and a multiple of 8.
    parameter int unsigned APB_DATA_WIDTH = 32
) (
    input  wire                            clk,
    input  wire                            rst_n,

    // ---------------------------------------------------------------- APB4
    input  wire  [APB_ADDR_WIDTH-1:0]      paddr_i,
    input  wire                            psel_i,
    input  wire                            penable_i,
    input  wire                            pwrite_i,
    input  wire  [APB_DATA_WIDTH-1:0]      pwdata_i,
    input  wire  [APB_DATA_WIDTH/8-1:0]    pstrb_i,
    output logic [APB_DATA_WIDTH-1:0]      prdata_o,
    output logic                           pready_o,
    output logic                           pslverr_o,

    // ------------------------------------------------------- TileLink-UL
    output tlul_pkg::tl_h2d_t              tl_o,   // host -> device
    input  tlul_pkg::tl_d2h_t              tl_i    // device -> host
);

  //---------------------------------------------------------------------------
  // Elaboration guards
  //---------------------------------------------------------------------------
  if (APB_DATA_WIDTH < 32) begin : gen_chk_dw_min
    $error("aes_apb_to_tlul: APB_DATA_WIDTH must be >= 32 (got %0d)",
           APB_DATA_WIDTH);
  end
  if ((APB_DATA_WIDTH % 8) != 0) begin : gen_chk_dw_mod
    $error("aes_apb_to_tlul: APB_DATA_WIDTH must be a multiple of 8 (got %0d)",
           APB_DATA_WIDTH);
  end
  if (APB_ADDR_WIDTH > top_pkg::TL_AW) begin : gen_chk_aw_max
    $error("aes_apb_to_tlul: APB_ADDR_WIDTH must be <= %0d (got %0d)",
           top_pkg::TL_AW, APB_ADDR_WIDTH);
  end
  if (APB_ADDR_WIDTH < 2) begin : gen_chk_aw_min
    $error("aes_apb_to_tlul: APB_ADDR_WIDTH must be >= 2 (got %0d)",
           APB_ADDR_WIDTH);
  end

  // TL-UL A-channel opcodes (TileLink spec 1.8.1, table 5).
  localparam logic [2:0] TL_PUT_FULL    = 3'd0;
  localparam logic [2:0] TL_PUT_PARTIAL = 3'd1;
  localparam logic [2:0] TL_GET         = 3'd4;

  // Every access is exactly one 32-bit beat, so a_size is log2(4) and never
  // varies.  A partial write is expressed by the MASK.
  localparam logic [top_pkg::TL_SZW-1:0] BEAT_SIZE =
      top_pkg::TL_SZW'($clog2(top_pkg::TL_DW / 8));



  //---------------------------------------------------------------------------
  // Request formation
  //---------------------------------------------------------------------------
  logic [top_pkg::TL_AW-1:0]  addr_q;
  logic [top_pkg::TL_DW-1:0]  wdata_q;
  logic [top_pkg::TL_DBW-1:0] mask_q;
  logic [2:0]                 opcode_q;
  logic                       a_valid_q;
  logic                       d_ready_q;

  logic [top_pkg::TL_DW-1:0]  rdata_q;
  logic                       pready_q;
  logic                       pslverr_q;

  // Only the low 32 lanes reach a register; the rest are deliberately unused.
  logic [top_pkg::TL_DW-1:0]  wdata_sel;
  logic [top_pkg::TL_DBW-1:0] strb_sel;
  assign wdata_sel = pwdata_i[top_pkg::TL_DW-1:0];
  assign strb_sel  = pstrb_i[top_pkg::TL_DBW-1:0];

  // An APB_DATA_WIDTH wider than the TL beat leaves upper bits with no reader.
  // Naming them keeps the linter honest about the fact rather than silencing
  // the warning: they are ignored BY DESIGN, and the design says so here.
  if (APB_DATA_WIDTH > top_pkg::TL_DW) begin : gen_unused_upper
    logic unused_upper;
    assign unused_upper = ^{pwdata_i[APB_DATA_WIDTH-1:top_pkg::TL_DW],
                            pstrb_i[APB_DATA_WIDTH/8-1:top_pkg::TL_DBW]};
  end

  logic all_bytes;
  assign all_bytes = &strb_sel;

  //---------------------------------------------------------------------------
  // Transaction FSM
  //---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    S_IDLE = 2'd0,
    S_REQ  = 2'd1,
    S_RSP  = 2'd2,
    S_DONE = 2'd3
  } state_e;

  state_e st_q;

  logic rsp_intg_err;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q      <= S_IDLE;
      a_valid_q <= 1'b0;
      opcode_q  <= TL_GET;
      addr_q    <= '0;
      wdata_q   <= '0;
      mask_q    <= '0;
      d_ready_q <= 1'b0;
      rdata_q   <= '0;
      pready_q  <= 1'b0;
      pslverr_q <= 1'b0;
    end else begin
      unique case (st_q)
        S_IDLE: begin
          pready_q  <= 1'b0;
          pslverr_q <= 1'b0;
          d_ready_q <= 1'b0;
          // The ACCESS phase is the request.  psel alone is SETUP; issuing
          // there would put a transaction on the bus a cycle early and repeat
          // it when penable rises.
          if (psel_i && penable_i && !pready_q) begin
            a_valid_q <= 1'b1;
            opcode_q  <= !pwrite_i   ? TL_GET
                       : all_bytes   ? TL_PUT_FULL
                                     : TL_PUT_PARTIAL;
            addr_q    <= top_pkg::TL_AW'(paddr_i);
            wdata_q   <= wdata_sel;
            // A read must still present a mask: TL uses it to say which lanes
            // it wants back, and an all-zero mask returns nothing.
            mask_q    <= pwrite_i ? strb_sel : {top_pkg::TL_DBW{1'b1}};
            st_q      <= S_REQ;
          end
        end

        S_REQ: begin
          if (tl_i.a_ready) begin
            a_valid_q <= 1'b0;
            d_ready_q <= 1'b1;
            st_q      <= S_RSP;
          end
        end

        S_RSP: begin
          if (tl_i.d_valid) begin
            d_ready_q <= 1'b0;
            rdata_q   <= tl_i.d_data;
            // Three failure modes reach APB as ONE error bit, which is all APB
            // has: the device denied the request, the device flagged the
            // response corrupt, or the response failed its own integrity
            // check here.  Reporting success and handing over untrustworthy
            // data would be worse than reporting the error.
            pslverr_q <= tl_i.d_error | rsp_intg_err;
            pready_q  <= 1'b1;
            st_q      <= S_DONE;
          end
        end

        S_DONE: begin
          // Hold pready for exactly the one cycle APB samples it.
          pready_q  <= 1'b0;
          pslverr_q <= 1'b0;
          st_q      <= S_IDLE;
        end

        default: st_q <= S_IDLE;   // illegal-state recovery
      endcase
    end
  end

  assign prdata_o  = APB_DATA_WIDTH'(rdata_q);
  assign pready_o  = pready_q;
  assign pslverr_o = pslverr_q;

  //---------------------------------------------------------------------------
  // TL-UL command assembly + integrity generation
  //
  // tl_raw carries the command; tlul_cmd_intg_gen adds the two checksums the
  // device's tlul_cmd_intg_chk will verify.  Without this the device answers
  // d_error on every access - see the file header.
  //---------------------------------------------------------------------------
  tlul_pkg::tl_h2d_t tl_raw;

  always_comb begin
    tl_raw           = tlul_pkg::TL_H2D_DEFAULT;
    tl_raw.a_valid   = a_valid_q;
    tl_raw.a_opcode  = tlul_pkg::tl_a_op_e'(opcode_q);
    tl_raw.a_param   = 3'b000;
    tl_raw.a_size    = BEAT_SIZE;
    tl_raw.a_source  = '0;             // one outstanding: one source id
    tl_raw.a_address = addr_q;
    tl_raw.a_mask    = mask_q;
    tl_raw.a_data    = wdata_q;
    tl_raw.d_ready   = d_ready_q;
  end

  tlul_cmd_intg_gen #(
      .EnableDataIntgGen (1)
  ) u_cmd_intg_gen (
      .tl_i (tl_raw),
      .tl_o (tl_o)
  );

  // EnableRspDataIntgCheck: the AES register block generates data integrity on
  // its read responses, so it is worth checking.  err_o is already qualified
  // by d_valid inside the module.
  tlul_rsp_intg_chk #(
      .EnableRspDataIntgCheck (1)
  ) u_rsp_intg_chk (
      .tl_i  (tl_i),
      .err_o (rsp_intg_err)
  );

  // Fields of the D channel this bridge structurally cannot use: APB has no
  // burst, no source id and no sink id, and the size is fixed.  Named rather
  // than left dangling so the linter reports a real unused signal if one
  // appears later.
  logic unused_d;
  assign unused_d = ^{tl_i.d_opcode, tl_i.d_param, tl_i.d_size,
                      tl_i.d_source, tl_i.d_sink, tl_i.d_user};

  // paddr bits above the TL address bus, if any, cannot exist: the guard above
  // rejects APB_ADDR_WIDTH > TL_AW.  Bits [1:0] are ignored because every
  // register is word-aligned; the device answers d_error on a misaligned
  // access, which this bridge forwards as PSLVERR.

endmodule : aes_apb_to_tlul

`default_nettype wire
