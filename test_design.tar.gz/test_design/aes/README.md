# aes

Top module: **`aes_apb`**. RTL: 102 files (29427 lines per the benchmark list),
copied from `/home/test/designs/aes` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/aes_apb.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/aes/inputs/aes_apb.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |


Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| clk_edn | clk_edn | 3.14 |
| PCLK | PCLK | 3.14 |

Minimum period: **3.14 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- **Top-level parameter overrides** (apply them in every tool; they are not defaults in the RTL): `APB_ADDR_WIDTH=12`, `APB_DATA_WIDTH=32`, `AES192_ENABLE=1`, `AES_GCM_ENABLE=1`, `SEC_MASKING=0`, `SEC_SBOX_IMPL=0`, `SEC_ALLOW_FORCING_MASKS=0`, `SEC_SKIP_PRNG_RESEEDING=0`, `RESET_POLARITY=0`, `RESET_SYNC_STAGES=2`.

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 43,534 | 2,948 | 60,910 | +0.094 | 0.000 | -11.833 | 75 s | 282 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 37,792 | 2,903 | 54,769 | +0.042 | 0.000 | +2.837 | 177 s | 523 MB |
