# ldpc

Top module: **`ldpc`**. RTL: 1 files (5645 lines per the benchmark list),
copied from `/home/test/designs/ldpc` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/ldpc.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/ldpc/inputs/ldpc.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |


Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| clk | clk | 4.63 |

Minimum period: **4.63 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- Note: Fmax SDC (synthesis-level OpenSTA search, 25%/25% I/O): clk 4.63 ns met, 4.57 failed

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 109,182 | 11,962 | 161,871 | +0.157 | 0.000 | – | 382 s | 3276 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 46,889 | 7,783 | 78,638 | +0.006 | 0.000 | – | 284 s | 3224 MB |
