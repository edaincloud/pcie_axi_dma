// ldpc: top ldpc; paths relative to this directory
rtl/inputs/designs/ldpc.v
