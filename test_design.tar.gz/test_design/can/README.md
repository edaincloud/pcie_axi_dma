# can

Top module: **`can_top`**. RTL: 10 files (3954 lines per the benchmark list),
copied from `/home/test/designs/can` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/can_top.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/can/inputs/can_top.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |


Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| pclk | pclk | 2.01 |

Minimum period: **2.01 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- **Top-level parameter overrides** (apply them in every tool; they are not defaults in the RTL): `APB_ADDR_WIDTH=12`, `APB_DATA_WIDTH=32`, `TX_FIFO_DEPTH=4`, `RX_FIFO_DEPTH=4`, `NUM_FILTERS=4`, `BRP_WIDTH=8`, `TIMESTAMP_ENABLE=1`, `TIMESTAMP_WIDTH=16`.

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 8,271 | 1,726 | 17,947 | +0.060 | 0.000 | -6.944 | 9 s | 86 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 6,760 | 1,723 | 14,773 | +0.006 | 0.000 | +1.748 | 17 s | 173 MB |
