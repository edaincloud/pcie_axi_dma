//=============================================================================
// File        : can_fault_conf.sv
// Description : Fault confinement: transmit / receive error counters and the
//               error-active / error-passive / bus-off state machine
//               (specification 07_Error_Handling_and_Fault_Confinement.md).
//
//               The protocol engine emits the ISO 11898-1 clause 12 counter
//               events; this block applies them and derives the node state:
//
//                 rule 7  successful transmission  -> TEC -= 1 (floor 0)
//                 rule 8  successful reception     -> REC -= 1, or REC = 127
//                                                     when REC > 127
//                 rule 9  TEC >= 128 or REC >= 128 -> error passive
//                 rule 10 TEC >= 256               -> bus off
//                 rule 11 128 x 11 recessive bits  -> error active, TEC=REC=0
//
//               TEC is nine bits wide so that the bus-off threshold of 256 is
//               representable and software can see it; REC saturates at 255
//               because it never causes bus off.
//=============================================================================

`default_nettype none

module can_fault_conf
  import can_pkg::*;
(
    input  wire              clk_i,
    input  wire              rst_ni,

    // Controller started (CONTROL.ENABLE and not CONTROL.INIT).  Leaving the
    // started state clears the counters and returns to error active.
    input  wire              enable_i,

    // Counter events from the protocol engine (single-clock pulses).
    input  wire              tec_inc8_i,
    input  wire              tec_dec_i,
    input  wire              rec_inc1_i,
    input  wire              rec_inc8_i,
    input  wire              rec_dec_i,
    input  wire              recovery_done_i,

    // Error warning limit (ERROR_CONTROL.EWL).
    input  wire  [7:0]       ewl_i,

    output can_fault_state_e state_o,
    output logic [8:0]       tec_o,
    output logic [7:0]       rec_o,
    output logic             error_warning_o,
    output logic             bus_off_entry_o,   // single-clock pulse
    output logic [7:0]       bus_off_count_o
);

  logic [8:0] tec_q;
  logic [7:0] rec_q;
  logic [7:0] boc_q;

  can_fault_state_e state_q;

  //---------------------------------------------------------------------------
  // Next TEC
  //---------------------------------------------------------------------------
  logic [9:0] tec_sum;
  logic [8:0] tec_next;

  always_comb begin
    tec_sum = {1'b0, tec_q};
    if (tec_inc8_i)                    tec_sum = tec_sum + 10'd8;
    else if (tec_dec_i && (tec_q != 0)) tec_sum = tec_sum - 10'd1;

    // Saturate at the bus-off threshold: once there, the node is bus off and
    // the counter is only ever cleared by a successful recovery.
    tec_next = (tec_sum > 10'(CAN_BUS_OFF_LIMIT)) ? 9'(CAN_BUS_OFF_LIMIT)
                                                  : tec_sum[8:0];
  end

  //---------------------------------------------------------------------------
  // Next REC
  //---------------------------------------------------------------------------
  logic [8:0] rec_sum;
  logic [7:0] rec_next;

  always_comb begin
    rec_sum = {1'b0, rec_q};
    if (rec_inc8_i)      rec_sum = rec_sum + 9'd8;
    else if (rec_inc1_i) rec_sum = rec_sum + 9'd1;
    else if (rec_dec_i) begin
      // ISO rule 8: a successful reception pulls a high REC back into the
      // 119..127 window rather than decrementing it one at a time.
      if (rec_q > 8'(CAN_REC_RELOAD))  rec_sum = 9'(CAN_REC_RELOAD);
      else if (rec_q != 0)             rec_sum = rec_sum - 9'd1;
    end

    rec_next = (rec_sum > 9'd255) ? 8'd255 : rec_sum[7:0];
  end

  //---------------------------------------------------------------------------
  // State
  //---------------------------------------------------------------------------
  can_fault_state_e state_next;

  always_comb begin
    if (tec_next >= 9'(CAN_BUS_OFF_LIMIT)) begin
      state_next = FC_BUS_OFF;
    end else if ((tec_next >= 9'(CAN_ERROR_PASSIVE_LIMIT)) ||
                 (rec_next >= 8'(CAN_ERROR_PASSIVE_LIMIT))) begin
      state_next = FC_ERROR_PASSIVE;
    end else begin
      state_next = FC_ERROR_ACTIVE;
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      tec_q           <= '0;
      rec_q           <= '0;
      boc_q           <= '0;
      state_q         <= FC_ERROR_ACTIVE;
      bus_off_entry_o <= 1'b0;
    end else begin
      bus_off_entry_o <= 1'b0;

      if (!enable_i) begin
        tec_q   <= '0;
        rec_q   <= '0;
        state_q <= FC_ERROR_ACTIVE;
      end else if (recovery_done_i) begin
        tec_q   <= '0;
        rec_q   <= '0;
        state_q <= FC_ERROR_ACTIVE;
      end else begin
        tec_q   <= tec_next;
        rec_q   <= rec_next;
        state_q <= state_next;
        if ((state_next == FC_BUS_OFF) && (state_q != FC_BUS_OFF)) begin
          bus_off_entry_o <= 1'b1;
          if (boc_q != 8'hFF) boc_q <= boc_q + 8'd1;
        end
      end
    end
  end

  assign state_o         = state_q;
  assign tec_o           = tec_q;
  assign rec_o           = rec_q;
  assign bus_off_count_o = boc_q;
  assign error_warning_o = (tec_q >= {1'b0, ewl_i}) || (rec_q >= ewl_i);

endmodule : can_fault_conf

`default_nettype wire
