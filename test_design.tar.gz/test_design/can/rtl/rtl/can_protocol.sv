//=============================================================================
// File        : can_protocol.sv
// Description : Classical CAN bit-serial protocol engine.
//
//               One unified engine implements both the transmit and the
//               receive protocol.  A CAN node always receives the bit stream
//               it is transmitting, and the two roles share field sequencing,
//               bit stuffing, CRC accumulation, error detection and error
//               signalling; splitting them into two FSMs duplicates all of
//               that and creates a synchronisation problem between the
//               copies.  See design spec Appendix A.
//
//               Timing contract
//               ---------------
//               The engine is driven by two single-clock events produced by
//               can_bit_timing:
//
//                 sample_point_i : the bus level `rx_bit_i` is valid now.
//                                  ALL protocol state advances on this event.
//                 bit_end_i      : the current bit time has finished.  The
//                                  transmitted level `txd_o` is updated now,
//                                  from the state that the preceding sample
//                                  point produced.
//
//               Because sample_point precedes bit_end inside a bit time, the
//               level driven for bit N+1 is a pure function of the state
//               after bit N was processed.  That is the property the
//               reference model reproduces.
//
//               Bit stuffing
//               ------------
//               A single stuff counter is driven by the bit observed on the
//               BUS, not by the bit the node intended to send.  This is what
//               makes destuffing continue correctly after a loss of
//               arbitration, when the observed stream stops being ours.
//               The stuffed region runs from SOF up to and including the last
//               bit of the CRC sequence, so a stuff bit may still be inserted
//               between the CRC sequence and the CRC delimiter.  `stuff_en_q`
//               therefore survives into ST_CRC_DELIM for exactly one bit.
//
//               Fault confinement
//               -----------------
//               The engine emits the ISO 11898-1 counter events; the counters
//               and the state machine live in can_fault_conf.  The rule
//               numbers quoted below are those of ISO 11898-1 clause 12
//               ("Fault confinement", rules 1..11) and are reproduced in the
//               design specification.
//=============================================================================

`default_nettype none

module can_protocol
  import can_pkg::*;
(
    input  wire                        clk_i,
    input  wire                        rst_ni,

    // ---- configuration -----------------------------------------------------
    // Engine running: CONTROL.ENABLE set and CONTROL.INIT clear.
    input  wire                        enable_i,
    input  wire                        listen_only_i,
    input  wire                        loopback_i,
    input  wire                        self_ack_i,
    input  wire                        one_shot_i,        // CONTROL.ONE_SHOT
    input  wire                        auto_retx_i,       // CONTROL.AUTO_RETRANSMIT
    input  wire                        accept_remote_i,

    // ---- bit timing --------------------------------------------------------
    input  wire                        sample_point_i,
    input  wire                        bit_end_i,
    input  wire                        rx_bit_i,          // synchronized bus level

    output logic                       txd_o,
    output logic                       tx_dominant_o,
    output logic                       hard_sync_en_o,

    // ---- fault confinement -------------------------------------------------
    input  can_fault_state_e           fault_state_i,
    output logic                       tec_inc8_o,
    output logic                       tec_dec_o,
    output logic                       rec_inc1_o,
    output logic                       rec_inc8_o,
    output logic                       rec_dec_o,
    input  wire                        auto_recover_i,
    input  wire                        recover_req_i,
    output logic                       recovery_done_o,

    // ---- transmit message interface ----------------------------------------
    input  wire                        tx_valid_i,        // TX FIFO not empty
    input  wire  [CAN_MSG_WIDTH-1:0]   tx_msg_i,          // TX FIFO head
    input  wire                        tx_cancel_i,       // abort / flush pulse
    output logic                       tx_pop_o,
    output logic                       tx_active_o,

    // ---- receive message interface -----------------------------------------
    output logic                       rx_push_o,
    output logic [CAN_MSG_WIDTH-1:0]   rx_msg_o,
    output logic                       sof_o,             // start-of-frame pulse

    // ---- acceptance filter (combinational, evaluated on these outputs) -----
    output logic [CAN_ID_WIDTH-1:0]    rx_id_o,
    output logic                       rx_ide_o,
    output logic                       rx_rtr_o,
    input  wire                        filter_accept_i,
    input  wire  [2:0]                 filter_hit_i,
    input  wire                        filter_matched_i,
    input  wire                        filter_irq_i,

    // ---- events ------------------------------------------------------------
    output logic                       evt_tx_complete_o,
    output logic                       evt_tx_abort_o,
    output logic                       evt_arb_lost_o,
    output logic                       evt_err_valid_o,
    output can_err_kind_e              evt_err_kind_o,
    output logic [4:0]                 evt_err_phase_o,
    // A completely received frame was discarded because its data length code
    // is not a valid Classical CAN data length (specification 02 section 7).
    output logic                       evt_dlc_err_o,

    // ---- status ------------------------------------------------------------
    output can_state_e                 state_o,
    output logic [2:0]                 stuff_cnt_o,
    output logic                       rx_busy_o,
    output logic                       bus_idle_o
);

  //===========================================================================
  // State
  //===========================================================================
  can_state_e               state_q;
  logic [6:0]               bit_cnt_q;
  logic                     transmitting_q;

  logic [CAN_MSG_WIDTH-1:0] tx_frame_q;
  logic                     tx_no_retry_q;      // current attempt must not retry

  logic [10:0]              rx_id_a_q;
  logic [17:0]              rx_id_b_q;
  logic                     rx_ide_q;
  logic                     rx_rtr_q;
  logic                     rtr_srr_q;          // RTR/SRR bit as received
  logic [3:0]               rx_dlc_q;
  logic [CAN_DATA_WIDTH-1:0] rx_data_q;
  logic [6:0]               data_bits_q;        // payload length in bits

  logic [14:0]              crc_q;              // locally computed CRC
  logic [13:0]              rx_crc_q;           // CRC sequence, MSBs only
  logic                     crc_err_q;          // deferred to the ACK delimiter

  logic [2:0]               stuff_cnt_q;
  logic                     last_bit_q;
  logic                     stuff_en_q;

  logic                     txd_q;
  logic                     ack_drive_q;

  logic                     err_is_ovl_q;       // overload flag rather than error flag
  logic                     err_flag_dom_q;     // flag is driven dominant
  logic [2:0]               err_eq_cnt_q;       // passive flag: equal-bit run
  logic                     err_prev_bit_q;
  logic [2:0]               dom8_q;             // rule 6: every 8 dominant bits
  logic                     tec8_defer_q;       // rule 3 exception 1

  logic [3:0]               recessive_run_q;
  logic [7:0]               busoff_seq_q;
  logic                     recovery_armed_q;

  logic                     susp_needed_q;

  //===========================================================================
  // Combinational helpers
  //===========================================================================
  logic bus_off;
  logic can_drive;          // the node is allowed to drive the bus at all
  logic can_transmit;       // the node is allowed to start a transmission

  assign bus_off      = (fault_state_i == FC_BUS_OFF);
  assign can_drive    = enable_i && !listen_only_i && !bus_off;
  assign can_transmit = can_drive && tx_valid_i && !tx_no_retry_q;

  // ---- transmit frame field extraction --------------------------------------
  logic [CAN_ID_WIDTH-1:0] tx_id;
  logic                    tx_ide, tx_rtr, tx_one_shot;
  logic [3:0]              tx_dlc;
  logic [CAN_DATA_WIDTH-1:0] tx_data;
  logic [10:0]             tx_id_a;
  logic [17:0]             tx_id_b;

  assign tx_data     = tx_frame_q[CAN_MSG_DATA_LSB +: CAN_DATA_WIDTH];
  assign tx_id       = tx_frame_q[CAN_MSG_ID_LSB +: CAN_ID_WIDTH];
  assign tx_ide      = tx_frame_q[CAN_MSG_IDE_BIT];
  assign tx_rtr      = tx_frame_q[CAN_MSG_RTR_BIT];
  assign tx_dlc      = tx_frame_q[CAN_MSG_DLC_LSB +: 4];
  assign tx_one_shot = tx_frame_q[CAN_MSG_FLAG_BIT];

  assign tx_id_a = tx_ide ? tx_id[28:18] : tx_id[10:0];
  assign tx_id_b = tx_id[17:0];

  // MSB-first bit selection out of the payload: bit k of the frame is bit
  // (7 - k mod 8) of byte (k / 8), and byte b occupies tx_data[b*8 +: 8].
  function automatic logic data_bit(input logic [CAN_DATA_WIDTH-1:0] d,
                                   input logic [5:0]                 k);
    logic [5:0] idx;
    idx      = {k[5:3], 3'b000} + 6'(3'd7 - k[2:0]);
    data_bit = d[idx];
  endfunction

  // ---- stuffing -------------------------------------------------------------
  logic stuff_pending;
  assign stuff_pending = stuff_en_q && (stuff_cnt_q == 3'(CAN_STUFF_LEN));

  // ---- receive identifier ---------------------------------------------------
  assign rx_id_o  = rx_ide_q ? {rx_id_a_q, rx_id_b_q} : {18'd0, rx_id_a_q};
  assign rx_ide_o = rx_ide_q;
  assign rx_rtr_o = rx_rtr_q;

  //===========================================================================
  // Transmitted level for the NEXT bit time
  //
  // Evaluated from the state left behind by the last sample point, and
  // registered into txd_q on bit_end.
  //===========================================================================
  logic tx_bit_next;

  always_comb begin
    if (!can_drive) begin
      tx_bit_next = CAN_RECESSIVE;
    end else if (stuff_pending) begin
      // A stuff bit is due; every node in the stuffed region inserts it.
      tx_bit_next = transmitting_q ? ~last_bit_q : CAN_RECESSIVE;
    end else begin
      unique case (state_q)
        ST_SOF      : tx_bit_next = transmitting_q ? CAN_DOMINANT : CAN_RECESSIVE;
        ST_ID_A     : tx_bit_next = transmitting_q ? tx_id_a[10 - bit_cnt_q[3:0]]
                                                   : CAN_RECESSIVE;
        ST_RTR_SRR  : tx_bit_next = transmitting_q ? (tx_ide ? CAN_RECESSIVE : tx_rtr)
                                                   : CAN_RECESSIVE;
        ST_IDE      : tx_bit_next = transmitting_q ? tx_ide : CAN_RECESSIVE;
        ST_ID_B     : tx_bit_next = transmitting_q ? tx_id_b[17 - bit_cnt_q[4:0]]
                                                   : CAN_RECESSIVE;
        ST_RTR_EXT  : tx_bit_next = transmitting_q ? tx_rtr : CAN_RECESSIVE;
        // ISO 11898-1: the reserved bits r1 and r0 are transmitted dominant.
        ST_R1       : tx_bit_next = transmitting_q ? CAN_DOMINANT : CAN_RECESSIVE;
        ST_R0       : tx_bit_next = transmitting_q ? CAN_DOMINANT : CAN_RECESSIVE;
        ST_DLC      : tx_bit_next = transmitting_q ? tx_dlc[3 - bit_cnt_q[1:0]]
                                                   : CAN_RECESSIVE;
        ST_DATA     : tx_bit_next = transmitting_q ? data_bit(tx_data, bit_cnt_q[5:0])
                                                   : CAN_RECESSIVE;
        ST_CRC      : tx_bit_next = transmitting_q ? crc_q[14 - bit_cnt_q[3:0]]
                                                   : CAN_RECESSIVE;
        ST_ACK_SLOT : tx_bit_next = ack_drive_q ? CAN_DOMINANT : CAN_RECESSIVE;
        ST_ERR_FLAG : tx_bit_next = err_flag_dom_q ? CAN_DOMINANT : CAN_RECESSIVE;
        default     : tx_bit_next = CAN_RECESSIVE;
      endcase
    end
  end

  // The transmitted level is the registered bit, gated by the conditions that
  // forbid this node from driving at all.  Gating here rather than only inside
  // the bit register means listen-only, bus-off and a disabled controller take
  // effect immediately instead of at the next bit boundary, which is what the
  // specification requires.  `can_drive` is a function of registers only, so
  // no primary input reaches can_txd combinationally.
  assign txd_o         = can_drive ? txd_q : CAN_RECESSIVE;
  assign tx_dominant_o = (txd_o == CAN_DOMINANT);
  assign hard_sync_en_o = !can_state_in_frame(state_q);
  assign state_o       = state_q;
  assign stuff_cnt_o   = stuff_cnt_q;
  assign rx_busy_o     = can_state_in_frame(state_q) && !transmitting_q;
  assign bus_idle_o    = (state_q == ST_IDLE);
  assign tx_active_o   = transmitting_q;

  //===========================================================================
  // Sample-point processing
  //===========================================================================
  // The received bit and the levels the node is currently driving.
  logic rx;
  assign rx = rx_bit_i;

  // Message descriptor written into the RX FIFO.
  always_comb begin
    rx_msg_o                                = '0;
    rx_msg_o[CAN_MSG_DATA_LSB +: CAN_DATA_WIDTH] = rx_data_q;
    rx_msg_o[CAN_MSG_ID_LSB +: CAN_ID_WIDTH]= rx_id_o;
    rx_msg_o[CAN_MSG_IDE_BIT]               = rx_ide_q;
    rx_msg_o[CAN_MSG_RTR_BIT]               = rx_rtr_q;
    rx_msg_o[CAN_MSG_DLC_LSB +: 4]          = rx_dlc_q;
    // Bit CAN_MSG_FLAG_BIT carries the one-shot flag on the transmit side and
    // the accepting filter's interrupt enable on the receive side
    // (specification 08 section 4): the frame is stored either way, but only
    // an interrupt-enabled filter announces it.
    rx_msg_o[CAN_MSG_FLAG_BIT]              = filter_irq_i;
    rx_msg_o[CAN_MSG_FHIT_LSB +: 3]         = filter_hit_i;
    rx_msg_o[CAN_MSG_FMATCH_BIT]            = filter_matched_i;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin : p_engine
    // ---- local working variables ------------------------------------------
    // Declared inside the process on purpose: they are combinational
    // temporaries of this evaluation, not state.
    can_state_e nx_state;
    logic [6:0] nx_bit_cnt;
    logic err_now;
    logic arb_lost_now;
    can_err_kind_e err_k;
    logic frame_done_rx;
    logic frame_done_tx;

    if (!rst_ni) begin
      state_q          <= ST_IDLE;
      bit_cnt_q        <= '0;
      transmitting_q   <= 1'b0;
      tx_frame_q       <= '0;
      tx_no_retry_q    <= 1'b0;
      rx_id_a_q        <= '0;
      rx_id_b_q        <= '0;
      rx_ide_q         <= 1'b0;
      rx_rtr_q         <= 1'b0;
      rtr_srr_q        <= 1'b0;
      rx_dlc_q         <= '0;
      rx_data_q        <= '0;
      data_bits_q      <= '0;
      crc_q            <= '0;
      rx_crc_q         <= '0;
      crc_err_q        <= 1'b0;
      stuff_cnt_q      <= 3'd1;
      last_bit_q       <= CAN_RECESSIVE;
      stuff_en_q       <= 1'b0;
      txd_q            <= CAN_RECESSIVE;
      ack_drive_q      <= 1'b0;
      err_is_ovl_q     <= 1'b0;
      err_flag_dom_q   <= 1'b0;
      err_eq_cnt_q     <= 3'd0;
      err_prev_bit_q   <= CAN_RECESSIVE;
      dom8_q           <= 3'd0;
      tec8_defer_q     <= 1'b0;
      recessive_run_q  <= '0;
      busoff_seq_q     <= '0;
      recovery_armed_q <= 1'b0;
      susp_needed_q    <= 1'b0;

      tec_inc8_o        <= 1'b0;
      tec_dec_o         <= 1'b0;
      rec_inc1_o        <= 1'b0;
      rec_inc8_o        <= 1'b0;
      rec_dec_o         <= 1'b0;
      recovery_done_o   <= 1'b0;
      tx_pop_o          <= 1'b0;
      rx_push_o         <= 1'b0;
      sof_o             <= 1'b0;
      evt_tx_complete_o <= 1'b0;
      evt_tx_abort_o    <= 1'b0;
      evt_arb_lost_o    <= 1'b0;
      evt_err_valid_o   <= 1'b0;
      evt_err_kind_o    <= ERR_NONE;
      evt_err_phase_o   <= '0;
      evt_dlc_err_o     <= 1'b0;
    end else begin
      // Every output below is a single-clock pulse.
      tec_inc8_o        <= 1'b0;
      tec_dec_o         <= 1'b0;
      rec_inc1_o        <= 1'b0;
      rec_inc8_o        <= 1'b0;
      rec_dec_o         <= 1'b0;
      recovery_done_o   <= 1'b0;
      tx_pop_o          <= 1'b0;
      rx_push_o         <= 1'b0;
      sof_o             <= 1'b0;
      evt_tx_complete_o <= 1'b0;
      evt_tx_abort_o    <= 1'b0;
      evt_arb_lost_o    <= 1'b0;
      evt_err_valid_o   <= 1'b0;
      evt_dlc_err_o     <= 1'b0;

      // ---- software abort / flush -----------------------------------------
      // The flag only suppresses the RETRY of a frame that is already in
      // flight.  Latching it while the engine is idle would block every
      // future transmission, because nothing would ever clear it again: the
      // clearing paths all require a transmission to complete or to fail.
      if (tx_cancel_i && transmitting_q) begin
        tx_no_retry_q <= 1'b1;
      end

      // ---- manual bus-off recovery arming ---------------------------------
      if (recover_req_i) begin
        recovery_armed_q <= 1'b1;
      end

      //---------------------------------------------------------------------
      // Controller disabled or in initialization: hold everything idle.
      //---------------------------------------------------------------------
      if (!enable_i) begin
        state_q          <= ST_IDLE;
        bit_cnt_q        <= '0;
        transmitting_q   <= 1'b0;
        txd_q            <= CAN_RECESSIVE;
        stuff_en_q       <= 1'b0;
        stuff_cnt_q      <= 3'd1;
        last_bit_q       <= CAN_RECESSIVE;
        ack_drive_q      <= 1'b0;
        crc_err_q        <= 1'b0;
        recessive_run_q  <= '0;
        busoff_seq_q     <= '0;
        recovery_armed_q <= 1'b0;
        susp_needed_q    <= 1'b0;
        tx_no_retry_q    <= 1'b0;
      end else begin

        //-------------------------------------------------------------------
        // Transmit level update.  Uses the state produced by the preceding
        // sample point, which is what makes txd a pure function of it.
        //-------------------------------------------------------------------
        if (bit_end_i) begin
          txd_q <= tx_bit_next;
        end

        //-------------------------------------------------------------------
        // Sample point: all protocol state advances here.
        //-------------------------------------------------------------------
        if (sample_point_i) begin
          nx_state   = state_q;
          nx_bit_cnt = bit_cnt_q;
          err_now      = 1'b0;
          arb_lost_now = 1'b0;
          err_k        = ERR_NONE;
          frame_done_rx = 1'b0;
          frame_done_tx = 1'b0;

          // ---- consecutive recessive bit run -----------------------------
          if (rx == CAN_RECESSIVE) begin
            if (recessive_run_q < 4'(CAN_RECESSIVE_RUN_LEN)) begin
              recessive_run_q <= recessive_run_q + 4'd1;
            end
          end else begin
            recessive_run_q <= '0;
          end

          //=================================================================
          // BUS OFF
          //=================================================================
          if (bus_off) begin
            transmitting_q <= 1'b0;
            stuff_en_q     <= 1'b0;
            ack_drive_q    <= 1'b0;
            nx_state       = ST_BUS_OFF;
            nx_bit_cnt     = '0;

            if (auto_recover_i) recovery_armed_q <= 1'b1;

            if (state_q == ST_BUS_OFF) begin
              // 128 sequences of 11 consecutive recessive bits (rule 11).
              //
              // The comparison is >= rather than ==, and that matters when
              // recovery is armed LATE.  `recessive_run_q` saturates at
              // CAN_RECESSIVE_RUN_LEN and is only cleared by a dominant bit or
              // by this branch, so on a node that entered bus off with
              // recovery disarmed and then sat on an idle bus, the counter is
              // already parked at its saturation value by the time software
              // writes ERROR_CONTROL.RECOVER_REQ.  With an equality test that
              // value can never be observed again without a dominant bit
              // first, and manual recovery on a quiet bus never starts at all.
              if ((recovery_armed_q || auto_recover_i) &&
                  (rx == CAN_RECESSIVE) &&
                  (recessive_run_q >= 4'(CAN_RECESSIVE_RUN_LEN - 1))) begin
                recessive_run_q <= '0;
                if (busoff_seq_q == 8'(CAN_BUSOFF_RECOVERY_SEQS - 1)) begin
                  busoff_seq_q     <= '0;
                  recovery_armed_q <= 1'b0;
                  recovery_done_o  <= 1'b1;
                  nx_state         = ST_IDLE;
                end else begin
                  busoff_seq_q <= busoff_seq_q + 8'd1;
                end
              end
            end else begin
              // Just entered bus off: abandon whatever was in flight.
              busoff_seq_q <= '0;
              if (tx_valid_i) begin
                evt_tx_abort_o <= 1'b1;
              end
            end

          //=================================================================
          // ERROR / OVERLOAD SIGNALLING
          //=================================================================
          end else if (state_q == ST_ERR_FLAG) begin
            if (err_flag_dom_q) begin
              // Active error flag / overload flag: six dominant bits.
              if (rx == CAN_RECESSIVE) begin
                // Bit error while sending a flag (ISO rules 4 and 5).
                if (transmitting_q) tec_inc8_o <= 1'b1;
                else                rec_inc8_o <= 1'b1;
                nx_bit_cnt = '0;                       // restart the flag
              end else if (bit_cnt_q == 7'(CAN_ERR_FLAG_LEN - 1)) begin
                nx_state   = ST_ERR_ECHO;
                nx_bit_cnt = '0;
                dom8_q     <= 3'd0;
              end else begin
                nx_bit_cnt = bit_cnt_q + 7'd1;
              end
            end else begin
              // Passive error flag: wait for six consecutive equal bits.
              // A dominant bit inside this window cancels the ISO rule 3
              // exception 1 deferral.
              if ((rx == CAN_DOMINANT) && tec8_defer_q) begin
                tec_inc8_o   <= 1'b1;
                tec8_defer_q <= 1'b0;
              end
              if (rx == err_prev_bit_q) begin
                if (err_eq_cnt_q == 3'(CAN_ERR_FLAG_LEN - 1)) begin
                  nx_state   = ST_ERR_ECHO;
                  nx_bit_cnt = '0;
                  dom8_q     <= 3'd0;
                end else begin
                  err_eq_cnt_q <= err_eq_cnt_q + 3'd1;
                end
              end else begin
                err_eq_cnt_q <= 3'd1;
              end
              err_prev_bit_q <= rx;
            end

          end else if (state_q == ST_ERR_ECHO) begin
            if (rx == CAN_RECESSIVE) begin
              // First bit of the error delimiter.
              nx_state     = ST_ERR_DELIM;
              nx_bit_cnt   = 7'd1;
              tec8_defer_q <= 1'b0;
            end else begin
              // ISO rule 2: a receiver that sees a dominant bit as the first
              // bit after its own error flag adds 8 to REC.
              if ((bit_cnt_q == '0) && !transmitting_q && !err_is_ovl_q) begin
                rec_inc8_o <= 1'b1;
              end
              // ISO rule 6: every further 8 consecutive dominant bits.
              if (dom8_q == 3'd7) begin
                dom8_q <= 3'd0;
                if (transmitting_q) tec_inc8_o <= 1'b1;
                else                rec_inc8_o <= 1'b1;
              end else begin
                dom8_q <= dom8_q + 3'd1;
              end
              nx_bit_cnt = bit_cnt_q + 7'd1;
            end

          end else if (state_q == ST_ERR_DELIM) begin
            if (rx == CAN_DOMINANT) begin
              // The error delimiter is a fixed-form field, so a dominant bit
              // inside it is a FORM ERROR (ISO 11898-1 clause 10, "a form
              // error is detected when a fixed-form bit field contains one or
              // more illegal bits").  A new error flag is started and the
              // clause 12 counter rule for the node's current role is applied.
              //
              // This is handled locally rather than through the shared
              // `err_now` block at the end of the normal-frame branch: that
              // block is inside the `else` arm below and is not reachable from
              // here, so setting err_now here alone would be dead code.
              nx_state        = ST_ERR_FLAG;
              nx_bit_cnt      = '0;
              err_is_ovl_q    <= 1'b0;
              err_flag_dom_q  <= can_drive && (fault_state_i == FC_ERROR_ACTIVE);
              err_eq_cnt_q    <= 3'd1;
              err_prev_bit_q  <= rx;
              dom8_q          <= 3'd0;

              evt_err_valid_o <= 1'b1;
              evt_err_kind_o  <= ERR_FORM;
              evt_err_phase_o <= state_q;

              // ISO rule 3 for a transmitter, rule 1 for a receiver.
              if (transmitting_q) tec_inc8_o <= 1'b1;
              else                rec_inc1_o <= 1'b1;
            end else if (bit_cnt_q == 7'(CAN_ERR_DELIM_LEN - 1)) begin
              nx_state   = ST_INTERMISSION;
              nx_bit_cnt = '0;
              if (transmitting_q) begin
                susp_needed_q  <= (fault_state_i == FC_ERROR_PASSIVE);
                transmitting_q <= 1'b0;
              end
            end else begin
              nx_bit_cnt = bit_cnt_q + 7'd1;
            end

          //=================================================================
          // NORMAL FRAME PROCESSING
          //=================================================================
          end else begin
            // ---- bit error / arbitration ---------------------------------
            arb_lost_now = 1'b0;
            if (can_drive && (txd_q == CAN_DOMINANT) && (rx == CAN_RECESSIVE)) begin
              // Drove dominant, read recessive: always a bit error.
              err_now = 1'b1;
              err_k   = ERR_BIT;
            end else if (transmitting_q && (txd_q == CAN_RECESSIVE) &&
                         (rx == CAN_DOMINANT)) begin
              if (can_state_is_arbitration(state_q)) begin
                // Loss of arbitration is not an error.  The frame stays at
                // the head of the TX FIFO and the node continues as a
                // receiver of the winning frame.
                transmitting_q <= 1'b0;
                tx_no_retry_q  <= 1'b0;
                arb_lost_now    = 1'b1;
                evt_arb_lost_o <= 1'b1;
                if (one_shot_i || !auto_retx_i || tx_one_shot) begin
                  // Nothing to release when a flush already removed the frame.
                  tx_pop_o       <= !tx_no_retry_q;
                  evt_tx_abort_o <= 1'b1;
                end
              end else if (state_q == ST_ACK_SLOT) begin
                // The expected acknowledgement.
                ack_drive_q <= 1'b0;
              end else begin
                err_now = 1'b1;
                err_k   = ERR_BIT;
              end
            end

            // ---- destuffing ----------------------------------------------
            if (!err_now && stuff_pending) begin
              if (rx == last_bit_q) begin
                err_now = 1'b1;
                err_k   = ERR_STUFF;
              end else begin
                stuff_cnt_q <= 3'd1;
                last_bit_q  <= rx;
                // The stuffed region ends with the bit that precedes the CRC
                // delimiter, so a stuff bit consumed in ST_CRC_DELIM is the
                // last one.
                if (state_q == ST_CRC_DELIM) stuff_en_q <= 1'b0;
              end
              // A stuff bit never advances the field sequencer.
            end else if (!err_now) begin
              // ---- real (destuffed) bit ----------------------------------
              if (stuff_en_q) begin
                if (rx == last_bit_q) stuff_cnt_q <= stuff_cnt_q + 3'd1;
                else                  stuff_cnt_q <= 3'd1;
                last_bit_q <= rx;
              end

              if (can_state_is_crc_protected(state_q)) begin
                crc_q <= can_crc15_next(crc_q, rx);
              end

              unique case (state_q)
                //-----------------------------------------------------------
                ST_IDLE : begin
                  if (rx == CAN_DOMINANT) begin
                    // Somebody started a frame; this bit is its SOF.
                    nx_state       = ST_ID_A;
                    nx_bit_cnt     = '0;
                    transmitting_q <= 1'b0;
                    stuff_en_q     <= 1'b1;
                    stuff_cnt_q    <= 3'd1;
                    last_bit_q     <= CAN_DOMINANT;
                    crc_q          <= can_crc15_next(15'd0, CAN_DOMINANT);
                    crc_err_q      <= 1'b0;
                    rx_ide_q       <= 1'b0;
                    rx_rtr_q       <= 1'b0;
                    rx_data_q      <= '0;
                    rx_dlc_q       <= '0;
                    sof_o          <= 1'b1;
                  end else if (can_transmit) begin
                    nx_state       = ST_SOF;
                    transmitting_q <= 1'b1;
                    tx_frame_q     <= tx_msg_i;
                  end
                end

                //-----------------------------------------------------------
                ST_SOF : begin
                  // Only reached as a transmitter; the SOF we drove.
                  nx_state    = ST_ID_A;
                  nx_bit_cnt  = '0;
                  stuff_en_q  <= 1'b1;
                  stuff_cnt_q <= 3'd1;
                  last_bit_q  <= rx;
                  crc_q       <= can_crc15_next(15'd0, rx);
                  crc_err_q   <= 1'b0;
                  rx_ide_q    <= 1'b0;
                  rx_rtr_q    <= 1'b0;
                  rx_data_q   <= '0;
                  rx_dlc_q    <= '0;
                  sof_o       <= 1'b1;
                end

                //-----------------------------------------------------------
                ST_ID_A : begin
                  rx_id_a_q <= {rx_id_a_q[9:0], rx};
                  if (bit_cnt_q == 7'(CAN_BASE_ID_WIDTH - 1)) begin
                    nx_state   = ST_RTR_SRR;
                    nx_bit_cnt = '0;
                  end else begin
                    nx_bit_cnt = bit_cnt_q + 7'd1;
                  end
                end

                ST_RTR_SRR : begin
                  rtr_srr_q <= rx;
                  nx_state  = ST_IDE;
                end

                ST_IDE : begin
                  rx_ide_q <= rx;
                  if (rx == CAN_DOMINANT) begin
                    // Base format: the previous bit was RTR.
                    rx_rtr_q   <= rtr_srr_q;
                    nx_state   = ST_R0;
                  end else begin
                    nx_state   = ST_ID_B;
                    nx_bit_cnt = '0;
                  end
                end

                ST_ID_B : begin
                  rx_id_b_q <= {rx_id_b_q[16:0], rx};
                  if (bit_cnt_q == 7'(CAN_EXT_ID_WIDTH - 1)) begin
                    nx_state   = ST_RTR_EXT;
                    nx_bit_cnt = '0;
                  end else begin
                    nx_bit_cnt = bit_cnt_q + 7'd1;
                  end
                end

                ST_RTR_EXT : begin
                  rx_rtr_q <= rx;
                  nx_state = ST_R1;
                end

                // The two reserved bits are fixed-format fields: a Classical
                // CAN transmitter sends them dominant, so a recessive one is
                // an illegal value in a fixed-format field and therefore a
                // FORM ERROR (specification 02 sections 2 and 3, specification
                // 06 section 8).
                ST_R1 : begin
                  if (rx == CAN_RECESSIVE) begin
                    err_now = 1'b1;
                    err_k   = ERR_FORM;
                  end else begin
                    nx_state = ST_R0;
                  end
                end

                ST_R0 : begin
                  if (rx == CAN_RECESSIVE) begin
                    err_now = 1'b1;
                    err_k   = ERR_FORM;
                  end else begin
                    nx_state   = ST_DLC;
                    nx_bit_cnt = '0;
                  end
                end

                ST_DLC : begin
                  rx_dlc_q <= {rx_dlc_q[2:0], rx};
                  if (bit_cnt_q == 7'(CAN_DLC_WIDTH - 1)) begin
                    nx_bit_cnt = '0;
                    // The length must be derived from the value that includes
                    // the bit being consumed now.
                    if (rx_rtr_q || (can_dlc_to_len({rx_dlc_q[2:0], rx}) == 4'd0)) begin
                      data_bits_q <= '0;
                      nx_state    = ST_CRC;
                    end else begin
                      data_bits_q <= {can_dlc_to_len({rx_dlc_q[2:0], rx}), 3'b000};
                      nx_state    = ST_DATA;
                    end
                  end else begin
                    nx_bit_cnt = bit_cnt_q + 7'd1;
                  end
                end

                ST_DATA : begin
                  rx_data_q[{bit_cnt_q[5:3], 3'b000} + 6'(3'd7 - bit_cnt_q[2:0])] <= rx;
                  if (bit_cnt_q == (data_bits_q - 7'd1)) begin
                    nx_state   = ST_CRC;
                    nx_bit_cnt = '0;
                  end else begin
                    nx_bit_cnt = bit_cnt_q + 7'd1;
                  end
                end

                ST_CRC : begin
                  rx_crc_q <= {rx_crc_q[12:0], rx};
                  if (bit_cnt_q == 7'(CAN_CRC_WIDTH - 1)) begin
                    nx_state   = ST_CRC_DELIM;
                    nx_bit_cnt = '0;
                    // The CRC comparison uses the value including this bit.
                    crc_err_q  <= ({rx_crc_q, rx} != crc_q);
                  end else begin
                    nx_bit_cnt = bit_cnt_q + 7'd1;
                  end
                end

                ST_CRC_DELIM : begin
                  stuff_en_q <= 1'b0;
                  if (rx == CAN_DOMINANT) begin
                    err_now = 1'b1;
                    err_k   = ERR_FORM;
                  end else begin
                    nx_state = ST_ACK_SLOT;
                    // Decide the acknowledgement now, so that it is driven at
                    // the following bit_end.
                    ack_drive_q <= !listen_only_i && !crc_err_q &&
                                   (!transmitting_q || (loopback_i && self_ack_i));
                  end
                end

                ST_ACK_SLOT : begin
                  if (transmitting_q && (rx == CAN_RECESSIVE)) begin
                    err_now = 1'b1;
                    err_k   = ERR_ACK;
                  end else begin
                    nx_state = ST_ACK_DELIM;
                  end
                  ack_drive_q <= 1'b0;
                end

                ST_ACK_DELIM : begin
                  if (rx == CAN_DOMINANT) begin
                    err_now = 1'b1;
                    err_k   = ERR_FORM;
                  end else if (crc_err_q) begin
                    // ISO signals a CRC error after the ACK delimiter.
                    err_now = 1'b1;
                    err_k   = ERR_CRC;
                  end else begin
                    nx_state   = ST_EOF;
                    nx_bit_cnt = '0;
                  end
                end

                ST_EOF : begin
                  if ((rx == CAN_DOMINANT) && (bit_cnt_q < 7'(CAN_EOF_LEN - 1))) begin
                    err_now = 1'b1;
                    err_k   = ERR_FORM;
                  end else begin
                    if (bit_cnt_q == 7'(CAN_EOF_LEN - 2)) begin
                      // Valid for a receiver after six recessive EOF bits.
                      frame_done_rx = 1'b1;
                    end
                    if (bit_cnt_q == 7'(CAN_EOF_LEN - 1)) begin
                      frame_done_tx = 1'b1;
                      if (rx == CAN_DOMINANT) begin
                        // A dominant last EOF bit is an overload condition;
                        // the frame is still valid for both roles.
                        nx_state       = ST_ERR_FLAG;
                        nx_bit_cnt     = '0;
                        err_is_ovl_q   <= 1'b1;
                        err_flag_dom_q <= can_drive;
                        err_eq_cnt_q   <= 3'd1;
                        err_prev_bit_q <= rx;
                      end else begin
                        nx_state   = ST_INTERMISSION;
                        nx_bit_cnt = '0;
                      end
                    end else begin
                      nx_bit_cnt = bit_cnt_q + 7'd1;
                    end
                  end
                end

                ST_INTERMISSION : begin
                  if (rx == CAN_DOMINANT) begin
                    if (bit_cnt_q == 7'(CAN_INTERMISSION_LEN - 1)) begin
                      // A dominant bit in the last intermission bit is a SOF.
                      nx_state       = ST_ID_A;
                      nx_bit_cnt     = '0;
                      transmitting_q <= 1'b0;
                      stuff_en_q     <= 1'b1;
                      stuff_cnt_q    <= 3'd1;
                      last_bit_q     <= CAN_DOMINANT;
                      crc_q          <= can_crc15_next(15'd0, CAN_DOMINANT);
                      crc_err_q      <= 1'b0;
                      rx_ide_q       <= 1'b0;
                      rx_rtr_q       <= 1'b0;
                      rx_data_q      <= '0;
                      rx_dlc_q       <= '0;
                      sof_o          <= 1'b1;
                    end else begin
                      // Overload condition.
                      nx_state       = ST_ERR_FLAG;
                      nx_bit_cnt     = '0;
                      err_is_ovl_q   <= 1'b1;
                      err_flag_dom_q <= can_drive;
                      err_eq_cnt_q   <= 3'd1;
                      err_prev_bit_q <= rx;
                    end
                  end else begin
                    if (bit_cnt_q == 7'(CAN_INTERMISSION_LEN - 1)) begin
                      nx_bit_cnt = '0;
                      if (susp_needed_q) begin
                        nx_state = ST_SUSPEND;
                      end else if (can_transmit) begin
                        nx_state       = ST_SOF;
                        transmitting_q <= 1'b1;
                        tx_frame_q     <= tx_msg_i;
                      end else begin
                        nx_state = ST_IDLE;
                      end
                    end else begin
                      nx_bit_cnt = bit_cnt_q + 7'd1;
                    end
                  end
                end

                ST_SUSPEND : begin
                  if (rx == CAN_DOMINANT) begin
                    nx_state       = ST_ID_A;
                    nx_bit_cnt     = '0;
                    susp_needed_q  <= 1'b0;
                    transmitting_q <= 1'b0;
                    stuff_en_q     <= 1'b1;
                    stuff_cnt_q    <= 3'd1;
                    last_bit_q     <= CAN_DOMINANT;
                    crc_q          <= can_crc15_next(15'd0, CAN_DOMINANT);
                    crc_err_q      <= 1'b0;
                    rx_ide_q       <= 1'b0;
                    rx_rtr_q       <= 1'b0;
                    rx_data_q      <= '0;
                    rx_dlc_q       <= '0;
                    sof_o          <= 1'b1;
                  end else if (bit_cnt_q == 7'(CAN_SUSPEND_LEN - 1)) begin
                    nx_bit_cnt    = '0;
                    susp_needed_q <= 1'b0;
                    if (can_transmit) begin
                      nx_state       = ST_SOF;
                      transmitting_q <= 1'b1;
                      tx_frame_q     <= tx_msg_i;
                    end else begin
                      nx_state = ST_IDLE;
                    end
                  end else begin
                    nx_bit_cnt = bit_cnt_q + 7'd1;
                  end
                end

                default : begin
                  nx_state = ST_IDLE;
                end
              endcase
            end

            //---------------------------------------------------------------
            // Frame completion bookkeeping
            //---------------------------------------------------------------
            if (frame_done_rx) begin
              if (!transmitting_q || loopback_i) begin
                // Specification 02 section 7: a data length code above eight is
                // not a valid Classical CAN data length and is rejected.  The
                // frame is still received, acknowledged and counted, so the bus
                // is left undisturbed and no other node is penalised; it simply
                // never reaches the software-visible RX FIFO (specification 05
                // section 11).  The rejection is reported so that the
                // information is not lost.
                if (!can_dlc_is_valid(rx_dlc_q)) begin
                  evt_dlc_err_o <= 1'b1;
                end
                // A remote frame is stored only when ACCEPT_REMOTE is set.
                else if (filter_accept_i && (!rx_rtr_q || accept_remote_i)) begin
                  rx_push_o <= 1'b1;
                end
              end
              if (!transmitting_q) begin
                rec_dec_o <= 1'b1;      // ISO rule 8
              end
            end

            if (frame_done_tx && transmitting_q) begin
              // The pop releases the frame that was being transmitted.  If a
              // software abort or FIFO flush has already removed it, there is
              // nothing left to release: popping here would discard whatever
              // software queued in the meantime, which is a frame that was
              // never sent.  `tx_no_retry_q` is set only by a cancel taken
              // while transmitting, and a cancel always flushes the FIFO, so
              // it is exactly the "the frame is already gone" condition.
              tx_pop_o          <= !tx_no_retry_q;
              evt_tx_complete_o <= 1'b1;
              tec_dec_o         <= 1'b1;      // ISO rule 7
              tx_no_retry_q     <= 1'b0;
              susp_needed_q     <= (fault_state_i == FC_ERROR_PASSIVE);
              transmitting_q    <= 1'b0;
            end

            //---------------------------------------------------------------
            // Error detected in a normal frame state: start error signalling.
            //---------------------------------------------------------------
            if (err_now) begin
              nx_state       = ST_ERR_FLAG;
              nx_bit_cnt     = '0;
              err_is_ovl_q   <= 1'b0;
              err_flag_dom_q <= can_drive && (fault_state_i == FC_ERROR_ACTIVE);
              err_eq_cnt_q   <= 3'd1;
              err_prev_bit_q <= rx;
              stuff_en_q     <= 1'b0;
              ack_drive_q    <= 1'b0;
              dom8_q         <= 3'd0;

              evt_err_valid_o <= 1'b1;
              evt_err_kind_o  <= err_k;
              evt_err_phase_o <= state_q;

              if (arb_lost_now) begin
                // ISO rule 3 exception 2: a stuff error on a bit that was sent
                // recessive and monitored dominant inside the arbitration
                // field carries no counter penalty.  The node has just become
                // a receiver, so the transmitter rule does not apply either,
                // and the frame disposition was already decided by the
                // arbitration branch above.
                ;
              end else if (transmitting_q) begin
                // ISO rule 3 with exception 1: an error passive transmitter
                // that only failed to see the acknowledgement defers the
                // increment until it sees a dominant bit inside its own
                // passive error flag.
                if ((err_k == ERR_ACK) && (fault_state_i == FC_ERROR_PASSIVE)) begin
                  tec8_defer_q <= 1'b1;
                end else begin
                  tec_inc8_o <= 1'b1;
                end
                if (one_shot_i || !auto_retx_i || tx_one_shot || tx_no_retry_q) begin
                  // Nothing to release when a flush already removed the frame.
                  tx_pop_o       <= !tx_no_retry_q;
                  evt_tx_abort_o <= 1'b1;
                  tx_no_retry_q  <= 1'b0;
                  transmitting_q <= 1'b0;
                end
              end else begin
                rec_inc1_o <= 1'b1;     // ISO rule 1
              end
            end
          end

          state_q   <= nx_state;
          bit_cnt_q <= nx_bit_cnt;
        end
      end
    end
  end : p_engine

endmodule : can_protocol

`default_nettype wire
