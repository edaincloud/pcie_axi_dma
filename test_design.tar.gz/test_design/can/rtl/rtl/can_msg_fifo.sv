//=============================================================================
// File        : can_msg_fifo.sv
// Description : Synchronous message FIFO used for both the TX and the RX
//               message store (specification 08_Acceptance_Filter_and_
//               Message_RAM.md section 8).
//
//               Register-file based, arbitrary depth 1 .. CAN_MAX_FIFO_DEPTH.
//               The head entry is continuously visible on `head_o` so that
//               the transmit scheduler and the RX read registers can use it
//               without a read-latency cycle.
//
//               Overflow / underflow safety
//               --------------------------
//               A push into a full FIFO is either dropped (`push_i` with
//               `drop_old_i` low) or replaces the oldest entry (`drop_old_i`
//               high, the DROP_OLD policy).  A pop from an empty FIFO is
//               ignored.  `overflow_o` pulses whenever a push could not be
//               stored without loss; the FIFO itself can therefore never
//               overflow or underflow, which is asserted in the SVA module.
//=============================================================================

`default_nettype none

module can_msg_fifo
  import can_pkg::*;
#(
    parameter int unsigned WIDTH = 104,
    parameter int unsigned DEPTH = 4
) (
    input  wire              clk_i,
    input  wire              rst_ni,

    input  wire              flush_i,

    input  wire              push_i,
    input  wire [WIDTH-1:0]  wdata_i,
    // 1: a push into a full FIFO discards the OLDEST entry instead of the new
    //    one (DROP_OLD).  0: the new entry is discarded (DROP_NEW / BLOCK).
    input  wire              drop_old_i,

    input  wire              pop_i,

    output logic [WIDTH-1:0] head_o,
    output logic             empty_o,
    output logic             full_o,
    output logic [7:0]       level_o,
    // Pulses when a push was lost, or forced an entry out.
    output logic             overflow_o
);

  if (DEPTH < 1) begin : gen_chk_depth_min
    $error("can_msg_fifo: DEPTH must be >= 1 (got %0d)", DEPTH);
  end
  if (DEPTH > CAN_MAX_FIFO_DEPTH) begin : gen_chk_depth_max
    $error("can_msg_fifo: DEPTH must be <= %0d (got %0d)",
           CAN_MAX_FIFO_DEPTH, DEPTH);
  end

  localparam int unsigned PTR_W = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int unsigned LVL_W = $clog2(DEPTH + 1);

  logic [WIDTH-1:0] mem_q [DEPTH];
  logic [PTR_W-1:0] wr_ptr_q;
  logic [PTR_W-1:0] rd_ptr_q;
  logic [LVL_W-1:0] level_q;

  assign empty_o = (level_q == '0);
  assign full_o  = (level_q == LVL_W'(DEPTH));
  assign head_o  = mem_q[rd_ptr_q];

  always_comb begin
    level_o = '0;
    level_o[LVL_W-1:0] = level_q;
  end

  // A push is stored when there is room, or when it is allowed to displace the
  // oldest entry.
  logic do_push, do_pop, do_drop;
  assign do_pop  = pop_i && !empty_o;
  assign do_push = push_i && (!full_o || drop_old_i);
  assign do_drop = push_i && full_o && drop_old_i && !do_pop;

  assign overflow_o = push_i && full_o && !do_pop;

  function automatic logic [PTR_W-1:0] next_ptr(input logic [PTR_W-1:0] p);
    next_ptr = (p == PTR_W'(DEPTH - 1)) ? PTR_W'(0) : (p + PTR_W'(1));
  endfunction

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      wr_ptr_q <= '0;
      rd_ptr_q <= '0;
      level_q  <= '0;
      for (int unsigned i = 0; i < DEPTH; i++) begin
        mem_q[i] <= '0;
      end
    end else if (flush_i) begin
      wr_ptr_q <= '0;
      rd_ptr_q <= '0;
      level_q  <= '0;
    end else begin
      if (do_push) begin
        mem_q[wr_ptr_q] <= wdata_i;
        wr_ptr_q        <= next_ptr(wr_ptr_q);
      end
      if (do_pop || do_drop) begin
        rd_ptr_q <= next_ptr(rd_ptr_q);
      end

      // Level tracking: a displaced entry keeps the level unchanged.
      unique case ({do_push, (do_pop || do_drop)})
        2'b10   : level_q <= level_q + LVL_W'(1);
        2'b01   : level_q <= level_q - LVL_W'(1);
        default : level_q <= level_q;
      endcase
    end
  end

endmodule : can_msg_fifo

`default_nettype wire
