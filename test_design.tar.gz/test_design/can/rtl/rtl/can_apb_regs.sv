//=============================================================================
// File        : can_apb_regs.sv
// Description : APB4 slave and register bank for the Classical CAN IP
//               (specification 09_APB_Register_Specification.md).
//
//               Owns:
//                 - the APB4 protocol layer (zero wait state, PSTRB, PSLVERR)
//                 - every software visible register
//                 - the interrupt block
//                 - the acceptance-filter register file
//                 - the timestamp counter
//
//               Owns no protocol state: the bit engine, the error counters
//               and the message FIFOs are separate blocks, and everything
//               crossing between them is registered.
//
//               APB4 behaviour
//               --------------
//               PREADY  : tied high (zero wait state).
//               PSLVERR : asserted during the access phase for unmapped or
//                         misaligned addresses, writes to read-only registers,
//                         and writes to a bit-timing register while the
//                         controller is not in the initialization state
//                         (specification 09 section 5).  No state changes for
//                         an erroring access.
//               PRDATA  : combinational read mux, zero for anything that is
//                         not a valid read.
//               PSTRB   : honoured on every writable register.  Plain RW
//                         fields use read-modify-write; W1C and write-one-pulse
//                         fields use the strobed write data directly.
//=============================================================================

`default_nettype none

module can_apb_regs
  import can_pkg::*;
#(
    parameter int unsigned APB_ADDR_WIDTH   = 12,
    parameter int unsigned APB_DATA_WIDTH   = 32,
    parameter int unsigned BRP_WIDTH        = 8,
    parameter int unsigned NUM_FILTERS      = 4,
    parameter bit          TIMESTAMP_ENABLE = 1'b1,
    parameter int unsigned TIMESTAMP_WIDTH  = 32
) (
    input  wire                          clk_i,
    input  wire                          rst_ni,

    // ---------------------------------------------------------------- APB4
    input  wire                          psel_i,
    input  wire                          penable_i,
    input  wire                          pwrite_i,
    input  wire  [APB_ADDR_WIDTH-1:0]    paddr_i,
    input  wire  [APB_DATA_WIDTH-1:0]    pwdata_i,
    input  wire  [APB_DATA_WIDTH/8-1:0]  pstrb_i,
    output logic [APB_DATA_WIDTH-1:0]    prdata_o,
    output logic                         pready_o,
    output logic                         pslverr_o,

    // ------------------------------------------------------- mode / control
    output logic                         ctrl_enable_o,       // engine running
    output logic                         ctrl_init_o,
    output logic                         ctrl_loopback_o,
    output logic                         ctrl_listen_only_o,
    output logic                         ctrl_one_shot_o,
    output logic                         ctrl_auto_retx_o,
    output logic                         ctrl_accept_remote_o,
    output logic [1:0]                   mode_ovfl_policy_o,
    output logic                         mode_self_ack_o,
    output logic                         mode_native_en_o,

    // ---------------------------------------------------------- bit timing
    output logic [BRP_WIDTH-1:0]                brp_o,
    output logic [CAN_TSEG1_FIELD_WIDTH-1:0]    tseg1_o,
    output logic [CAN_TSEG2_FIELD_WIDTH-1:0]    tseg2_o,
    output logic [CAN_SJW_FIELD_WIDTH-1:0]      sjw_o,
    input  wire                                 bt_cfg_error_i,
    input  wire                                 bit_tick_i,   // one per bit time

    // ---------------------------------------------------- fault confinement
    output logic                         err_auto_recover_o,
    output logic                         err_recover_req_o,   // single-clock
    output logic [7:0]                   err_ewl_o,
    input  can_fault_state_e             fault_state_i,
    input  wire  [8:0]                   tec_i,
    input  wire  [7:0]                   rec_i,
    input  wire                          error_warning_i,
    input  wire                          bus_off_entry_i,
    input  wire  [7:0]                   bus_off_count_i,

    // -------------------------------------------------------------- filters
    output logic [NUM_FILTERS-1:0][CAN_FATTR_WIDTH-1:0] filter_attr_o,
    output logic [NUM_FILTERS-1:0][CAN_ID_WIDTH-1:0]    filter_id_o,
    output logic [NUM_FILTERS-1:0][CAN_ID_WIDTH-1:0]    filter_mask_o,
    output logic                         filter_gaccept_o,
    output logic                         filter_greject_o,

    // ------------------------------------------------------ TX message FIFO
    output logic                         tx_push_o,
    output logic [CAN_MSG_WIDTH-1:0]     tx_msg_o,
    output logic                         tx_flush_o,
    output logic                         tx_cancel_o,
    input  wire  [7:0]                   tx_level_i,
    input  wire                          tx_empty_i,
    input  wire                          tx_full_i,
    input  wire                          tx_active_i,

    // ------------------------------------------------------ RX message FIFO
    output logic                         rx_pop_o,
    output logic                         rx_flush_o,
    // Software acknowledged the overflow condition: releases the BLOCK policy.
    output logic                         rx_ovfl_clear_o,
    input  wire                          rx_blocked_i,
    input  wire  [CAN_MSG_WIDTH-1:0]     rx_head_i,
    input  wire  [TIMESTAMP_WIDTH-1:0]   rx_head_ts_i,
    input  wire  [7:0]                   rx_level_i,
    input  wire                          rx_empty_i,
    input  wire                          rx_full_i,
    input  wire                          rx_push_i,
    input  wire                          rx_overflow_i,

    // -------------------------------------------------------------- events
    input  wire                          evt_tx_complete_i,
    input  wire                          evt_tx_abort_i,
    input  wire                          evt_arb_lost_i,
    input  wire                          evt_err_valid_i,
    input  can_err_kind_e                evt_err_kind_i,
    input  wire  [4:0]                   evt_err_phase_i,
    // A received frame was rejected for an invalid data length code, or a
    // native transmit request was.
    input  wire                          evt_dlc_err_i,
    // A native transmit request was discarded.
    input  wire                          evt_tx_reject_i,

    // -------------------------------------------------------------- status
    input  can_state_e                   proto_state_i,
    input  wire  [CAN_BIT_POS_WIDTH-1:0] bit_pos_i,
    input  wire  [2:0]                   stuff_cnt_i,
    input  wire                          txd_i,
    input  wire                          rxd_i,
    input  wire                          rx_busy_i,
    input  wire                          bus_idle_i,

    // ----------------------------------------------------------- timestamp
    output logic [TIMESTAMP_WIDTH-1:0]   ts_value_o,
    output logic                         ts_capture_sof_o,

    // ----------------------------------------------------------- interrupt
    output logic                         irq_o
);

  //===========================================================================
  // APB phase decode
  //===========================================================================
  logic apb_access, apb_write, apb_read;

  assign apb_access = psel_i & penable_i;
  assign apb_write  = apb_access &  pwrite_i;
  assign apb_read   = apb_access & ~pwrite_i;

  assign pready_o = 1'b1;

  logic [31:0] addr32;
  always_comb begin
    addr32 = '0;
    addr32[APB_ADDR_WIDTH-1:0] = paddr_i;
  end

  logic addr_aligned, addr_mapped, addr_valid, write_to_ro, bt_locked;
  // Set for a bit-timing write that would leave the controller with a bit time
  // the hardware cannot execute; computed below, once the strobed write data
  // is available.  Declared here because the PSLVERR and write-enable terms
  // that consume it come first in the file.
  logic bt_illegal_wr;

  assign addr_aligned = (paddr_i[1:0] == 2'b00);
  assign addr_mapped  = can_addr_is_valid(addr32);
  assign addr_valid   = addr_aligned & addr_mapped;
  assign write_to_ro  = can_addr_is_ro(addr32);

  //===========================================================================
  // Register storage
  //===========================================================================
  logic [CAN_CTRL_WIDTH-1:0]           ctrl_q;
  logic [CAN_MODE_WIDTH-1:0]           mode_q;
  logic [CAN_INT_WIDTH-1:0]            int_status_q;
  logic [CAN_INT_WIDTH-1:0]            int_enable_q;

  logic [BRP_WIDTH-1:0]                brp_q;
  logic [CAN_TSEG1_FIELD_WIDTH-1:0]    tseg1_q;
  logic [CAN_TSEG2_FIELD_WIDTH-1:0]    tseg2_q;
  logic [CAN_SJW_FIELD_WIDTH-1:0]      sjw_q;

  logic                                auto_recover_q;
  logic [7:0]                          ewl_q;

  logic [2:0]                          lec_q;
  logic [4:0]                          lphase_q;
  logic [CAN_ERRSTICKY_WIDTH-1:0]      esticky_q;

  logic [CAN_ID_WIDTH-1:0]             tx_id_q;
  logic [31:0]                         tx_data0_q;
  logic [31:0]                         tx_data1_q;
  logic [3:0]                          tx_dlc_q;
  logic                                tx_rtr_q;
  logic                                tx_ide_q;
  logic                                tx_oneshot_q;

  logic [2:0]                          fidx_q;
  logic                                gaccept_q;
  logic                                greject_q;
  logic [NUM_FILTERS-1:0][CAN_FATTR_WIDTH-1:0] fattr_q;
  logic [NUM_FILTERS-1:0][CAN_ID_WIDTH-1:0]    fid_q;
  logic [NUM_FILTERS-1:0][CAN_ID_WIDTH-1:0]    fmask_q;

  logic                                ts_enable_q;
  logic                                ts_capture_q;
  logic [TIMESTAMP_WIDTH-1:0]          ts_cnt;

  logic                                dbg_enable_q;

  // Controller initialization state: bit-timing registers are writable and
  // the protocol engine is held idle.
  logic init_state;
  assign init_state = !ctrl_q[CAN_CTRL_ENABLE_BIT] || ctrl_q[CAN_CTRL_INIT_BIT];

  assign bt_locked = can_addr_is_bit_timing(addr32) && !init_state;

  assign pslverr_o = apb_access & (~addr_valid |
                                   (pwrite_i & (write_to_ro | bt_locked |
                                                bt_illegal_wr)));

  logic wr_en;
  assign wr_en = apb_write & addr_valid & ~write_to_ro & ~bt_locked & ~bt_illegal_wr;

  //===========================================================================
  // Byte strobes
  //===========================================================================
  logic [31:0] strb_mask;
  always_comb begin
    for (int unsigned b = 0; b < 4; b++) begin
      strb_mask[b*8 +: 8] = {8{pstrb_i[b]}};
    end
  end

  logic [31:0] wdata32, wdata_strobed;
  assign wdata32       = pwdata_i[31:0];
  assign wdata_strobed = wdata32 & strb_mask;

  //===========================================================================
  // Derived status
  //===========================================================================
  logic err_active, err_passive, bus_off;
  assign err_active  = (fault_state_i == FC_ERROR_ACTIVE);
  assign err_passive = (fault_state_i == FC_ERROR_PASSIVE);
  assign bus_off     = (fault_state_i == FC_BUS_OFF);

  logic tx_busy;
  assign tx_busy = tx_active_i || !tx_empty_i;

  //===========================================================================
  // Read mux
  //===========================================================================
  logic [31:0] reg_rdata;
  logic [31:0] filter_ctrl_rd;
  logic [CAN_FATTR_WIDTH-1:0] sel_attr;
  logic [CAN_ID_WIDTH-1:0]    sel_fid, sel_fmask;

  always_comb begin
    sel_attr  = '0;
    sel_fid   = '0;
    sel_fmask = '0;
    for (int unsigned f = 0; f < NUM_FILTERS; f++) begin
      if (fidx_q == 3'(f)) begin
        sel_attr  = fattr_q[f];
        sel_fid   = fid_q[f];
        sel_fmask = fmask_q[f];
      end
    end
  end

  always_comb begin
    filter_ctrl_rd = '0;
    filter_ctrl_rd[CAN_FCTRL_INDEX_LSB +: 3] = fidx_q;
    filter_ctrl_rd[CAN_FCTRL_ENABLE_BIT]     = sel_attr[CAN_FATTR_ENABLE];
    filter_ctrl_rd[CAN_FCTRL_IDE_SEL_BIT]    = sel_attr[CAN_FATTR_IDE_SEL];
    filter_ctrl_rd[CAN_FCTRL_IDE_CARE_BIT]   = sel_attr[CAN_FATTR_IDE_CARE];
    filter_ctrl_rd[CAN_FCTRL_RTR_SEL_BIT]    = sel_attr[CAN_FATTR_RTR_SEL];
    filter_ctrl_rd[CAN_FCTRL_RTR_CARE_BIT]   = sel_attr[CAN_FATTR_RTR_CARE];
    filter_ctrl_rd[CAN_FCTRL_RANGE_BIT]      = sel_attr[CAN_FATTR_RANGE];
    filter_ctrl_rd[CAN_FCTRL_IRQ_EN_BIT]     = sel_attr[CAN_FATTR_IRQ_EN];
    filter_ctrl_rd[CAN_FCTRL_GACCEPT_BIT]    = gaccept_q;
    filter_ctrl_rd[CAN_FCTRL_GREJECT_BIT]    = greject_q;
  end

  always_comb begin
    reg_rdata = 32'h0;

    unique case (addr32)
      CAN_ADDR_VERSION : reg_rdata = CAN_VERSION_VALUE;

      CAN_ADDR_CONTROL : reg_rdata[CAN_CTRL_WIDTH-1:0] = ctrl_q;

      CAN_ADDR_STATUS : begin
        reg_rdata[CAN_STAT_WIDTH-1:0]            = '0;
        reg_rdata[CAN_STAT_TX_BUSY_BIT]          = tx_busy;
        reg_rdata[CAN_STAT_RX_BUSY_BIT]          = rx_busy_i;
        reg_rdata[CAN_STAT_ERROR_ACTIVE_BIT]     = err_active;
        reg_rdata[CAN_STAT_ERROR_PASSIVE_BIT]    = err_passive;
        reg_rdata[CAN_STAT_BUS_OFF_BIT]          = bus_off;
        reg_rdata[CAN_STAT_RX_OVERFLOW_BIT]      = int_status_q[CAN_INT_RX_OVERFLOW_BIT];
        reg_rdata[CAN_STAT_TX_COMPLETE_BIT]      = int_status_q[CAN_INT_TX_COMPLETE_BIT];
        reg_rdata[CAN_STAT_ARBITRATION_LOST_BIT] = int_status_q[CAN_INT_ARBITRATION_LOST_BIT];
        reg_rdata[CAN_STAT_INIT_ACK_BIT]         = init_state;
        reg_rdata[CAN_STAT_BUS_IDLE_BIT]         = bus_idle_i;
        reg_rdata[CAN_STAT_ERROR_WARNING_BIT]    = error_warning_i;
        reg_rdata[CAN_STAT_BT_CFG_ERROR_BIT]     = bt_cfg_error_i;
      end

      CAN_ADDR_MODE       : reg_rdata[CAN_MODE_WIDTH-1:0] = mode_q;
      CAN_ADDR_INT_STATUS : reg_rdata[CAN_INT_WIDTH-1:0]  = int_status_q;
      CAN_ADDR_INT_ENABLE : reg_rdata[CAN_INT_WIDTH-1:0]  = int_enable_q;

      CAN_ADDR_BIT_BRP    : reg_rdata[BRP_WIDTH-1:0]                = brp_q;
      CAN_ADDR_BIT_TSEG1  : reg_rdata[CAN_TSEG1_FIELD_WIDTH-1:0]    = tseg1_q;
      CAN_ADDR_BIT_TSEG2  : reg_rdata[CAN_TSEG2_FIELD_WIDTH-1:0]    = tseg2_q;
      CAN_ADDR_BIT_SJW    : reg_rdata[CAN_SJW_FIELD_WIDTH-1:0]      = sjw_q;

      CAN_ADDR_ERROR_CONTROL : begin
        reg_rdata[CAN_ERRCTRL_AUTO_RECOVER_BIT] = auto_recover_q;
        reg_rdata[CAN_ERRCTRL_EWL_LSB +: 8]     = ewl_q;
      end

      CAN_ADDR_TEC : reg_rdata[8:0] = tec_i;
      CAN_ADDR_REC : reg_rdata[7:0] = rec_i;

      CAN_ADDR_ERROR_STATUS : begin
        reg_rdata[CAN_ERRSTAT_LEC_LSB   +: 3] = lec_q;
        reg_rdata[CAN_ERRSTAT_PHASE_LSB +: 5] = lphase_q;
        reg_rdata[CAN_ERRSTAT_STICKY_LSB +: CAN_ERRSTICKY_WIDTH] = esticky_q;
        reg_rdata[CAN_ERRSTAT_BOCNT_LSB +: 8] = bus_off_count_i;
      end

      CAN_ADDR_TX_CONTROL : reg_rdata = 32'h0;   // write-one-pulse only

      CAN_ADDR_TX_STATUS : begin
        reg_rdata[CAN_TXSTAT_LEVEL_LSB +: 8] = tx_level_i;
        reg_rdata[CAN_TXSTAT_EMPTY_BIT]      = tx_empty_i;
        reg_rdata[CAN_TXSTAT_FULL_BIT]       = tx_full_i;
        reg_rdata[CAN_TXSTAT_ACTIVE_BIT]     = tx_active_i;
      end

      CAN_ADDR_RX_CONTROL : reg_rdata = 32'h0;   // write-one-pulse only

      CAN_ADDR_RX_STATUS : begin
        reg_rdata[CAN_RXSTAT_LEVEL_LSB +: 8] = rx_level_i;
        reg_rdata[CAN_RXSTAT_EMPTY_BIT]      = rx_empty_i;
        reg_rdata[CAN_RXSTAT_FULL_BIT]       = rx_full_i;
        reg_rdata[CAN_RXSTAT_OVERFLOW_BIT]   = int_status_q[CAN_INT_RX_OVERFLOW_BIT];
        reg_rdata[CAN_RXSTAT_BLOCKED_BIT]    = rx_blocked_i;
      end

      CAN_ADDR_TX_ID    : reg_rdata[CAN_ID_WIDTH-1:0] = tx_id_q;
      CAN_ADDR_TX_DATA0 : reg_rdata = tx_data0_q;
      CAN_ADDR_TX_DATA1 : reg_rdata = tx_data1_q;

      CAN_ADDR_TX_DLC_CONTROL : begin
        reg_rdata[CAN_DLCC_DLC_LSB +: 4]  = tx_dlc_q;
        reg_rdata[CAN_DLCC_RTR_BIT]       = tx_rtr_q;
        reg_rdata[CAN_DLCC_IDE_BIT]       = tx_ide_q;
        reg_rdata[CAN_DLCC_ONE_SHOT_BIT]  = tx_oneshot_q;
      end

      CAN_ADDR_RX_ID : begin
        if (!rx_empty_i) begin
          reg_rdata[CAN_ID_WIDTH-1:0] = rx_head_i[CAN_MSG_ID_LSB +: CAN_ID_WIDTH];
        end
      end

      CAN_ADDR_RX_DATA0 : begin
        if (!rx_empty_i) reg_rdata = rx_head_i[CAN_MSG_DATA_LSB +: 32];
      end

      CAN_ADDR_RX_DATA1 : begin
        if (!rx_empty_i) reg_rdata = rx_head_i[(CAN_MSG_DATA_LSB + 32) +: 32];
      end

      CAN_ADDR_RX_DLC_STATUS : begin
        if (!rx_empty_i) begin
          reg_rdata[CAN_RXDLC_DLC_LSB +: 4]  = rx_head_i[CAN_MSG_DLC_LSB +: 4];
          reg_rdata[CAN_RXDLC_RTR_BIT]       = rx_head_i[CAN_MSG_RTR_BIT];
          reg_rdata[CAN_RXDLC_IDE_BIT]       = rx_head_i[CAN_MSG_IDE_BIT];
          reg_rdata[CAN_RXDLC_VALID_BIT]     = 1'b1;
          reg_rdata[CAN_RXDLC_FHIT_LSB +: 3] = rx_head_i[CAN_MSG_FHIT_LSB +: 3];
          reg_rdata[CAN_RXDLC_FMATCH_BIT]    = rx_head_i[CAN_MSG_FMATCH_BIT];
        end
      end

      CAN_ADDR_FILTER_CONTROL : reg_rdata = filter_ctrl_rd;
      CAN_ADDR_FILTER_ID      : reg_rdata[CAN_ID_WIDTH-1:0] = sel_fid;
      CAN_ADDR_FILTER_MASK    : reg_rdata[CAN_ID_WIDTH-1:0] = sel_fmask;

      CAN_ADDR_TIMESTAMP_CONTROL : begin
        reg_rdata[CAN_TSCTRL_ENABLE_BIT]  = ts_enable_q;
        reg_rdata[CAN_TSCTRL_CAPTURE_BIT] = ts_capture_q;
      end

      CAN_ADDR_TIMESTAMP_VALUE : reg_rdata[TIMESTAMP_WIDTH-1:0] = ts_cnt;

      CAN_ADDR_DEBUG_CONTROL : reg_rdata[CAN_DBGCTRL_ENABLE_BIT] = dbg_enable_q;

      CAN_ADDR_DEBUG_STATUS : begin
        if (dbg_enable_q) begin
          reg_rdata[CAN_DBGSTAT_STATE_LSB  +: 5] = proto_state_i;
          reg_rdata[CAN_DBGSTAT_BITPOS_LSB +: 5] = bit_pos_i;
          reg_rdata[CAN_DBGSTAT_STUFF_LSB  +: 3] = stuff_cnt_i;
          reg_rdata[CAN_DBGSTAT_TXD_BIT]         = txd_i;
          reg_rdata[CAN_DBGSTAT_RXD_BIT]         = rxd_i;
          reg_rdata[CAN_DBGSTAT_TXING_BIT]       = tx_active_i;
          reg_rdata[CAN_DBGSTAT_RXING_BIT]       = rx_busy_i;
        end
      end

      CAN_ADDR_RX_TIMESTAMP : begin
        if (!rx_empty_i) reg_rdata[TIMESTAMP_WIDTH-1:0] = rx_head_ts_i;
      end

      default : reg_rdata = 32'h0;
    endcase
  end

  always_comb begin
    prdata_o = '0;
    if (apb_read && addr_valid) begin
      prdata_o[31:0] = reg_rdata;
    end
  end

  logic [31:0] wdata_rmw;
  assign wdata_rmw = (wdata32 & strb_mask) | (reg_rdata & ~strb_mask);

  //===========================================================================
  // Bit-timing legality (specification 03 section 8: "Reject configurations
  // where: BRP == illegal, TSEG1 == illegal, TSEG2 == illegal, SJW > TSEG2")
  //
  // Three of the four conditions have no illegal encoding: every value the
  // BRP, TSEG1 and TSEG2 fields can hold maps to a segment length inside the
  // range the engine implements - with one exception, which this block
  // rejects.  A bit time whose sample point falls fewer than four core clocks
  // after the start of the bit is not executable at all, because the receive
  // path costs three core clocks; such a node samples the previous bit.  The
  // sample point lies (TSEG1 + 2) x (BRP + 1) core clocks into the bit time,
  // so the only encodable violation is BRP = 0 with TSEG1 < 2, and the write
  // that would create it is refused with PSLVERR and leaves the register
  // unchanged.  Because the reset values (BRP = 0, TSEG1 = 4) are legal and
  // both fields are guarded, the pair can never hold an illegal combination.
  //
  // SJW > TSEG2 is the fourth condition and is handled differently, in
  // can_bit_timing: the illegal value is rejected in favour of a clamped one
  // and reported in STATUS.BT_CFG_ERROR.  It has to be, because it is a
  // relation between two registers that software may legitimately program in
  // either order, so no single write is the offending one.
  //===========================================================================
  logic bt_wr_attempt;
  assign bt_wr_attempt = apb_write & addr_valid & ~write_to_ro & ~bt_locked;

  always_comb begin
    bt_illegal_wr = 1'b0;
    if (bt_wr_attempt) begin
      unique case (addr32)
        CAN_ADDR_BIT_TSEG1 :
          bt_illegal_wr = can_bit_time_too_short(
              brp_q == '0, wdata_rmw[CAN_TSEG1_FIELD_WIDTH-1:0]);
        CAN_ADDR_BIT_BRP :
          bt_illegal_wr = can_bit_time_too_short(
              wdata_rmw[BRP_WIDTH-1:0] == '0, tseg1_q);
        default : bt_illegal_wr = 1'b0;
      endcase
    end
  end

  //===========================================================================
  // Per-register write enables
  //===========================================================================
  logic wr_control, wr_mode, wr_int_status, wr_int_enable;
  logic wr_brp, wr_tseg1, wr_tseg2, wr_sjw;
  logic wr_errctrl, wr_errstat;
  logic wr_txctrl, wr_rxctrl;
  logic wr_txid, wr_txd0, wr_txd1, wr_txdlc;
  logic wr_fctrl, wr_fid, wr_fmask;
  logic wr_tsctrl, wr_dbgctrl;

  assign wr_control    = wr_en && (addr32 == CAN_ADDR_CONTROL);
  assign wr_mode       = wr_en && (addr32 == CAN_ADDR_MODE);
  assign wr_int_status = wr_en && (addr32 == CAN_ADDR_INT_STATUS);
  assign wr_int_enable = wr_en && (addr32 == CAN_ADDR_INT_ENABLE);
  assign wr_brp        = wr_en && (addr32 == CAN_ADDR_BIT_BRP);
  assign wr_tseg1      = wr_en && (addr32 == CAN_ADDR_BIT_TSEG1);
  assign wr_tseg2      = wr_en && (addr32 == CAN_ADDR_BIT_TSEG2);
  assign wr_sjw        = wr_en && (addr32 == CAN_ADDR_BIT_SJW);
  assign wr_errctrl    = wr_en && (addr32 == CAN_ADDR_ERROR_CONTROL);
  assign wr_errstat    = wr_en && (addr32 == CAN_ADDR_ERROR_STATUS);
  assign wr_txctrl     = wr_en && (addr32 == CAN_ADDR_TX_CONTROL);
  assign wr_rxctrl     = wr_en && (addr32 == CAN_ADDR_RX_CONTROL);
  assign wr_txid       = wr_en && (addr32 == CAN_ADDR_TX_ID);
  assign wr_txd0       = wr_en && (addr32 == CAN_ADDR_TX_DATA0);
  assign wr_txd1       = wr_en && (addr32 == CAN_ADDR_TX_DATA1);
  assign wr_txdlc      = wr_en && (addr32 == CAN_ADDR_TX_DLC_CONTROL);
  assign wr_fctrl      = wr_en && (addr32 == CAN_ADDR_FILTER_CONTROL);
  assign wr_fid        = wr_en && (addr32 == CAN_ADDR_FILTER_ID);
  assign wr_fmask      = wr_en && (addr32 == CAN_ADDR_FILTER_MASK);
  assign wr_tsctrl     = wr_en && (addr32 == CAN_ADDR_TIMESTAMP_CONTROL);
  assign wr_dbgctrl    = wr_en && (addr32 == CAN_ADDR_DEBUG_CONTROL);

  //===========================================================================
  // CONTROL / MODE / INT_ENABLE / bit timing / ERROR_CONTROL / DEBUG_CONTROL
  //===========================================================================
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ctrl_q         <= CAN_CTRL_RESET_VALUE;
      mode_q         <= '0;
      int_enable_q   <= '0;
      brp_q          <= '0;
      tseg1_q        <= CAN_TSEG1_FIELD_WIDTH'(4);   // 5 TQ
      tseg2_q        <= CAN_TSEG2_FIELD_WIDTH'(1);   // 2 TQ
      sjw_q          <= '0;                          // 1 TQ
      auto_recover_q <= 1'b1;
      ewl_q          <= 8'(CAN_DEFAULT_WARN_LIMIT);
      dbg_enable_q   <= 1'b0;
    end else begin
      if (wr_control)    ctrl_q       <= wdata_rmw[CAN_CTRL_WIDTH-1:0];
      if (wr_mode)       mode_q       <= wdata_rmw[CAN_MODE_WIDTH-1:0];
      if (wr_int_enable) int_enable_q <= wdata_rmw[CAN_INT_WIDTH-1:0];
      if (wr_brp)        brp_q        <= wdata_rmw[BRP_WIDTH-1:0];
      if (wr_tseg1)      tseg1_q      <= wdata_rmw[CAN_TSEG1_FIELD_WIDTH-1:0];
      if (wr_tseg2)      tseg2_q      <= wdata_rmw[CAN_TSEG2_FIELD_WIDTH-1:0];
      if (wr_sjw)        sjw_q        <= wdata_rmw[CAN_SJW_FIELD_WIDTH-1:0];
      if (wr_errctrl) begin
        auto_recover_q <= wdata_rmw[CAN_ERRCTRL_AUTO_RECOVER_BIT];
        ewl_q          <= wdata_rmw[CAN_ERRCTRL_EWL_LSB +: 8];
      end
      if (wr_dbgctrl)    dbg_enable_q <= wdata_rmw[CAN_DBGCTRL_ENABLE_BIT];
    end
  end

  //===========================================================================
  // TX staging registers
  //===========================================================================
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      tx_id_q      <= '0;
      tx_data0_q   <= '0;
      tx_data1_q   <= '0;
      tx_dlc_q     <= '0;
      tx_rtr_q     <= 1'b0;
      tx_ide_q     <= 1'b0;
      tx_oneshot_q <= 1'b0;
    end else begin
      if (wr_txid) tx_id_q    <= wdata_rmw[CAN_ID_WIDTH-1:0];
      if (wr_txd0) tx_data0_q <= wdata_rmw;
      if (wr_txd1) tx_data1_q <= wdata_rmw;
      if (wr_txdlc) begin
        tx_dlc_q     <= wdata_rmw[CAN_DLCC_DLC_LSB +: 4];
        tx_rtr_q     <= wdata_rmw[CAN_DLCC_RTR_BIT];
        tx_ide_q     <= wdata_rmw[CAN_DLCC_IDE_BIT];
        tx_oneshot_q <= wdata_rmw[CAN_DLCC_ONE_SHOT_BIT];
      end
    end
  end

  // The TX command atomically captures the whole staged frame
  // (specification 09 section 8).
  always_comb begin
    tx_msg_o                                 = '0;
    tx_msg_o[CAN_MSG_DATA_LSB +: 32]         = tx_data0_q;
    tx_msg_o[(CAN_MSG_DATA_LSB + 32) +: 32]  = tx_data1_q;
    tx_msg_o[CAN_MSG_ID_LSB +: CAN_ID_WIDTH] = tx_id_q;
    tx_msg_o[CAN_MSG_IDE_BIT]                = tx_ide_q;
    tx_msg_o[CAN_MSG_RTR_BIT]                = tx_rtr_q;
    tx_msg_o[CAN_MSG_DLC_LSB +: 4]           = tx_dlc_q;
    tx_msg_o[CAN_MSG_FLAG_BIT]               = tx_oneshot_q;
  end

  //===========================================================================
  // Command pulses
  //===========================================================================
  logic tx_request, tx_dlc_ok, tx_req_rejected, tx_dlc_rejected;
  assign tx_request  = wr_txctrl && wdata_strobed[CAN_TXCTRL_REQUEST_BIT];
  assign tx_flush_o  = wr_txctrl && (wdata_strobed[CAN_TXCTRL_ABORT_BIT] |
                                     wdata_strobed[CAN_TXCTRL_FLUSH_BIT]);
  assign tx_cancel_o = tx_flush_o;

  // Specification 02 section 7: a data length code above eight is not a valid
  // Classical CAN data length and is rejected rather than transmitted.
  assign tx_dlc_ok       = can_dlc_is_valid(tx_dlc_q);
  // A request is discarded when the FIFO is full, when its length code is
  // invalid, or when the native interface owns the FIFO.  All three are
  // reported as TX_ABORT: from software's point of view a transmit request
  // that will never be sent is an abort.
  assign tx_req_rejected = tx_request && (tx_full_i || !tx_dlc_ok || mode_native_en_o);
  assign tx_dlc_rejected = tx_request && !tx_dlc_ok && !mode_native_en_o;
  assign tx_push_o       = tx_request && !tx_full_i && tx_dlc_ok && !mode_native_en_o;

  assign rx_pop_o    = wr_rxctrl && wdata_strobed[CAN_RXCTRL_RELEASE_BIT] && !rx_empty_i;
  assign rx_flush_o  = wr_rxctrl && wdata_strobed[CAN_RXCTRL_FLUSH_BIT];

  assign rx_ovfl_clear_o = wr_int_status && wdata_strobed[CAN_INT_RX_OVERFLOW_BIT];

  assign err_recover_req_o = wr_errctrl && wdata_strobed[CAN_ERRCTRL_RECOVER_REQ_BIT];

  //===========================================================================
  // Acceptance filter register file
  //===========================================================================
  logic [2:0] fctrl_index;
  assign fctrl_index = wdata_rmw[CAN_FCTRL_INDEX_LSB +: 3];

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      fidx_q    <= 3'd0;
      gaccept_q <= 1'b1;      // accept everything until software programs a filter
      greject_q <= 1'b0;
      for (int unsigned f = 0; f < NUM_FILTERS; f++) begin
        fattr_q[f]  <= '0;
        fid_q[f]    <= '0;
        fmask_q[f]  <= '0;
      end
    end else begin
      if (wr_fctrl) begin
        fidx_q    <= fctrl_index;
        gaccept_q <= wdata_rmw[CAN_FCTRL_GACCEPT_BIT];
        greject_q <= wdata_rmw[CAN_FCTRL_GREJECT_BIT];
      end
      for (int unsigned f = 0; f < NUM_FILTERS; f++) begin
        // A FILTER_CONTROL write updates the attributes of the filter it
        // selects, so index and attributes always land together.
        if (wr_fctrl && (fctrl_index == 3'(f))) begin
          fattr_q[f][CAN_FATTR_ENABLE]   <= wdata_rmw[CAN_FCTRL_ENABLE_BIT];
          fattr_q[f][CAN_FATTR_IDE_SEL]  <= wdata_rmw[CAN_FCTRL_IDE_SEL_BIT];
          fattr_q[f][CAN_FATTR_IDE_CARE] <= wdata_rmw[CAN_FCTRL_IDE_CARE_BIT];
          fattr_q[f][CAN_FATTR_RTR_SEL]  <= wdata_rmw[CAN_FCTRL_RTR_SEL_BIT];
          fattr_q[f][CAN_FATTR_RTR_CARE] <= wdata_rmw[CAN_FCTRL_RTR_CARE_BIT];
          fattr_q[f][CAN_FATTR_RANGE]    <= wdata_rmw[CAN_FCTRL_RANGE_BIT];
          fattr_q[f][CAN_FATTR_IRQ_EN]   <= wdata_rmw[CAN_FCTRL_IRQ_EN_BIT];
        end
        if (wr_fid && (fidx_q == 3'(f))) begin
          fid_q[f] <= wdata_rmw[CAN_ID_WIDTH-1:0];
        end
        if (wr_fmask && (fidx_q == 3'(f))) begin
          fmask_q[f] <= wdata_rmw[CAN_ID_WIDTH-1:0];
        end
      end
    end
  end

  assign filter_attr_o    = fattr_q;
  assign filter_id_o      = fid_q;
  assign filter_mask_o    = fmask_q;
  assign filter_gaccept_o = gaccept_q;
  assign filter_greject_o = greject_q;

  //===========================================================================
  // Timestamp counter
  //
  // Ticks once per CAN bit time while enabled.  When TIMESTAMP_ENABLE is
  // clear the counter is not instantiated at all, so the option costs nothing
  // and leaves no unreachable logic behind.
  //===========================================================================
  if (TIMESTAMP_ENABLE) begin : gen_timestamp
    logic [TIMESTAMP_WIDTH-1:0] ts_cnt_q;

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        ts_cnt_q     <= '0;
        ts_enable_q  <= 1'b0;
        ts_capture_q <= 1'b0;
      end else begin
        if (wr_tsctrl) begin
          ts_enable_q  <= wdata_rmw[CAN_TSCTRL_ENABLE_BIT];
          ts_capture_q <= wdata_rmw[CAN_TSCTRL_CAPTURE_BIT];
        end
        if (wr_tsctrl && wdata_strobed[CAN_TSCTRL_RESET_BIT]) begin
          ts_cnt_q <= '0;
        end else if (ts_enable_q && bit_tick_i) begin
          ts_cnt_q <= ts_cnt_q + TIMESTAMP_WIDTH'(1);
        end
      end
    end

    assign ts_cnt = ts_cnt_q;
  end else begin : gen_no_timestamp
    assign ts_cnt      = '0;
    assign ts_enable_q = 1'b0;
    assign ts_capture_q = 1'b0;
    logic unused_ts;
    assign unused_ts = ^{bit_tick_i, wr_tsctrl, 1'b0};
  end

  assign ts_value_o       = ts_cnt;
  assign ts_capture_sof_o = !ts_capture_q;

  //===========================================================================
  // ERROR_STATUS: last error code / phase and the sticky flags
  //===========================================================================
  logic [CAN_ERRSTICKY_WIDTH-1:0] esticky_set;

  always_comb begin
    esticky_set = '0;
    if (evt_err_valid_i) begin
      unique case (evt_err_kind_i)
        ERR_BIT   : esticky_set[CAN_ERRSTICKY_BIT]   = 1'b1;
        ERR_STUFF : esticky_set[CAN_ERRSTICKY_STUFF] = 1'b1;
        ERR_CRC   : esticky_set[CAN_ERRSTICKY_CRC]   = 1'b1;
        ERR_FORM  : esticky_set[CAN_ERRSTICKY_FORM]  = 1'b1;
        ERR_ACK   : esticky_set[CAN_ERRSTICKY_ACK]   = 1'b1;
        default   : esticky_set = '0;
      endcase
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      lec_q     <= CAN_LEC_NONE;
      lphase_q  <= '0;
      esticky_q <= '0;
    end else begin
      if (evt_err_valid_i) begin
        unique case (evt_err_kind_i)
          ERR_BIT   : lec_q <= CAN_LEC_BIT;
          ERR_STUFF : lec_q <= CAN_LEC_STUFF;
          ERR_CRC   : lec_q <= CAN_LEC_CRC;
          ERR_FORM  : lec_q <= CAN_LEC_FORM;
          ERR_ACK   : lec_q <= CAN_LEC_ACK;
          default   : lec_q <= CAN_LEC_NONE;
        endcase
        lphase_q <= evt_err_phase_i;
      end
      for (int unsigned i = 0; i < CAN_ERRSTICKY_WIDTH; i++) begin
        if (esticky_set[i]) begin
          esticky_q[i] <= 1'b1;
        end else if (wr_errstat && wdata_strobed[CAN_ERRSTAT_STICKY_LSB + i]) begin
          esticky_q[i] <= 1'b0;
        end
      end
    end
  end

  //===========================================================================
  // Interrupts
  //
  // Hardware set always wins over a simultaneous write-one-to-clear, so an
  // event can never be lost.
  //===========================================================================
  logic err_warn_q, err_pass_q;
  logic [CAN_INT_WIDTH-1:0] int_set;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      err_warn_q <= 1'b0;
      err_pass_q <= 1'b0;
    end else begin
      err_warn_q <= error_warning_i;
      err_pass_q <= err_passive;
    end
  end

  always_comb begin
    int_set = '0;
    int_set[CAN_INT_RX_AVAILABLE_BIT]     = rx_push_i;
    int_set[CAN_INT_TX_COMPLETE_BIT]      = evt_tx_complete_i;
    int_set[CAN_INT_TX_ABORT_BIT]         = evt_tx_abort_i || evt_tx_reject_i ||
                                            tx_req_rejected;
    int_set[CAN_INT_ARBITRATION_LOST_BIT] = evt_arb_lost_i;
    int_set[CAN_INT_ERROR_WARNING_BIT]    = error_warning_i & ~err_warn_q;
    int_set[CAN_INT_ERROR_PASSIVE_BIT]    = err_passive & ~err_pass_q;
    int_set[CAN_INT_BUS_OFF_BIT]          = bus_off_entry_i;
    int_set[CAN_INT_RX_OVERFLOW_BIT]      = rx_overflow_i;
    int_set[CAN_INT_CRC_ERROR_BIT]        = evt_err_valid_i && (evt_err_kind_i == ERR_CRC);
    int_set[CAN_INT_STUFF_ERROR_BIT]      = evt_err_valid_i && (evt_err_kind_i == ERR_STUFF);
    int_set[CAN_INT_FORM_ERROR_BIT]       = evt_err_valid_i && (evt_err_kind_i == ERR_FORM);
    int_set[CAN_INT_BIT_ERROR_BIT]        = evt_err_valid_i && (evt_err_kind_i == ERR_BIT);
    int_set[CAN_INT_ACK_ERROR_BIT]        = evt_err_valid_i && (evt_err_kind_i == ERR_ACK);
    int_set[CAN_INT_DLC_ERROR_BIT]        = evt_dlc_err_i || tx_dlc_rejected;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      int_status_q <= '0;
    end else begin
      for (int unsigned i = 0; i < CAN_INT_WIDTH; i++) begin
        if (int_set[i]) begin
          int_status_q[i] <= 1'b1;
        end else if (wr_int_status && wdata_strobed[i]) begin
          int_status_q[i] <= 1'b0;
        end
      end
    end
  end

  assign irq_o = |(int_status_q & int_enable_q);

  //===========================================================================
  // Outputs
  //===========================================================================
  assign ctrl_enable_o        = ctrl_q[CAN_CTRL_ENABLE_BIT] & ~ctrl_q[CAN_CTRL_INIT_BIT];
  assign ctrl_init_o          = ctrl_q[CAN_CTRL_INIT_BIT];
  assign ctrl_loopback_o      = ctrl_q[CAN_CTRL_LOOPBACK_BIT];
  assign ctrl_listen_only_o   = ctrl_q[CAN_CTRL_LISTEN_ONLY_BIT];
  assign ctrl_one_shot_o      = ctrl_q[CAN_CTRL_ONE_SHOT_BIT];
  assign ctrl_auto_retx_o     = ctrl_q[CAN_CTRL_AUTO_RETRANSMIT_BIT];
  assign ctrl_accept_remote_o = ctrl_q[CAN_CTRL_ACCEPT_REMOTE_BIT];

  assign mode_ovfl_policy_o = mode_q[CAN_MODE_RX_OVFL_POLICY_LSB +: 2];
  assign mode_self_ack_o    = mode_q[CAN_MODE_SELF_ACK_BIT];
  assign mode_native_en_o   = mode_q[CAN_MODE_NATIVE_EN_BIT];

  assign brp_o   = brp_q;
  assign tseg1_o = tseg1_q;
  assign tseg2_o = tseg2_q;
  assign sjw_o   = sjw_q;

  assign err_auto_recover_o = auto_recover_q;
  assign err_ewl_o          = ewl_q;

  //===========================================================================
  // Unused signal absorption (keeps lint clean for legal but unused bits).
  //===========================================================================
  logic unused;
  assign unused = ^{pwdata_i, pstrb_i, paddr_i, 1'b0};

endmodule : can_apb_regs

`default_nettype wire
