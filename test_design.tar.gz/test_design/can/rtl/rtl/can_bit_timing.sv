//=============================================================================
// File        : can_bit_timing.sv
// Description : CAN nominal bit timing and synchronization
//               (specification 03_Bit_Timing_and_Synchronization.md).
//
//               Bit-time structure
//               -----------------
//                   | SYNC | TSEG1 (prop + phase1) |^| TSEG2 |
//                                                   |
//                                             sample point
//
//               A bit time is a whole number of time quanta (TQ).  One TQ is
//               (BRP+1) core clocks.  Segment lengths are programmed as
//               (length - 1):
//
//                   TSEG1 length = tseg1_i + 1   (1 .. 16 TQ)
//                   TSEG2 length = tseg2_i + 1   (1 ..  8 TQ)
//                   SJW          = sjw_i   + 1   (1 ..  4 TQ)
//                   bit time     = 1 + TSEG1 + TSEG2 TQ
//
//               Position model
//               --------------
//               `bit_pos` is the index of the TQ currently in progress inside
//               the bit time:
//
//                   bit_pos == 0                       SYNC segment
//                   1 .. tseg1_eff                     TSEG1
//                   tseg1_eff+1 .. tseg1_eff+tseg2_eff TSEG2
//
//               `tq_en` marks the core clock on which the TQ in progress
//               completes.  Two single-clock events are exported:
//
//                   sample_point_o : the TQ at bit_pos == tseg1_eff completes
//                                    -> the bus level is sampled now.  It is
//                                       raised at most ONCE per bit time: a
//                                       resynchronization on the sample clock
//                                       moves the end of TSEG1 later, and
//                                       without the one-shot the position
//                                       would match the lengthened TSEG1 a
//                                       second time.
//                   bit_end_o      : the last TQ of TSEG2 completes
//                                    -> a new bit time starts on the next TQ,
//                                       and the transmitted level changes now
//
//               Synchronization
//               ---------------
//               Hard synchronization restarts the bit time at a recessive to
//               dominant edge while `hard_sync_en_i` is asserted (bus idle and
//               intermission).  Resynchronization corrects at most SJW TQ of
//               phase error, once per bit time:
//
//                   edge inside TSEG1 (late,  e = bit_pos > 0)
//                       -> TSEG1 lengthened by min(e, SJW)
//                   edge inside TSEG2 (early, e = bit_len - bit_pos)
//                       -> TSEG2 shortened  by min(e, SJW)
//
//               A node that is itself driving a dominant bit does not
//               resynchronize on a positive phase error: the edge is its own.
//
//               Simultaneity contract
//               ---------------------
//               When an edge and a TQ boundary land on the same core clock,
//               the exported events are computed from the state BEFORE the
//               edge is applied, and the segment adjustment uses the
//               pre-advance `bit_pos`.  A bit that ends on that clock reloads
//               the nominal segment lengths and the adjustment is discarded.
//               The behaviour is therefore fully defined rather than
//               dependent on evaluation order, which is what lets the
//               reference model reproduce it exactly.
//=============================================================================

`default_nettype none

module can_bit_timing
  import can_pkg::*;
#(
    // Width of the BRP register field.  Prescaler = brp_i + 1.
    parameter int unsigned BRP_WIDTH = 8
) (
    input  wire                       clk_i,
    input  wire                       rst_ni,

    // Held reset while the controller is disabled or in initialization.
    input  wire                       enable_i,

    // Bit timing configuration (all encoded as length - 1).
    input  wire [BRP_WIDTH-1:0]       brp_i,
    input  wire [CAN_TSEG1_FIELD_WIDTH-1:0] tseg1_i,
    input  wire [CAN_TSEG2_FIELD_WIDTH-1:0] tseg2_i,
    input  wire [CAN_SJW_FIELD_WIDTH-1:0]   sjw_i,

    // Recessive -> dominant edge on the synchronized receive input.
    input  wire                       rx_fall_i,
    // Hard synchronization permitted (bus idle / intermission).
    input  wire                       hard_sync_en_i,
    // The node is currently driving a dominant level.
    input  wire                       tx_dominant_i,

    output logic                      sample_point_o,
    output logic                      bit_end_o,
    output logic [CAN_BIT_POS_WIDTH-1:0] bit_pos_o,
    // SJW is programmed larger than TSEG2 (specification 03 section 8).  The
    // hardware clamps the applied value; this reports the illegal setting.
    output logic                      cfg_error_o
);

  if (BRP_WIDTH < 1) begin : gen_chk_brp_min
    $error("can_bit_timing: BRP_WIDTH must be >= 1 (got %0d)", BRP_WIDTH);
  end
  if (BRP_WIDTH > CAN_MAX_BRP_WIDTH) begin : gen_chk_brp_max
    $error("can_bit_timing: BRP_WIDTH must be <= %0d (got %0d)",
           CAN_MAX_BRP_WIDTH, BRP_WIDTH);
  end

  //---------------------------------------------------------------------------
  // Effective segment lengths (nominal)
  //---------------------------------------------------------------------------
  localparam int unsigned LEN_W = CAN_BIT_POS_WIDTH;   // 5 bits, 0 .. 31

  logic [LEN_W-1:0] tseg1_len;   // 1 .. 16
  logic [LEN_W-1:0] tseg2_len;   // 1 ..  8
  logic [LEN_W-1:0] sjw_len;     // 1 ..  4
  logic [LEN_W-1:0] sjw_eff;

  assign tseg1_len = LEN_W'(tseg1_i) + LEN_W'(1);
  assign tseg2_len = LEN_W'(tseg2_i) + LEN_W'(1);
  assign sjw_len   = LEN_W'(sjw_i)   + LEN_W'(1);

  // SJW may never exceed either phase segment; the illegal programming is
  // reported rather than silently mis-timing the bus.
  always_comb begin
    sjw_eff = sjw_len;
    if (sjw_eff > tseg2_len) sjw_eff = tseg2_len;
    if (sjw_eff > tseg1_len) sjw_eff = tseg1_len;
  end

  assign cfg_error_o = (sjw_len > tseg2_len);

  //---------------------------------------------------------------------------
  // Time quantum prescaler
  //---------------------------------------------------------------------------
  logic [BRP_WIDTH-1:0] tq_cnt_q;
  logic                 tq_en;

  assign tq_en = enable_i && (tq_cnt_q == brp_i);

  //---------------------------------------------------------------------------
  // Bit position and per-bit effective segment lengths
  //---------------------------------------------------------------------------
  logic [LEN_W-1:0] bit_pos_q;
  logic [LEN_W-1:0] tseg1_eff_q;
  logic [LEN_W-1:0] tseg2_eff_q;
  logic             sync_done_q;
  // A bit time has exactly ONE sample point.  Without this flag a
  // resynchronization that lands on the sample clock produces a second one:
  // `sample_point_o` fires at bit_pos == tseg1_eff, the same clock's
  // `do_resync` lengthens tseg1_eff by up to SJW, and bit_pos then walks up to
  // the new, larger tseg1_eff and matches again.  The receiver consumed two
  // bits in one bit time, so every field after it was one bit out.  The edge
  // that triggers it is the ordinary one another node makes when it pulls the
  // ACK slot dominant part-way through the bit, which is why this only ever
  // appeared with a second node on the bus and never in loopback.
  logic             sample_done_q;

  // Total TQ in the bit time as currently adjusted.  One extra bit of width so
  // that the comparison against bit_pos can never wrap.
  logic [LEN_W:0] bit_last_pos;
  assign bit_last_pos = {1'b0, tseg1_eff_q} + {1'b0, tseg2_eff_q};

  //---------------------------------------------------------------------------
  // Synchronization decision
  //---------------------------------------------------------------------------
  logic in_tseg1;      // positive phase error region
  logic in_tseg2;      // negative phase error region
  logic hard_sync;
  logic do_resync;

  assign in_tseg1 = (bit_pos_q != '0) && (bit_pos_q <= tseg1_eff_q);
  assign in_tseg2 = (bit_pos_q > tseg1_eff_q);

  assign hard_sync = enable_i && rx_fall_i && hard_sync_en_i && !tx_dominant_i;

  //---------------------------------------------------------------------------
  // Exported bit-time events
  //
  // `hard_sync` abandons the bit time in progress, so the TQ that completes on
  // that clock is not the end of a bit and must not produce a sample.  Without
  // the term the node samples the dominant start-of-frame bit twice - once in
  // the truncated bit and again at the sample point of the bit the hard
  // synchronization starts - and every field of that frame is then one bit out:
  // the DLC reads as the previous bit, the data field is skipped when it reads
  // zero, and the frame ends in a CRC error at the acknowledge delimiter.
  //
  // It only bites when the start-of-frame edge arrives late in the receiver's
  // own bit time, which is the case after the node has driven an error flag
  // and its phase is no longer locked to the transmitter.  That is why it
  // showed up as "the first frame after an error frame is lost, the next
  // identical frame is received".
  //---------------------------------------------------------------------------
  assign sample_point_o = tq_en && (bit_pos_q == tseg1_eff_q) &&
                          !sample_done_q && !hard_sync;
  assign bit_end_o      = tq_en && ({1'b0, bit_pos_q} >= bit_last_pos);
  assign bit_pos_o      = bit_pos_q;

  // One synchronization per bit time.  A transmitter ignores a positive phase
  // error while it is driving dominant, because the edge is its own.
  assign do_resync = enable_i && rx_fall_i && !hard_sync && !sync_done_q &&
                     !(tx_dominant_i && in_tseg1);

  // Phase error magnitudes and the SJW-limited corrections.
  logic [LEN_W-1:0] e_pos, e_neg;
  logic [LEN_W-1:0] adj_pos, adj_neg;
  logic [LEN_W:0]   bit_len_nom;

  assign bit_len_nom = {1'b0, tseg1_len} + {1'b0, tseg2_len} + {{LEN_W{1'b0}}, 1'b1};

  always_comb begin
    e_pos   = bit_pos_q;
    adj_pos = (e_pos > sjw_eff) ? sjw_eff : e_pos;

    // bit_pos_q < bit_len_nom always holds inside TSEG2, so the subtraction
    // cannot underflow.
    e_neg   = LEN_W'(bit_len_nom - {1'b0, bit_pos_q});
    adj_neg = (e_neg > sjw_eff) ? sjw_eff : e_neg;
  end

  //---------------------------------------------------------------------------
  // Sequential state
  //---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      tq_cnt_q      <= '0;
      bit_pos_q     <= '0;
      tseg1_eff_q   <= LEN_W'(1);
      tseg2_eff_q   <= LEN_W'(1);
      sync_done_q   <= 1'b0;
      sample_done_q <= 1'b0;
    end else if (!enable_i) begin
      // Held in a known state while the controller is in initialization, so
      // that enabling always starts a fresh bit time.
      tq_cnt_q      <= '0;
      bit_pos_q     <= '0;
      tseg1_eff_q   <= tseg1_len;
      tseg2_eff_q   <= tseg2_len;
      sync_done_q   <= 1'b0;
      sample_done_q <= 1'b0;
    end else if (hard_sync) begin
      tq_cnt_q      <= '0;
      bit_pos_q     <= '0;
      tseg1_eff_q   <= tseg1_len;
      tseg2_eff_q   <= tseg2_len;
      sync_done_q   <= 1'b1;
      sample_done_q <= 1'b0;
    end else begin
      tq_cnt_q <= tq_en ? '0 : (tq_cnt_q + {{(BRP_WIDTH-1){1'b0}}, 1'b1});

      if (sample_point_o) sample_done_q <= 1'b1;

      if (bit_end_o) begin
        bit_pos_q     <= '0;
        tseg1_eff_q   <= tseg1_len;
        tseg2_eff_q   <= tseg2_len;
        sync_done_q   <= 1'b0;
        sample_done_q <= 1'b0;
      end else begin
        if (tq_en) begin
          bit_pos_q <= bit_pos_q + LEN_W'(1);
        end
        if (do_resync) begin
          sync_done_q <= 1'b1;
          if (in_tseg1) begin
            tseg1_eff_q <= tseg1_len + adj_pos;
          end else if (in_tseg2) begin
            tseg2_eff_q <= (tseg2_len > adj_neg) ? (tseg2_len - adj_neg) : '0;
          end
        end
      end
    end
  end

endmodule : can_bit_timing

`default_nettype wire
