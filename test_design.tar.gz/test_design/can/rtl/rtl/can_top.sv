//=============================================================================
// File        : can_top.sv
// Description : Top level of the APB4-programmed Classical CAN (CAN CC)
//               controller.
//
//               Structure
//               ---------
//                        +------------------+
//    APB4  ------------->|  can_apb_regs    |<--- status ------------+
//                        |  (APB + CSR)     |---- config ----+       |
//                        +---+----------+---+                |       |
//                            |          |                    v       |
//                    tx_msg  v          v  rx_pop      +-----------+ |
//                     +-------------+  +-------------+ | can_bit_  | |
//                     | can_msg_fifo|  | can_msg_fifo| |  timing   | |
//                     |    (TX)     |  |    (RX)     | +-----+-----+ |
//                     +------+------+  +------^------+       |       |
//                            |                |     sample / bit_end |
//                            v                |               v      |
//                        +---------------------------------------+   |
//                        |            can_protocol               |---+
//                        |  unified TX/RX bit-serial engine      |
//                        +---+-----------------+-------------+---+
//                            |                 |             |
//                            v                 v             v
//                     +-------------+   +-------------+   can_txd
//                     | can_filter  |   |can_fault_conf|
//                     +-------------+   +-------------+
//
//               All logic is in the single `pclk` domain.  There are no
//               generated or gated clocks.  `can_rxd` is the only
//               asynchronous input and crosses through can_sync.
//
// Parameters   : see below.  Illegal combinations fail elaboration.
//=============================================================================

`default_nettype none

module can_top
  import can_pkg::*;
#(
    // APB address bus width.  Must span the whole register region.
    parameter int unsigned APB_ADDR_WIDTH    = 12,
    // APB data bus width.  Must be >= 32 and a multiple of 8.
    parameter int unsigned APB_DATA_WIDTH    = 32,
    // Transmit message FIFO depth (1 .. CAN_MAX_FIFO_DEPTH).
    parameter int unsigned TX_FIFO_DEPTH     = 4,
    // Receive message FIFO depth (1 .. CAN_MAX_FIFO_DEPTH).
    parameter int unsigned RX_FIFO_DEPTH     = 4,
    // Number of acceptance filters (1 .. CAN_MAX_FILTERS).
    parameter int unsigned NUM_FILTERS       = 4,
    // Width of the BRP register field; prescaler range is 1 .. 2**BRP_WIDTH.
    parameter int unsigned BRP_WIDTH         = 8,
    // Optional frame timestamping.
    parameter bit          TIMESTAMP_ENABLE  = 1'b1,
    parameter int unsigned TIMESTAMP_WIDTH   = 16,
    // 1'b0 : `presetn` is active low (default, APB standard)
    // 1'b1 : `presetn` is active high
    parameter bit          RESET_POLARITY    = 1'b0,
    // Reset synchroniser depth (asynchronous assert, synchronous de-assert).
    parameter int unsigned RESET_SYNC_STAGES = 2
) (
    input  wire                          pclk,
    input  wire                          presetn,

    // ------------------------------------------------------------------ APB4
    input  wire                          psel,
    input  wire                          penable,
    input  wire                          pwrite,
    input  wire  [APB_ADDR_WIDTH-1:0]    paddr,
    input  wire  [APB_DATA_WIDTH-1:0]    pwdata,
    input  wire  [APB_DATA_WIDTH/8-1:0]  pstrb,

    output logic [APB_DATA_WIDTH-1:0]    prdata,
    output logic                         pready,
    output logic                         pslverr,

    // ------------------------------------------------------- CAN PHY (logic)
    output logic                         can_txd,
    input  wire                          can_rxd,

    // ------------------------------------------------ native transmit stream
    // Specification 01_Functional_Architecture section 8.  A ready/valid
    // handshake straight into the transmit message FIFO, so a hardware traffic
    // source can queue frames without a processor in the path.  The port is
    // owned by the FIFO only while MODE.NATIVE_ENABLE is set; with the bit
    // clear `tx_ready` is low and the register interface owns the FIFO, so
    // exactly one requester can ever push and no arbitration is needed.
    input  wire                          tx_valid,
    output logic                         tx_ready,
    input  wire  [CAN_ID_WIDTH-1:0]      tx_id,
    input  wire                          tx_ide,
    input  wire                          tx_rtr,
    input  wire  [CAN_DLC_WIDTH-1:0]     tx_dlc,
    input  wire  [CAN_DATA_WIDTH-1:0]    tx_data,

    // ------------------------------------------------- native receive stream
    // Specification 01_Functional_Architecture section 9.  `rx_*` presents the
    // head of the receive FIFO; the handshake releases it.
    output logic                         rx_valid,
    input  wire                          rx_ready,
    output logic [CAN_ID_WIDTH-1:0]      rx_id,
    output logic                         rx_ide,
    output logic                         rx_rtr,
    output logic [CAN_DLC_WIDTH-1:0]     rx_dlc,
    output logic [CAN_DATA_WIDTH-1:0]    rx_data,
    // Zero-extended to the widest supported timestamp so that the port width
    // does not move with TIMESTAMP_WIDTH; bits above the configured width read
    // zero, and all of them read zero when TIMESTAMP_ENABLE is clear.
    output logic [CAN_MAX_TIMESTAMP_WIDTH-1:0] rx_timestamp,
    output logic [CAN_RXNAT_WIDTH-1:0]   rx_status,

    // Level-sensitive interrupt request.  Tie off at the SoC level if unused.
    output logic                         irq
);

  //---------------------------------------------------------------------------
  // Elaboration checks
  //---------------------------------------------------------------------------
  if (APB_ADDR_WIDTH > 32) begin : gen_chk_aw_max
    $error("can_top: APB_ADDR_WIDTH must be <= 32 (got %0d)", APB_ADDR_WIDTH);
  end
  // The whole register region must be addressable.  The shift is evaluated in
  // 64 bits on purpose: `32'(1) << 32` is zero in a 32-bit context, which
  // would make this check fire for APB_ADDR_WIDTH == 32 - a value the guard
  // above explicitly permits.
  if ((64'(1) << APB_ADDR_WIDTH) < 64'(CAN_REGION_END)) begin : gen_chk_aw_span
    $error("can_top: APB_ADDR_WIDTH=%0d cannot address the 0x%0h byte register region",
           APB_ADDR_WIDTH, CAN_REGION_END);
  end
  if (APB_DATA_WIDTH < 32) begin : gen_chk_dw_min
    $error("can_top: APB_DATA_WIDTH must be >= 32 (got %0d)", APB_DATA_WIDTH);
  end
  if ((APB_DATA_WIDTH % 8) != 0) begin : gen_chk_dw_mod
    $error("can_top: APB_DATA_WIDTH must be a multiple of 8 (got %0d)", APB_DATA_WIDTH);
  end
  if (TX_FIFO_DEPTH < 1) begin : gen_chk_txd_min
    $error("can_top: TX_FIFO_DEPTH must be >= 1 (got %0d)", TX_FIFO_DEPTH);
  end
  if (TX_FIFO_DEPTH > CAN_MAX_FIFO_DEPTH) begin : gen_chk_txd_max
    $error("can_top: TX_FIFO_DEPTH must be <= %0d (got %0d)",
           CAN_MAX_FIFO_DEPTH, TX_FIFO_DEPTH);
  end
  if (RX_FIFO_DEPTH < 1) begin : gen_chk_rxd_min
    $error("can_top: RX_FIFO_DEPTH must be >= 1 (got %0d)", RX_FIFO_DEPTH);
  end
  if (RX_FIFO_DEPTH > CAN_MAX_FIFO_DEPTH) begin : gen_chk_rxd_max
    $error("can_top: RX_FIFO_DEPTH must be <= %0d (got %0d)",
           CAN_MAX_FIFO_DEPTH, RX_FIFO_DEPTH);
  end
  if (NUM_FILTERS < 1) begin : gen_chk_nf_min
    $error("can_top: NUM_FILTERS must be >= 1 (got %0d)", NUM_FILTERS);
  end
  if (NUM_FILTERS > CAN_MAX_FILTERS) begin : gen_chk_nf_max
    $error("can_top: NUM_FILTERS must be <= %0d (got %0d)",
           CAN_MAX_FILTERS, NUM_FILTERS);
  end
  if (BRP_WIDTH < 1) begin : gen_chk_brp_min
    $error("can_top: BRP_WIDTH must be >= 1 (got %0d)", BRP_WIDTH);
  end
  if (BRP_WIDTH > CAN_MAX_BRP_WIDTH) begin : gen_chk_brp_max
    $error("can_top: BRP_WIDTH must be <= %0d (got %0d)", CAN_MAX_BRP_WIDTH, BRP_WIDTH);
  end
  if (TIMESTAMP_ENABLE && (TIMESTAMP_WIDTH < CAN_MIN_TIMESTAMP_WIDTH)) begin : gen_chk_ts_min
    $error("can_top: TIMESTAMP_WIDTH must be >= %0d when TIMESTAMP_ENABLE is set (got %0d)",
           CAN_MIN_TIMESTAMP_WIDTH, TIMESTAMP_WIDTH);
  end
  if (TIMESTAMP_ENABLE && (TIMESTAMP_WIDTH > CAN_MAX_TIMESTAMP_WIDTH)) begin : gen_chk_ts_max
    $error("can_top: TIMESTAMP_WIDTH must be <= %0d (got %0d)",
           CAN_MAX_TIMESTAMP_WIDTH, TIMESTAMP_WIDTH);
  end

  // Effective timestamp width.  Nothing is stored when timestamping is
  // disabled, so the option costs a single dead bit rather than a counter and
  // a per-entry field in the RX FIFO.
  localparam int unsigned TSW   = TIMESTAMP_ENABLE ? TIMESTAMP_WIDTH : 1;
  localparam int unsigned RXF_W = CAN_MSG_WIDTH + TSW;

  //---------------------------------------------------------------------------
  // Reset conditioning
  //
  //   1. Normalise the configured reset polarity to an internal active-low
  //      asynchronous reset.
  //   2. Synchronise the de-assertion to `pclk` (asynchronous assert,
  //      synchronous de-assert) to remove the recovery/removal hazard.
  //---------------------------------------------------------------------------
  logic rst_async_n;
  assign rst_async_n = RESET_POLARITY ? ~presetn : presetn;

  logic rst_n;

  can_reset_sync #(
      .STAGES (RESET_SYNC_STAGES)
  ) u_reset_sync (
      .clk      (pclk),
      .rst_in_n (rst_async_n),
      .rst_out_n(rst_n)
  );

  //---------------------------------------------------------------------------
  // Interconnect
  //---------------------------------------------------------------------------
  // configuration
  logic                             cfg_enable;
  logic                             cfg_init;
  logic                             cfg_loopback;
  logic                             cfg_listen_only;
  logic                             cfg_one_shot;
  logic                             cfg_auto_retx;
  logic                             cfg_accept_remote;
  logic [1:0]                       cfg_ovfl_policy;
  logic                             cfg_self_ack;
  logic                             cfg_native_en;

  logic [BRP_WIDTH-1:0]             cfg_brp;
  logic [CAN_TSEG1_FIELD_WIDTH-1:0] cfg_tseg1;
  logic [CAN_TSEG2_FIELD_WIDTH-1:0] cfg_tseg2;
  logic [CAN_SJW_FIELD_WIDTH-1:0]   cfg_sjw;

  logic                             cfg_auto_recover;
  logic                             cfg_recover_req;
  logic [7:0]                       cfg_ewl;

  // bit timing
  logic                             sample_point;
  logic                             bit_end;
  logic [CAN_BIT_POS_WIDTH-1:0]     bit_pos;
  logic                             bt_cfg_error;

  // bus levels
  logic                             rxd_sync;
  logic                             rx_lvl;
  logic                             rx_lvl_q;
  logic                             rx_fall;
  logic                             txd_int;
  logic                             tx_dominant;
  logic                             hard_sync_en;

  // fault confinement
  can_fault_state_e                 fault_state;
  logic [8:0]                       tec;
  logic [7:0]                       rec;
  logic                             error_warning;
  logic                             bus_off_entry;
  logic [7:0]                       bus_off_count;
  logic                             tec_inc8, tec_dec, rec_inc1, rec_inc8, rec_dec;
  logic                             recovery_done;

  // messages
  logic                             tx_push, tx_pop, tx_flush, tx_cancel;
  logic [CAN_MSG_WIDTH-1:0]         tx_msg_in;
  logic [CAN_MSG_WIDTH-1:0]         tx_head;
  logic                             tx_empty, tx_full;
  logic [7:0]                       tx_level;
  logic                             tx_active;
  logic                             tx_fifo_ovf;

  logic                             rx_push, rx_pop, rx_flush;
  logic                             rx_fifo_push;
  logic                             rx_fifo_push_irq;
  logic [CAN_MSG_WIDTH-1:0]         rx_msg;
  logic [RXF_W-1:0]                 rx_fifo_in;
  logic [RXF_W-1:0]                 rx_head_full;
  logic                             rx_empty, rx_full;
  logic [7:0]                       rx_level;
  logic                             rx_fifo_ovf;
  logic                             rx_overflow;
  logic                             rx_blocked_q;
  logic                             rx_ovfl_clear;

  // register-block side of the two FIFO command paths, before the native
  // interface takes ownership
  logic                             tx_push_reg, rx_pop_reg;
  logic [CAN_MSG_WIDTH-1:0]         tx_msg_reg;

  // filter
  // Live parse output of the protocol engine, evaluated by the acceptance
  // filter.  Distinct from the native `rx_*` ports, which present the head of
  // the receive FIFO.
  logic [CAN_ID_WIDTH-1:0]                          flt_id;
  logic                                             flt_ide, flt_rtr;
  logic [NUM_FILTERS-1:0][CAN_FATTR_WIDTH-1:0]      filter_attr;
  logic [NUM_FILTERS-1:0][CAN_ID_WIDTH-1:0]         filter_id;
  logic [NUM_FILTERS-1:0][CAN_ID_WIDTH-1:0]         filter_mask;
  logic                                             filter_gaccept, filter_greject;
  logic                                             filter_accept, filter_matched;
  logic                                             filter_irq;
  logic [2:0]                                       filter_hit;

  // events / status
  logic                             evt_tx_complete, evt_tx_abort, evt_arb_lost;
  logic                             evt_err_valid;
  logic                             evt_dlc_err_proto;
  logic                             evt_dlc_err;
  logic                             evt_tx_reject;
  can_err_kind_e                    evt_err_kind;
  logic [4:0]                       evt_err_phase;
  can_state_e                       proto_state;
  logic [2:0]                       stuff_cnt;
  logic                             rx_busy, bus_idle;
  logic                             sof_pulse;

  // timestamp
  logic [TSW-1:0]                   ts_value;
  logic                             ts_capture_sof;
  logic [TSW-1:0]                   ts_capture_q;

  //---------------------------------------------------------------------------
  // Receive input conditioning
  //
  // The transceiver output is asynchronous and crosses into this clock domain
  // through a two-flop synchroniser.  In internal loopback the received
  // stream is taken from the transmitted bit instead, so the node hears its
  // own frame; `can_txd` still carries the frame so that the bus side stays
  // observable.
  //---------------------------------------------------------------------------
  can_sync #(
      .STAGES (2)
  ) u_rxd_sync (
      .clk_i    (pclk),
      .rst_ni   (rst_n),
      .d_i      (can_rxd),
      .d_sync_o (rxd_sync)
  );

  assign rx_lvl = cfg_loopback ? txd_int : rxd_sync;

  always_ff @(posedge pclk or negedge rst_n) begin
    if (!rst_n) rx_lvl_q <= CAN_RECESSIVE;
    else        rx_lvl_q <= rx_lvl;
  end

  assign rx_fall = ~rx_lvl & rx_lvl_q;

  //---------------------------------------------------------------------------
  // Bit timing
  //---------------------------------------------------------------------------
  can_bit_timing #(
      .BRP_WIDTH (BRP_WIDTH)
  ) u_bit_timing (
      .clk_i          (pclk),
      .rst_ni         (rst_n),
      .enable_i       (cfg_enable),
      .brp_i          (cfg_brp),
      .tseg1_i        (cfg_tseg1),
      .tseg2_i        (cfg_tseg2),
      .sjw_i          (cfg_sjw),
      .rx_fall_i      (rx_fall),
      .hard_sync_en_i (hard_sync_en),
      .tx_dominant_i  (tx_dominant),
      .sample_point_o (sample_point),
      .bit_end_o      (bit_end),
      .bit_pos_o      (bit_pos),
      .cfg_error_o    (bt_cfg_error)
  );

  //---------------------------------------------------------------------------
  // Protocol engine
  //---------------------------------------------------------------------------
  can_protocol u_protocol (
      .clk_i             (pclk),
      .rst_ni            (rst_n),

      .enable_i          (cfg_enable),
      .listen_only_i     (cfg_listen_only),
      .loopback_i        (cfg_loopback),
      .self_ack_i        (cfg_self_ack),
      .one_shot_i        (cfg_one_shot),
      .auto_retx_i       (cfg_auto_retx),
      .accept_remote_i   (cfg_accept_remote),

      .sample_point_i    (sample_point),
      .bit_end_i         (bit_end),
      .rx_bit_i          (rx_lvl),
      .txd_o             (txd_int),
      .tx_dominant_o     (tx_dominant),
      .hard_sync_en_o    (hard_sync_en),

      .fault_state_i     (fault_state),
      .tec_inc8_o        (tec_inc8),
      .tec_dec_o         (tec_dec),
      .rec_inc1_o        (rec_inc1),
      .rec_inc8_o        (rec_inc8),
      .rec_dec_o         (rec_dec),
      .auto_recover_i    (cfg_auto_recover),
      .recover_req_i     (cfg_recover_req),
      .recovery_done_o   (recovery_done),

      .tx_valid_i        (!tx_empty),
      .tx_msg_i          (tx_head),
      .tx_cancel_i       (tx_cancel),
      .tx_pop_o          (tx_pop),
      .tx_active_o       (tx_active),

      .rx_push_o         (rx_push),
      .rx_msg_o          (rx_msg),
      .sof_o             (sof_pulse),

      .rx_id_o           (flt_id),
      .rx_ide_o          (flt_ide),
      .rx_rtr_o          (flt_rtr),
      .filter_accept_i   (filter_accept),
      .filter_hit_i      (filter_hit),
      .filter_matched_i  (filter_matched),
      .filter_irq_i      (filter_irq),

      .evt_tx_complete_o (evt_tx_complete),
      .evt_tx_abort_o    (evt_tx_abort),
      .evt_arb_lost_o    (evt_arb_lost),
      .evt_err_valid_o   (evt_err_valid),
      .evt_err_kind_o    (evt_err_kind),
      .evt_err_phase_o   (evt_err_phase),
      .evt_dlc_err_o     (evt_dlc_err_proto),

      .state_o           (proto_state),
      .stuff_cnt_o       (stuff_cnt),
      .rx_busy_o         (rx_busy),
      .bus_idle_o        (bus_idle)
  );

  assign can_txd = txd_int;

  //---------------------------------------------------------------------------
  // Fault confinement
  //---------------------------------------------------------------------------
  can_fault_conf u_fault_conf (
      .clk_i           (pclk),
      .rst_ni          (rst_n),
      .enable_i        (cfg_enable),
      .tec_inc8_i      (tec_inc8),
      .tec_dec_i       (tec_dec),
      .rec_inc1_i      (rec_inc1),
      .rec_inc8_i      (rec_inc8),
      .rec_dec_i       (rec_dec),
      .recovery_done_i (recovery_done),
      .ewl_i           (cfg_ewl),
      .state_o         (fault_state),
      .tec_o           (tec),
      .rec_o           (rec),
      .error_warning_o (error_warning),
      .bus_off_entry_o (bus_off_entry),
      .bus_off_count_o (bus_off_count)
  );

  //---------------------------------------------------------------------------
  // Acceptance filter
  //---------------------------------------------------------------------------
  can_filter #(
      .NUM_FILTERS (NUM_FILTERS)
  ) u_filter (
      .id_i            (flt_id),
      .ide_i           (flt_ide),
      .rtr_i           (flt_rtr),
      .attr_i          (filter_attr),
      .fid_i           (filter_id),
      .fmask_i         (filter_mask),
      .global_accept_i (filter_gaccept),
      .global_reject_i (filter_greject),
      .accept_o        (filter_accept),
      .hit_index_o     (filter_hit),
      .matched_o       (filter_matched),
      .accept_irq_o    (filter_irq)
  );

  //---------------------------------------------------------------------------
  // Message FIFOs
  //---------------------------------------------------------------------------
  can_msg_fifo #(
      .WIDTH (CAN_MSG_WIDTH),
      .DEPTH (TX_FIFO_DEPTH)
  ) u_tx_fifo (
      .clk_i      (pclk),
      .rst_ni     (rst_n),
      .flush_i    (tx_flush),
      .push_i     (tx_push),
      .wdata_i    (tx_msg_in),
      .drop_old_i (1'b0),
      .pop_i      (tx_pop),
      .head_o     (tx_head),
      .empty_o    (tx_empty),
      .full_o     (tx_full),
      .level_o    (tx_level),
      .overflow_o (tx_fifo_ovf)
  );

  // Timestamp capture point: start of frame, or successful frame commit
  // (specification 08 section 10).
  always_ff @(posedge pclk or negedge rst_n) begin
    if (!rst_n)         ts_capture_q <= '0;
    else if (sof_pulse) ts_capture_q <= ts_value;
  end

  assign rx_fifo_in = {ts_capture_sof ? ts_capture_q : ts_value, rx_msg};

  //---------------------------------------------------------------------------
  // RX overflow policy (specification 08 section 9)
  //
  //   DROP_NEW : the arriving frame is discarded, and reception resumes as
  //              soon as software frees an entry.
  //   DROP_OLD : the arriving frame displaces the oldest stored one.
  //   BLOCK    : the arriving frame is discarded AND reception is latched off,
  //              so no later frame is stored either, until software
  //              acknowledges the condition by clearing INT_STATUS.RX_OVERFLOW
  //              (or flushes the FIFO, or stops the controller).  The stored
  //              frames and their arrival order are therefore frozen at the
  //              instant of the overflow, which is what a blocking queue gives
  //              a reader and what neither DROP policy gives.
  //
  // The blocking is local: the node keeps receiving, acknowledging and
  // error-counting normally, so a full FIFO in one node never turns into
  // retransmission traffic for the whole bus.
  //---------------------------------------------------------------------------
  logic rx_drop_old;
  always_comb begin
    unique case (cfg_ovfl_policy)
      CAN_OVFL_DROP_OLD                  : rx_drop_old = 1'b1;
      CAN_OVFL_DROP_NEW, CAN_OVFL_BLOCK  : rx_drop_old = 1'b0;
      default                            : rx_drop_old = 1'b0;
    endcase
  end

  logic rx_block_mode, rx_block_set;
  assign rx_block_mode = (cfg_ovfl_policy == CAN_OVFL_BLOCK);
  assign rx_block_set  = rx_block_mode && rx_fifo_ovf;

  always_ff @(posedge pclk or negedge rst_n) begin
    if (!rst_n) begin
      rx_blocked_q <= 1'b0;
    end else if (rx_block_set) begin
      // A new overflow always wins over a simultaneous acknowledgement, so the
      // condition can never be lost.
      rx_blocked_q <= 1'b1;
    end else if (!cfg_enable || rx_flush || rx_ovfl_clear || !rx_block_mode) begin
      rx_blocked_q <= 1'b0;
    end
  end

  // While blocked, the push never reaches the FIFO; the discarded frame is
  // still reported through the same overflow event.
  assign rx_fifo_push = rx_push && !rx_blocked_q;
  assign rx_overflow  = rx_fifo_ovf || (rx_push && rx_blocked_q);

  // Per-filter interrupt enable (specification 08 section 4): the frame is
  // stored either way; only a filter with the attribute set announces it.
  assign rx_fifo_push_irq = rx_fifo_push && rx_msg[CAN_MSG_FLAG_BIT];

  can_msg_fifo #(
      .WIDTH (RXF_W),
      .DEPTH (RX_FIFO_DEPTH)
  ) u_rx_fifo (
      .clk_i      (pclk),
      .rst_ni     (rst_n),
      .flush_i    (rx_flush),
      .push_i     (rx_fifo_push),
      .wdata_i    (rx_fifo_in),
      .drop_old_i (rx_drop_old),
      .pop_i      (rx_pop),
      .head_o     (rx_head_full),
      .empty_o    (rx_empty),
      .full_o     (rx_full),
      .level_o    (rx_level),
      .overflow_o (rx_fifo_ovf)
  );

  //---------------------------------------------------------------------------
  // Native transmit / receive interfaces (specification 01 sections 8 and 9)
  //
  // MODE.NATIVE_ENABLE hands each message FIFO to exactly one requester: with
  // the bit clear the register block owns both, with it set the native ports
  // do.  There is therefore never a cycle in which two requesters push the
  // same FIFO or pop the same frame, which is what makes the two interfaces
  // safe to have in one design.
  //---------------------------------------------------------------------------
  logic [CAN_MSG_WIDTH-1:0] native_tx_msg;
  logic                     native_tx_xfer, native_tx_dlc_ok;
  logic                     native_rx_xfer;

  always_comb begin
    native_tx_msg                                 = '0;
    native_tx_msg[CAN_MSG_DATA_LSB +: CAN_DATA_WIDTH] = tx_data;
    native_tx_msg[CAN_MSG_ID_LSB +: CAN_ID_WIDTH] = tx_id;
    native_tx_msg[CAN_MSG_IDE_BIT]                = tx_ide;
    native_tx_msg[CAN_MSG_RTR_BIT]                = tx_rtr;
    native_tx_msg[CAN_MSG_DLC_LSB +: CAN_DLC_WIDTH] = tx_dlc;
    // Per-frame one-shot has no native port; CONTROL.ONE_SHOT still applies.
    native_tx_msg[CAN_MSG_FLAG_BIT]               = 1'b0;
  end

  assign tx_ready         = cfg_native_en && !tx_full;
  assign native_tx_xfer   = tx_valid && tx_ready;
  assign native_tx_dlc_ok = can_dlc_is_valid(tx_dlc);

  // Specification 02 section 7: a frame whose data length code is not a valid
  // Classical CAN data length is rejected rather than transmitted.  The
  // handshake still completes - the source is told the request was consumed -
  // and the rejection is reported as TX_ABORT plus DLC_ERROR.
  assign tx_push    = cfg_native_en ? (native_tx_xfer && native_tx_dlc_ok)
                                    : tx_push_reg;
  assign tx_msg_in  = cfg_native_en ? native_tx_msg : tx_msg_reg;
  assign evt_tx_reject = native_tx_xfer && !native_tx_dlc_ok;
  assign evt_dlc_err   = evt_dlc_err_proto || evt_tx_reject;

  assign rx_valid       = cfg_native_en && !rx_empty;
  assign native_rx_xfer = rx_valid && rx_ready;
  assign rx_pop         = cfg_native_en ? native_rx_xfer : rx_pop_reg;

  assign rx_id  = rx_head_full[CAN_MSG_ID_LSB +: CAN_ID_WIDTH];
  assign rx_ide = rx_head_full[CAN_MSG_IDE_BIT];
  assign rx_rtr = rx_head_full[CAN_MSG_RTR_BIT];
  assign rx_dlc = rx_head_full[CAN_MSG_DLC_LSB +: CAN_DLC_WIDTH];
  assign rx_data = rx_head_full[CAN_MSG_DATA_LSB +: CAN_DATA_WIDTH];

  always_comb begin
    rx_timestamp = '0;
    rx_timestamp[TSW-1:0] = rx_head_full[CAN_MSG_WIDTH +: TSW];
  end

  always_comb begin
    rx_status                            = '0;
    rx_status[CAN_RXNAT_FHIT_LSB +: 3]   = rx_head_full[CAN_MSG_FHIT_LSB +: 3];
    rx_status[CAN_RXNAT_FMATCH_BIT]      = rx_head_full[CAN_MSG_FMATCH_BIT];
    rx_status[CAN_RXNAT_OVERFLOW_BIT]    = rx_overflow;
    rx_status[CAN_RXNAT_BLOCKED_BIT]     = rx_blocked_q;
  end

  //---------------------------------------------------------------------------
  // Register block
  //---------------------------------------------------------------------------
  can_apb_regs #(
      .APB_ADDR_WIDTH   (APB_ADDR_WIDTH),
      .APB_DATA_WIDTH   (APB_DATA_WIDTH),
      .BRP_WIDTH        (BRP_WIDTH),
      .NUM_FILTERS      (NUM_FILTERS),
      .TIMESTAMP_ENABLE (TIMESTAMP_ENABLE),
      .TIMESTAMP_WIDTH  (TSW)
  ) u_regs (
      .clk_i                (pclk),
      .rst_ni               (rst_n),

      .psel_i               (psel),
      .penable_i            (penable),
      .pwrite_i             (pwrite),
      .paddr_i              (paddr),
      .pwdata_i             (pwdata),
      .pstrb_i              (pstrb),
      .prdata_o             (prdata),
      .pready_o             (pready),
      .pslverr_o            (pslverr),

      .ctrl_enable_o        (cfg_enable),
      .ctrl_init_o          (cfg_init),
      .ctrl_loopback_o      (cfg_loopback),
      .ctrl_listen_only_o   (cfg_listen_only),
      .ctrl_one_shot_o      (cfg_one_shot),
      .ctrl_auto_retx_o     (cfg_auto_retx),
      .ctrl_accept_remote_o (cfg_accept_remote),
      .mode_ovfl_policy_o   (cfg_ovfl_policy),
      .mode_self_ack_o      (cfg_self_ack),
      .mode_native_en_o     (cfg_native_en),

      .brp_o                (cfg_brp),
      .tseg1_o              (cfg_tseg1),
      .tseg2_o              (cfg_tseg2),
      .sjw_o                (cfg_sjw),
      .bt_cfg_error_i       (bt_cfg_error),
      .bit_tick_i           (bit_end),

      .err_auto_recover_o   (cfg_auto_recover),
      .err_recover_req_o    (cfg_recover_req),
      .err_ewl_o            (cfg_ewl),
      .fault_state_i        (fault_state),
      .tec_i                (tec),
      .rec_i                (rec),
      .error_warning_i      (error_warning),
      .bus_off_entry_i      (bus_off_entry),
      .bus_off_count_i      (bus_off_count),

      .filter_attr_o        (filter_attr),
      .filter_id_o          (filter_id),
      .filter_mask_o        (filter_mask),
      .filter_gaccept_o     (filter_gaccept),
      .filter_greject_o     (filter_greject),

      .tx_push_o            (tx_push_reg),
      .tx_msg_o             (tx_msg_reg),
      .tx_flush_o           (tx_flush),
      .tx_cancel_o          (tx_cancel),
      .tx_level_i           (tx_level),
      .tx_empty_i           (tx_empty),
      .tx_full_i            (tx_full),
      .tx_active_i          (tx_active),

      .rx_pop_o             (rx_pop_reg),
      .rx_flush_o           (rx_flush),
      .rx_ovfl_clear_o      (rx_ovfl_clear),
      .rx_blocked_i         (rx_blocked_q),
      .rx_head_i            (rx_head_full[CAN_MSG_WIDTH-1:0]),
      .rx_head_ts_i         (rx_head_full[CAN_MSG_WIDTH +: TSW]),
      .rx_level_i           (rx_level),
      .rx_empty_i           (rx_empty),
      .rx_full_i            (rx_full),
      .rx_push_i            (rx_fifo_push_irq),
      .rx_overflow_i        (rx_overflow),

      .evt_tx_complete_i    (evt_tx_complete),
      .evt_tx_abort_i       (evt_tx_abort),
      .evt_arb_lost_i       (evt_arb_lost),
      .evt_err_valid_i      (evt_err_valid),
      .evt_err_kind_i       (evt_err_kind),
      .evt_err_phase_i      (evt_err_phase),
      .evt_dlc_err_i        (evt_dlc_err),
      .evt_tx_reject_i      (evt_tx_reject),

      .proto_state_i        (proto_state),
      .bit_pos_i            (bit_pos),
      .stuff_cnt_i          (stuff_cnt),
      .txd_i                (txd_int),
      .rxd_i                (rx_lvl),
      .rx_busy_i            (rx_busy),
      .bus_idle_i           (bus_idle),

      .ts_value_o           (ts_value),
      .ts_capture_sof_o     (ts_capture_sof),

      .irq_o                (irq)
  );

  //---------------------------------------------------------------------------
  // Signals kept for observability (status, assertions, debug) but not used
  // in the functional datapath at this level.
  //---------------------------------------------------------------------------
  logic unused_top;
  assign unused_top = ^{cfg_init, tx_fifo_ovf, 1'b0};

endmodule : can_top

`default_nettype wire
