//=============================================================================
// File        : can_filter.sv
// Description : Acceptance filter bank
//               (specification 08_Acceptance_Filter_and_Message_RAM.md).
//
//               NUM_FILTERS independent identifier/mask filters, each with
//               optional IDE and RTR qualification:
//
//                   id_match = ((rx_id ^ filter_id) & filter_mask) == 0
//
//               A mask bit of 1 means "this identifier bit must match"; the
//               reset mask of zero therefore accepts every identifier.
//
//               Decision order (design spec section on acceptance filtering):
//
//                 1. GLOBAL_REJECT set          -> reject
//                 2. an enabled filter matches  -> accept, lowest index wins
//                 3. GLOBAL_ACCEPT set          -> accept, no filter hit
//                 4. otherwise                  -> reject
//
//               Purely combinational; the caller presents a frame that has
//               already been received and is stable.
//=============================================================================

`default_nettype none

module can_filter
  import can_pkg::*;
#(
    parameter int unsigned NUM_FILTERS = 4
) (
    input  wire [CAN_ID_WIDTH-1:0]                          id_i,
    input  wire                                             ide_i,
    input  wire                                             rtr_i,

    input  wire [NUM_FILTERS-1:0][CAN_FATTR_WIDTH-1:0]      attr_i,
    input  wire [NUM_FILTERS-1:0][CAN_ID_WIDTH-1:0]         fid_i,
    input  wire [NUM_FILTERS-1:0][CAN_ID_WIDTH-1:0]         fmask_i,

    input  wire                                             global_accept_i,
    input  wire                                             global_reject_i,

    output logic                                            accept_o,
    output logic [2:0]                                      hit_index_o,
    output logic                                            matched_o,
    // Per-filter interrupt enable of the filter that accepted the frame
    // (specification 08 section 4).  A frame accepted by the global-accept
    // rule has no filter to consult and always announces itself.
    output logic                                            accept_irq_o
);

  if (NUM_FILTERS < 1) begin : gen_chk_nf_min
    $error("can_filter: NUM_FILTERS must be >= 1 (got %0d)", NUM_FILTERS);
  end
  if (NUM_FILTERS > CAN_MAX_FILTERS) begin : gen_chk_nf_max
    $error("can_filter: NUM_FILTERS must be <= %0d (got %0d)",
           CAN_MAX_FILTERS, NUM_FILTERS);
  end

  logic [NUM_FILTERS-1:0] match;

  for (genvar f = 0; f < NUM_FILTERS; f++) begin : gen_match
    logic id_ok, ide_ok, rtr_ok;

    // Specification 08 section 1 lists both forms.  In range mode the two
    // registers are the inclusive bounds instead of a value and a mask; an
    // empty range (lower > upper) matches nothing, which is the natural
    // reading and is what the comparison gives.
    assign id_ok  = attr_i[f][CAN_FATTR_RANGE]
                  ? ((id_i >= fid_i[f]) && (id_i <= fmask_i[f]))
                  : ((((id_i ^ fid_i[f]) & fmask_i[f]) == '0));
    assign ide_ok = !attr_i[f][CAN_FATTR_IDE_CARE] ||
                    (ide_i == attr_i[f][CAN_FATTR_IDE_SEL]);
    assign rtr_ok = !attr_i[f][CAN_FATTR_RTR_CARE] ||
                    (rtr_i == attr_i[f][CAN_FATTR_RTR_SEL]);

    assign match[f] = attr_i[f][CAN_FATTR_ENABLE] && id_ok && ide_ok && rtr_ok;
  end : gen_match

  // Lowest matching index wins.
  logic hit_irq;

  always_comb begin
    matched_o   = 1'b0;
    hit_index_o = 3'd0;
    hit_irq     = 1'b0;
    for (int unsigned f = 0; f < NUM_FILTERS; f++) begin
      if (match[f] && !matched_o) begin
        matched_o   = 1'b1;
        hit_index_o = 3'(f);
        hit_irq     = attr_i[f][CAN_FATTR_IRQ_EN];
      end
    end
  end

  assign accept_irq_o = matched_o ? hit_irq : 1'b1;

  always_comb begin
    if (global_reject_i)   accept_o = 1'b0;
    else if (matched_o)    accept_o = 1'b1;
    else if (global_accept_i) accept_o = 1'b1;
    else                   accept_o = 1'b0;
  end

endmodule : can_filter

`default_nettype wire
