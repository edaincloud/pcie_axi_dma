//=============================================================================
// File        : can_pkg.sv
// Description : Common constants, register offsets, field definitions and
//               pure helper functions for the Classical CAN (CAN CC) IP.
//
//               Every address and field magic number used by the RTL, the
//               verification environment, the RAL model and software lives
//               here so that the three can never diverge.
//
// Project     : Classical CAN controller (ISO 11898-1 CAN CC), APB4 programmed
// Standard    : IEEE 1800-2017 SystemVerilog
//
// Notes       : Compile-time constants and pure functions only.  Synthesizable
//               and stateless.
//=============================================================================

`ifndef CAN_PKG_SV
`define CAN_PKG_SV

package can_pkg;

  //---------------------------------------------------------------------------
  // Implementation limits
  //---------------------------------------------------------------------------
  // Largest supported acceptance-filter count.  Bounded by the 3-bit
  // FILTER_CONTROL.FILTER_INDEX field.
  localparam int unsigned CAN_MAX_FILTERS = 8;

  // Largest supported TX / RX message FIFO depth.  Bounded by the 8-bit
  // TX_STATUS.LEVEL / RX_STATUS.LEVEL fields.
  localparam int unsigned CAN_MAX_FIFO_DEPTH = 16;

  // Largest supported baud-rate prescaler field width.  BRP is programmed as
  // (prescaler - 1), so BRP_WIDTH = 10 gives prescalers 1 .. 1024.
  localparam int unsigned CAN_MAX_BRP_WIDTH = 10;

  // Timestamp counter width bounds.
  localparam int unsigned CAN_MIN_TIMESTAMP_WIDTH = 16;
  localparam int unsigned CAN_MAX_TIMESTAMP_WIDTH = 32;

  //---------------------------------------------------------------------------
  // Protocol constants (ISO 11898-1 Classical CAN)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_ID_WIDTH      = 29;  // full extended identifier
  localparam int unsigned CAN_BASE_ID_WIDTH = 11;
  localparam int unsigned CAN_EXT_ID_WIDTH  = 18;
  localparam int unsigned CAN_DLC_WIDTH     = 4;
  localparam int unsigned CAN_MAX_DATA_BYTES = 8;
  localparam int unsigned CAN_DATA_WIDTH    = 64;
  localparam int unsigned CAN_CRC_WIDTH     = 15;

  // Number of identical consecutive bits after which a stuff bit is inserted.
  localparam int unsigned CAN_STUFF_LEN = 5;

  localparam int unsigned CAN_EOF_LEN          = 7;
  localparam int unsigned CAN_INTERMISSION_LEN = 3;
  localparam int unsigned CAN_SUSPEND_LEN      = 8;
  localparam int unsigned CAN_ERR_FLAG_LEN     = 6;
  localparam int unsigned CAN_ERR_DELIM_LEN    = 8;

  // Bus is idle once this many consecutive recessive bits have been seen
  // after the end of intermission (ISO: 11 bits for bus-off recovery).
  localparam int unsigned CAN_RECESSIVE_RUN_LEN = 11;

  // Number of 11-consecutive-recessive-bit sequences required to leave the
  // bus-off state (ISO 11898-1 rule 11).
  localparam int unsigned CAN_BUSOFF_RECOVERY_SEQS = 128;

  // Fault-confinement thresholds (ISO 11898-1 rules 9 and 10).
  localparam int unsigned CAN_ERROR_PASSIVE_LIMIT = 128;  // TEC or REC >= 128
  localparam int unsigned CAN_BUS_OFF_LIMIT       = 256;  // TEC >= 256
  localparam int unsigned CAN_DEFAULT_WARN_LIMIT  = 96;

  // Value REC is forced to after a successful reception while REC > 127
  // (ISO rule 8 permits any value in 119..127).
  localparam int unsigned CAN_REC_RELOAD = 127;

  // CRC-15 generator polynomial x^15+x^14+x^10+x^8+x^7+x^4+x^3+1, expressed
  // as the 15-bit XOR mask used by the shift-register implementation.
  localparam logic [14:0] CAN_CRC15_POLY = 15'h4599;

  //---------------------------------------------------------------------------
  // Bus levels
  //---------------------------------------------------------------------------
  localparam logic CAN_DOMINANT  = 1'b0;
  localparam logic CAN_RECESSIVE = 1'b1;

  //---------------------------------------------------------------------------
  // Identification / version register
  //
  //   VERSION = {'C', MAJOR, MINOR, PATCH}
  //---------------------------------------------------------------------------
  localparam logic [7:0] CAN_VERSION_MAGIC = 8'h43;   // 'C'
  localparam logic [7:0] CAN_VERSION_MAJOR = 8'd1;
  localparam logic [7:0] CAN_VERSION_MINOR = 8'd0;
  localparam logic [7:0] CAN_VERSION_PATCH = 8'd0;

  localparam logic [31:0] CAN_VERSION_VALUE =
      {CAN_VERSION_MAGIC, CAN_VERSION_MAJOR, CAN_VERSION_MINOR, CAN_VERSION_PATCH};

  //---------------------------------------------------------------------------
  // Register byte offsets (specification 09_APB_Register_Specification.md)
  //---------------------------------------------------------------------------
  localparam logic [31:0] CAN_ADDR_VERSION           = 32'h0000_0000;
  localparam logic [31:0] CAN_ADDR_CONTROL           = 32'h0000_0004;
  localparam logic [31:0] CAN_ADDR_STATUS            = 32'h0000_0008;
  localparam logic [31:0] CAN_ADDR_MODE              = 32'h0000_000C;
  localparam logic [31:0] CAN_ADDR_INT_STATUS        = 32'h0000_0010;
  localparam logic [31:0] CAN_ADDR_INT_ENABLE        = 32'h0000_0014;
  localparam logic [31:0] CAN_ADDR_BIT_BRP           = 32'h0000_0018;
  localparam logic [31:0] CAN_ADDR_BIT_TSEG1         = 32'h0000_001C;
  localparam logic [31:0] CAN_ADDR_BIT_TSEG2         = 32'h0000_0020;
  localparam logic [31:0] CAN_ADDR_BIT_SJW           = 32'h0000_0024;
  localparam logic [31:0] CAN_ADDR_ERROR_CONTROL     = 32'h0000_0028;
  localparam logic [31:0] CAN_ADDR_TEC               = 32'h0000_002C;
  localparam logic [31:0] CAN_ADDR_REC               = 32'h0000_0030;
  localparam logic [31:0] CAN_ADDR_ERROR_STATUS      = 32'h0000_0034;
  localparam logic [31:0] CAN_ADDR_TX_CONTROL        = 32'h0000_0038;
  localparam logic [31:0] CAN_ADDR_TX_STATUS         = 32'h0000_003C;
  localparam logic [31:0] CAN_ADDR_RX_CONTROL        = 32'h0000_0040;
  localparam logic [31:0] CAN_ADDR_RX_STATUS         = 32'h0000_0044;
  localparam logic [31:0] CAN_ADDR_TX_ID             = 32'h0000_0048;
  localparam logic [31:0] CAN_ADDR_TX_DATA0          = 32'h0000_004C;
  localparam logic [31:0] CAN_ADDR_TX_DATA1          = 32'h0000_0050;
  localparam logic [31:0] CAN_ADDR_TX_DLC_CONTROL    = 32'h0000_0054;
  localparam logic [31:0] CAN_ADDR_RX_ID             = 32'h0000_0058;
  localparam logic [31:0] CAN_ADDR_RX_DATA0          = 32'h0000_005C;
  localparam logic [31:0] CAN_ADDR_RX_DATA1          = 32'h0000_0060;
  localparam logic [31:0] CAN_ADDR_RX_DLC_STATUS     = 32'h0000_0064;
  localparam logic [31:0] CAN_ADDR_FILTER_CONTROL    = 32'h0000_0068;
  localparam logic [31:0] CAN_ADDR_FILTER_ID         = 32'h0000_006C;
  localparam logic [31:0] CAN_ADDR_FILTER_MASK       = 32'h0000_0070;
  localparam logic [31:0] CAN_ADDR_TIMESTAMP_CONTROL = 32'h0000_0074;
  localparam logic [31:0] CAN_ADDR_TIMESTAMP_VALUE   = 32'h0000_0078;
  localparam logic [31:0] CAN_ADDR_DEBUG_CONTROL     = 32'h0000_007C;
  localparam logic [31:0] CAN_ADDR_DEBUG_STATUS      = 32'h0000_0080;
  // Extension beyond the normative register list - see design spec Appendix A.
  localparam logic [31:0] CAN_ADDR_RX_TIMESTAMP      = 32'h0000_0084;

  // First byte address above the implemented register region.
  localparam logic [31:0] CAN_REGION_END = 32'h0000_0088;

  //---------------------------------------------------------------------------
  // CONTROL (0x004)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_CTRL_ENABLE_BIT          = 0;
  localparam int unsigned CAN_CTRL_INIT_BIT            = 1;
  localparam int unsigned CAN_CTRL_LOOPBACK_BIT        = 2;
  localparam int unsigned CAN_CTRL_LISTEN_ONLY_BIT     = 3;
  localparam int unsigned CAN_CTRL_ONE_SHOT_BIT        = 4;
  localparam int unsigned CAN_CTRL_AUTO_RETRANSMIT_BIT = 5;
  localparam int unsigned CAN_CTRL_ACCEPT_REMOTE_BIT   = 6;
  localparam int unsigned CAN_CTRL_WIDTH               = 7;

  // CONTROL reset value: INIT set, AUTO_RETRANSMIT set, ACCEPT_REMOTE set.
  localparam logic [CAN_CTRL_WIDTH-1:0] CAN_CTRL_RESET_VALUE = 7'b110_0010;

  //---------------------------------------------------------------------------
  // STATUS (0x008), read-only
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_STAT_TX_BUSY_BIT          = 0;
  localparam int unsigned CAN_STAT_RX_BUSY_BIT          = 1;
  localparam int unsigned CAN_STAT_ERROR_ACTIVE_BIT     = 2;
  localparam int unsigned CAN_STAT_ERROR_PASSIVE_BIT    = 3;
  localparam int unsigned CAN_STAT_BUS_OFF_BIT          = 4;
  localparam int unsigned CAN_STAT_RX_OVERFLOW_BIT      = 5;
  localparam int unsigned CAN_STAT_TX_COMPLETE_BIT      = 6;
  localparam int unsigned CAN_STAT_ARBITRATION_LOST_BIT = 7;
  localparam int unsigned CAN_STAT_INIT_ACK_BIT         = 8;
  localparam int unsigned CAN_STAT_BUS_IDLE_BIT         = 9;
  localparam int unsigned CAN_STAT_ERROR_WARNING_BIT    = 10;
  localparam int unsigned CAN_STAT_BT_CFG_ERROR_BIT     = 11;
  localparam int unsigned CAN_STAT_WIDTH                = 12;

  //---------------------------------------------------------------------------
  // MODE (0x00C)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_MODE_RX_OVFL_POLICY_LSB = 0;   // 2 bits
  localparam int unsigned CAN_MODE_SELF_ACK_BIT       = 2;
  // Hands the two message FIFOs to the native TX/RX ports (specification
  // 01_Functional_Architecture sections 8 and 9).  While set, the register
  // TX_CONTROL.TX_REQUEST and RX_CONTROL.RX_RELEASE commands are ignored, so
  // exactly one requester owns each FIFO and no arbitration is needed.
  localparam int unsigned CAN_MODE_NATIVE_EN_BIT      = 3;
  localparam int unsigned CAN_MODE_WIDTH              = 4;

  // RX overflow policies (specification 08_Acceptance_Filter section 9).
  localparam logic [1:0] CAN_OVFL_DROP_NEW = 2'd0;
  localparam logic [1:0] CAN_OVFL_DROP_OLD = 2'd1;
  localparam logic [1:0] CAN_OVFL_BLOCK    = 2'd2;

  //---------------------------------------------------------------------------
  // INT_STATUS (0x010, RW1C) / INT_ENABLE (0x014, RW)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_INT_RX_AVAILABLE_BIT     = 0;
  localparam int unsigned CAN_INT_TX_COMPLETE_BIT      = 1;
  localparam int unsigned CAN_INT_TX_ABORT_BIT         = 2;
  localparam int unsigned CAN_INT_ARBITRATION_LOST_BIT = 3;
  localparam int unsigned CAN_INT_ERROR_WARNING_BIT    = 4;
  localparam int unsigned CAN_INT_ERROR_PASSIVE_BIT    = 5;
  localparam int unsigned CAN_INT_BUS_OFF_BIT          = 6;
  localparam int unsigned CAN_INT_RX_OVERFLOW_BIT      = 7;
  localparam int unsigned CAN_INT_CRC_ERROR_BIT        = 8;
  localparam int unsigned CAN_INT_STUFF_ERROR_BIT      = 9;
  localparam int unsigned CAN_INT_FORM_ERROR_BIT       = 10;
  localparam int unsigned CAN_INT_BIT_ERROR_BIT        = 11;
  localparam int unsigned CAN_INT_ACK_ERROR_BIT        = 12;
  // A frame carrying a data length code above eight was rejected
  // (specification 02_Classical_CAN_Frame_Format section 7).
  localparam int unsigned CAN_INT_DLC_ERROR_BIT        = 13;
  localparam int unsigned CAN_INT_WIDTH                = 14;

  //---------------------------------------------------------------------------
  // Bit timing registers
  //---------------------------------------------------------------------------
  // Programmed values are (length - 1) in every case.
  localparam int unsigned CAN_TSEG1_FIELD_WIDTH = 4;   // 1 .. 16 TQ
  localparam int unsigned CAN_TSEG2_FIELD_WIDTH = 3;   // 1 ..  8 TQ
  localparam int unsigned CAN_SJW_FIELD_WIDTH   = 2;   // 1 ..  4 TQ

  // Widest possible bit time in TQ: 1 (sync) + 16 (tseg1) + 8 (tseg2) = 25,
  // extended by at most SJW = 4 by resynchronisation.
  localparam int unsigned CAN_MAX_BIT_TQ = 1 + 16 + 8 + 4;
  localparam int unsigned CAN_BIT_POS_WIDTH = $clog2(CAN_MAX_BIT_TQ + 1);  // 5

  //---------------------------------------------------------------------------
  // ERROR_CONTROL (0x028)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_ERRCTRL_AUTO_RECOVER_BIT = 0;
  localparam int unsigned CAN_ERRCTRL_RECOVER_REQ_BIT  = 1;   // write-one-pulse
  localparam int unsigned CAN_ERRCTRL_EWL_LSB          = 8;   // 8 bits

  //---------------------------------------------------------------------------
  // ERROR_STATUS (0x034)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_ERRSTAT_LEC_LSB       = 0;    // 3 bits, RO
  localparam int unsigned CAN_ERRSTAT_PHASE_LSB     = 4;    // 5 bits, RO
  localparam int unsigned CAN_ERRSTAT_STICKY_LSB    = 16;   // 5 bits, W1C
  localparam int unsigned CAN_ERRSTAT_BOCNT_LSB     = 24;   // 8 bits, RO

  // Last error codes.
  localparam logic [2:0] CAN_LEC_NONE  = 3'd0;
  localparam logic [2:0] CAN_LEC_BIT   = 3'd1;
  localparam logic [2:0] CAN_LEC_STUFF = 3'd2;
  localparam logic [2:0] CAN_LEC_CRC   = 3'd3;
  localparam logic [2:0] CAN_LEC_FORM  = 3'd4;
  localparam logic [2:0] CAN_LEC_ACK   = 3'd5;

  // Sticky error flags, ERROR_STATUS[20:16].
  localparam int unsigned CAN_ERRSTICKY_BIT   = 0;
  localparam int unsigned CAN_ERRSTICKY_STUFF = 1;
  localparam int unsigned CAN_ERRSTICKY_CRC   = 2;
  localparam int unsigned CAN_ERRSTICKY_FORM  = 3;
  localparam int unsigned CAN_ERRSTICKY_ACK   = 4;
  localparam int unsigned CAN_ERRSTICKY_WIDTH = 5;

  //---------------------------------------------------------------------------
  // TX_CONTROL (0x038) - write-one-pulse command bits
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_TXCTRL_REQUEST_BIT = 0;
  localparam int unsigned CAN_TXCTRL_ABORT_BIT   = 1;
  localparam int unsigned CAN_TXCTRL_FLUSH_BIT   = 2;

  //---------------------------------------------------------------------------
  // TX_STATUS (0x03C), read-only
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_TXSTAT_LEVEL_LSB  = 0;    // 8 bits
  localparam int unsigned CAN_TXSTAT_EMPTY_BIT  = 8;
  localparam int unsigned CAN_TXSTAT_FULL_BIT   = 9;
  localparam int unsigned CAN_TXSTAT_ACTIVE_BIT = 10;

  //---------------------------------------------------------------------------
  // RX_CONTROL (0x040) - write-one-pulse command bits
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_RXCTRL_RELEASE_BIT = 0;
  localparam int unsigned CAN_RXCTRL_FLUSH_BIT   = 1;

  //---------------------------------------------------------------------------
  // RX_STATUS (0x044), read-only
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_RXSTAT_LEVEL_LSB    = 0;   // 8 bits
  localparam int unsigned CAN_RXSTAT_EMPTY_BIT    = 8;
  localparam int unsigned CAN_RXSTAT_FULL_BIT     = 9;
  localparam int unsigned CAN_RXSTAT_OVERFLOW_BIT = 10;
  // BLOCK policy: reception is latched off after an overflow until software
  // clears INT_STATUS.RX_OVERFLOW (specification 08 section 9).
  localparam int unsigned CAN_RXSTAT_BLOCKED_BIT  = 11;

  //---------------------------------------------------------------------------
  // Native receive status word (specification 01 section 9, `rx_status`;
  // the fields are the receive-side status of specification 05 section 12
  // that survive frame commit).
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_RXNAT_FHIT_LSB    = 0;   // 3 bits
  localparam int unsigned CAN_RXNAT_FMATCH_BIT  = 3;
  localparam int unsigned CAN_RXNAT_OVERFLOW_BIT = 4;
  localparam int unsigned CAN_RXNAT_BLOCKED_BIT = 5;
  localparam int unsigned CAN_RXNAT_WIDTH       = 6;

  //---------------------------------------------------------------------------
  // TX_DLC_CONTROL (0x054) / RX_DLC_STATUS (0x064)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_DLCC_DLC_LSB       = 0;   // 4 bits
  localparam int unsigned CAN_DLCC_RTR_BIT       = 4;
  localparam int unsigned CAN_DLCC_IDE_BIT       = 5;
  localparam int unsigned CAN_DLCC_ONE_SHOT_BIT  = 6;

  localparam int unsigned CAN_RXDLC_DLC_LSB      = 0;   // 4 bits
  localparam int unsigned CAN_RXDLC_RTR_BIT      = 4;
  localparam int unsigned CAN_RXDLC_IDE_BIT      = 5;
  localparam int unsigned CAN_RXDLC_VALID_BIT    = 6;
  localparam int unsigned CAN_RXDLC_FHIT_LSB     = 8;   // 3 bits
  localparam int unsigned CAN_RXDLC_FMATCH_BIT   = 11;

  //---------------------------------------------------------------------------
  // FILTER_CONTROL (0x068)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_FCTRL_INDEX_LSB     = 0;   // 3 bits
  localparam int unsigned CAN_FCTRL_ENABLE_BIT    = 8;
  localparam int unsigned CAN_FCTRL_IDE_SEL_BIT   = 9;
  localparam int unsigned CAN_FCTRL_IDE_CARE_BIT  = 10;
  localparam int unsigned CAN_FCTRL_RTR_SEL_BIT   = 11;
  localparam int unsigned CAN_FCTRL_RTR_CARE_BIT  = 12;
  // Specification 08 section 1 lists range filters alongside identifier+mask;
  // with RANGE set, FILTER_ID is the lower bound and FILTER_MASK the upper.
  localparam int unsigned CAN_FCTRL_RANGE_BIT     = 13;
  // Specification 08 section 4's per-filter `interrupt_enable`: a frame this
  // filter accepts is stored, but does not raise INT_STATUS.RX_AVAILABLE.
  localparam int unsigned CAN_FCTRL_IRQ_EN_BIT    = 14;
  localparam int unsigned CAN_FCTRL_GACCEPT_BIT   = 16;
  localparam int unsigned CAN_FCTRL_GREJECT_BIT   = 17;

  // Per-filter attribute vector layout, as stored in the filter register file.
  localparam int unsigned CAN_FATTR_ENABLE   = 0;
  localparam int unsigned CAN_FATTR_IDE_SEL  = 1;
  localparam int unsigned CAN_FATTR_IDE_CARE = 2;
  localparam int unsigned CAN_FATTR_RTR_SEL  = 3;
  localparam int unsigned CAN_FATTR_RTR_CARE = 4;
  localparam int unsigned CAN_FATTR_RANGE    = 5;
  localparam int unsigned CAN_FATTR_IRQ_EN   = 6;
  localparam int unsigned CAN_FATTR_WIDTH    = 7;

  //---------------------------------------------------------------------------
  // TIMESTAMP_CONTROL (0x074)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_TSCTRL_ENABLE_BIT   = 0;
  localparam int unsigned CAN_TSCTRL_RESET_BIT    = 1;   // write-one-pulse
  localparam int unsigned CAN_TSCTRL_CAPTURE_BIT  = 2;   // 0 = SOF, 1 = commit

  //---------------------------------------------------------------------------
  // DEBUG_CONTROL (0x07C) / DEBUG_STATUS (0x080)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_DBGCTRL_ENABLE_BIT = 0;

  localparam int unsigned CAN_DBGSTAT_STATE_LSB  = 0;    // 5 bits
  localparam int unsigned CAN_DBGSTAT_BITPOS_LSB = 8;    // 5 bits
  localparam int unsigned CAN_DBGSTAT_STUFF_LSB  = 16;   // 3 bits
  localparam int unsigned CAN_DBGSTAT_TXD_BIT    = 20;
  localparam int unsigned CAN_DBGSTAT_RXD_BIT    = 21;
  localparam int unsigned CAN_DBGSTAT_TXING_BIT  = 22;
  localparam int unsigned CAN_DBGSTAT_RXING_BIT  = 23;

  //---------------------------------------------------------------------------
  // Protocol engine state encoding.
  //
  // A single unified bit-serial engine handles transmission and reception:
  // a CAN node always receives the bit stream it is transmitting, and the two
  // roles share the field sequencing, stuffing, CRC and error machinery.  See
  // design spec Appendix A for why this replaces the separate TX/RX FSMs of
  // the normative architecture document.
  //---------------------------------------------------------------------------
  typedef enum logic [4:0] {
    ST_IDLE         = 5'd0,
    ST_SOF          = 5'd1,
    ST_ID_A         = 5'd2,   // 11 base identifier bits
    ST_RTR_SRR      = 5'd3,   // RTR (standard) / SRR (extended)
    ST_IDE          = 5'd4,
    ST_ID_B         = 5'd5,   // 18 extended identifier bits
    ST_RTR_EXT      = 5'd6,
    ST_R1           = 5'd7,
    ST_R0           = 5'd8,
    ST_DLC          = 5'd9,   // 4 bits
    ST_DATA         = 5'd10,  // 0 .. 64 bits
    ST_CRC          = 5'd11,  // 15 bits
    ST_CRC_DELIM    = 5'd12,
    ST_ACK_SLOT     = 5'd13,
    ST_ACK_DELIM    = 5'd14,
    ST_EOF          = 5'd15,  // 7 bits
    ST_INTERMISSION = 5'd16,  // 3 bits
    ST_SUSPEND      = 5'd17,  // 8 bits
    ST_ERR_FLAG     = 5'd18,  // 6 bits (error or overload flag)
    ST_ERR_ECHO     = 5'd19,  // superposition / passive-flag wait window
    ST_ERR_DELIM    = 5'd20,  // 8 bits
    ST_BUS_OFF      = 5'd21
  } can_state_e;

  //---------------------------------------------------------------------------
  // Fault-confinement state.
  //---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    FC_ERROR_ACTIVE  = 2'd0,
    FC_ERROR_PASSIVE = 2'd1,
    FC_BUS_OFF       = 2'd2
  } can_fault_state_e;

  //---------------------------------------------------------------------------
  // Error kinds raised by the protocol engine.
  //---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    ERR_NONE  = 3'd0,
    ERR_BIT   = 3'd1,
    ERR_STUFF = 3'd2,
    ERR_CRC   = 3'd3,
    ERR_FORM  = 3'd4,
    ERR_ACK   = 3'd5
  } can_err_kind_e;

  //---------------------------------------------------------------------------
  // Message descriptor layout shared by the TX and RX FIFOs.
  //
  //   [63:0]    data (byte 0 in [7:0])
  //   [92:64]   identifier, right aligned
  //   [93]      IDE
  //   [94]      RTR
  //   [98:95]   DLC
  //   [99]      one-shot (TX) / interrupt-enabled (RX)
  //   [102:100] filter hit index (RX only)
  //   [103]     filter matched   (RX only)
  //---------------------------------------------------------------------------
  localparam int unsigned CAN_MSG_DATA_LSB   = 0;
  localparam int unsigned CAN_MSG_ID_LSB     = 64;
  localparam int unsigned CAN_MSG_IDE_BIT    = 93;
  localparam int unsigned CAN_MSG_RTR_BIT    = 94;
  localparam int unsigned CAN_MSG_DLC_LSB    = 95;
  localparam int unsigned CAN_MSG_FLAG_BIT   = 99;
  localparam int unsigned CAN_MSG_FHIT_LSB   = 100;
  localparam int unsigned CAN_MSG_FMATCH_BIT = 103;
  localparam int unsigned CAN_MSG_WIDTH      = 104;

  //---------------------------------------------------------------------------
  // Pure helper functions
  //---------------------------------------------------------------------------

  // One CRC-15 shift-register step.
  function automatic logic [14:0] can_crc15_next(input logic [14:0] crc,
                                                 input logic        b);
    logic fb;
    logic [14:0] shifted;
    fb      = b ^ crc[14];
    shifted = {crc[13:0], 1'b0};
    can_crc15_next = fb ? (shifted ^ CAN_CRC15_POLY) : shifted;
  endfunction

  // Number of payload bytes carried by a DLC value.  ISO 11898-1 defines DLC
  // values 9..15 as eight data bytes for Classical CAN.
  function automatic logic [3:0] can_dlc_to_len(input logic [3:0] dlc);
    can_dlc_to_len = (dlc > 4'(CAN_MAX_DATA_BYTES)) ? 4'(CAN_MAX_DATA_BYTES) : dlc;
  endfunction

  // 1 when the data length code is a valid Classical CAN data length.
  // Specification 02 section 7: "DLC values above 8 are not valid Classical
  // CAN data lengths and shall be rejected or handled as protocol errors."
  // The controller rejects them - it neither transmits nor delivers such a
  // frame - which is the option that leaves the bus undisturbed.
  function automatic logic can_dlc_is_valid(input logic [3:0] dlc);
    can_dlc_is_valid = (dlc <= 4'(CAN_MAX_DATA_BYTES));
  endfunction

  // 1 when the programmed bit timing places the sample point fewer than four
  // core clocks after the start of the bit time.  The receive path costs three
  // core clocks (two synchroniser stages plus the input register), so such a
  // node samples the previous bit and cannot work at all.  The sample point
  // lies (TSEG1 + 2) x (BRP + 1) core clocks into the bit time, so the only
  // encodable violation is BRP = 0 together with TSEG1 < 2.  Specification 03
  // section 8 requires such configurations to be rejected; the register block
  // refuses the write that would create one.
  function automatic logic can_bit_time_too_short(
      input logic                             brp_is_zero,
      input logic [CAN_TSEG1_FIELD_WIDTH-1:0] tseg1);
    can_bit_time_too_short = brp_is_zero && (tseg1 < CAN_TSEG1_FIELD_WIDTH'(2));
  endfunction

  // 1 when the offset selects an implemented register.
  function automatic logic can_addr_is_valid(input logic [31:0] a);
    unique case (a)
      CAN_ADDR_VERSION, CAN_ADDR_CONTROL, CAN_ADDR_STATUS, CAN_ADDR_MODE,
      CAN_ADDR_INT_STATUS, CAN_ADDR_INT_ENABLE, CAN_ADDR_BIT_BRP,
      CAN_ADDR_BIT_TSEG1, CAN_ADDR_BIT_TSEG2, CAN_ADDR_BIT_SJW,
      CAN_ADDR_ERROR_CONTROL, CAN_ADDR_TEC, CAN_ADDR_REC,
      CAN_ADDR_ERROR_STATUS, CAN_ADDR_TX_CONTROL, CAN_ADDR_TX_STATUS,
      CAN_ADDR_RX_CONTROL, CAN_ADDR_RX_STATUS, CAN_ADDR_TX_ID,
      CAN_ADDR_TX_DATA0, CAN_ADDR_TX_DATA1, CAN_ADDR_TX_DLC_CONTROL,
      CAN_ADDR_RX_ID, CAN_ADDR_RX_DATA0, CAN_ADDR_RX_DATA1,
      CAN_ADDR_RX_DLC_STATUS, CAN_ADDR_FILTER_CONTROL, CAN_ADDR_FILTER_ID,
      CAN_ADDR_FILTER_MASK, CAN_ADDR_TIMESTAMP_CONTROL,
      CAN_ADDR_TIMESTAMP_VALUE, CAN_ADDR_DEBUG_CONTROL,
      CAN_ADDR_DEBUG_STATUS, CAN_ADDR_RX_TIMESTAMP : can_addr_is_valid = 1'b1;
      default                                      : can_addr_is_valid = 1'b0;
    endcase
  endfunction

  // 1 when the offset selects a read-only register (writes raise PSLVERR).
  function automatic logic can_addr_is_ro(input logic [31:0] a);
    unique case (a)
      CAN_ADDR_VERSION, CAN_ADDR_STATUS, CAN_ADDR_TEC, CAN_ADDR_REC,
      CAN_ADDR_TX_STATUS, CAN_ADDR_RX_STATUS, CAN_ADDR_RX_ID,
      CAN_ADDR_RX_DATA0, CAN_ADDR_RX_DATA1, CAN_ADDR_RX_DLC_STATUS,
      CAN_ADDR_TIMESTAMP_VALUE, CAN_ADDR_DEBUG_STATUS,
      CAN_ADDR_RX_TIMESTAMP : can_addr_is_ro = 1'b1;
      default               : can_addr_is_ro = 1'b0;
    endcase
  endfunction

  // 1 when the offset selects a bit-timing register.  These accept writes
  // only while the controller is in the initialization state.
  function automatic logic can_addr_is_bit_timing(input logic [31:0] a);
    unique case (a)
      CAN_ADDR_BIT_BRP, CAN_ADDR_BIT_TSEG1,
      CAN_ADDR_BIT_TSEG2, CAN_ADDR_BIT_SJW : can_addr_is_bit_timing = 1'b1;
      default                              : can_addr_is_bit_timing = 1'b0;
    endcase
  endfunction

  // 1 while the protocol engine is inside the arbitration field, where a
  // transmitted recessive bit that reads back dominant is a loss of
  // arbitration rather than a bit error.
  function automatic logic can_state_is_arbitration(input can_state_e s);
    unique case (s)
      ST_ID_A, ST_RTR_SRR, ST_IDE,
      ST_ID_B, ST_RTR_EXT : can_state_is_arbitration = 1'b1;
      default             : can_state_is_arbitration = 1'b0;
    endcase
  endfunction

  // 1 while dynamic bit stuffing applies: from SOF through the last bit of
  // the CRC sequence inclusive.
  function automatic logic can_state_is_stuffed(input can_state_e s);
    unique case (s)
      ST_SOF, ST_ID_A, ST_RTR_SRR, ST_IDE, ST_ID_B, ST_RTR_EXT,
      ST_R1, ST_R0, ST_DLC, ST_DATA, ST_CRC : can_state_is_stuffed = 1'b1;
      default                               : can_state_is_stuffed = 1'b0;
    endcase
  endfunction

  // 1 while the received bit is part of the CRC-protected sequence.
  function automatic logic can_state_is_crc_protected(input can_state_e s);
    unique case (s)
      ST_SOF, ST_ID_A, ST_RTR_SRR, ST_IDE, ST_ID_B, ST_RTR_EXT,
      ST_R1, ST_R0, ST_DLC, ST_DATA : can_state_is_crc_protected = 1'b1;
      default                       : can_state_is_crc_protected = 1'b0;
    endcase
  endfunction

  // 1 while the engine is inside a frame (used for STATUS.RX_BUSY and for
  // deciding whether a new transmission may be started).
  function automatic logic can_state_in_frame(input can_state_e s);
    unique case (s)
      ST_IDLE, ST_INTERMISSION, ST_SUSPEND, ST_BUS_OFF : can_state_in_frame = 1'b0;
      default                                          : can_state_in_frame = 1'b1;
    endcase
  endfunction

endpackage : can_pkg

`endif // CAN_PKG_SV
