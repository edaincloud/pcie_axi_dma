//=============================================================================
// File        : can_sync.sv
// Description : Two-flop synchronizer for the asynchronous CAN receive data
//               input (specification 10_PHY_Interface_Specification section 3).
//
//               `can_rxd` is driven by an external transceiver and has no
//               timing relationship to the controller clock, so it is the one
//               genuine clock-domain crossing in this IP.  Everything
//               downstream of `d_sync_o` is fully synchronous.
//
//               CDC contract
//               ------------
//                 - single-bit level signal, no protocol, no bus;
//                 - STAGES >= 2 flip-flops, no combinational logic between
//                   them, so metastability settles inside the chain;
//                 - the resulting latency (STAGES clocks) is a fixed
//                   propagation delay that applies equally to edge detection
//                   and to sampling, so it cannot skew the bit timing;
//                 - the reset value is recessive, which is the safe bus level.
//
//               There is no digital glitch filter: a Classical CAN
//               transceiver is specified to deliver a clean logic level and
//               the sample point is placed by the bit timing logic.  This is
//               recorded as a limitation in the design specification.
//=============================================================================

`default_nettype none

module can_sync #(
    parameter int unsigned STAGES = 2
) (
    input  wire  clk_i,
    input  wire  rst_ni,
    input  wire  d_i,        // asynchronous input
    output logic d_sync_o    // synchronized input
);

  if (STAGES < 2) begin : gen_chk_stages
    $error("can_sync: STAGES must be >= 2 (got %0d)", STAGES);
  end

  /* verilator lint_off SYNCASYNCNET */
  logic [STAGES-1:0] sync_q;
  /* verilator lint_on SYNCASYNCNET */

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      sync_q <= {STAGES{1'b1}};   // recessive
    end else begin
      sync_q <= {sync_q[STAGES-2:0], d_i};
    end
  end

  assign d_sync_o = sync_q[STAGES-1];

endmodule : can_sync

`default_nettype wire
