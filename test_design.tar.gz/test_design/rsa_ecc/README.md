# rsa_ecc

Top module: **`rsa_ecc_top`**. RTL: 123 files (33996 lines per the benchmark list),
copied from `/home/test/designs/rsa_ecc` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/rsa_ecc_top.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/rsa_ecc/inputs/rsa_ecc_top.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |
| `macros/` | macro Liberty/LEF and the fakeram45 memory mapping files |

Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| PCLK | PCLK | 13.99 |

Minimum period: **13.99 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- **`--single-unit`** (yosys-slang): all files are compiled as one compilation unit (macros/`define visible across files).
- **Macros:** `macros/fakeram45_1024x32.lib`. Memories are mapped to fakeram45 macros (`macros/fakeram45.memlib` + `fakeram45_map.v`, yosys `memory_libmap`); other tools need equivalent memory compilation/mapping.
- Note: --single-unit: OpenTitan macro files shared across the file list; writable memories >= 2048 bits as black-box macros (mem_macro/prep_<d>.ys)

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 161,909 | 19,940 | 272,018 | +1.297 | 0.000 | -7.605 | 1016 s | 1043 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 144,471 | 19,940 | 240,757 | +1.245 | 0.000 | +13.447 | 1685 s | 1937 MB |
