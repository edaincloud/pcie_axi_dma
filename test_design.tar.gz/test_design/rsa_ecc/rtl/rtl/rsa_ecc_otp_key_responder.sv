//=============================================================================
// File        : rsa_ecc_otp_key_responder.sv
// Description : On-chip responder for the vendored core's OTP scrambling-key
//               interface.
//
//               WHY THIS EXISTS
//               ---------------
//               The core's IMEM and DMEM are scrambled memories.  Out of reset
//               and again on every secure wipe, the core asks an OTP
//               controller for an ephemeral scrambling key and nonce.  Until
//               that request is answered the memories hold no usable key, and
//               the core does not become IDLE.  An APB4 IP with no OTP block
//               behind it therefore has to answer this itself.
//
//               WHAT IT IS NOT
//               --------------
//               THIS IS NOT A KEY MANAGER.  It returns a COMPILE-TIME
//               CONSTANT key and nonce, taken from the KEY and NONCE
//               parameters.  Memory scrambling with a constant key is
//               obfuscation, not confidentiality: two instances of this
//               netlist scramble identically, and the key is readable from the
//               netlist.  `seed_valid` is driven LOW, which is the honest
//               encoding - it tells the core, and through ERR_BITS the
//               software, that the key was NOT derived from a provisioned
//               seed.  Driving it high would be a lie the core would believe.
//
//               An integrator with a real otp_ctrl builds with
//               KEY_MODE = RSA_ECC_OTP_KEY_EXTERNAL, which removes this module
//               and brings the request/response pair out to the boundary.
//
//               PROTOCOL
//               --------
//               `prim_sync_reqack_data`, the same shape as the EDN ports:
//               `req` is held until a one-cycle `ack`, and is not re-asserted
//               before it has returned low.  A fixed latency would be fine
//               functionally; a small pseudo-random one is used instead so
//               that the core's request path is not only ever exercised at one
//               timing.
//=============================================================================

`default_nettype none

module rsa_ecc_otp_key_responder
  import rsa_ecc_pkg::*;
#(
    // The constant scrambling key and nonce.  See the warning above: these are
    // in the netlist and are not secret.
    parameter logic [OTP_KEY_WIDTH-1:0]   KEY   = otp_ctrl_pkg::otbn_key_t'(
                                                    otbn_pkg::RndCnstOtbnKeyDefault),
    parameter logic [OTP_NONCE_WIDTH-1:0] NONCE = otp_ctrl_pkg::otbn_nonce_t'(
                                                    otbn_pkg::RndCnstOtbnNonceDefault),
    parameter logic [63:0]                SEED  = 64'h13F5_7B9D_2468_ACE1
) (
    input  wire                          clk_i,
    input  wire                          rst_ni,

    input  wire                          key_req_i,
    output logic                         key_ack_o,
    output logic [OTP_KEY_WIDTH-1:0]     key_o,
    output logic [OTP_NONCE_WIDTH-1:0]   nonce_o,
    output logic                         seed_valid_o
);

  typedef enum logic [1:0] {
    ST_WAIT_REQ  = 2'b00,
    ST_DELAY     = 2'b01,
    ST_ACK       = 2'b10,
    ST_WAIT_DROP = 2'b11
  } state_e;

  state_e      state_q, state_d;
  logic [1:0]  delay_q, delay_d;
  logic [63:0] lfsr_state;

  rsa_ecc_lfsr #(
    .SEED  (SEED),
    .STEPS (7)
  ) u_lfsr (
    .clk_i,
    .rst_ni,
    .en_i    (1'b1),
    .state_o (lfsr_state)
  );

  always_comb begin
    state_d   = state_q;
    delay_d   = delay_q;
    key_ack_o = 1'b0;

    unique case (state_q)
      ST_WAIT_REQ: begin
        if (key_req_i) begin
          delay_d = lfsr_state[1:0];
          state_d = ST_DELAY;
        end
      end
      ST_DELAY: begin
        if (delay_q == 2'd0) begin
          state_d = ST_ACK;
        end else begin
          delay_d = delay_q - 2'd1;
        end
      end
      ST_ACK: begin
        key_ack_o = 1'b1;
        state_d   = ST_WAIT_DROP;
      end
      ST_WAIT_DROP: begin
        if (!key_req_i) begin
          state_d = ST_WAIT_REQ;
        end
      end
      // Unreachable: state_e is fully enumerated over two bits.  Present so a
      // corrupted state recovers rather than persists.
      default: state_d = ST_WAIT_REQ;
    endcase
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= ST_WAIT_REQ;
      delay_q <= 2'd0;
    end else begin
      state_q <= state_d;
      delay_q <= delay_d;
    end
  end

  // Only the bottom two bits of the LFSR pick the response latency.
  logic unused_lfsr;
  assign unused_lfsr = ^lfsr_state[63:2];

  assign key_o        = KEY;
  assign nonce_o      = NONCE;
  // See the header: this key was never derived from a provisioned seed, and
  // saying otherwise would be a claim the core has no way to check.
  assign seed_valid_o = 1'b0;

endmodule : rsa_ecc_otp_key_responder

`default_nettype wire
