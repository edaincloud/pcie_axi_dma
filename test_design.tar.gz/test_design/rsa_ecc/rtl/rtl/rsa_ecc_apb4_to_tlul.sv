//=============================================================================
// File        : rsa_ecc_apb4_to_tlul.sv
// Description : APB4 subordinate to TileLink-UL host bridge.
//
//               The house bus is APB4.  The vendored compute core speaks
//               TL-UL, because it is OpenTitan RTL that has not been modified
//               and must not be.  This module is the whole of the conversion.
//
//               DERIVED FROM a bridge already proven in the socgen project
//               (tools/../data/ip_rtl/socgen_apb_tlul/socgen_apb_to_tlul.sv).
//               Re-expressed in this tree's house style (`logic`, `always_ff`,
//               `default_nettype none`, elaboration guards, SVA) and extended
//               with the integrity generation described below, which the
//               original deliberately left to its callers.  The transaction
//               model, the ACCESS-phase issue point and the read-mask rule are
//               that bridge's, not new work, and they are the two things in
//               here that cost real debugging time elsewhere:
//
//               1. THE REQUEST IS ISSUED ON THE ACCESS PHASE.
//                  `psel` alone is the SETUP phase.  Issuing there puts a
//                  transaction on the bus one cycle early and then repeats it
//                  when `penable` rises, so a read has side effects twice and
//                  a FIFO pops twice.
//
//               2. A READ MUST STILL PRESENT A MASK.
//                  TL-UL uses `a_mask` on a Get to say which lanes it wants
//                  back.  An all-zero mask is a legal encoding that returns
//                  nothing, and the symptom is a read of zero rather than a
//                  bus error.  Reads therefore drive all ones; writes drive
//                  PSTRB, and a partial write is expressed by the MASK with a
//                  full-width size, never by a smaller size.
//
//               INTEGRITY - the trap that makes a correct bridge look broken
//               ----------------------------------------------------------
//               `tlul_pkg::TL_H2D_DEFAULT` leaves `a_user.cmd_intg` and
//               `a_user.data_intg` at all ones.  That is a deliberately
//               INVALID checksum, not a "do not check" encoding.  OTBN's
//               `otbn_reg_top` runs `tlul_cmd_intg_chk` unconditionally and
//               answers `d_error` on EVERY access, however well formed, so
//               the entire IP reads back as one big bus error and nothing
//               about the failure points at integrity.
//
//               The command is therefore routed through OpenTitan's own
//               `tlul_cmd_intg_gen` with `EnableDataIntgGen(1)`, here, in the
//               one module that has assembled the whole command.  It is
//               instantiated INSIDE the bridge rather than by the parent so
//               that no future integration can wire the bridge up and forget
//               it.
//
//               TRANSACTION MODEL: one outstanding.  APB is two-phase and
//               cannot overlap accesses, so there is never a second request to
//               track and a queue here would only be testing itself.
//
//               NO TIMEOUT.  `PREADY` is asserted only when the device
//               answers.  A TL-UL device that never responds hangs the APB
//               bus, and that is deliberate: the alternative is to invent a
//               completion the device never gave and hand software data that
//               was never read.  The vendored core always answers - including
//               while it is busy, where it answers with an error - so the
//               hang is unreachable in this IP; the testbench proves the
//               point with an assertion rather than the design carrying a
//               counter that nothing can exercise.
//=============================================================================

`default_nettype none

module rsa_ecc_apb4_to_tlul
  import rsa_ecc_pkg::*;
#(
    // APB address bus width.  Only the low TL_AW bits reach the device; the
    // parent is responsible for having decoded everything above them.
    parameter int unsigned APB_ADDR_WIDTH = 20
) (
    input  wire                          clk_i,
    input  wire                          rst_ni,

    // ------------------------------------------------------------ APB4 side
    input  wire                          psel_i,
    input  wire                          penable_i,
    input  wire                          pwrite_i,
    input  wire  [APB_ADDR_WIDTH-1:0]    paddr_i,
    input  wire  [31:0]                  pwdata_i,
    input  wire  [3:0]                   pstrb_i,
    output logic [31:0]                  prdata_o,
    output logic                         pready_o,
    output logic                         pslverr_o,

    // ------------------------------------------------------------ TL-UL side
    output tlul_pkg::tl_h2d_t            tl_o,
    input  tlul_pkg::tl_d2h_t            tl_i
);

  //---------------------------------------------------------------------------
  // Elaboration guards
  //---------------------------------------------------------------------------
  // The bridge is 32-bit because the device is.  There is no repacking layer,
  // so a mismatch would truncate silently rather than fail.
  if (TL_DW != 32) begin : gen_chk_tl_dw
    $error("rsa_ecc_apb4_to_tlul: the vendored core's TL_DW is %0d, not 32", TL_DW);
  end
  if (TL_DBW != 4) begin : gen_chk_tl_dbw
    $error("rsa_ecc_apb4_to_tlul: the vendored core's TL_DBW is %0d, not 4", TL_DBW);
  end
  if (APB_ADDR_WIDTH < 2) begin : gen_chk_aw
    $error("rsa_ecc_apb4_to_tlul: APB_ADDR_WIDTH must be >= 2 (got %0d)",
           APB_ADDR_WIDTH);
  end

  //---------------------------------------------------------------------------
  // A full-width beat is log2(bytes) = 2.  A partial write keeps this size and
  // narrows the MASK; getting that backwards produces a bus error on every
  // sub-word store, which reads as a device fault rather than a bridge bug.
  //---------------------------------------------------------------------------
  localparam logic [TL_SZW-1:0] BEAT_SIZE = TL_SZW'(2);

  typedef enum logic [1:0] {
    ST_IDLE = 2'b00,   // waiting for an ACCESS phase
    ST_REQ  = 2'b01,   // a_valid held until a_ready
    ST_RSP  = 2'b10,   // d_ready held until d_valid
    ST_DONE = 2'b11    // pready held for exactly the one cycle APB samples it
  } state_e;

  state_e state_q, state_d;

  logic                        a_valid_q, a_valid_d;
  tlul_pkg::tl_a_op_e          a_opcode_q, a_opcode_d;
  logic [TL_AW-1:0]            a_address_q, a_address_d;
  logic [TL_DBW-1:0]           a_mask_q, a_mask_d;
  logic [TL_DW-1:0]            a_data_q, a_data_d;
  logic                        d_ready_q, d_ready_d;
  logic [31:0]                 prdata_q, prdata_d;
  logic                        pready_q, pready_d;
  logic                        pslverr_q, pslverr_d;

  // An APB write with every strobe set is a PutFullData; anything else is a
  // PutPartialData.  A device may legally treat the two differently, and the
  // register adapters in the core do.
  wire all_lanes = &pstrb_i;

  // The ACCESS phase.  `!pready_q` keeps a completed transfer from being
  // re-issued in the cycle where PREADY is still high.
  wire access_phase = psel_i && penable_i && !pready_q;

  always_comb begin
    state_d     = state_q;
    a_valid_d   = a_valid_q;
    a_opcode_d  = a_opcode_q;
    a_address_d = a_address_q;
    a_mask_d    = a_mask_q;
    a_data_d    = a_data_q;
    d_ready_d   = d_ready_q;
    prdata_d    = prdata_q;
    pready_d    = pready_q;
    pslverr_d   = pslverr_q;

    unique case (state_q)
      ST_IDLE: begin
        pready_d  = 1'b0;
        pslverr_d = 1'b0;
        d_ready_d = 1'b0;
        if (access_phase) begin
          a_valid_d   = 1'b1;
          a_opcode_d  = !pwrite_i ? tlul_pkg::Get
                      : all_lanes ? tlul_pkg::PutFullData
                                  : tlul_pkg::PutPartialData;
          // Bits above TL_AW have already been decoded by the parent; bits
          // [1:0] are byte-within-word and are carried by the mask, so they
          // are forced to zero rather than passed on.  A device that sees a
          // non-zero low address on a full-width beat reports a bus error.
          a_address_d = TL_AW'({paddr_i[APB_ADDR_WIDTH-1:WORD_ADDR_LSB],
                                {WORD_ADDR_LSB{1'b0}}});
          // A Get carries ZERO, never PWDATA. APB leaves PWDATA undefined on
          // a read, and a real bridge holds the LAST WRITE there -- whatever
          // was written to any slave on the segment. The core folds a
          // full-word IMEM/DMEM read into LOAD_CHECKSUM over this field
          // (otbn.sv:763, design spec 5.3, "with zero in the data field"),
          // so forwarding PWDATA made the checksum after a read depend on
          // unrelated traffic: the same driver read 0x3109527B on one SoC
          // and 0x4BF13706 on another. The bench never saw it because its
          // APB driver parks PWDATA at 0 on reads (found by the socgen demo
          // SoCs, IP_ENHANCEMENTS E33).
          a_data_d    = pwrite_i ? pwdata_i : '0;
          a_mask_d    = pwrite_i ? pstrb_i : {TL_DBW{1'b1}};
          state_d     = ST_REQ;
        end
      end

      ST_REQ: begin
        if (tl_i.a_ready) begin
          a_valid_d = 1'b0;
          d_ready_d = 1'b1;
          state_d   = ST_RSP;
        end
      end

      ST_RSP: begin
        if (tl_i.d_valid) begin
          d_ready_d = 1'b0;
          prdata_d  = tl_i.d_data;
          // TL-UL reports a device error on one bit.  APB has exactly one bit
          // to report it on, so the mapping is total and lossless here.
          pslverr_d = tl_i.d_error;
          pready_d  = 1'b1;
          state_d   = ST_DONE;
        end
      end

      ST_DONE: begin
        pready_d  = 1'b0;
        pslverr_d = 1'b0;
        state_d   = ST_IDLE;
      end

      // Unreachable: state_e is fully enumerated over two bits.  Kept because
      // an FSM must recover from a corrupted state rather than stay in one.
      default: begin
        state_d   = ST_IDLE;
        a_valid_d = 1'b0;
        d_ready_d = 1'b0;
        pready_d  = 1'b0;
      end
    endcase
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q     <= ST_IDLE;
      a_valid_q   <= 1'b0;
      a_opcode_q  <= tlul_pkg::Get;
      a_address_q <= '0;
      a_mask_q    <= '0;
      a_data_q    <= '0;
      d_ready_q   <= 1'b0;
      prdata_q    <= '0;
      pready_q    <= 1'b0;
      pslverr_q   <= 1'b0;
    end else begin
      state_q     <= state_d;
      a_valid_q   <= a_valid_d;
      a_opcode_q  <= a_opcode_d;
      a_address_q <= a_address_d;
      a_mask_q    <= a_mask_d;
      a_data_q    <= a_data_d;
      d_ready_q   <= d_ready_d;
      prdata_q    <= prdata_d;
      pready_q    <= pready_d;
      pslverr_q   <= pslverr_d;
    end
  end

  assign prdata_o  = prdata_q;
  assign pready_o  = pready_q;
  assign pslverr_o = pslverr_q;

  //---------------------------------------------------------------------------
  // Command assembly and integrity generation
  //---------------------------------------------------------------------------
  // Deliberately unread inputs, absorbed explicitly rather than waived:
  //   paddr_i[1:0]  byte-within-word, carried by the strobe (see ST_IDLE)
  //   tl_i          the response fields APB has nowhere to put - d_param,
  //                 d_size, d_source, d_sink and the integrity user field.
  //                 Note in particular that d_user.rsp_intg is NOT checked
  //                 here; see doc/rsa_ecc_design_spec.md, "Known limitations".
  logic unused_inputs;
  assign unused_inputs = ^{paddr_i[WORD_ADDR_LSB-1:0], tl_i.d_param, tl_i.d_size,
                           tl_i.d_source, tl_i.d_sink, tl_i.d_user, tl_i.d_opcode};

  tlul_pkg::tl_h2d_t tl_raw;

  always_comb begin
    tl_raw           = tlul_pkg::TL_H2D_DEFAULT;
    tl_raw.a_valid   = a_valid_q;
    tl_raw.a_opcode  = a_opcode_q;
    tl_raw.a_param   = 3'b000;
    tl_raw.a_size    = BEAT_SIZE;
    tl_raw.a_source  = '0;               // one outstanding: one source id
    tl_raw.a_address = a_address_q;
    tl_raw.a_mask    = a_mask_q;
    tl_raw.a_data    = a_data_q;
    tl_raw.d_ready   = d_ready_q;
  end

  // See the INTEGRITY note in the file header.  Without this the device
  // answers d_error on every well-formed access.
  tlul_cmd_intg_gen #(
    .EnableDataIntgGen (1'b1)
  ) u_cmd_intg_gen (
    .tl_i (tl_raw),
    .tl_o (tl_o)
  );

endmodule : rsa_ecc_apb4_to_tlul

`default_nettype wire
