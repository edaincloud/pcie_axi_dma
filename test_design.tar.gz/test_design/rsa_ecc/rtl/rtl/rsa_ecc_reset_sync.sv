//=============================================================================
// File        : rsa_ecc_reset_sync.sv
// Description : Reset synchroniser.  Asserts asynchronously, de-asserts
//               synchronously to the destination clock.
//
//               The house default is async assert / sync de-assert.  This cell
//               is what makes the de-assertion legal: it removes the reset
//               recovery/removal timing hazard and keeps the design RDC clean.
//
//               The vendored OTBN core is itself built for an active-low,
//               asynchronously asserted reset, so this cell feeds it directly
//               and there is exactly one reset tree in the IP.
//
// Notes       : - No combinational logic in the reset path other than the
//                 optional polarity inversion done by the parent.
//               - The flops reset to 0 and shift in a constant 1, so the
//                 output can only leave reset after STAGES rising clock edges
//                 with the input reset released.
//               - DFT: ordinary flops, scan replaceable.  Reset control during
//                 scan is an SoC-level concern, handled by driving `rst_in_n`
//                 from the test reset.
//=============================================================================

`default_nettype none

module rsa_ecc_reset_sync #(
    // Number of synchroniser stages.  Two is the industry minimum; more is
    // used for very high frequency or high-MTBF requirements.
    parameter int unsigned STAGES = 2
) (
    input  wire  clk,       // Destination clock
    input  wire  rst_in_n,  // Asynchronous active-low reset input
    output wire  rst_out_n  // Synchronously de-asserted active-low reset
);

  if (STAGES < 2) begin : gen_chk_stages
    $error("rsa_ecc_reset_sync: STAGES must be >= 2 (got %0d)", STAGES);
  end

  // A reset synchroniser is by construction a chain whose flops are reset
  // asynchronously and clocked synchronously; the SYNCASYNCNET check fires on
  // every correct implementation of this cell and is waived here only.
  /* verilator lint_off SYNCASYNCNET */
  logic [STAGES-1:0] sync_q;
  /* verilator lint_on SYNCASYNCNET */

  always_ff @(posedge clk or negedge rst_in_n) begin
    if (!rst_in_n) begin
      sync_q <= '0;
    end else begin
      sync_q <= {sync_q[STAGES-2:0], 1'b1};
    end
  end

  assign rst_out_n = sync_q[STAGES-1];

endmodule : rsa_ecc_reset_sync

`default_nettype wire
