//=============================================================================
// File        : rsa_ecc_top.sv
// Description : Top level of the APB4-programmed RSA/ECC public-key
//               accelerator.
//
//               WHAT THIS IP IS
//               ---------------
//               A programmable big-number coprocessor with an APB4
//               configuration interface.  RSA-2048/3072/4096 and ECDSA
//               P-256/P-384 are SOFTWARE that runs on it, not fixed-function
//               blocks inside it.  There is no "start RSA" bit anywhere in the
//               register map, and there is no key length parameter, because
//               the algorithm is a program in IMEM and its operands are words
//               in DMEM.  Anyone looking for a one-register RSA engine is
//               looking at the wrong IP.
//
//               The compute core is OpenTitan's OTBN, vendored UNMODIFIED
//               under rtl/core/ - see rtl/core/PROVENANCE.txt.  Everything
//               else in rtl/ is original work wrapped around it.
//
//               STRUCTURE
//               ---------
//
//   PCLK/PRESETn                              +-------------------------+
//        |                                    | rsa_ecc_edn_responder   |
//        v                                    |   (x2: RND, URND)       |
//   +----------------+                        | rsa_ecc_otp_key_responder|
//   | rsa_ecc_reset_ |  rst_n                 +-----------+-------------+
//   |   sync         |------+                             | (internal mode
//   +----------------+      |                             |  only)
//                           v                             v
//   APB4 --+-> [decode] -+->| rsa_ecc_apb4_to_tlul |--> TL-UL --> +--------+
//          |             |  |   + tlul_cmd_intg_gen|              |  otbn  |
//          |             |  +----------------------+ <-- TL-UL <--| (vendored)
//          |             |                                        +---+----+
//          |             +->| rsa_ecc_id_regs |                       |
//          |                +-----------------+                  intr_done
//          |                                                     idle / alerts
//          +-> unmapped -> PSLVERR
//
//               ADDRESS MAP
//               -----------
//                 0x0000 .. 0x002F  core registers  (CMD/CTRL/STATUS/...)
//                 0x0030 .. 0x3FFF  core, undecoded -> PSLVERR from the core
//                 0x4000 .. 0x7FFF  IMEM window     (16 KiB)
//                 0x8000 .. 0xBFFF  DMEM window     (16 KiB visible)
//                 0xC000 .. 0xC00F  wrapper ID region
//                 0xC010 ..         unmapped        -> PSLVERR from the wrapper
//
//               Offsets are not written here: they come from rsa_ecc_pkg,
//               which re-exports the core's own otbn_reg_pkg.  A window that
//               moves upstream moves here too, and the elaboration guard on
//               the ID region catches an overlap rather than aliasing.
//
//               CLOCKING
//               --------
//               ONE CLOCK.  `PCLK` drives the wrapper, the core, and the
//               core's EDN and OTP-key ports.  The core is built for three
//               clocks and its request/acknowledge synchronisers are still
//               present and still correct in this configuration; they are
//               simply degenerate.  There is NO clock domain crossing in this
//               IP, and there are no generated or gated clocks.
//
//               If your SoC's EDN or OTP controller runs on a different clock,
//               this wrapper is not what you want to instantiate: use the
//               vendored `otbn` directly, which brings clk_edn_i and clk_otp_i
//               out, or put an asynchronous interface in front of these ports.
//               That limitation is stated here, in the design spec and in the
//               CAP register rather than being left for someone to discover.
//
//               SECURITY - READ THIS BEFORE BUILDING SILICON
//               --------------------------------------------
//               Two of the core's inputs are security-critical and this
//               wrapper can supply them itself, for simulation and bring-up:
//
//                 ENTROPY_EXTERNAL = 0 puts an LFSR behind the EDN ports.
//                   The core uses that entropy to BLIND and MASK its
//                   arithmetic.  A predictable mask is no mask, so an
//                   RSA or ECDSA private-key operation performed in this
//                   configuration must be assumed to leak the key.
//
//                 OTP_KEY_EXTERNAL = 0 puts a compile-time constant behind
//                   the memory scrambling key port, and reports
//                   `seed_valid = 0` so that the core knows.  Memory
//                   scrambling with a netlist constant is obfuscation, not
//                   confidentiality.
//
//               Both defaults are the INTERNAL ones, because an IP that does
//               not run out of the box is not testable and the failure mode is
//               silent (the core never leaves its initial secure wipe).  A
//               production build sets both to 1 and connects a real EDN and a
//               real otp_ctrl.  Software can read which build it is on from
//               the CAP register - it is not required to take anyone's word
//               for it.
//
// Parameters   : see below.  Every constraint is enforced by an elaboration
//                guard with a unique message; run/scripts/elab_check.sh proves
//                each guard fires for its own illegal value and does not fire
//                for the legal ones.
//=============================================================================

`default_nettype none

module rsa_ecc_top
  import rsa_ecc_pkg::*;
#(
    // APB address bus width.  Must span the top of the address map above.
    parameter int unsigned APB_ADDR_WIDTH    = 20,
    // APB data bus width.  The compute core is a 32-bit TL-UL device and this
    // wrapper contains no repacking layer, so 32 is the only legal value.  The
    // parameter exists so that a mismatch is an elaboration error naming the
    // reason, rather than a silent truncation on the data path.
    parameter int unsigned APB_DATA_WIDTH    = 32,
    // 1'b0 : `PRESETn` is active low (default, APB standard)
    // 1'b1 : `PRESETn` is active high
    parameter bit          RESET_POLARITY    = 1'b0,
    // Reset synchroniser depth (asynchronous assert, synchronous de-assert).
    parameter int unsigned RESET_SYNC_STAGES = 2,
    // 1'b0 : an on-chip LFSR answers the core's EDN ports.  NOT AN ENTROPY
    //        SOURCE - see the security note above.
    // 1'b1 : the EDN ports are brought out to the boundary.
    parameter bit          ENTROPY_EXTERNAL  = 1'b0,
    // 1'b0 : an on-chip constant answers the memory-scrambling key port.
    // 1'b1 : the key port is brought out to the boundary.
    parameter bit          OTP_KEY_EXTERNAL  = 1'b0,
    // 1'b1 : the keymgr sideload key port is brought out to the boundary, so
    //        software can use the KEY_S0/KEY_S1 WSRs.
    // 1'b0 : the port is tied off invalid; reading those WSRs raises
    //        ERR_BITS.KEY_INVALID, which is the defined behaviour for an
    //        absent key, not a fault of this wrapper.
    parameter bit          SIDELOAD_KEY_EN   = 1'b1,
    // 1'b1 : the core's masking accelerator is stubbed out.  A large area and
    //        build-time saving for targets that do not run masked software.
    parameter bit          FEAT_STUB_MAI     = 1'b0,
    // Reported through the VERSION register.
    parameter int unsigned VERSION_MAJOR     = 1,
    parameter int unsigned VERSION_MINOR     = 0,
    parameter int unsigned VERSION_BUILD     = 0,
    // Seeds for the internal entropy responders.  The two must differ, or the
    // RND and URND streams are identical.
    parameter logic [63:0] ENTROPY_SEED_RND  = 64'hA5C3_9F17_2D6B_E481,
    parameter logic [63:0] ENTROPY_SEED_URND = 64'h5C3A_179F_6B2D_81E4
) (
    input  wire                          PCLK,
    // SYNCASYNCNET: see the note on `rst_async_n` below.  The only synchronous
    // sampling of this net is the assertion that proves its ASYNCHRONOUS
    // assertion reaches the output; the design uses it asynchronously only.
    /* verilator lint_off SYNCASYNCNET */
    input  wire                          PRESETn,
    /* verilator lint_on SYNCASYNCNET */

    // ------------------------------------------------------------------ APB4
    input  wire                          PSEL,
    input  wire                          PENABLE,
    input  wire                          PWRITE,
    input  wire  [APB_ADDR_WIDTH-1:0]    PADDR,
    input  wire  [APB_DATA_WIDTH-1:0]    PWDATA,
    input  wire  [APB_DATA_WIDTH/8-1:0]  PSTRB,

    output logic [APB_DATA_WIDTH-1:0]    PRDATA,
    output logic                         PREADY,
    output logic                         PSLVERR,

    // ------------------------------------------------------------- interrupt
    // Level-sensitive.  Raised when the core finishes an operation and
    // INTR_ENABLE.done is set; cleared by writing 1 to INTR_STATE.done.
    output logic                         irq,

    // Asserted while the core is idle and can accept a new command or a bus
    // access to IMEM/DMEM.  Intended for SoC clock gating.
    output logic                         idle_o,

    // ----------------------------------------------------------- alert pairs
    // OpenTitan differential alert signalling, index 0 = fatal,
    // 1 = recoverable.  An integrator with an alert handler connects these to
    // `prim_alert_receiver`.  An integrator without one ties
    // {ping_p, ack_p} = 0 and {ping_n, ack_n} = 1 (the idle differential
    // state) and watches `alert_p_o`.
    input  wire  [1:0]                   alert_ping_p_i,
    input  wire  [1:0]                   alert_ping_n_i,
    input  wire  [1:0]                   alert_ack_p_i,
    input  wire  [1:0]                   alert_ack_n_i,
    output logic [1:0]                   alert_p_o,
    output logic [1:0]                   alert_n_o,

    // ------------------------------------------------------------- lifecycle
    // Security escalation.  While asserted the core wipes and locks itself.
    input  wire                          escalate_en_i,
    // RMA (return material authorisation) wipe request / acknowledge.
    input  wire                          rma_req_i,
    output logic                         rma_ack_o,

    // -------------------------------------------------- keymgr sideload key
    // Used only when SIDELOAD_KEY_EN = 1.  Two shares, concatenated
    // {share1, share0}.
    input  wire                                            sideload_key_valid_i,
    input  wire [SIDELOAD_SHARES*SIDELOAD_KEY_WIDTH-1:0]   sideload_key_i,

    // ------------------------------------------------------------ external EDN
    // Used only when ENTROPY_EXTERNAL = 1.  Synchronous to PCLK - see the
    // CLOCKING note above.  Four-phase: `req` is held until a one-cycle `ack`.
    output logic                         edn_rnd_req_o,
    input  wire                          edn_rnd_ack_i,
    input  wire                          edn_rnd_fips_i,
    input  wire  [EDN_BUS_WIDTH-1:0]     edn_rnd_bus_i,
    output logic                         edn_urnd_req_o,
    input  wire                          edn_urnd_ack_i,
    input  wire                          edn_urnd_fips_i,
    input  wire  [EDN_BUS_WIDTH-1:0]     edn_urnd_bus_i,

    // -------------------------------------------------- external OTP key port
    // Used only when OTP_KEY_EXTERNAL = 1.  Synchronous to PCLK.
    output logic                         otp_key_req_o,
    input  wire                          otp_key_ack_i,
    input  wire  [OTP_KEY_WIDTH-1:0]     otp_key_i,
    input  wire  [OTP_NONCE_WIDTH-1:0]   otp_key_nonce_i,
    input  wire                          otp_key_seed_valid_i
);

  //---------------------------------------------------------------------------
  // Elaboration guards
  //
  // Every span comparison below is evaluated in 64 bits.  A width-derived
  // expression evaluated in a type whose size IS the parameter under test
  // yields zero at the top of the range instead of overflowing, and the guard
  // then rejects a configuration it was written to permit.
  //---------------------------------------------------------------------------
  if (APB_DATA_WIDTH != 32) begin : gen_chk_apb_dw
    $error("rsa_ecc_top: APB_DATA_WIDTH must be 32 (got %0d): the compute core is a 32-bit TL-UL device and this wrapper has no repacking layer",
           APB_DATA_WIDTH);
  end
  if ((64'(1) << APB_ADDR_WIDTH) < REGION_TOP) begin : gen_chk_apb_aw_min
    $error("rsa_ecc_top: APB_ADDR_WIDTH must be >= 16 to span the 0x%0h byte address map (got %0d)",
           REGION_TOP, APB_ADDR_WIDTH);
  end
  if (APB_ADDR_WIDTH > 32) begin : gen_chk_apb_aw_max
    $error("rsa_ecc_top: APB_ADDR_WIDTH must be <= 32 (got %0d)", APB_ADDR_WIDTH);
  end
  if (RESET_SYNC_STAGES < 2) begin : gen_chk_rst_stages_min
    $error("rsa_ecc_top: RESET_SYNC_STAGES must be >= 2 (got %0d)", RESET_SYNC_STAGES);
  end
  if (RESET_SYNC_STAGES > 8) begin : gen_chk_rst_stages_max
    $error("rsa_ecc_top: RESET_SYNC_STAGES must be <= 8 (got %0d)", RESET_SYNC_STAGES);
  end
  if (ENTROPY_SEED_RND == 64'd0) begin : gen_chk_seed_rnd
    $error("rsa_ecc_top: ENTROPY_SEED_RND must be non-zero (the all-zero LFSR state is absorbing)");
  end
  if (ENTROPY_SEED_URND == 64'd0) begin : gen_chk_seed_urnd
    $error("rsa_ecc_top: ENTROPY_SEED_URND must be non-zero (the all-zero LFSR state is absorbing)");
  end
  if (ENTROPY_SEED_RND == ENTROPY_SEED_URND) begin : gen_chk_seed_distinct
    $error("rsa_ecc_top: ENTROPY_SEED_RND and ENTROPY_SEED_URND must differ, or RND and URND produce the same stream");
  end
  // The wrapper's ID region sits immediately above the core's DMEM window.  If
  // a future re-vendor grows that window, this fires rather than letting the
  // two regions alias.
  if (ID_BASE < (DMEM_BASE + DMEM_SIZE)) begin : gen_chk_id_overlap
    $error("rsa_ecc_top: the wrapper ID region at 0x%0h overlaps the core DMEM window ending at 0x%0h",
           ID_BASE, DMEM_BASE + DMEM_SIZE);
  end
  if (VERSION_MAJOR > 255) begin : gen_chk_ver_major
    $error("rsa_ecc_top: VERSION_MAJOR must be <= 255 (got %0d)", VERSION_MAJOR);
  end
  if (VERSION_MINOR > 255) begin : gen_chk_ver_minor
    $error("rsa_ecc_top: VERSION_MINOR must be <= 255 (got %0d)", VERSION_MINOR);
  end
  if (VERSION_BUILD > 65535) begin : gen_chk_ver_build
    $error("rsa_ecc_top: VERSION_BUILD must be <= 65535 (got %0d)", VERSION_BUILD);
  end

  //---------------------------------------------------------------------------
  // Reset
  //---------------------------------------------------------------------------
  // The polarity select is a constant in any one elaboration, so one arm is
  // structurally dead per build.  Both are exercised across the regression
  // matrix (the `rst_high` build selects the other one), and the dead arm is
  // recorded in run/scripts/code_coverage_exclude.txt with that justification.
  //
  // SYNCASYNCNET fires on this net and on PRESETn behind it.  The "synchronous
  // usage" it has found is the ASSERTION in rtl/sva/rsa_ecc_reset_sync_sva.sv,
  // which samples the raw reset on a clock edge to check that the asynchronous
  // assertion really does reach the output.  That check cannot be written any
  // other way, and it is verification code that never reaches the netlist -
  // the design itself uses this net asynchronously and only asynchronously.
  //
  // The waiver is therefore two lines wide and names one rule.  The
  // independent structural lint sees the same net declared with `set_reset`
  // (run/scripts/assayer_lint.tcl) and still reports its flop reset coverage,
  // which is how we know a check was described rather than switched off.
  /* verilator lint_off SYNCASYNCNET */
  wire rst_async_n = RESET_POLARITY ? ~PRESETn : PRESETn;
  /* verilator lint_on SYNCASYNCNET */

  wire rst_n;

  rsa_ecc_reset_sync #(
    .STAGES (RESET_SYNC_STAGES)
  ) u_reset_sync (
    .clk       (PCLK),
    .rst_in_n  (rst_async_n),
    .rst_out_n (rst_n)
  );

  //---------------------------------------------------------------------------
  // Address decode
  //---------------------------------------------------------------------------
  // Zero-extended to 32 bits so that the comparisons below are against the map
  // constants rather than against a truncated copy of them.
  wire [31:0] addr32 = 32'(PADDR);

  wire hit_core = PSEL && (addr32 <  ID_BASE);
  wire hit_id   = PSEL && (addr32 >= ID_BASE) && (addr32 < (ID_BASE + ID_SIZE));
  wire hit_none = PSEL && (addr32 >= (ID_BASE + ID_SIZE));

  //---------------------------------------------------------------------------
  // APB4 -> TL-UL bridge and the core
  //---------------------------------------------------------------------------
  tlul_pkg::tl_h2d_t tl_h2d;
  tlul_pkg::tl_d2h_t tl_d2h;

  logic [31:0] core_prdata;
  logic        core_pready;
  logic        core_pslverr;

  rsa_ecc_apb4_to_tlul #(
    .APB_ADDR_WIDTH (APB_ADDR_WIDTH)
  ) u_apb4_to_tlul (
    .clk_i     (PCLK),
    .rst_ni    (rst_n),
    .psel_i    (hit_core),
    .penable_i (PENABLE),
    .pwrite_i  (PWRITE),
    .paddr_i   (PADDR),
    .pwdata_i  (PWDATA[31:0]),
    .pstrb_i   (PSTRB[3:0]),
    .prdata_o  (core_prdata),
    .pready_o  (core_pready),
    .pslverr_o (core_pslverr),
    .tl_o      (tl_h2d),
    .tl_i      (tl_d2h)
  );

  //---------------------------------------------------------------------------
  // Wrapper ID region
  //---------------------------------------------------------------------------
  localparam logic [31:0] CAP_VALUE =
      (32'(SIDELOAD_KEY_EN)   << CAP_SIDELOAD_KEY_BIT) |
      (32'(ENTROPY_EXTERNAL)  << CAP_EXT_ENTROPY_BIT)  |
      (32'(!FEAT_STUB_MAI)    << CAP_MAI_BIT)          |
      (32'(RESET_POLARITY)    << CAP_RST_POL_BIT);

  logic [31:0] id_prdata;
  logic        id_pready;
  logic        id_pslverr;

  rsa_ecc_id_regs #(
    .APB_ADDR_WIDTH (APB_ADDR_WIDTH),
    .VERSION_MAJOR  (VERSION_MAJOR),
    .VERSION_MINOR  (VERSION_MINOR),
    .VERSION_BUILD  (VERSION_BUILD),
    .CAP_VALUE      (CAP_VALUE)
  ) u_id_regs (
    .clk_i     (PCLK),
    .rst_ni    (rst_n),
    .sel_i     (hit_id),
    .penable_i (PENABLE),
    .pwrite_i  (PWRITE),
    .paddr_i   (PADDR),
    .prdata_o  (id_prdata),
    .pready_o  (id_pready),
    .pslverr_o (id_pslverr)
  );

  //---------------------------------------------------------------------------
  // Unmapped region
  //---------------------------------------------------------------------------
  // Terminated by the wrapper rather than passed to the core, so that the
  // response to an out-of-map access is a property of this design and not of
  // whatever the vendored core happens to do with an address it was never
  // shown.  One wait state, so the timing is the same shape as the ID region.
  logic none_pready_q;

  always_ff @(posedge PCLK or negedge rst_n) begin
    if (!rst_n) begin
      none_pready_q <= 1'b0;
    end else begin
      none_pready_q <= hit_none && PENABLE && !none_pready_q;
    end
  end

  //---------------------------------------------------------------------------
  // APB response mux
  //---------------------------------------------------------------------------
  // Exactly one of the three regions can be selected at a time, so this is a
  // priority-free OR of mutually exclusive terms.  The SVA in rtl/sva asserts
  // the mutual exclusion rather than leaving it as a comment.
  always_comb begin
    PRDATA  = '0;
    PREADY  = 1'b0;
    PSLVERR = 1'b0;
    if (hit_id) begin
      PRDATA  = APB_DATA_WIDTH'(id_prdata);
      PREADY  = id_pready;
      PSLVERR = id_pslverr;
    end else if (hit_core) begin
      PRDATA  = APB_DATA_WIDTH'(core_prdata);
      PREADY  = core_pready;
      PSLVERR = core_pslverr;
    end else if (hit_none) begin
      PRDATA  = '0;
      PREADY  = none_pready_q;
      PSLVERR = none_pready_q;
    end
  end

  //---------------------------------------------------------------------------
  // Entropy: internal responder or boundary ports
  //---------------------------------------------------------------------------
  edn_pkg::edn_req_t edn_rnd_req, edn_urnd_req;
  edn_pkg::edn_rsp_t edn_rnd_rsp, edn_urnd_rsp;

  if (ENTROPY_EXTERNAL) begin : gen_edn_external
    assign edn_rnd_req_o  = edn_rnd_req.edn_req;
    assign edn_urnd_req_o = edn_urnd_req.edn_req;

    assign edn_rnd_rsp  = '{edn_ack:  edn_rnd_ack_i,
                            edn_fips: edn_rnd_fips_i,
                            edn_bus:  edn_rnd_bus_i};
    assign edn_urnd_rsp = '{edn_ack:  edn_urnd_ack_i,
                            edn_fips: edn_urnd_fips_i,
                            edn_bus:  edn_urnd_bus_i};
  end else begin : gen_edn_internal
    // NOT AN ENTROPY SOURCE.  See the security note in the file header and the
    // full statement in rsa_ecc_edn_responder.sv.
    logic rnd_ack, rnd_fips;
    logic [EDN_BUS_WIDTH-1:0] rnd_bus;
    logic urnd_ack, urnd_fips;
    logic [EDN_BUS_WIDTH-1:0] urnd_bus;

    rsa_ecc_edn_responder #(
      .SEED (ENTROPY_SEED_RND)
    ) u_edn_rnd (
      .clk_i      (PCLK),
      .rst_ni     (rst_n),
      .edn_req_i  (edn_rnd_req.edn_req),
      .edn_ack_o  (rnd_ack),
      .edn_fips_o (rnd_fips),
      .edn_bus_o  (rnd_bus)
    );

    rsa_ecc_edn_responder #(
      .SEED (ENTROPY_SEED_URND)
    ) u_edn_urnd (
      .clk_i      (PCLK),
      .rst_ni     (rst_n),
      .edn_req_i  (edn_urnd_req.edn_req),
      .edn_ack_o  (urnd_ack),
      .edn_fips_o (urnd_fips),
      .edn_bus_o  (urnd_bus)
    );

    assign edn_rnd_rsp  = '{edn_ack: rnd_ack,  edn_fips: rnd_fips,  edn_bus: rnd_bus};
    assign edn_urnd_rsp = '{edn_ack: urnd_ack, edn_fips: urnd_fips, edn_bus: urnd_bus};

    assign edn_rnd_req_o  = 1'b0;
    assign edn_urnd_req_o = 1'b0;

    // The boundary inputs are not part of this build.  Absorbed explicitly so
    // that an unconnected port is a lint result rather than a surprise, and
    // named so it is obvious nothing computed is being hidden here.
    logic unused_edn_in;
    assign unused_edn_in = ^{edn_rnd_ack_i, edn_rnd_fips_i, edn_rnd_bus_i,
                             edn_urnd_ack_i, edn_urnd_fips_i, edn_urnd_bus_i};
  end

  //---------------------------------------------------------------------------
  // Memory scrambling key: internal responder or boundary ports
  //---------------------------------------------------------------------------
  otp_ctrl_pkg::otbn_otp_key_req_t otp_key_req;
  otp_ctrl_pkg::otbn_otp_key_rsp_t otp_key_rsp;

  if (OTP_KEY_EXTERNAL) begin : gen_otp_external
    assign otp_key_req_o = otp_key_req.req;
    assign otp_key_rsp   = '{ack:        otp_key_ack_i,
                             key:        otp_key_i,
                             nonce:      otp_key_nonce_i,
                             seed_valid: otp_key_seed_valid_i};
  end else begin : gen_otp_internal
    // NOT A KEY MANAGER.  See rsa_ecc_otp_key_responder.sv.
    logic                          k_ack;
    logic [OTP_KEY_WIDTH-1:0]      k_key;
    logic [OTP_NONCE_WIDTH-1:0]    k_nonce;
    logic                          k_seed_valid;

    rsa_ecc_otp_key_responder u_otp_key (
      .clk_i        (PCLK),
      .rst_ni       (rst_n),
      .key_req_i    (otp_key_req.req),
      .key_ack_o    (k_ack),
      .key_o        (k_key),
      .nonce_o      (k_nonce),
      .seed_valid_o (k_seed_valid)
    );

    assign otp_key_rsp   = '{ack:        k_ack,
                             key:        k_key,
                             nonce:      k_nonce,
                             seed_valid: k_seed_valid};
    assign otp_key_req_o = 1'b0;

    logic unused_otp_in;
    assign unused_otp_in = ^{otp_key_ack_i, otp_key_i, otp_key_nonce_i,
                             otp_key_seed_valid_i};
  end

  //---------------------------------------------------------------------------
  // Sideload key
  //---------------------------------------------------------------------------
  keymgr_pkg::otbn_key_req_t sideload_key;

  if (SIDELOAD_KEY_EN) begin : gen_sideload_present
    always_comb begin
      sideload_key.valid = sideload_key_valid_i;
      for (int unsigned s = 0; s < SIDELOAD_SHARES; s++) begin
        sideload_key.key[s] =
            sideload_key_i[s*SIDELOAD_KEY_WIDTH +: SIDELOAD_KEY_WIDTH];
      end
    end
  end else begin : gen_sideload_absent
    // Tied off INVALID.  The core answers a read of the KEY_S0/KEY_S1 WSRs
    // with ERR_BITS.KEY_INVALID, which is the defined behaviour for an absent
    // sideload key.  It is not a fault introduced here, and software can tell
    // the two apart from the CAP register.
    assign sideload_key = keymgr_pkg::OTBN_KEY_REQ_DEFAULT;

    logic unused_sideload_in;
    assign unused_sideload_in = ^{sideload_key_valid_i, sideload_key_i};
  end

  //---------------------------------------------------------------------------
  // The vendored compute core
  //---------------------------------------------------------------------------
  prim_ram_1p_pkg::ram_1p_cfg_rsp_t ram_cfg_rsp_imem, ram_cfg_rsp_dmem;
  prim_mubi_pkg::mubi4_t      core_idle;
  lc_ctrl_pkg::lc_tx_t        lc_rma_ack;
  prim_alert_pkg::alert_rx_t [otbn_reg_pkg::NumAlerts-1:0] alert_rx;
  prim_alert_pkg::alert_tx_t [otbn_reg_pkg::NumAlerts-1:0] alert_tx;

  always_comb begin
    for (int unsigned a = 0; a < otbn_reg_pkg::NumAlerts; a++) begin
      alert_rx[a] = '{ping_p: alert_ping_p_i[a],
                      ping_n: alert_ping_n_i[a],
                      ack_p:  alert_ack_p_i[a],
                      ack_n:  alert_ack_n_i[a]};
    end
  end

  otbn #(
    .Stub        (1'b0),
    .RegFile     (otbn_pkg::RegFileFF),
    .FeatStubMai (FEAT_STUB_MAI)
  ) u_otbn (
    .clk_i  (PCLK),
    .rst_ni (rst_n),

    .tl_i (tl_h2d),
    .tl_o (tl_d2h),

    .idle_o (core_idle),

    .intr_done_o (irq),

    .alert_rx_i (alert_rx),
    .alert_tx_o (alert_tx),

    // A single wrapper input drives the multi-bit lifecycle encoding.  The
    // conversion is here rather than at the boundary so that the IP's port
    // list stays a plain APB4 peripheral's.
    .lc_escalate_en_i (escalate_en_i ? lc_ctrl_pkg::On : lc_ctrl_pkg::Off),
    .lc_rma_req_i     (rma_req_i     ? lc_ctrl_pkg::On : lc_ctrl_pkg::Off),
    .lc_rma_ack_o     (lc_rma_ack),

    // Memory configuration (margin, retention) is an SoC-level, technology
    // specific input.  Tied to the library default, which is the "no
    // adjustment" setting; an SoC that needs to drive it should instantiate
    // the vendored core directly.
    .ram_cfg_imem_i     (prim_ram_1p_pkg::RAM_1P_CFG_DEFAULT),
    .ram_cfg_dmem_i     (prim_ram_1p_pkg::RAM_1P_CFG_DEFAULT),
    .ram_cfg_rsp_imem_o (ram_cfg_rsp_imem),
    .ram_cfg_rsp_dmem_o (ram_cfg_rsp_dmem),

    // One clock: see the CLOCKING note in the file header.
    .clk_edn_i  (PCLK),
    .rst_edn_ni (rst_n),
    .edn_rnd_o  (edn_rnd_req),
    .edn_rnd_i  (edn_rnd_rsp),
    .edn_urnd_o (edn_urnd_req),
    .edn_urnd_i (edn_urnd_rsp),

    .clk_otp_i      (PCLK),
    .rst_otp_ni     (rst_n),
    .otbn_otp_key_o (otp_key_req),
    .otbn_otp_key_i (otp_key_rsp),

    .keymgr_key_i (sideload_key)
  );

  // The memory-configuration response is the acknowledgement of a margin
  // setting this wrapper never changes, so there is nothing here to act on.
  logic unused_ram_cfg_rsp;
  assign unused_ram_cfg_rsp = ^{ram_cfg_rsp_imem, ram_cfg_rsp_dmem};

  assign idle_o    = prim_mubi_pkg::mubi4_test_true_strict(core_idle);
  assign rma_ack_o = lc_ctrl_pkg::lc_tx_test_true_strict(lc_rma_ack);

  always_comb begin
    for (int unsigned a = 0; a < otbn_reg_pkg::NumAlerts; a++) begin
      alert_p_o[a] = alert_tx[a].alert_p;
      alert_n_o[a] = alert_tx[a].alert_n;
    end
  end

  // THERE IS NO PWDATA / PSTRB ABSORBER HERE, AND THERE MUST NOT BE.
  //
  // An earlier revision carried one, guarded by `if (APB_DATA_WIDTH > 32)`.
  // The elaboration guard rejects every value except 32, so that block could
  // never elaborate and absorbed nothing - but it was a standing invitation to
  // widen, and a write-data absorber is precisely where a byte lane that the
  // design has stopped using would go dark and stay dark.
  //
  // Measured, with every absorber in this IP removed and the bound assertions
  // left OUT of the file list (they consume the full vectors and would hide
  // the answer), the complete set of signals the remaining absorbers stand in
  // for is:
  //
  //   rsa_ecc_apb4_to_tlul   paddr_i[1:0]          byte-within-word
  //                          tl_i[64:48,15:2]      D-channel fields APB cannot carry
  //   rsa_ecc_id_regs        paddr_i[19:4,1:0]     decoded by the parent
  //   rsa_ecc_edn_responder  lfsr_state[60:32]     neither data nor latency
  //   rsa_ecc_otp_key_resp   lfsr_state[63:2]      only the latency is taken
  //   rsa_ecc_top            edn_*_i, otp_key_*_i  boundary ports of the OTHER
  //                          sideload_key_*        build; live when EXTERNAL
  //                          ram_cfg_rsp_*         tie-off acknowledgement
  //
  // PWDATA and PSTRB appear nowhere in that list, which is the point.  Repeat
  // the measurement before adding to any absorber - the risk is the BREADTH of
  // the expression, not the name.

endmodule : rsa_ecc_top

`default_nettype wire
