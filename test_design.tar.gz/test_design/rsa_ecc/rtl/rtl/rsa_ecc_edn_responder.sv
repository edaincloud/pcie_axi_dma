//=============================================================================
// File        : rsa_ecc_edn_responder.sv
// Description : On-chip responder for the vendored core's two EDN (entropy
//               distribution network) ports.
//
//               WHY THIS EXISTS AT ALL
//               ----------------------
//               OTBN cannot run without entropy.  It performs an initial
//               secure wipe out of reset which needs a URND seed, and it will
//               not report IDLE - and will not accept a bus access to IMEM or
//               DMEM - until that wipe has completed.  A design that leaves
//               the EDN ports dangling does not "work with slightly weaker
//               random numbers"; it never leaves BUSY_SEC_WIPE_INT and the IP
//               appears dead.  So an APB4 IP that is meant to be usable
//               stand-alone has to answer these ports somehow, and this is
//               that answer.
//
//               WHAT IT IS NOT
//               --------------
//               THIS IS NOT AN ENTROPY SOURCE.  It is a deterministic LFSR
//               with a compile-time seed.  Its output is fully predictable to
//               anyone who knows the seed, which is a parameter in the
//               netlist.  Using it in production silicon that performs real
//               RSA or ECDSA signing DESTROYS the security of those
//               operations: OTBN uses URND for blinding and masking, and a
//               predictable mask is no mask.
//
//               It is here so that:
//                 * the IP is self-contained for simulation, FPGA bring-up
//                   and lab use, and
//                 * an integrator who has a real EDN can build with
//                   ENTROPY_MODE = RSA_ECC_ENTROPY_EXTERNAL and connect it,
//                   which removes this module from the netlist entirely.
//
//               rsa_ecc_top's header states the same thing at the boundary,
//               and the CAP register lets software read back which of the two
//               it is talking to.
//
//               PROTOCOL
//               --------
//               `prim_sync_reqack` on the core side: `req` is held until it
//               sees a one-cycle `ack`, and does not re-assert before `req`
//               has returned low.  This responder therefore waits for req,
//               waits a pseudo-random 0..7 further cycles so that the core is
//               never exercised at one fixed latency, drives `ack` and the
//               data word for exactly one cycle, then holds off until `req`
//               drops.
//
//               `fips` is driven high.  Driving it low makes the core raise
//               ERR_BITS.RND_FIPS_CHK_FAIL, i.e. it would report a hardware
//               fault rather than degrade, so there is no useful "not FIPS"
//               behaviour to offer here.
//
//               REPETITION CHECK.  The core instantiates prim_edn_req with
//               RepCheck(1) on the RND port: two IDENTICAL consecutive words
//               are reported as ERR_BITS.RND_REP_CHK_FAIL.  That check exists
//               to catch a STUCK source.  A maximal-length LFSR advanced 32
//               bits per word still produces a repeat with probability about
//               2**-32 per word, so this is a real - if vanishingly rare -
//               false positive, and it is left in place rather than papered
//               over: suppressing it here would also suppress a genuinely
//               stuck external source in the ENTROPY_MODE = EXTERNAL build,
//               where the same core logic is doing the checking.
//=============================================================================

`default_nettype none

module rsa_ecc_edn_responder
  import rsa_ecc_pkg::*;
#(
    // Non-zero LFSR seed.  The two EDN ports of one IP must not be given the
    // same seed, or the RND and URND streams are identical.
    parameter logic [63:0] SEED = 64'hA5C3_9F17_2D6B_E481
) (
    input  wire                        clk_i,
    input  wire                        rst_ni,

    input  wire                        edn_req_i,
    output logic                       edn_ack_o,
    output logic                       edn_fips_o,
    output logic [EDN_BUS_WIDTH-1:0]   edn_bus_o
);

  typedef enum logic [1:0] {
    ST_WAIT_REQ  = 2'b00,  // idle, waiting for the core to ask
    ST_DELAY     = 2'b01,  // burning the pseudo-random response latency
    ST_ACK       = 2'b10,  // driving ack + data for exactly one cycle
    ST_WAIT_DROP = 2'b11   // holding off until req returns low
  } state_e;

  state_e      state_q, state_d;
  logic [2:0]  delay_q, delay_d;
  logic [63:0] lfsr_state;
  logic        lfsr_en;

  rsa_ecc_lfsr #(
    .SEED  (SEED),
    .STEPS (32)
  ) u_lfsr (
    .clk_i,
    .rst_ni,
    .en_i    (lfsr_en),
    .state_o (lfsr_state)
  );

  always_comb begin
    state_d   = state_q;
    delay_d   = delay_q;
    lfsr_en   = 1'b0;
    edn_ack_o = 1'b0;

    unique case (state_q)
      ST_WAIT_REQ: begin
        if (edn_req_i) begin
          // Latency taken from the top of the state, which the ack path does
          // not use, so the delay and the data are not the same bits.
          delay_d = lfsr_state[63:61];
          state_d = ST_DELAY;
        end
      end

      ST_DELAY: begin
        if (delay_q == 3'd0) begin
          state_d = ST_ACK;
        end else begin
          delay_d = delay_q - 3'd1;
        end
      end

      ST_ACK: begin
        edn_ack_o = 1'b1;
        // Advance only on a completed handshake, so the word the core took is
        // never handed out twice.
        lfsr_en   = 1'b1;
        state_d   = ST_WAIT_DROP;
      end

      ST_WAIT_DROP: begin
        if (!edn_req_i) begin
          state_d = ST_WAIT_REQ;
        end
      end

      // Unreachable: state_e is fully enumerated over two bits.  Present so
      // that a corrupted state recovers rather than persists.
      default: state_d = ST_WAIT_REQ;
    endcase
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= ST_WAIT_REQ;
      delay_q <= 3'd0;
    end else begin
      state_q <= state_d;
      delay_q <= delay_d;
    end
  end

  // See the FIPS note in the header: the core treats a low fips as a fault,
  // not as a weaker grade of entropy.
  assign edn_fips_o = 1'b1;
  assign edn_bus_o  = lfsr_state[EDN_BUS_WIDTH-1:0];

  // The middle of the LFSR state feeds neither the data word nor the latency.
  logic unused_lfsr;
  assign unused_lfsr = ^lfsr_state[60:EDN_BUS_WIDTH];

endmodule : rsa_ecc_edn_responder

`default_nettype wire
