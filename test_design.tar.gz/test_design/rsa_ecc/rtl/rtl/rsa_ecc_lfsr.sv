//=============================================================================
// File        : rsa_ecc_lfsr.sv
// Description : 64-bit maximal-length Fibonacci LFSR, advanced STEPS bits per
//               enabled clock.
//
//               This is the bit source behind the on-chip entropy responder
//               and behind the request-latency jitter in it.  It is NOT a
//               cryptographic random number generator and is never described
//               as one - see rsa_ecc_edn_responder.sv, which is where the
//               consequences of that are written down.
//
//               Advancing STEPS bits per clock (rather than one) is what makes
//               successive 32-bit words unrelated to each other by a single
//               shift.  With STEPS = 32 the low half of the state is entirely
//               replaced between one output word and the next.
//
//               Polynomial x^64 + x^63 + x^61 + x^60 + 1 (maximal length,
//               period 2**64 - 1).  The all-zero state is the single
//               absorbing state of any LFSR, so SEED must not be zero; an
//               elaboration guard enforces it rather than leaving a source
//               that silently outputs a constant.
//=============================================================================

`default_nettype none

module rsa_ecc_lfsr #(
    // Non-zero initial state.
    parameter logic [63:0] SEED  = 64'hA5C3_9F17_2D6B_E481,
    // Bit positions advanced per enabled clock.
    parameter int unsigned STEPS = 32
) (
    input  wire         clk_i,
    input  wire         rst_ni,
    input  wire         en_i,
    output logic [63:0] state_o
);

  if (SEED == 64'd0) begin : gen_chk_seed
    $error("rsa_ecc_lfsr: SEED must be non-zero (the all-zero state is absorbing)");
  end
  if (STEPS < 1) begin : gen_chk_steps_min
    $error("rsa_ecc_lfsr: STEPS must be >= 1 (got %0d)", STEPS);
  end
  if (STEPS > 64) begin : gen_chk_steps_max
    $error("rsa_ecc_lfsr: STEPS must be <= 64 (got %0d)", STEPS);
  end

  logic [63:0] state_q;
  logic [63:0] state_next;

  // Unrolled advance.  Combinational and flat: STEPS single-bit XOR feedbacks,
  // which synthesises to a small XOR network rather than a deep chain.
  always_comb begin
    state_next = state_q;
    for (int unsigned i = 0; i < STEPS; i++) begin
      state_next = {state_next[62:0],
                    state_next[63] ^ state_next[62] ^ state_next[60] ^ state_next[59]};
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= SEED;
    end else if (en_i) begin
      state_q <= state_next;
    end
  end

  assign state_o = state_q;

endmodule : rsa_ecc_lfsr

`default_nettype wire
