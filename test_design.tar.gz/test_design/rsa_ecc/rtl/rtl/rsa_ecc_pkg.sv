//=============================================================================
// File        : rsa_ecc_pkg.sv
// Description : Address map, field positions and identification constants for
//               the RSA/ECC public-key accelerator.
//
//               EVERY address and field position used by the RTL, the RAL
//               model and the reference model comes from here.  An offset
//               written inline in three places is an offset that will
//               eventually disagree with itself in one of them.
//
//               TWO REGISTER REGIONS
//               --------------------
//               The compute core is OpenTitan's OTBN, vendored unmodified
//               under rtl/core/.  It owns its own register map and its own
//               IMEM/DMEM windows; those offsets are NOT redefined here, they
//               are IMPORTED from otbn_reg_pkg so that a change upstream
//               cannot silently desynchronise this wrapper.  The wrapper adds
//               one small read-only region of its own, above the core, for
//               identification and build-configuration discovery.
//
//                 0x0000 .. 0x002F   core registers      (otbn_reg_pkg)
//                 0x4000 .. 0x7FFF   IMEM window         (otbn_reg_pkg)
//                 0x8000 .. 0xBFFF   DMEM window         (otbn_reg_pkg)
//                 0xC000 .. 0xC00F   wrapper ID region   (this package)
//
//               Nothing is aliased: RSA_ECC_ID_BASE sits immediately above the
//               top of the DMEM window and the decode is a strict compare, so
//               growing a core window upstream cannot start overlapping this
//               region without the elaboration guard in rsa_ecc_top firing.
//=============================================================================

`default_nettype none

package rsa_ecc_pkg;

  //---------------------------------------------------------------------------
  // Core address map, imported rather than restated
  //---------------------------------------------------------------------------
  // Most of the constants below are consumed by the RAL model, the reference
  // model, the assertions and the documentation rather than by synthesizable
  // RTL, so a lint run over rtl/ alone reports them as unused parameters.
  // They are deliberately kept in ONE package anyway: the alternative is the
  // same offset written down in the RTL, the RAL and the model, which is how
  // three copies of an address map end up disagreeing.  The waiver is scoped
  // to this declaration block and to that one rule.
  /* verilator lint_off UNUSEDPARAM */
  // Byte offset of the first core register and the size of the core's own
  // register block.  otbn_reg_pkg::BlockAw is the number of address bits the
  // core's reg_top decodes.
  localparam int unsigned CORE_ADDR_BITS = otbn_reg_pkg::BlockAw;

  localparam logic [31:0] IMEM_BASE = 32'(otbn_reg_pkg::OTBN_IMEM_OFFSET);
  localparam logic [31:0] IMEM_SIZE = 32'(otbn_reg_pkg::OTBN_IMEM_SIZE);
  localparam logic [31:0] DMEM_BASE = 32'(otbn_reg_pkg::OTBN_DMEM_OFFSET);
  localparam logic [31:0] DMEM_SIZE = 32'(otbn_reg_pkg::OTBN_DMEM_SIZE);

  // Core register offsets, re-exported under wrapper names so that the RAL and
  // the reference model have one vocabulary.  These are aliases, not copies:
  // if otbn_reg_pkg moves a register, these move with it.
  localparam logic [31:0] REG_INTR_STATE       = 32'(otbn_reg_pkg::OTBN_INTR_STATE_OFFSET);
  localparam logic [31:0] REG_INTR_ENABLE      = 32'(otbn_reg_pkg::OTBN_INTR_ENABLE_OFFSET);
  localparam logic [31:0] REG_INTR_TEST        = 32'(otbn_reg_pkg::OTBN_INTR_TEST_OFFSET);
  localparam logic [31:0] REG_ALERT_TEST       = 32'(otbn_reg_pkg::OTBN_ALERT_TEST_OFFSET);
  localparam logic [31:0] REG_CMD              = 32'(otbn_reg_pkg::OTBN_CMD_OFFSET);
  localparam logic [31:0] REG_CTRL             = 32'(otbn_reg_pkg::OTBN_CTRL_OFFSET);
  localparam logic [31:0] REG_STATUS           = 32'(otbn_reg_pkg::OTBN_STATUS_OFFSET);
  localparam logic [31:0] REG_ERR_BITS         = 32'(otbn_reg_pkg::OTBN_ERR_BITS_OFFSET);
  localparam logic [31:0] REG_FATAL_ALERT_CAUSE= 32'(otbn_reg_pkg::OTBN_FATAL_ALERT_CAUSE_OFFSET);
  localparam logic [31:0] REG_INSN_CNT         = 32'(otbn_reg_pkg::OTBN_INSN_CNT_OFFSET);
  localparam logic [31:0] REG_LOAD_CHECKSUM    = 32'(otbn_reg_pkg::OTBN_LOAD_CHECKSUM_OFFSET);

  //---------------------------------------------------------------------------
  // CMD encodings (otbn.hjson).  These are magic constants chosen upstream for
  // Hamming distance, not an enumeration - a wrong value is a NO-OP, not an
  // error, so they must never be retyped from memory.
  //---------------------------------------------------------------------------
  typedef enum logic [7:0] {
    CMD_EXECUTE       = 8'hd8,
    CMD_SEC_WIPE_DMEM = 8'hc3,
    CMD_SEC_WIPE_IMEM = 8'h1e
  } cmd_e;

  //---------------------------------------------------------------------------
  // STATUS encodings (otbn.hjson).
  //---------------------------------------------------------------------------
  typedef enum logic [7:0] {
    STATUS_IDLE            = 8'h00,
    STATUS_BUSY_EXECUTE    = 8'h01,
    STATUS_BUSY_SEC_WIPE_DMEM = 8'h02,
    STATUS_BUSY_SEC_WIPE_IMEM = 8'h03,
    STATUS_BUSY_SEC_WIPE_INT  = 8'h04,
    STATUS_LOCKED          = 8'hFF
  } status_e;

  //---------------------------------------------------------------------------
  // Wrapper identification region
  //---------------------------------------------------------------------------
  // Placed immediately above the core's DMEM window.  Four 32-bit registers,
  // all read-only; a write is accepted and discarded rather than raising an
  // error, which is the same policy the core applies to its own RO registers.
  localparam logic [31:0] ID_BASE   = DMEM_BASE + DMEM_SIZE;   // 0x0000_C000
  localparam logic [31:0] ID_SIZE   = 32'h10;

  localparam logic [31:0] REG_ID      = ID_BASE + 32'h0;
  localparam logic [31:0] REG_VERSION = ID_BASE + 32'h4;
  localparam logic [31:0] REG_CAP     = ID_BASE + 32'h8;
  localparam logic [31:0] REG_CORE_ID = ID_BASE + 32'hC;

  // "RSAE" in ASCII.  A read of ID that returns anything else means the bus
  // did not reach this IP, which is a different fault from the IP misbehaving.
  localparam logic [31:0] ID_VALUE = 32'h5253_4145;

  // CORE_ID identifies the vendored compute core so that software can tell
  // which instruction set it is programming.  "OTBN".
  localparam logic [31:0] CORE_ID_VALUE = 32'h4F54_424E;

  // CAP bit positions.  A feature compiled out reads back as 0, so a driver
  // can discover the build rather than being told about it.
  localparam int unsigned CAP_SIDELOAD_KEY_BIT = 0;  // keymgr sideload port present
  localparam int unsigned CAP_EXT_ENTROPY_BIT  = 1;  // EDN brought out to the boundary
  localparam int unsigned CAP_MAI_BIT          = 2;  // masking accelerator present
  localparam int unsigned CAP_RST_POL_BIT      = 3;  // 1 = active-high reset build

  //---------------------------------------------------------------------------
  // Fixed widths of the vendored core's interfaces, re-exported so that the
  // wrapper never writes a literal for something the core owns.
  //---------------------------------------------------------------------------
  localparam int unsigned EDN_BUS_WIDTH   = edn_pkg::ENDPOINT_BUS_WIDTH;      // 32
  localparam int unsigned OTP_KEY_WIDTH   = otp_ctrl_pkg::OtbnKeyWidth;       // 128
  localparam int unsigned OTP_NONCE_WIDTH = otp_ctrl_pkg::OtbnNonceWidth;     // 64
  localparam int unsigned SIDELOAD_KEY_WIDTH = keymgr_pkg::OtbnKeyWidth;
  localparam int unsigned SIDELOAD_SHARES    = keymgr_pkg::Shares;

  // TL-UL geometry the bridge must match.  Taken from the core's own package
  // so a width change upstream is an elaboration error here rather than a
  // silent truncation.
  localparam int unsigned TL_AW  = top_pkg::TL_AW;
  localparam int unsigned TL_DW  = top_pkg::TL_DW;
  localparam int unsigned TL_DBW = top_pkg::TL_DBW;
  localparam int unsigned TL_SZW = top_pkg::TL_SZW;
  localparam int unsigned TL_AIW = top_pkg::TL_AIW;

  //---------------------------------------------------------------------------
  // Number of APB address bits the wrapper must decode, i.e. the smallest
  // width that spans the top of the ID region.
  //
  // Evaluated in 64 bits.  A span computed from a width parameter in a type
  // whose size IS that parameter yields zero at the top of the range instead
  // of overflowing, and the guard built on it then fires on a legal
  // configuration - see .skills/tapeout_grade_rtl/rtl.md, "Parameter
  // Arithmetic".
  localparam longint unsigned REGION_TOP = longint'(ID_BASE) + longint'(ID_SIZE);

  /* verilator lint_on UNUSEDPARAM */

  //---------------------------------------------------------------------------
  // Sub-word write permission, per core register.
  //
  // The core's register file does NOT require whole-word writes.  Each
  // register carries a mask of the bytes that MUST be enabled, and a write
  // errors when a permitted byte is left out:
  //
  //     wr_err = |(OTBN_PERMIT[i] & ~byte_enables)
  //
  // Most registers permit 4'b0001 - only byte 0 has to be present - so a
  // single-byte write to INTR_ENABLE is ACCEPTED and takes effect, while the
  // same write to LOAD_CHECKSUM (4'b1111) is refused.  Assuming "partial write
  // -> error" everywhere is wrong in both directions at once: it predicts an
  // error the hardware does not raise, and it predicts no state change where
  // the hardware does change state.
  //
  // The table is IMPORTED from the core's own package, not restated, so a
  // register that changes its permission upstream changes it here too.
  //---------------------------------------------------------------------------

  // Index of `addr` in the core's register table, or -1 if it is not a
  // register.  The order is otbn_reg_pkg's own (otbn_id_e).
  function automatic int reg_permit_index(logic [31:0] addr);
    case (addr & ~32'h3)
      REG_INTR_STATE       : return 0;
      REG_INTR_ENABLE      : return 1;
      REG_INTR_TEST        : return 2;
      REG_ALERT_TEST       : return 3;
      REG_CMD              : return 4;
      REG_CTRL             : return 5;
      REG_STATUS           : return 6;
      REG_ERR_BITS         : return 7;
      REG_FATAL_ALERT_CAUSE: return 8;
      REG_INSN_CNT         : return 9;
      REG_LOAD_CHECKSUM    : return 10;
      default              : return -1;
    endcase
  endfunction

  // The byte-enable mask a write to `addr` must contain.  Zero means the
  // address is not a register at all.
  function automatic logic [3:0] reg_permit_mask(logic [31:0] addr);
    int i = reg_permit_index(addr);
    if (i < 0) return 4'h0;
    return otbn_reg_pkg::OTBN_PERMIT[i];
  endfunction

  // True when a write with byte enables `strb` to `addr` is refused.
  function automatic bit reg_write_refused(logic [31:0] addr, logic [3:0] strb);
    logic [3:0] permit = reg_permit_mask(addr);
    if (permit == 4'h0) return 1'b0;      // not a register; caller decides
    return |(permit & ~strb);
  endfunction

  //---------------------------------------------------------------------------
  // A single 32-bit word address is always 4-byte aligned in this IP: the core
  // is a 32-bit TL-UL device and the wrapper does not repack.  Bits [1:0] of
  // an address therefore select bytes inside a word and are carried in the
  // strobe, never in the address.
  localparam int unsigned WORD_ADDR_LSB = 2;

endpackage : rsa_ecc_pkg

`default_nettype wire
