//=============================================================================
// File        : rsa_ecc_id_regs.sv
// Description : The wrapper's own read-only register region.
//
//               The compute core brings its own register map, so this IP does
//               not need a register bank to be programmable.  What the core
//               cannot provide is identification of the WRAPPER: which build
//               of it software is talking to, and which optional pieces of it
//               were compiled in.  Four read-only words at the top of the
//               address map answer that.
//
//                 +0x0  ID       32'h5253_4145  ("RSAE")
//                 +0x4  VERSION  {major[15:8], minor[7:0]} in the low half,
//                                build in the high half
//                 +0x8  CAP      build-configuration bits, see rsa_ecc_pkg
//                 +0xC  CORE_ID  32'h4F54_424E  ("OTBN")
//
//               Every word is read-only.  A write is ACCEPTED and DISCARDED
//               rather than raising PSLVERR: that is the policy the vendored
//               core applies to its own read-only registers, and having two
//               different policies inside one address map is a worse surprise
//               than either policy on its own.
//
//               Zero wait states.  The region is a mux over constants, so
//               PREADY is asserted in the ACCESS phase.
//=============================================================================

`default_nettype none

module rsa_ecc_id_regs
  import rsa_ecc_pkg::*;
#(
    parameter int unsigned APB_ADDR_WIDTH = 20,
    parameter int unsigned VERSION_MAJOR  = 1,
    parameter int unsigned VERSION_MINOR  = 0,
    parameter int unsigned VERSION_BUILD  = 0,
    // Build-configuration bits reported through CAP.  Assembled by the parent
    // from its own parameters so that this module has no opinion about what
    // the options mean.
    parameter logic [31:0] CAP_VALUE      = 32'h0
) (
    input  wire                       clk_i,
    input  wire                       rst_ni,

    input  wire                       sel_i,      // decoded: this region
    input  wire                       penable_i,
    input  wire                       pwrite_i,
    input  wire  [APB_ADDR_WIDTH-1:0] paddr_i,

    output logic [31:0]               prdata_o,
    output logic                      pready_o,
    output logic                      pslverr_o
);

  localparam logic [31:0] VERSION_VALUE =
      {16'(VERSION_BUILD), 8'(VERSION_MAJOR), 8'(VERSION_MINOR)};

  // Two address bits select one of the four words.  Bits [1:0] are
  // byte-within-word and are not decoded here: a sub-word read returns the
  // whole word and the requester keeps the lanes it asked for, which is what
  // an APB4 subordinate with no side effects is entitled to do.
  wire [1:0] word_sel = paddr_i[3:2];

  // Everything above bit 3 has already been decoded by the parent, and bits
  // [1:0] are byte-within-word (see the header).
  logic unused_paddr;
  assign unused_paddr = ^{paddr_i[APB_ADDR_WIDTH-1:4], paddr_i[1:0]};

  logic [31:0] rdata;

  always_comb begin
    unique case (word_sel)
      2'd0:    rdata = ID_VALUE;
      2'd1:    rdata = VERSION_VALUE;
      2'd2:    rdata = CAP_VALUE;
      2'd3:    rdata = CORE_ID_VALUE;
      // Unreachable: word_sel is two bits and all four are enumerated above.
      default: rdata = ID_VALUE;
    endcase
  end

  // Registered so that the APB read data path out of this block has the same
  // shape as the one out of the bridge and the parent's output mux is a
  // selection between two registered values rather than a mixture.
  logic [31:0] prdata_q;
  logic        pready_q;

  wire access = sel_i && penable_i && !pready_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      prdata_q <= '0;
      pready_q <= 1'b0;
    end else begin
      pready_q <= access;
      if (access && !pwrite_i) begin
        prdata_q <= rdata;
      end
    end
  end

  assign prdata_o  = prdata_q;
  assign pready_o  = pready_q;
  assign pslverr_o = 1'b0;   // see the read-only write policy in the header

endmodule : rsa_ecc_id_regs

`default_nettype wire
