# Test designs: same RTL and SDC for any synthesis tool

The 23 benchmark designs (all of `/home/test/designs` except fpu, tiny_gpu, roe and pcie6.0), packaged
for running other synthesis tools on exactly the inputs used for the yosys and compcarta comparison.

Each `<design>/` has:
- `rtl/`: sources and include directories, in their original layout;
- `filelist.f`: `+incdir+`, `+define+` and files, relative to the design directory;
- `sdc/`: the design's own SDC, unchanged;
- `design.json`;
- `README.md`: top module, top-level parameter overrides, defines, clocks, tool notes, and the results of
  the reference and compcarta runs;
- `macros/`, where the design uses memory macros.

Technology files are in `_tech/`:
- the nangate45 typical Liberty;
- `tech_config.tcl` (don't-use cells, tie cells, driving cell);
- the latch map;
- the tech and macro LEFs.

**Important:**
- Several designs need **top-level parameter overrides** (`-G` values) that are not the RTL defaults. They
  are listed in each README and in `design.json`; run every tool with them, or the design is a different one.
- Use the SDC as is. Both runs below took the synthesis delay target from the minimum clock period in it.

| Design | Top | Files | SDC | Min period (ns) | Clocks | Macros | Area ref (µm²) | Area compcarta (µm²) | compcarta WS (ns) |
|---|---|---:|---|---:|---:|---|---:|---:|---:|
| [fifo](fifo/README.md) | `fifo` | 1 | `fifo.sdc` | 0.71 | 1 |  | 2,158 | 1,705 | +0.009 |
| [cordic](cordic/README.md) | `cordic_top` | 8 | `cordic_top.sdc` | 3.29 | 1 |  | 18,457 | 15,824 | +0.014 |
| [dma](dma/README.md) | `dma_top` | 10 | `dma_top.sdc` | 1.27 | 1 |  | 21,900 | 15,993 | +0.001 |
| [i2s](i2s/README.md) | `i2s_top` | 16 | `i2s_top.sdc` | 1.23 | 2 |  | 24,921 | 21,442 | +0.007 |
| [i3c](i3c/README.md) | `i3c_top` | 11 | `i3c_top.sdc` | 1.32 | 1 |  | 19,185 | 14,287 | +0.016 |
| [can](can/README.md) | `can_top` | 10 | `can_top.sdc` | 2.01 | 1 |  | 17,947 | 14,773 | +0.006 |
| [can-fd](can-fd/README.md) | `ctu_can_fd_top_apb` | 89 | `ctu_can_fd_top_apb.sdc` | 1.78 | 1 |  | 44,608 | 34,643 | +0.076 |
| [hmac](hmac/README.md) | `hmac_top` | 60 | `hmac_top.sdc` | 4.01 | 1 |  | 63,783 | 54,132 | +0.006 |
| [sha3](sha3/README.md) | `sha3_top` | 91 | `sha3_top.sdc` | 1.7 | 2 |  | 54,727 | 46,932 | +0.019 |
| [dma_suite](dma_suite/README.md) | `dma_suite_top` | 10 | `dma_suite_top.sdc` | 2.14 | 1 |  | 39,947 | 31,286 | +0.004 |
| [tpu](tpu/README.md) | `tpu_axi_wrapper` | 22 | `tpu.sdc` | 1.23 | 1 |  | 1,419,041 | 938,940 | +0.001 |
| [aes](aes/README.md) | `aes_apb` | 102 | `aes_apb.sdc` | 3.14 | 2 |  | 60,910 | 54,769 | +0.042 |
| [ethmac](ethmac/README.md) | `ethmac` | 24 | `ethmac.sdc` | 1.58 | 3 |  | 90,787 | 68,006 | +0.536 |
| [pcie_axi_dma](pcie_axi_dma/README.md) | `pcie_us_axi_dma` | 3 | `pcie_us_axi_dma.sdc` | 4.01 | 1 |  | 370,237 | 274,061 | +0.659 |
| [ldpc](ldpc/README.md) | `ldpc` | 1 | `ldpc.sdc` | 4.63 | 1 |  | 161,871 | 78,638 | +0.006 |
| [usb3.0](usb3.0/README.md) | `usb3_device_controller` | 19 | `usb3_device_controller.sdc` | 3.25 | 2 |  | 2,451,323 | 1,670,464 | +0.329 |
| [ravenoc](ravenoc/README.md) | `ravenoc` | 18 | `ravenoc.sdc` | 1.48 | 2 |  | 274,990 | 208,329 | +0.003 |
| [yamuna](yamuna/README.md) | `mkDebugSoc` | 91 | `yamuna.sdc` | 2.9 | 2 | yes | 374,359 | 318,800 | +0.002 |
| [rsa_ecc](rsa_ecc/README.md) | `rsa_ecc_top` | 123 | `rsa_ecc_top.sdc` | 13.99 | 1 | yes | 272,018 | 240,757 | +1.245 |
| [tinyRocket](tinyRocket/README.md) | `RocketTile` | 6 | `tinyRocket.sdc` | 2.81 | 1 | yes | 43,399 | 35,281 | +0.350 |
| [eth_10g_25g](eth_10g_25g/README.md) | `eth_top` | 30 | `eth_top.sdc` | 2.72 | 2 |  | 810,467 | 562,899 | +0.266 |
| [ethernetSwitch](ethernetSwitch/README.md) | `switch` | 15 | `ethernetSwitch.sdc` | 1.0 | 1 |  | 1,153,015 | 785,811 | +0.060 |
| [orsoc_gfx](orsoc_gfx/README.md) | `gfx_top` | 20 | `orsoc_gfx.sdc` | 3.0 | 1 |  | 525,558 | 371,066 | +0.004 |

Reference = upstream yosys 0.69 standard flow. compcarta = yosys `arith-opt` 2bb4677e6, `synth_ppa -goal area`.
Sign-off for both: OpenSTA 3.1.0 with the SDC unchanged.
Full comparison: `/home/test/experiments/COMPCARTA_RESULTS_20261008.md`.
