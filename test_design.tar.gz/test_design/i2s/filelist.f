// i2s: top i2s_top; paths relative to this directory
rtl/rtl/i2s_pkg.sv
rtl/rtl/i2s_reset_sync.sv
rtl/rtl/i2s_sync.sv
rtl/rtl/i2s_cdc_data.sv
rtl/rtl/i2s_cdc_pulse.sv
rtl/rtl/i2s_cdc_evcnt.sv
rtl/rtl/i2s_fifo_async.sv
rtl/rtl/i2s_clkgen.sv
rtl/rtl/i2s_frame.sv
rtl/rtl/i2s_track.sv
rtl/rtl/i2s_prbs.sv
rtl/rtl/i2s_tx.sv
rtl/rtl/i2s_rx.sv
rtl/rtl/i2s_regs.sv
rtl/rtl/i2s_core.sv
rtl/rtl/i2s_top.sv
