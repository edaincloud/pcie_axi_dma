//=============================================================================
// File        : i2s_core.sv
// Description : Serial datapath of the I2S IP: clock generation, serial-pin
//               synchronisation, frame timing, transmit and receive engines,
//               the active configuration, the clock monitor and the test hooks.
//
//               The sample FIFOs are NOT here.  They straddle the clock
//               boundary and are instantiated in i2s_top, which owns both
//               clocks; this module sees only their serial-side port.
//
//               Clocking and CDC (specification sections 32, 40, 42, 43, 71)
//               -----------------------------------------------------------
//               EVERY FLOP IN THIS MODULE IS CLOCKED BY THE SERIAL CLOCK.
//               `clk_i` here is `sclk`, the IP's second clock input, and
//               `rst_ni` is its reset.  Nothing in this module runs on PCLK,
//               and nothing here may be connected directly to a PCLK-domain
//               signal: the register block reaches this module only through the
//               crossing structures instantiated in i2s_top.
//
//               SCK itself is still not a clock.  In controller mode it is a
//               REGISTERED OUTPUT divided down from the serial clock; in target
//               mode it is a sampled INPUT.  Serial timing is expressed
//               entirely as serial-clock enables derived from SCK edges, so the
//               netlist contains no generated and no gated clocks - which is
//               precisely why a separate serial clock port is what makes the
//               FIFO crossing real, rather than clocking this datapath from SCK
//               through a mux (a generated clock, forbidden) or leaving it on
//               PCLK (no crossing at all).
//
//               There are exactly two classes of crossing at this boundary:
//                 - the three serial pins entering through i2s_sync, which is
//                   unchanged; every consumer takes them from the synchroniser
//                   output and from nowhere else;
//                 - the register-block interface, which is handled entirely
//                   OUTSIDE this module by i2s_cdc_data, i2s_cdc_pulse,
//                   i2s_cdc_evcnt and i2s_fifo_async.
//
//               Matched-delay receive path
//               --------------------------
//               The RX capture strobe is derived from the SYNCHRONISED SCK,
//               and the captured data is the SYNCHRONISED SD.  Both therefore
//               carry the same SYNC_STAGES of delay, so their relationship at
//               the pin is preserved exactly - in controller mode, in target
//               mode and in loopback alike.  That is why the receive path has
//               a single timing model instead of one per mode.
//
//               The transmit path in controller mode deliberately does NOT go
//               through the synchronisers: it launches from the undelayed
//               internal SCK so that SD and SCK change together at the pin.
//               In target mode it necessarily follows the synchronised SCK,
//               which costs SYNC_STAGES serial-clock cycles of output delay and
//               is the origin of the documented f_sclk >= 8 x f_sck
//               requirement.
//
//               Configuration commit (specification section 51)
//               ----------------------------------------------
//               The ACTIVE configuration lives here, in the serial domain, and
//               is replaced atomically at a serial-domain frame boundary.  The
//               register block offers a validated shadow copy through
//               `cfg_valid_i` / `cfg_data_i` and learns that it has been
//               applied from `cfg_consume_o`, which closes the four-phase
//               handshake back in PCLK.  Keeping the active copy on this side
//               is what makes "atomic at a frame boundary" true of the domain
//               the frame actually exists in.
//=============================================================================

`default_nettype none

module i2s_core
  import i2s_pkg::*;
#(
    parameter int unsigned SAMPLE_WIDTH_MAX = 32,
    parameter int unsigned SLOT_WIDTH_MAX   = 32,
    parameter int unsigned DIV_WIDTH        = 8,
    parameter int unsigned SYNC_STAGES      = 2,
    parameter bit          HAS_MCLK         = 1'b1,
    parameter bit          SD_IDLE_LEVEL    = 1'b0
) (
    input  wire                          clk_i,
    input  wire                          rst_ni,

    // ---- serial interface ---------------------------------------------------
    input  wire                          sck_i,
    input  wire                          ws_i,
    input  wire                          sd_rx_i,
    output logic                         sck_o,
    output logic                         ws_o,
    output logic                         sd_tx_o,
    output logic                         mclk_o,
    output logic                         sck_oe_o,
    output logic                         ws_oe_o,
    output logic                         sd_tx_oe_o,
    output logic                         mclk_oe_o,

    // ---- control from the register block ------------------------------------
    input  wire                          soft_reset_i,
    input  wire                          ip_enable_i,
    input  wire                          tx_enable_i,
    input  wire                          rx_enable_i,
    input  wire                          controller_en_i,
    input  wire                          loopback_en_i,
    input  wire                          mute_global_i,
    input  wire                          stop_at_frame_i,
    input  wire  [1:0]                   underrun_mode_i,
    input  wire  [1:0]                   overrun_mode_i,
    input  wire                          rx_sign_extend_i,
    input  wire                          mute_tx_i,
    input  wire                          mute_rx_i,
    input  wire                          mute_left_i,
    input  wire                          mute_right_i,
    input  wire  [SAMPLE_WIDTH_MAX-1:0]  mute_value_i,
    input  wire                          clk_mon_en_i,
    input  wire  [7:0]                   clk_tol_i,

    // ---- configuration commit handshake (destination side) --------------------
    // `cfg_data_i` is stable for the whole time `cfg_valid_i` is asserted; it
    // is applied atomically at a frame boundary and acknowledged by pulsing
    // `cfg_consume_o`.
    input  wire  i2s_cfg_t               cfg_data_i,
    input  wire                          cfg_valid_i,
    output logic                         cfg_consume_o,

    // ---- serial side of the asynchronous FIFOs --------------------------------
    input  wire                          tx_fifo_empty_i,
    input  wire  [SAMPLE_WIDTH_MAX-1:0]  tx_fifo_rdata_i,
    output logic                         tx_fifo_pop_o,
    input  wire                          rx_fifo_full_i,
    output logic                         rx_fifo_push_o,
    output logic [SAMPLE_WIDTH_MAX-1:0]  rx_fifo_wdata_o,

    // ---- test and error injection ---------------------------------------------
    input  wire                          test_sd_force_en_i,
    input  wire                          test_sd_force_val_i,
    input  wire                          inj_en_i,
    input  wire  [I2S_EI_TYPE_W-1:0]     inj_type_i,
    input  wire  [7:0]                   inj_count_i,
    input  wire  [2:0]                   prbs_sel_i,
    input  wire                          prbs_tx_en_i,
    input  wire                          prbs_rx_en_i,
    input  wire                          prbs_reseed_i,
    output logic                         prbs_locked_o,
    output logic [15:0]                  prbs_err_cnt_o,

    // ---- events and status -----------------------------------------------------
    output logic                         ev_tx_underrun_o,
    output logic                         ev_rx_overrun_o,
    output logic                         ev_frame_err_o,
    output logic                         ev_ws_err_o,
    output logic                         ev_clk_err_o,
    output logic                         ev_frame_done_o,
    output logic                         ev_tx_sample_o,
    output logic                         ev_rx_sample_o,

    output logic                         sts_tx_active_o,
    output logic                         sts_rx_active_o,
    output logic                         sts_sck_running_o,
    output logic                         sts_tx_busy_o,
    output logic                         sts_rx_busy_o,
    output logic [2:0]                   dbg_tx_state_o,
    output logic [2:0]                   dbg_rx_state_o,
    output logic                         dbg_tx_slot_o,
    output logic                         dbg_rx_slot_o,
    output logic [I2S_WIDTH_FIELD_W-1:0] dbg_tx_bit_o,
    output logic [I2S_WIDTH_FIELD_W-1:0] dbg_rx_bit_o,
    output logic [SAMPLE_WIDTH_MAX-1:0]  dbg_shift_o,
    output logic [15:0]                  clk_sck_period_o,
    output logic [15:0]                  clk_sck_per_ws_o,
    output logic [31:0]                  clk_ws_period_o,
    output logic [15:0]                  clk_sck_high_o,
    output logic [15:0]                  clk_sck_low_o
);

  localparam int unsigned SW = SAMPLE_WIDTH_MAX;
  localparam int unsigned BW = I2S_WIDTH_FIELD_W;

  //---------------------------------------------------------------------------
  // Active configuration (specification section 51)
  //
  // Declared first because everything below reads it.  The apply condition is
  // the same one the register block used to evaluate in PCLK - a frame
  // boundary, or immediately if the engine is idle - but it is now evaluated
  // HERE, on the clock the frame boundary belongs to, so the transfer really is
  // atomic with respect to the frame rather than merely close to it.
  //---------------------------------------------------------------------------
  i2s_cfg_t active_q;

  logic [BW-1:0]        cfg_sample_width, cfg_slot_width, cfg_fs_width;
  logic [2:0]           cfg_format;
  logic                 cfg_ws_pol;
  logic [I2S_DELAY_FIELD_W-1:0] cfg_ws_lead;
  logic [DIV_WIDTH-1:0] cfg_sck_div, cfg_mclk_div;
  logic                 cfg_sck_inv, cfg_mclk_en, cfg_mclk_pol;
  logic [1:0]           cfg_mono, cfg_pad_mode;
  logic                 cfg_swap, cfg_target, cfg_launch_edge, cfg_sample_edge;

  assign cfg_sample_width = active_q.sample_width;
  assign cfg_slot_width   = active_q.slot_width;
  assign cfg_format       = active_q.format;
  assign cfg_ws_pol       = active_q.ws_pol;
  assign cfg_ws_lead      = active_q.ws_lead;
  assign cfg_fs_width     = active_q.fs_width;
  // The crossing carries the divider fields at their maximum width so that the
  // channel is build independent; the register block never writes above
  // DIV_WIDTH, so the discarded bits are always zero.
  assign cfg_sck_div      = active_q.sck_div[DIV_WIDTH-1:0];
  assign cfg_sck_inv      = active_q.sck_inv;
  assign cfg_mclk_en      = HAS_MCLK ? active_q.mclk_en : 1'b0;
  assign cfg_mclk_div     = active_q.mclk_div[DIV_WIDTH-1:0];
  assign cfg_mclk_pol     = active_q.mclk_pol;
  assign cfg_mono         = active_q.mono;
  assign cfg_swap         = active_q.swap;
  assign cfg_target       = active_q.target;
  assign cfg_launch_edge  = active_q.launch_edge;
  assign cfg_sample_edge  = active_q.sample_edge;
  assign cfg_pad_mode     = active_q.pad_mode;

  //---------------------------------------------------------------------------
  // Engine enables
  //---------------------------------------------------------------------------
  // Role selection (specification section 72).
  //
  // GLOBAL_CTRL.CONTROLLER_ENABLE is an IMMEDIATE register bit while
  // MODE_CTRL.TARGET_MODE is shadowed and commits at a frame boundary, so the
  // two sources of the role are not sequenced with respect to each other.
  // Taking the role combinationally from them let a single APB write reverse
  // the direction of the SCK and WS pads in the middle of a live frame: the pad
  // enables would turn round mid-bit and, in target mode, the IP would start
  // driving against the external controller that owns those lines.
  //
  // Section 72 requires that switching controller/target while active is either
  // prohibited or done through a controlled disable sequence.  This is the
  // gate: while the link is quiescent the role follows the request directly,
  // and once the link has been active for a full cycle the role is frozen at
  // the value it had.  A role change requested while the link is running is not
  // lost and not partially applied; it simply waits for the disable the
  // programming model already requires.
  //
  // The quiescent condition is REGISTERED, and it has to be.  One GLOBAL_CTRL
  // write sets IP_ENABLE, TX_ENABLE, RX_ENABLE and CONTROLLER_ENABLE in the
  // same cycle, so testing the live enables would see the link as already
  // active on the very cycle the role arrives and would freeze the role at its
  // reset value - the IP would never become a controller at all.  Sampling
  // "was the link quiet at the previous edge" makes the enabling write itself
  // the moment the role is taken, which is exactly the controlled sequence the
  // section asks for.
  logic ctrl_mode, role_req, role_quiet, role_quiet_q, ctrl_mode_q;

  assign role_req   = controller_en_i & ~cfg_target;
  assign role_quiet = ~ip_enable_i | ~(tx_enable_i | rx_enable_i);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      role_quiet_q <= 1'b1;
      ctrl_mode_q  <= 1'b0;
    end else begin
      role_quiet_q <= role_quiet;
      ctrl_mode_q  <= ctrl_mode;
    end
  end

  assign ctrl_mode = (soft_reset_i | role_quiet_q) ? role_req : ctrl_mode_q;

  logic tx_stopped_q, rx_stopped_q;
  logic tx_run, rx_run;

  assign tx_run = ip_enable_i & tx_enable_i & ~tx_stopped_q;
  assign rx_run = ip_enable_i & rx_enable_i & ~rx_stopped_q;

  //---------------------------------------------------------------------------
  // SCK / MCLK generation (controller mode)
  //---------------------------------------------------------------------------
  logic clk_run_req, stopping_q, clkgen_run;
  logic sck_gen, sck_running, gen_rise_en, gen_fall_en;
  logic mclk_gen;

  assign clk_run_req = ip_enable_i & ctrl_mode & (tx_enable_i | rx_enable_i) &
                       ~(tx_stopped_q & rx_stopped_q);
  assign clkgen_run  = clk_run_req | stopping_q;

  i2s_clkgen #(
      .DIV_WIDTH (DIV_WIDTH)
  ) u_clkgen (
      .clk_i         (clk_i),
      .rst_ni        (rst_ni),
      .run_i         (clkgen_run),
      .div_i         (cfg_sck_div),
      .invert_i      (cfg_sck_inv),
      .sck_o         (sck_gen),
      .running_o     (sck_running),
      .sck_rise_en_o (gen_rise_en),
      .sck_fall_en_o (gen_fall_en),
      .mclk_en_i     (cfg_mclk_en),
      .mclk_div_i    (cfg_mclk_div),
      .mclk_pol_i    (cfg_mclk_pol),
      .mclk_o        (mclk_gen)
  );

  //---------------------------------------------------------------------------
  // Pin level and the single clock-domain crossing
  //---------------------------------------------------------------------------
  logic ws_gen;
  logic sd_tx_pin;

  logic sck_pad, ws_pad, sd_pad;
  assign sck_pad = ctrl_mode ? sck_gen   : sck_i;
  assign ws_pad  = ctrl_mode ? ws_gen    : ws_i;
  // Internal loopback (specification section 60) substitutes the transmitted
  // pin value for the received one at the pad boundary, so the loopback path
  // is bit-for-bit the same path an external device would drive.
  assign sd_pad  = loopback_en_i ? sd_tx_pin : sd_rx_i;

  logic sck_sync, ws_sync, sd_sync;

  i2s_sync #(.WIDTH(1), .STAGES(SYNC_STAGES)) u_sync_sck (
      .clk_i(clk_i), .rst_ni(rst_ni), .d_i(sck_pad), .q_o(sck_sync));
  i2s_sync #(.WIDTH(1), .STAGES(SYNC_STAGES)) u_sync_ws (
      .clk_i(clk_i), .rst_ni(rst_ni), .d_i(ws_pad),  .q_o(ws_sync));
  i2s_sync #(.WIDTH(1), .STAGES(SYNC_STAGES), .RESET_VALUE(SD_IDLE_LEVEL))
      u_sync_sd (
      .clk_i(clk_i), .rst_ni(rst_ni), .d_i(sd_pad),  .q_o(sd_sync));

  logic sck_sync_q, sync_rise_en, sync_fall_en;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) sck_sync_q <= 1'b0;
    else         sck_sync_q <= sck_sync;
  end

  assign sync_rise_en =  sck_sync & ~sck_sync_q;
  assign sync_fall_en = ~sck_sync &  sck_sync_q;

  // Capture always follows the synchronised clock, so that it stays matched
  // with the synchronised data in every mode.
  logic capture_en;
  assign capture_en = cfg_sample_edge ? sync_fall_en : sync_rise_en;

  // Launch uses the undelayed internal clock in controller mode.
  logic launch_en;
  always_comb begin
    if (ctrl_mode) launch_en = cfg_launch_edge ? gen_rise_en  : gen_fall_en;
    else           launch_en = cfg_launch_edge ? sync_rise_en : sync_fall_en;
  end

  //---------------------------------------------------------------------------
  // Error injection countdown
  //---------------------------------------------------------------------------
  logic [7:0] inj_cnt_q;
  logic       inj_active;

  // ENABLE and COUNT are two fields of ONE register and are flopped on the same
  // edge, so at the instant ENABLE goes high the OLD count is what is visible.
  // Reloading only while ENABLE is low therefore loaded the count from before
  // the write - zero, out of reset - and left the countdown permanently at
  // zero: `inj_active` never asserted and a single-write arm injected nothing
  // at all.  Reloading on the cycle after the rising edge as well means the
  // count that is loaded is the one the same write delivered, so the one-write
  // arm that software actually uses works.
  logic inj_en_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      inj_cnt_q <= 8'd0;
      inj_en_q  <= 1'b0;
    end else begin
      inj_en_q <= inj_en_i;

      if (!inj_en_i || !inj_en_q) begin
        inj_cnt_q <= inj_count_i;
      end else if (launch_en && (inj_cnt_q != 8'd0)) begin
        inj_cnt_q <= inj_cnt_q - 8'd1;
      end
    end
  end

  assign inj_active = inj_en_i & (inj_cnt_q != 8'd0);

  // The nine injections of specification section 62.  Each is a single decode
  // of the armed type, so an unimplemented encoding (9..15) simply injects
  // nothing, and every injection is inert while ERROR_INJECT_CTRL.ENABLE is
  // low or the countdown has expired.
  logic inj_bitflip, inj_underrun, inj_overrun, inj_ws_phase;
  logic inj_missing, inj_extra, inj_slot_len, inj_chan_swap, inj_corrupt;
  assign inj_bitflip   = inj_active & (inj_type_i == I2S_EINJ_BIT_FLIP);
  assign inj_underrun  = inj_active & (inj_type_i == I2S_EINJ_UNDERRUN);
  assign inj_overrun   = inj_active & (inj_type_i == I2S_EINJ_OVERRUN);
  assign inj_ws_phase  = inj_active & (inj_type_i == I2S_EINJ_WS_PHASE);
  assign inj_missing   = inj_active & (inj_type_i == I2S_EINJ_MISSING_BIT);
  assign inj_extra     = inj_active & (inj_type_i == I2S_EINJ_EXTRA_BIT);
  assign inj_slot_len  = inj_active & (inj_type_i == I2S_EINJ_SLOT_LEN);
  assign inj_chan_swap = inj_active & (inj_type_i == I2S_EINJ_CHAN_SWAP);
  assign inj_corrupt   = inj_active & (inj_type_i == I2S_EINJ_CORRUPT);

  //---------------------------------------------------------------------------
  // Frame timing
  //---------------------------------------------------------------------------
  logic          fg_pos_slot, fg_slot, fg_started;
  logic [BW-1:0] fg_pos_bit, fg_bit;
  logic          fg_frame_start, fg_slot_start, fg_frame_end;

  i2s_frame u_frame (
      .clk_i          (clk_i),
      .rst_ni         (rst_ni),
      .run_i          (sck_running & ctrl_mode),
      .adv_en_i       (launch_en),
      .slot_width_i   (cfg_slot_width),
      .ws_lead_i      (cfg_ws_lead),
      .format_i       (cfg_format),
      .ws_pol_i       (cfg_ws_pol),
      .fs_width_i     (cfg_fs_width),
      .ws_phase_err_i (inj_ws_phase),
      .slot_len_err_i (inj_slot_len),
      .ws_o           (ws_gen),
      .pos_slot_o     (fg_pos_slot),
      .pos_bit_o      (fg_pos_bit),
      .slot_o         (fg_slot),
      .bit_o          (fg_bit),
      .started_o      (fg_started),
      .frame_start_o  (fg_frame_start),
      .slot_start_o   (fg_slot_start),
      .frame_end_o    (fg_frame_end)
  );

  // Target-mode transmit follows the externally supplied frame.
  logic          tt_synced, tt_pos_valid, tt_pos_slot, tt_slot;
  logic [BW-1:0] tt_pos_bit, tt_bit;
  logic          tt_slot_start, tt_frame_end, tt_ws_err, tt_frame_err;

  i2s_track u_tx_track (
      .clk_i        (clk_i),
      .rst_ni       (rst_ni),
      .run_i        (tx_run & ~ctrl_mode),
      .strobe_i     (launch_en),
      .ws_i         (ws_sync),
      .slot_width_i (cfg_slot_width),
      .ws_lead_i    (cfg_ws_lead),
      .format_i     (cfg_format),
      .ws_pol_i     (cfg_ws_pol),
      .synced_o     (tt_synced),
      .pos_valid_o  (tt_pos_valid),
      .pos_slot_o   (tt_pos_slot),
      .pos_bit_o    (tt_pos_bit),
      .slot_o       (tt_slot),
      .bit_o        (tt_bit),
      .slot_start_o (tt_slot_start),
      .frame_end_o  (tt_frame_end),
      .ws_err_o     (tt_ws_err),
      .frame_err_o  (tt_frame_err)
  );

  // Receive always recovers the frame from the synchronised WS.
  logic          rt_synced, rt_pos_valid, rt_pos_slot, rt_slot;
  logic [BW-1:0] rt_pos_bit, rt_bit;
  logic          rt_slot_start, rt_frame_end, rt_ws_err, rt_frame_err;

  i2s_track u_rx_track (
      .clk_i        (clk_i),
      .rst_ni       (rst_ni),
      .run_i        (rx_run),
      .strobe_i     (capture_en),
      .ws_i         (ws_sync),
      .slot_width_i (cfg_slot_width),
      .ws_lead_i    (cfg_ws_lead),
      .format_i     (cfg_format),
      .ws_pol_i     (cfg_ws_pol),
      .synced_o     (rt_synced),
      .pos_valid_o  (rt_pos_valid),
      .pos_slot_o   (rt_pos_slot),
      .pos_bit_o    (rt_pos_bit),
      .slot_o       (rt_slot),
      .bit_o        (rt_bit),
      .slot_start_o (rt_slot_start),
      .frame_end_o  (rt_frame_end),
      .ws_err_o     (rt_ws_err),
      .frame_err_o  (rt_frame_err)
  );

  // Transmit position: generated in controller mode, recovered in target mode.
  logic          tx_pos_valid, tx_pos_slot, tx_frame_start;
  logic [BW-1:0] tx_pos_bit;

  always_comb begin
    if (ctrl_mode) begin
      tx_pos_valid   = 1'b1;
      tx_pos_slot    = fg_pos_slot;
      tx_pos_bit     = fg_pos_bit;
      tx_frame_start = fg_frame_start;
    end else begin
      tx_pos_valid   = tt_pos_valid;
      tx_pos_slot    = tt_pos_slot;
      tx_pos_bit     = tt_pos_bit;
      tx_frame_start = tt_slot_start & (tt_pos_slot == 1'b0);
    end
  end

  //---------------------------------------------------------------------------
  // PRBS generator and checker (specification section 61)
  //---------------------------------------------------------------------------
  logic tx_data_bit_en, rx_data_bit_en;
  logic prbs_tx_bit, prbs_rx_bit, prbs_rx_err, prbs_rx_locked;
  // The generator instance has no checking role; its lock/error outputs exist
  // only because the two instances share one module.
  logic prbs_tx_locked, prbs_tx_err;

  i2s_prbs u_prbs_tx (
      .clk_i        (clk_i),
      .rst_ni       (rst_ni),
      .en_i         (tx_data_bit_en & prbs_tx_en_i),
      .reseed_i     (prbs_reseed_i | soft_reset_i),
      .sel_i        (prbs_sel_i),
      .check_mode_i (1'b0),
      .rx_bit_i     (1'b0),
      .bit_o        (prbs_tx_bit),
      .locked_o     (prbs_tx_locked),
      .error_o      (prbs_tx_err)
  );

  i2s_prbs u_prbs_rx (
      .clk_i        (clk_i),
      .rst_ni       (rst_ni),
      .en_i         (rx_data_bit_en & prbs_rx_en_i),
      .reseed_i     (prbs_reseed_i | soft_reset_i),
      .sel_i        (prbs_sel_i),
      .check_mode_i (1'b1),
      .rx_bit_i     (sd_sync),
      .bit_o        (prbs_rx_bit),
      .locked_o     (prbs_rx_locked),
      .error_o      (prbs_rx_err)
  );

  logic [15:0] prbs_err_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)                                    prbs_err_q <= 16'h0;
    else if (prbs_reseed_i || soft_reset_i)         prbs_err_q <= 16'h0;
    else if (prbs_rx_err && (prbs_err_q != 16'hFFFF)) prbs_err_q <= prbs_err_q + 16'h1;
  end

  assign prbs_locked_o  = prbs_rx_locked;
  assign prbs_err_cnt_o = prbs_err_q;

  //---------------------------------------------------------------------------
  // Transmit engine
  //---------------------------------------------------------------------------
  logic          tx_sd, tx_underrun, tx_sample_sent, tx_stop_req;
  logic [SW-1:0] tx_shift_dbg;
  logic [2:0]    tx_state;

  i2s_tx #(
      .SAMPLE_WIDTH_MAX (SAMPLE_WIDTH_MAX)
  ) u_tx (
      .clk_i           (clk_i),
      .rst_ni          (rst_ni),
      .run_i           (tx_run),
      .launch_en_i     (launch_en),
      .pos_valid_i     (tx_pos_valid),
      .pos_slot_i      (tx_pos_slot),
      .pos_bit_i       (tx_pos_bit),
      .frame_start_i   (tx_frame_start),
      .sample_width_i  (cfg_sample_width),
      .slot_width_i    (cfg_slot_width),
      .format_i        (cfg_format),
      .pad_mode_i      (cfg_pad_mode),
      .mono_i          (cfg_mono),
      // Channel-swap injection inverts the transmit mapping only, so a
      // loopback link decodes left and right the wrong way round.
      .swap_i          (cfg_swap ^ inj_chan_swap),
      .underrun_mode_i (underrun_mode_i),
      .mute_all_i      (mute_global_i | mute_tx_i),
      .mute_left_i     (mute_left_i),
      .mute_right_i    (mute_right_i),
      .mute_value_i    (mute_value_i),
      .fifo_empty_i    (tx_fifo_empty_i),
      .fifo_rdata_i    (tx_fifo_rdata_i),
      .fifo_pop_o      (tx_fifo_pop_o),
      .prbs_en_i       (prbs_tx_en_i),
      .prbs_bit_i      (prbs_tx_bit),
      .inj_bitflip_i   (inj_bitflip),
      .inj_underrun_i  (inj_underrun),
      .inj_missing_i   (inj_missing),
      .inj_extra_i     (inj_extra),
      .inj_corrupt_i   (inj_corrupt),
      .sd_o            (tx_sd),
      .data_bit_en_o   (tx_data_bit_en),
      .underrun_o      (tx_underrun),
      .sample_sent_o   (tx_sample_sent),
      .stop_req_o      (tx_stop_req),
      .shift_dbg_o     (tx_shift_dbg),
      .state_dbg_o     (tx_state)
  );

  //---------------------------------------------------------------------------
  // Receive engine
  //---------------------------------------------------------------------------
  logic          rx_overrun, rx_sample_recv, rx_stop_req;
  logic [SW-1:0] rx_shift_dbg;
  logic [2:0]    rx_state;

  i2s_rx #(
      .SAMPLE_WIDTH_MAX (SAMPLE_WIDTH_MAX)
  ) u_rx (
      .clk_i          (clk_i),
      .rst_ni         (rst_ni),
      .run_i          (rx_run),
      .capture_en_i   (capture_en),
      .pos_valid_i    (rt_pos_valid),
      .pos_slot_i     (rt_pos_slot),
      .pos_bit_i      (rt_pos_bit),
      .sd_i           (sd_sync),
      .sample_width_i (cfg_sample_width),
      .slot_width_i   (cfg_slot_width),
      .format_i       (cfg_format),
      .mono_i         (cfg_mono),
      .swap_i         (cfg_swap),
      .sign_extend_i  (rx_sign_extend_i),
      .overrun_mode_i (overrun_mode_i),
      .mute_rx_i      (mute_global_i | mute_rx_i),
      .fifo_full_i    (rx_fifo_full_i),
      .fifo_push_o    (rx_fifo_push_o),
      .fifo_wdata_o   (rx_fifo_wdata_o),
      .inj_overrun_i  (inj_overrun),
      .data_bit_en_o  (rx_data_bit_en),
      .overrun_o      (rx_overrun),
      .sample_recv_o  (rx_sample_recv),
      .stop_req_o     (rx_stop_req),
      .shift_dbg_o    (rx_shift_dbg),
      .state_dbg_o    (rx_state)
  );

  //---------------------------------------------------------------------------
  // STOP policies and the clean-stop latch
  //---------------------------------------------------------------------------
  // A commit point is ONE frame boundary per frame, and in target mode it must
  // be a boundary the ENABLED directions have both passed.
  //
  // In target mode the two trackers are advanced by different strobes: the
  // transmit tracker by `launch_en` and the receive tracker by `capture_en`,
  // which in the default configuration (launch on the falling edge, sample on
  // the rising edge - specification section 17) are half an SCK period apart.
  // A launched bit is captured half a period later, so `tt_frame_end` always
  // PRECEDES `rt_frame_end` whenever the two differ.
  //
  // Taking the OR of the two was wrong in both directions of the requirement:
  //
  //   * Specification section 51 requires the commit to wait for a safe frame
  //     boundary and apply every field atomically.  The OR fired first at
  //     `tt_frame_end`, i.e. before the receiver had captured the last bit of
  //     the frame, so `active_q <= shadow_q` swapped sample width, sign
  //     extension, mono/swap mapping and slot width underneath a receive frame
  //     that was still in flight - tearing it, and able to move
  //     `last_bit_of_slot` under a running tracker and fabricate a WS/frame
  //     error.
  //   * Specification section 103 requires the frame counter to increment once
  //     per complete frame.  `frame_done` is also `ev_frame_done_o`, so in
  //     target full-duplex with split edges DEBUG_FRAME counted every frame
  //     twice and INT_STATUS.FRAME_DONE fired twice.
  //
  // Selecting the LATER of the two boundaries fixes both while keeping the
  // deadlock fix it was introduced for: with RX disabled the receive tracker is
  // held in reset and can never produce a boundary, so a target-mode TX-only
  // link takes `tt_frame_end` and an accepted configuration is no longer left
  // pending forever.
  logic frame_done;
  assign frame_done = ctrl_mode ? fg_frame_end : (rx_run ? rt_frame_end : tt_frame_end);

  // Deferred stop: keep SCK running to the end of the current frame when
  // GLOBAL_CTRL.STOP_AT_FRAME is set (specification section 45).
  //
  // Arming is EDGE triggered on the withdrawal of the run request, and it has
  // to be.  Armed on the level (`sck_running && !clk_run_req`), the latch
  // re-armed itself the cycle after it cleared: the generator only leaves the
  // running state at a falling SCK transition, so `sck_running` is still high
  // for up to a full SCK period after the frame boundary, and the level
  // condition was therefore still true.  SCK ran another frame, re-armed, and
  // never stopped at all - GLOBAL_STATUS.SCK_RUNNING stayed set indefinitely
  // whenever STOP_AT_FRAME was used.
  logic clk_run_req_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      tx_stopped_q  <= 1'b0;
      rx_stopped_q  <= 1'b0;
      stopping_q    <= 1'b0;
      clk_run_req_q <= 1'b0;
    end else begin
      clk_run_req_q <= clk_run_req;

      if (soft_reset_i || !tx_enable_i) tx_stopped_q <= 1'b0;
      else if (tx_stop_req)             tx_stopped_q <= 1'b1;

      if (soft_reset_i || !rx_enable_i) rx_stopped_q <= 1'b0;
      else if (rx_stop_req)             rx_stopped_q <= 1'b1;

      if (stopping_q) begin
        if (frame_done || clk_run_req) stopping_q <= 1'b0;
      end else if (sck_running && !clk_run_req && clk_run_req_q &&
                   stop_at_frame_i) begin
        stopping_q <= 1'b1;
      end
    end
  end

  //---------------------------------------------------------------------------
  // Clock monitor (specification sections 58 and 102)
  //---------------------------------------------------------------------------
  logic [15:0] per_cnt_q, per_meas_q;
  logic [15:0] ws_cnt_q,  ws_meas_q;
  logic        ws_meas_valid_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      per_cnt_q  <= 16'h0;
      per_meas_q <= 16'h0;
    end else if (sync_rise_en) begin
      per_meas_q <= per_cnt_q;
      per_cnt_q  <= 16'h1;
    end else if (per_cnt_q != 16'hFFFF) begin
      per_cnt_q  <= per_cnt_q + 16'h1;
    end
  end

  // SCK periods per WS period, counted between successive frame ends.
  logic frame_mark;
  assign frame_mark = rt_frame_end;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ws_cnt_q        <= 16'h0;
      ws_meas_q       <= 16'h0;
      ws_meas_valid_q <= 1'b0;
    end else if (!rx_run) begin
      ws_cnt_q        <= 16'h0;
      ws_meas_valid_q <= 1'b0;
    end else if (frame_mark) begin
      ws_meas_q       <= ws_cnt_q + 16'h1;
      ws_cnt_q        <= 16'h0;
      ws_meas_valid_q <= 1'b1;
    end else if (capture_en && (ws_cnt_q != 16'hFFFF)) begin
      ws_cnt_q        <= ws_cnt_q + 16'h1;
    end

  end

  logic [15:0] expect_sck_per_ws;
  logic [15:0] ws_now;
  logic [15:0] ws_delta;
  logic        clk_err;

  assign expect_sck_per_ws = 16'(I2S_NUM_SLOTS) * 16'(cfg_slot_width);

  // Grade the window that is closing AT THIS frame_mark, not the one stored by
  // the previous frame_mark.  `ws_cnt_q` starts counting when RX is enabled
  // rather than at a frame boundary, so the FIRST window is a partial WS period
  // and is one SCK short.  `ws_meas_valid_q` correctly suppresses the first
  // frame_mark, but the old form graded `ws_meas_q` - the value the first
  // frame_mark had just stored - at the SECOND frame_mark, so the partial
  // startup window was reported as a clock error on every otherwise perfect
  // link.  With the window that is closing, `ws_meas_valid_q` means exactly
  // "a previous frame_mark has been seen, so this window is a complete WS
  // period", which is the condition the check needs.
  assign ws_now = ws_cnt_q + 16'h1;
  assign ws_delta = (ws_now > expect_sck_per_ws) ? (ws_now - expect_sck_per_ws)
                                                 : (expect_sck_per_ws - ws_now);
  assign clk_err  = clk_mon_en_i & rx_run & frame_mark & ws_meas_valid_q &
                    (ws_delta > 16'(clk_tol_i));

  //---------------------------------------------------------------------------
  // The remaining two quantities of specification section 58: the WS period and
  // the SCK duty cycle.
  //
  // WS period is measured DIRECTLY, in PCLK cycles between successive frame
  // marks, rather than derived as SCK_PERIOD x SCK_PER_WS.  A direct count
  // costs one counter instead of a 16x16 multiplier and, more importantly, it
  // is an independent measurement: a disagreement between it and the product of
  // the other two is itself evidence of a malformed frame.  It is also
  // `actual_sample_rate` of section 102, in the same PCLK-cycles-per-frame
  // units as the configured value in SAMPLE_RATE_CFG, so software compares the
  // two directly and converts either with the f_pclk it already knows:
  //
  //     Fs = f_pclk / SAMPLE_RATE_ACT
  //
  // Duty cycle is measured as the two phase lengths separately rather than as a
  // percentage, because a percentage would need a divide and would throw away
  // the resolution the raw counts carry.
  //---------------------------------------------------------------------------
  logic [31:0] wsper_cnt_q, wsper_meas_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      wsper_cnt_q  <= 32'h0;
      wsper_meas_q <= 32'h0;
    end else if (!rx_run) begin
      wsper_cnt_q  <= 32'h0;
    end else if (frame_mark) begin
      if (ws_meas_valid_q) wsper_meas_q <= wsper_cnt_q + 32'h1;
      wsper_cnt_q <= 32'h0;
    end else if (wsper_cnt_q != 32'hFFFF_FFFF) begin
      wsper_cnt_q <= wsper_cnt_q + 32'h1;
    end
  end

  // The duty measurement is gated, and it has to be.  `sck_pad` is
  // `ctrl_mode ? sck_gen : sck_i`, and `sck_gen` is `cfg_sck_inv ^ sck_q`, so
  // a configuration commit that changes SCK_CTRL.INVERT while the generator is
  // PARKED flips the pad instantly.  The synchroniser sees that as an ordinary
  // transition, and an ungated phase counter measures the interval from that
  // fake edge to the next real one - which is not a phase of anything.  That is
  // exactly what it did: after a polarity change between two bursts the
  // measured high time was 2 PCLK cycles on a divider of 3.
  //
  // Two guards, both necessary:
  //   duty_en     only measure while the clock is genuinely toggling, which in
  //               controller mode is `sck_running`.  A parked generator cannot
  //               produce a real edge, so every edge seen while parked is an
  //               artefact of a register write.
  //   duty_seen_q never report the FIRST interval after the clock starts: the
  //               counter was reset at the start rather than at a transition,
  //               so that interval is a fragment of a phase, not a phase.
  //
  // The captured values HOLD while the clock is stopped, which is what makes
  // CLOCK_DUTY readable after a burst has finished.
  logic [15:0] phase_cnt_q, sck_high_q, sck_low_q;
  logic        duty_seen_q;
  logic        duty_en;

  assign duty_en = ctrl_mode ? sck_running : ip_enable_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      phase_cnt_q <= 16'h0;
      sck_high_q  <= 16'h0;
      sck_low_q   <= 16'h0;
      duty_seen_q <= 1'b0;
    end else if (!duty_en) begin
      phase_cnt_q <= 16'h0;
      duty_seen_q <= 1'b0;
    end else if (sync_rise_en) begin
      // The phase that just ended was the low one.
      if (duty_seen_q) sck_low_q <= phase_cnt_q + 16'h1;
      phase_cnt_q <= 16'h0;
      duty_seen_q <= 1'b1;
    end else if (sync_fall_en) begin
      if (duty_seen_q) sck_high_q <= phase_cnt_q + 16'h1;
      phase_cnt_q <= 16'h0;
      duty_seen_q <= 1'b1;
    end else if (phase_cnt_q != 16'hFFFF) begin
      phase_cnt_q <= phase_cnt_q + 16'h1;
    end
  end

  assign clk_sck_period_o = per_meas_q;
  assign clk_sck_per_ws_o = ws_meas_q;
  assign clk_ws_period_o  = wsper_meas_q;
  assign clk_sck_high_o   = sck_high_q;
  assign clk_sck_low_o    = sck_low_q;

  //---------------------------------------------------------------------------
  // Output pins
  //---------------------------------------------------------------------------
  always_comb begin
    if (test_sd_force_en_i)   sd_tx_pin = test_sd_force_val_i;
    else if (tx_run)          sd_tx_pin = tx_sd;
    else                      sd_tx_pin = SD_IDLE_LEVEL;
  end

  assign sck_o      = ctrl_mode ? sck_gen : cfg_sck_inv;
  assign ws_o       = ctrl_mode ? ws_gen  : cfg_ws_pol;
  assign sd_tx_o    = sd_tx_pin;
  assign mclk_o     = HAS_MCLK ? mclk_gen : 1'b0;

  assign sck_oe_o    = ctrl_mode & ip_enable_i;
  assign ws_oe_o     = ctrl_mode & ip_enable_i;
  assign sd_tx_oe_o  = ip_enable_i & (tx_enable_i | test_sd_force_en_i);
  assign mclk_oe_o   = HAS_MCLK ? cfg_mclk_en : 1'b0;

  //---------------------------------------------------------------------------
  // Events and status
  //---------------------------------------------------------------------------
  assign ev_tx_underrun_o = tx_underrun;
  assign ev_rx_overrun_o  = rx_overrun;
  assign ev_frame_err_o   = rt_frame_err | tt_frame_err;
  assign ev_ws_err_o      = rt_ws_err    | tt_ws_err;
  assign ev_clk_err_o     = clk_err;
  assign ev_frame_done_o  = frame_done;
  assign ev_tx_sample_o   = tx_sample_sent;
  assign ev_rx_sample_o   = rx_sample_recv;

  assign sts_tx_active_o   = tx_run;
  assign sts_rx_active_o   = rx_run;
  assign sts_sck_running_o = ctrl_mode ? sck_running : rt_synced;
  assign sts_tx_busy_o     = ctrl_mode ? (tx_run & fg_started) : (tx_run & tt_synced);
  assign sts_rx_busy_o     = rx_run & rt_synced;

  assign dbg_tx_state_o = tx_state;
  assign dbg_rx_state_o = rx_state;
  assign dbg_tx_slot_o  = ctrl_mode ? fg_slot : tt_slot;
  assign dbg_rx_slot_o  = rt_slot;
  assign dbg_tx_bit_o   = ctrl_mode ? fg_bit : tt_bit;
  assign dbg_rx_bit_o   = rt_bit;
  assign dbg_shift_o    = tx_shift_dbg;

  //---------------------------------------------------------------------------
  // Configuration commit, serial-domain side (specification section 51)
  //
  // `commit_point` is the same frame boundary the register block used to be
  // told about; it no longer leaves this module, because the apply happens
  // here.  `engine_idle` still permits an immediate apply while the link is
  // quiescent, which is what makes configuring a stopped IP take effect at once
  // instead of waiting for a frame that will never come.
  //
  // `cfg_consume_o` is the acknowledge edge of the four-phase handshake back to
  // PCLK: it means APPLIED, not ARRIVED, so CONFIG_STATUS.PENDING clears only
  // once the serial engine is really running the new configuration.
  //---------------------------------------------------------------------------
  logic commit_point, engine_idle;

  assign commit_point = frame_done;
  assign engine_idle  = ~sck_running & ~rt_synced & ~tt_synced;

  assign cfg_consume_o = cfg_valid_i & (commit_point | engine_idle);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      active_q <= i2s_cfg_reset_value(BW'(SAMPLE_WIDTH_MAX), BW'(SLOT_WIDTH_MAX));
    end else if (cfg_consume_o) begin
      active_q <= cfg_data_i;
    end
  end

  //---------------------------------------------------------------------------
  // Signals present for observability and assertions but not consumed here.
  //---------------------------------------------------------------------------
  logic unused_core;
  assign unused_core = ^{rx_shift_dbg, fg_slot_start, rt_slot_start,
                         prbs_rx_bit, prbs_tx_locked, prbs_tx_err, 1'b0};

endmodule : i2s_core

`default_nettype wire
