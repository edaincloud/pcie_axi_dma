//=============================================================================
// File        : i2s_track.sv
// Description : Frame position recovery from an observed WS / FS line.
//
//               This is the inverse of i2s_frame.  Given the synchronised WS
//               pin and a single-cycle SCK-edge strobe it recovers the
//               (slot, bit) position of the bit being processed at that
//               strobe, and reports the two framing errors of specification
//               section 57.
//
//               Recovery rule
//               -------------
//               i2s_frame changes WS exactly `ws_lead` SCK periods before the
//               MSB of the new slot.  Therefore, if a WS transition is
//               observed at strobe k, the MSB of the new slot is at strobe
//               k + ws_lead.  That single rule covers every supported format:
//
//                 I2S       ws_lead = 1 (the Philips one-clock delay)
//                 LEFT_J    ws_lead = 0
//                 RIGHT_J   ws_lead = 0 (the sample sits at the slot end)
//                 PCM_*     ws_lead as programmed, FS leading edge marks slot 0
//
//               Error reporting
//                 ws_err_o    : a WS/FS transition arrived at a bit position
//                               where none was expected (specification
//                               section 57 "unexpected WS transition")
//                 frame_err_o : a slot completed in a level-framed format
//                               without any WS transition (specification
//                               section 57 "incorrect slot length")
//
//               Port convention
//                 pos_* is the position of the bit being processed AT THIS
//                 strobe and is only meaningful while `strobe_i` is high.
//                 slot_o / bit_o are the registered copies, used for the
//                 DEBUG_STATE register.
//
//               Two instances exist in the design: one on the RX capture
//               strobe, and one on the TX launch strobe for target mode, where
//               the transmitter must follow an externally supplied frame.
//=============================================================================

`default_nettype none

module i2s_track
  import i2s_pkg::*;
(
    input  wire                          clk_i,
    input  wire                          rst_ni,

    input  wire                          run_i,       // engine active
    input  wire                          strobe_i,    // SCK edge strobe
    input  wire                          ws_i,        // synchronised WS/FS pin

    // ---- active configuration ----------------------------------------------
    input  wire  [I2S_WIDTH_FIELD_W-1:0] slot_width_i,
    input  wire  [I2S_DELAY_FIELD_W-1:0] ws_lead_i,
    input  wire  [2:0]                   format_i,
    input  wire                          ws_pol_i,

    // ---- recovered position -------------------------------------------------
    output logic                         synced_o,      // position established
    output logic                         pos_valid_o,   // pos_* valid AT THIS strobe
    output logic                         pos_slot_o,    // valid during strobe_i
    output logic [I2S_WIDTH_FIELD_W-1:0] pos_bit_o,     // valid during strobe_i
    output logic                         slot_o,        // registered copy
    output logic [I2S_WIDTH_FIELD_W-1:0] bit_o,         // registered copy
    output logic                         slot_start_o,  // strobe: pos_bit == 0
    output logic                         frame_end_o,   // strobe: last bit of frame

    // ---- framing errors -----------------------------------------------------
    output logic                         ws_err_o,
    output logic                         frame_err_o
);

  localparam int unsigned BW = I2S_WIDTH_FIELD_W;
  localparam int unsigned DW = I2S_DELAY_FIELD_W;

  // Polarity-normalised WS: 0 = slot 0 / FS inactive, 1 = slot 1 / FS active.
  logic ws_n;
  assign ws_n = ws_i ^ ws_pol_i;

  logic          ws_q;
  logic          slot_q;
  logic [BW-1:0] bit_q;
  logic          synced_q;
  logic          waiting_q;      // counting down ws_lead after a WS transition
  logic [DW-1:0] pre_q;
  logic          pend_slot_q;
  logic          edge_ok_q;      // a legal WS transition was seen in this slot

  logic level_fmt;
  assign level_fmt = (format_i == I2S_FMT_I2S) ||
                     (format_i == I2S_FMT_LEFT_J) ||
                     (format_i == I2S_FMT_RIGHT_J);

  // ---- transition detection ---------------------------------------------------
  logic ws_change, ws_rise, ws_event;
  assign ws_change = (ws_n != ws_q);
  assign ws_rise   = ws_n & ~ws_q;
  // Level formats re-frame on every transition; pulse formats only on the
  // leading edge of the frame sync.
  assign ws_event  = level_fmt ? ws_change : ws_rise;

  // ---- free-running next position ---------------------------------------------
  logic          nxt_slot;
  logic [BW-1:0] nxt_bit;
  logic          last_bit_of_slot;

  assign last_bit_of_slot = (bit_q >= (slot_width_i - BW'(1)));

  always_comb begin
    if (last_bit_of_slot) begin
      nxt_slot = ~slot_q;                  // I2S_NUM_SLOTS == 2
      nxt_bit  = '0;
    end else begin
      nxt_slot = slot_q;
      nxt_bit  = bit_q + BW'(1);
    end
  end

  // ---- expected WS transition position ---------------------------------------
  // The transition is expected at the free-running position
  // (slot_width - ws_lead) mod slot_width.
  logic [BW-1:0] exp_edge_bit;
  always_comb begin
    if ((BW'(ws_lead_i) == '0) || (BW'(ws_lead_i) >= slot_width_i)) begin
      exp_edge_bit = '0;
    end else begin
      exp_edge_bit = slot_width_i - BW'(ws_lead_i);
    end
  end

  // ---- framing decision ---------------------------------------------------------
  logic establish_now;   // this strobe carries bit 0 of a newly framed slot
  logic start_wait;      // this strobe begins a ws_lead countdown
  logic at_expected;
  logic new_slot_id;

  always_comb begin
    establish_now = 1'b0;
    start_wait    = 1'b0;
    at_expected   = 1'b0;

    if (ws_event) begin
      at_expected = synced_q && (nxt_bit == exp_edge_bit);
      if (DW'(ws_lead_i) == '0) establish_now = 1'b1;
      else                      start_wait    = 1'b1;
    end else if (waiting_q && (pre_q == '0)) begin
      establish_now = 1'b1;
    end
  end

  // Level formats name the slot directly; pulse formats always restart the
  // frame at slot 0.
  assign new_slot_id = ws_event ? (level_fmt ? ws_n : 1'b0) : pend_slot_q;

  // ---- position applying at this strobe ------------------------------------------
  logic          cur_slot;
  logic [BW-1:0] cur_bit;
  logic          synced_now;

  assign cur_slot   = establish_now ? new_slot_id : nxt_slot;
  assign cur_bit    = establish_now ? '0          : nxt_bit;
  assign synced_now = synced_q | establish_now;

  // A completed slot with no WS transition anywhere in it: the transmitter did
  // not delimit the slot, which is a frame error in a level format.
  logic wrap_now;
  assign wrap_now = synced_q && last_bit_of_slot && !establish_now;

  assign ws_err_o    = run_i & strobe_i & ws_event & synced_q & ~at_expected;
  assign frame_err_o = run_i & strobe_i & wrap_now & level_fmt &
                       ~(edge_ok_q | (ws_event & at_expected));

  //---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ws_q        <= 1'b0;
      slot_q      <= 1'b0;
      bit_q       <= '0;
      synced_q    <= 1'b0;
      waiting_q   <= 1'b0;
      pre_q       <= '0;
      pend_slot_q <= 1'b0;
      edge_ok_q   <= 1'b0;
    end else if (!run_i) begin
      ws_q        <= ws_n;
      slot_q      <= 1'b0;
      bit_q       <= '0;
      synced_q    <= 1'b0;
      waiting_q   <= 1'b0;
      pre_q       <= '0;
      pend_slot_q <= 1'b0;
      edge_ok_q   <= 1'b0;
    end else if (strobe_i) begin
      ws_q     <= ws_n;
      slot_q   <= cur_slot;
      bit_q    <= cur_bit;
      synced_q <= synced_now;

      if (ws_event) begin
        pend_slot_q <= new_slot_id;
        edge_ok_q   <= 1'b1;
      end else if (establish_now || wrap_now) begin
        edge_ok_q   <= 1'b0;
      end

      if (establish_now) begin
        waiting_q <= 1'b0;
      end else if (start_wait) begin
        waiting_q <= 1'b1;
        pre_q     <= ws_lead_i - DW'(1);
      end else if (waiting_q) begin
        pre_q     <= pre_q - DW'(1);
      end
    end
  end

  // Two different flags, deliberately.
  //
  //   synced_o     registered: "the recovery is framed", a STATUS fact.  It
  //                feeds GLOBAL_STATUS and the engine-idle handshake, both of
  //                which want a stable, glitch-free level.
  //   pos_valid_o  combinational: "pos_slot_o / pos_bit_o are meaningful at
  //                THIS strobe".  On the strobe that establishes the frame,
  //                pos_* is already bit 0 of the new slot, so a consumer of the
  //                position must accept it on that very strobe.
  //
  // The datapath used to take the registered flag, which declared that first
  // bit invalid: i2s_rx did not shift it in, and every burst lost the MSB of
  // its first framed slot - a sample that read back correctly whenever its true
  // MSB happened to be zero and wrong otherwise.  slot_start_o and frame_end_o
  // below were already qualified with synced_now; pos_valid_o makes the same
  // qualification available to the transmit and receive engines.
  assign synced_o     = synced_q;
  assign pos_valid_o  = synced_now;
  assign pos_slot_o   = cur_slot;
  assign pos_bit_o    = cur_bit;
  assign slot_o       = slot_q;
  assign bit_o        = bit_q;
  assign slot_start_o = run_i & strobe_i & synced_now & (cur_bit == '0);
  assign frame_end_o  = run_i & strobe_i & synced_now & (cur_slot == 1'b1) &
                        (cur_bit == (slot_width_i - BW'(1)));

endmodule : i2s_track

`default_nettype wire
