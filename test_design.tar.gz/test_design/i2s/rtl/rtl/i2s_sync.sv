//=============================================================================
// File        : i2s_sync.sv
// Description : Multi-stage flop synchroniser for signals crossing into the
//               `clk_i` domain from the asynchronous I2S serial-bus domain.
//
//               This cell is THE clock-domain crossing of this IP.  The serial
//               interface pins (SCK, WS, SD_RX) originate in an external
//               device whose clock has no defined phase relationship to PCLK
//               when the IP runs in target mode; every one of them enters the
//               design through an instance of this module and through nothing
//               else.
//
//               CDC contract (see the design specification, section
//               "Clock domain crossing"):
//                 - single-bit control/data lines only.  A multi-bit value is
//                   NEVER crossed through this cell as a vector: the three
//                   pins are independent one-bit signals whose relative skew
//                   after synchronisation is bounded by construction because
//                   every pin uses the same number of stages, and the
//                   receiving logic re-derives all timing from the
//                   synchronised SCK alone.
//                 - the destination logic must tolerate one destination-clock
//                   of jitter on the recovered edge, which it does: everything
//                   downstream is edge-triggered off the synchronised SCK.
//                 - the source must hold each level for at least two
//                   destination clocks.  That is the documented minimum
//                   oversampling requirement (f_pclk >= 8 x f_sck).
//
// Notes       : STAGES flops with no combinational logic between them, so a
//               CDC tool recognises the structure and an ASIC flow can swap in
//               a hardened synchroniser cell by replacing this file only.
//=============================================================================

`default_nettype none

module i2s_sync #(
    parameter int unsigned WIDTH  = 1,
    parameter int unsigned STAGES = 2,
    // Value the chain holds while reset is asserted.
    parameter bit          RESET_VALUE = 1'b0
) (
    input  wire              clk_i,
    input  wire              rst_ni,
    input  wire  [WIDTH-1:0] d_i,
    output logic [WIDTH-1:0] q_o
);

  if (STAGES < 2) begin : gen_chk_stages
    $error("i2s_sync: STAGES must be >= 2 (got %0d)", STAGES);
  end

  // Declared as an unpacked chain so that a CDC tool sees STAGES distinct
  // flop stages rather than one wide register.
  /* verilator lint_off SYNCASYNCNET */
  logic [WIDTH-1:0] sync_q [STAGES];
  /* verilator lint_on SYNCASYNCNET */

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      for (int unsigned s = 0; s < STAGES; s++) begin
        sync_q[s] <= {WIDTH{RESET_VALUE}};
      end
    end else begin
      sync_q[0] <= d_i;
      for (int unsigned s = 1; s < STAGES; s++) begin
        sync_q[s] <= sync_q[s-1];
      end
    end
  end

  assign q_o = sync_q[STAGES-1];

endmodule : i2s_sync

`default_nettype wire
