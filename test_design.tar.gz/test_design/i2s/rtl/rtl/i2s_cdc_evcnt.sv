//=============================================================================
// File        : i2s_cdc_evcnt.sv
// Description : Exact event-count crossing.
//
//               Why the toggle synchroniser is not good enough here
//               --------------------------------------------------
//               The saturating counters of specification sections 103 and 104
//               must report the NUMBER of events, so an event that the crossing
//               drops is a wrong answer in a diagnostic register rather than a
//               tolerable jitter.  A toggle synchroniser (i2s_cdc_pulse) has a
//               round-trip bandwidth limit and drops the third pulse inside one
//               round trip.  Serial-domain events can be that dense: with
//               SLOT_WIDTH = 1 and SCK_DIVIDER = 1 a sample event occurs every
//               two serial clocks, which is far faster than a pclk round trip
//               when pclk is the slower clock.
//
//               Structure
//               ---------
//               The source keeps a small free-running wrap counter and exports
//               it Gray coded, so exactly one bit changes per event and any
//               destination sample is either the value before or the value
//               after an increment - never a value that never existed.  The
//               destination converts back to binary and takes the DIFFERENCE
//               from the value it last saw.  Nothing is lost by a late sample:
//               a sample that misses several increments simply returns a larger
//               difference next time.
//
//               Bandwidth
//               ---------
//               The only requirement is that the source counter does not wrap
//               unobserved, i.e. fewer than 2**WIDTH source events per
//               destination clock period.  With the default WIDTH of 4 that is
//               16 events per destination cycle; a source event needs at least
//               one source clock, so the requirement is satisfied by any
//               f_serial < 16 x f_pclk, which the clocking section of the
//               specification already bounds far more tightly.
//
//               Reset
//               -----
//               `dst_resync_i` suppresses the difference and re-baselines the
//               destination.  It is driven from the destination's view of
//               "the source domain is out of reset", so an asymmetric reset
//               release cannot fabricate a burst of counts out of the source
//               counter returning to zero.
//=============================================================================

`default_nettype none

module i2s_cdc_evcnt
  import i2s_pkg::*;
#(
    parameter int unsigned STAGES = 2,
    parameter int unsigned WIDTH  = I2S_EVDELTA_W
) (
    input  wire              src_clk_i,
    input  wire              src_rst_ni,
    input  wire              src_event_i,

    input  wire              dst_clk_i,
    input  wire              dst_rst_ni,
    // Hold the destination baseline equal to the observed count and report no
    // events.  Used while the source domain is known to be in reset.
    input  wire              dst_resync_i,
    output logic [WIDTH-1:0] dst_delta_o,
    output logic             dst_pulse_o
);

  if (STAGES < 2) begin : gen_chk_stages
    $error("i2s_cdc_evcnt: STAGES must be >= 2 (got %0d)", STAGES);
  end
  if ((WIDTH < 2) || (WIDTH > I2S_MAX_PTR_W)) begin : gen_chk_width
    $error("i2s_cdc_evcnt: WIDTH must be in [2:%0d] (got %0d)", I2S_MAX_PTR_W, WIDTH);
  end

  //---------------------------------------------------------------------------
  // Source: a Gray-coded free-running event counter.
  //---------------------------------------------------------------------------
  logic [WIDTH-1:0] bin_q, gray_q;
  logic [WIDTH-1:0] bin_next;

  assign bin_next = bin_q + WIDTH'(1);

  always_ff @(posedge src_clk_i or negedge src_rst_ni) begin
    if (!src_rst_ni) begin
      bin_q  <= '0;
      gray_q <= '0;
    end else if (src_event_i) begin
      bin_q  <= bin_next;
      gray_q <= WIDTH'(i2s_bin2gray(I2S_MAX_PTR_W'(bin_next)));
    end
  end

  //---------------------------------------------------------------------------
  // Destination: synchronise, convert, difference.
  //---------------------------------------------------------------------------
  logic [WIDTH-1:0] gray_s, bin_s, base_q;

  i2s_sync #(.WIDTH(WIDTH), .STAGES(STAGES)) u_gray_sync (
      .clk_i(dst_clk_i), .rst_ni(dst_rst_ni), .d_i(gray_q), .q_o(gray_s));

  assign bin_s = WIDTH'(i2s_gray2bin(I2S_MAX_PTR_W'(gray_s)));

  always_ff @(posedge dst_clk_i or negedge dst_rst_ni) begin
    if (!dst_rst_ni) base_q <= '0;
    else             base_q <= bin_s;
  end

  assign dst_delta_o = dst_resync_i ? WIDTH'(0) : (bin_s - base_q);
  assign dst_pulse_o = (dst_delta_o != WIDTH'(0));

endmodule : i2s_cdc_evcnt

`default_nettype wire
