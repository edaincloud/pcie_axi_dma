//=============================================================================
// File        : i2s_regs.sv
// Description : APB4 slave, register bank, shadow/active configuration,
//               event counters and interrupt block for the I2S IP.
//
//               Owns:
//                 - the APB4 protocol layer (zero wait state, PSTRB, PSLVERR)
//                 - every architectural register
//                 - the SHADOW copy of the timing-critical configuration and
//                   the commit engine that validates it and transfers it to
//                   the ACTIVE copy at a frame boundary (specification
//                   sections 51 and 52)
//                 - the saturating event counters (specification sections 103
//                   and 104)
//                 - the sticky interrupt block (specification section 55)
//
//               Does NOT own any serial timing state; that lives in i2s_core.
//               The only signals leaving this block towards the serial engine
//               are register outputs and decoded single-cycle pulses, every
//               one of which terminates on a flop inside i2s_core.  There is
//               therefore no combinational path from any APB input to sck_o,
//               ws_o or sd_o.
//
// APB4 behaviour:
//   PREADY  : tied high (zero wait state).
//   PSLVERR : asserted during the access phase for unmapped addresses,
//             misaligned addresses and writes to read-only registers.  No
//             functional state is modified for an erroring access.
//   PRDATA  : combinational read mux, zero for anything that is not a valid
//             read (unmapped, misaligned, reserved bits, write-only regs).
//   PSTRB   : honoured on every writable register.  Plain RW registers use a
//             read-modify-write merge; W1C and W1P fields use the raw strobed
//             write data so that unstrobed lanes are untouched.
//=============================================================================

`default_nettype none

module i2s_regs
  import i2s_pkg::*;
#(
    parameter int unsigned SAMPLE_WIDTH_MAX = 32,
    parameter int unsigned SLOT_WIDTH_MAX   = 32,
    parameter int unsigned TX_FIFO_DEPTH    = 8,
    parameter int unsigned RX_FIFO_DEPTH    = 8,
    parameter int unsigned DIV_WIDTH        = 8,
    parameter int unsigned CNT_WIDTH        = 16,
    parameter int unsigned APB_ADDR_WIDTH   = 12,
    parameter int unsigned APB_DATA_WIDTH   = 32
) (
    input  wire                             clk_i,
    input  wire                             rst_ni,

    // ------------------------------------------------------------------ APB4
    input  wire                             psel_i,
    input  wire                             penable_i,
    input  wire                             pwrite_i,
    input  wire  [APB_ADDR_WIDTH-1:0]       paddr_i,
    input  wire  [APB_DATA_WIDTH-1:0]       pwdata_i,
    input  wire  [APB_DATA_WIDTH/8-1:0]     pstrb_i,
    output logic [APB_DATA_WIDTH-1:0]       prdata_o,
    output logic                            pready_o,
    output logic                            pslverr_o,

    // ---------------------------------------------------- immediate controls
    output logic                            soft_reset_o,
    output logic                            ip_enable_o,
    output logic                            tx_enable_o,
    output logic                            rx_enable_o,
    output logic                            controller_en_o,
    output logic                            loopback_en_o,
    output logic                            mute_global_o,
    output logic                            dma_enable_o,
    output logic                            stop_at_frame_o,
    output logic [1:0]                      underrun_mode_o,
    output logic [1:0]                      overrun_mode_o,
    output logic                            rx_sign_extend_o,
    output logic                            mute_tx_o,
    output logic                            mute_rx_o,
    output logic                            mute_left_o,
    output logic                            mute_right_o,
    // Configured TX mute / MUTE-policy substitution value (section 37 offers
    // "0 or another configured mute value"; this is that value).
    output logic [SAMPLE_WIDTH_MAX-1:0]     mute_value_o,
    output logic                            tx_dma_en_o,
    output logic                            rx_dma_en_o,
    output logic                            clk_mon_en_o,
    output logic [7:0]                      clk_tol_o,

    // ---- configuration commit, source side of the crossing -------------------
    // `cfg_data_o` is the validated shadow copy.  `cfg_launch_o` starts the
    // four-phase transfer into the serial domain and `cfg_applied_i` reports
    // that the serial engine has ADOPTED it at one of its own frame boundaries.
    // There is deliberately no `commit_point` input any more: the frame
    // boundary lives in the serial domain and this block never sees it.
    output i2s_cfg_t                        cfg_data_o,
    output logic                            cfg_launch_o,
    input  wire                             cfg_busy_i,
    input  wire                             cfg_applied_i,

    // ---- FIFO interface (both FIFOs are asynchronous and live in i2s_top) ----
    // Every signal here is a PCLK-domain signal: the near side of the TX FIFO's
    // write port and of the RX FIFO's read port.  The far-domain flags reach
    // this block only through the pointer synchronisers inside i2s_fifo_async
    // and through i2s_cdc_pulse for the overflow event.
    output logic                            tx_push_o,
    output logic [SAMPLE_WIDTH_MAX-1:0]     tx_wdata_o,
    output logic                            tx_flush_o,
    output logic                            rx_pop_o,
    output logic                            rx_flush_o,
    output logic                            tx_almost_o,
    output logic                            rx_almost_o,

    input  wire  [15:0]                     tx_level_i,
    input  wire                             tx_empty_i,
    input  wire                             tx_full_i,
    input  wire                             tx_overflow_i,
    input  wire                             tx_flush_busy_i,
    input  wire  [15:0]                     rx_level_i,
    input  wire                             rx_empty_i,
    input  wire                             rx_full_i,
    input  wire                             rx_overflow_i,
    input  wire                             rx_flush_busy_i,
    input  wire  [SAMPLE_WIDTH_MAX-1:0]     rx_rdata_i,

    // ---- events from the serial engine --------------------------------------
    // Each is a COUNT of events observed since the previous PCLK cycle, not a
    // pulse: the crossing (i2s_cdc_evcnt) is exact, and a serial domain running
    // faster than PCLK can legitimately produce more than one event between two
    // PCLK edges.  A saturating counter adds the delta; a sticky interrupt bit
    // only needs to know whether it is non-zero.
    input  wire  [I2S_EVDELTA_W-1:0]        ev_tx_underrun_i,
    input  wire  [I2S_EVDELTA_W-1:0]        ev_rx_overrun_i,
    input  wire  [I2S_EVDELTA_W-1:0]        ev_frame_err_i,
    input  wire  [I2S_EVDELTA_W-1:0]        ev_ws_err_i,
    input  wire  [I2S_EVDELTA_W-1:0]        ev_clk_err_i,
    input  wire  [I2S_EVDELTA_W-1:0]        ev_frame_done_i,
    input  wire  [I2S_EVDELTA_W-1:0]        ev_tx_sample_i,
    input  wire  [I2S_EVDELTA_W-1:0]        ev_rx_sample_i,

    // ---- status from the serial engine --------------------------------------
    input  wire                             sts_tx_active_i,
    input  wire                             sts_rx_active_i,
    input  wire                             sts_sck_running_i,
    input  wire                             sts_tx_busy_i,
    input  wire                             sts_rx_busy_i,
    input  wire  [2:0]                      dbg_tx_state_i,
    input  wire  [2:0]                      dbg_rx_state_i,
    input  wire                             dbg_tx_slot_i,
    input  wire                             dbg_rx_slot_i,
    input  wire  [I2S_WIDTH_FIELD_W-1:0]    dbg_tx_bit_i,
    input  wire  [I2S_WIDTH_FIELD_W-1:0]    dbg_rx_bit_i,
    input  wire  [SAMPLE_WIDTH_MAX-1:0]     dbg_shift_i,
    input  wire  [15:0]                     clk_sck_period_i,
    input  wire  [15:0]                     clk_sck_per_ws_i,
    // Clock monitor, section 58: the WS period and both SCK phases, all in
    // PCLK cycles.  The WS period is also the measured (actual) sample rate in
    // the reciprocal representation of section 102.
    input  wire  [31:0]                     clk_ws_period_i,
    input  wire  [15:0]                     clk_sck_high_i,
    input  wire  [15:0]                     clk_sck_low_i,

    // ---- test and error injection --------------------------------------------
    output logic                            test_sd_force_en_o,
    output logic                            test_sd_force_val_o,
    output logic                            inj_en_o,
    output logic [I2S_EI_TYPE_W-1:0]        inj_type_o,
    output logic [7:0]                      inj_count_o,
    output logic [2:0]                      prbs_sel_o,
    output logic                            prbs_tx_en_o,
    output logic                            prbs_rx_en_o,
    output logic                            prbs_reseed_o,
    input  wire                             prbs_locked_i,
    input  wire  [15:0]                     prbs_err_cnt_i,

    // ---- interrupt -------------------------------------------------------------
    output logic                            irq_o
);

  localparam int unsigned SW = SAMPLE_WIDTH_MAX;
  localparam int unsigned BW = I2S_WIDTH_FIELD_W;
  localparam int unsigned DW = I2S_DELAY_FIELD_W;

  //---------------------------------------------------------------------------
  // APB phase decode
  //---------------------------------------------------------------------------
  logic apb_access, apb_write, apb_read;

  assign apb_access = psel_i & penable_i;
  assign apb_write  = apb_access &  pwrite_i;
  assign apb_read   = apb_access & ~pwrite_i;

  assign pready_o = 1'b1;

  logic [31:0] addr32;
  always_comb begin
    addr32 = '0;
    addr32[APB_ADDR_WIDTH-1:0] = paddr_i;
  end

  logic addr_aligned, addr_mapped, addr_valid, write_to_ro;

  assign addr_aligned = (paddr_i[1:0] == 2'b00);
  assign addr_mapped  = i2s_addr_is_valid(addr32);
  assign addr_valid   = addr_aligned & addr_mapped;
  assign write_to_ro  = i2s_addr_is_ro(addr32);

  assign pslverr_o = apb_access & (~addr_valid | (pwrite_i & write_to_ro));

  logic wr_en;
  assign wr_en = apb_write & addr_valid & ~write_to_ro;

  logic rd_en;
  assign rd_en = apb_read & addr_valid;

  //---------------------------------------------------------------------------
  // Byte-strobe handling.  Every register is a 32-bit register on a 4-byte
  // stride, so strobe bits above lane 3 are ignored by construction.
  //---------------------------------------------------------------------------
  logic [31:0] strb_mask, wdata32, wdata_strobed;

  always_comb begin
    for (int unsigned b = 0; b < 4; b++) begin
      strb_mask[b*8 +: 8] = {8{pstrb_i[b]}};
    end
  end

  assign wdata32       = pwdata_i[31:0];
  assign wdata_strobed = wdata32 & strb_mask;

  //---------------------------------------------------------------------------
  // Register storage - immediate-effect controls
  //---------------------------------------------------------------------------
  logic        ip_en_q, tx_en_q, rx_en_q, ctrl_en_q, lb_en_q, mute_q, dma_en_q;
  logic        stop_frame_q;
  logic [1:0]  undr_mode_q, ovr_mode_q;
  logic        rx_sext_q;
  logic        mute_tx_q, mute_rx_q, mute_l_q, mute_r_q;
  logic        tx_dma_q, rx_dma_q;
  logic        clk_mon_q;
  logic [7:0]  clk_tol_q;
  logic [15:0] tx_low_q, rx_high_q;
  logic [15:0] tx_empty_thr_q, rx_full_thr_q;
  logic [SW-1:0] mute_val_q;
  logic [31:0] rate_req_q;
  logic        sd_force_en_q, sd_force_val_q;
  logic        inj_en_q;
  logic [I2S_EI_TYPE_W-1:0] inj_type_q;
  logic [7:0]  inj_count_q;
  logic [2:0]  prbs_sel_q;
  logic        prbs_tx_q, prbs_rx_q;

  //---------------------------------------------------------------------------
  // Register storage - shadow and active configuration
  //---------------------------------------------------------------------------
  // The layout is i2s_pkg::i2s_cfg_t, because it is also the payload of the
  // PCLK -> serial-clock configuration crossing and all three of the register
  // block, i2s_cdc_data and i2s_core must agree on it bit for bit.
  //
  // `active_q` here is a MIRROR, not the configuration the serial engine is
  // running: the real active copy lives in i2s_core, on the serial clock.  This
  // copy exists so that GLOBAL_STATUS.TARGET_MODE reads back what was last
  // adopted, and it is updated only when the serial side acknowledges.
  i2s_cfg_t shadow_q, active_q;

  //---------------------------------------------------------------------------
  // Configuration validation (specification section 52).
  //
  // Evaluated combinationally on the SHADOW copy, so software can read
  // CONFIG_STATUS.ERROR_CODE after a rejected commit and know exactly which
  // rule it broke.
  //---------------------------------------------------------------------------
  logic [3:0] cfg_err_code;
  logic       cfg_illegal;

  // Frame period the requested configuration actually produces, in SERIAL
  // CLOCK cycles:  SCK half period = sck_div serial clocks, so one SCK period
  // is 2 x sck_div and a stereo frame is I2S_NUM_SLOTS x slot_width SCK
  // periods.
  //
  //     frame_sclk = 2 x sck_div x I2S_NUM_SLOTS x slot_width
  //
  // The arithmetic is unchanged from the single-clock revision; the UNIT is
  // not.  SCK_DIVIDER divides the serial clock, not PCLK, so every quantity
  // derived from it - this one, SAMPLE_RATE_ACT and the whole CLOCK_STATUS /
  // CLOCK_DUTY group - is now counted in serial clock cycles, and the sample
  // rate is
  //
  //     Fs = f_sclk / SAMPLE_RATE_CFG
  //
  // This is still the only representation the hardware can produce, because the
  // IP is not told either clock frequency in Hz; and because the measured value
  // in SAMPLE_RATE_ACT is counted on the same clock, the achievability check
  // below still compares like with like.
  logic [31:0] cfg_frame_sclk;
  assign cfg_frame_sclk = 32'(shadow_q.sck_div) * 32'(shadow_q.slot_width) *
                          32'(2 * I2S_NUM_SLOTS);

  always_comb begin
    cfg_err_code = I2S_CFGE_NONE;

    if ((shadow_q.sample_width == '0) ||
        (shadow_q.sample_width > BW'(SAMPLE_WIDTH_MAX))) begin
      cfg_err_code = I2S_CFGE_SAMPLE_W;
    end else if ((shadow_q.slot_width == '0) ||
                 (shadow_q.slot_width > BW'(SLOT_WIDTH_MAX))) begin
      cfg_err_code = I2S_CFGE_SLOT_W;
    end else if (shadow_q.sample_width > shadow_q.slot_width) begin
      cfg_err_code = I2S_CFGE_WIDTH_ORDER;
    end else if (BW'(shadow_q.ws_lead) >= shadow_q.slot_width) begin
      cfg_err_code = I2S_CFGE_DELAY;
    end else if (shadow_q.sck_div == '0) begin
      cfg_err_code = I2S_CFGE_DIVIDER;
    end else if (shadow_q.format > I2S_FMT_MAX) begin
      cfg_err_code = I2S_CFGE_FORMAT;
    end else if ((shadow_q.format == I2S_FMT_RIGHT_J) && (shadow_q.ws_lead != '0)) begin
      // Right justified places the sample at the END of the slot, so the WS
      // edge must coincide with the slot boundary.  A non-zero data delay is
      // not a valid combination rather than a silently ignored one.
      cfg_err_code = I2S_CFGE_RJ_DELAY;
    end else if (shadow_q.mclk_en && (shadow_q.mclk_div == '0)) begin
      cfg_err_code = I2S_CFGE_MCLK_DIV;
    end else if ((shadow_q.format == I2S_FMT_PCM_LONG) &&
                 ((shadow_q.fs_width == '0) ||
                  (shadow_q.fs_width > shadow_q.slot_width))) begin
      cfg_err_code = I2S_CFGE_FS_WIDTH;
    end else if ((rate_req_q != 32'h0) && (rate_req_q != cfg_frame_sclk)) begin
      // Specification section 52 "sample_rate achievable" and section 101:
      // a requested sample rate the configured clock cannot deliver is
      // rejected with CONFIG_ERROR rather than silently ignored.  A request of
      // zero means "do not check", which is the reset state.
      cfg_err_code = I2S_CFGE_RATE;
    end
  end

  assign cfg_illegal = (cfg_err_code != I2S_CFGE_NONE);

  //---------------------------------------------------------------------------
  // Commit engine (specification section 51)
  //---------------------------------------------------------------------------
  logic       cfg_active_q, cfg_pending_q, cfg_error_q;
  logic [3:0] cfg_code_q;
  logic       commit_req;
  logic       do_apply;
  logic       cfg_req_q;
  i2s_cfg_t   cfg_xfer_q;

  // "Applied" is now reported by the serial domain, not decided here.
  assign do_apply = cfg_applied_i;

  //---------------------------------------------------------------------------
  // Per-register write enables
  //---------------------------------------------------------------------------
  logic wr_gctrl, wr_txctrl, wr_rxctrl, wr_mode, wr_format, wr_sampw, wr_slotw;
  logic wr_chan, wr_clkctrl, wr_sckdiv, wr_mclk, wr_wsctrl, wr_sckctrl;
  logic wr_delay, wr_pad, wr_mutec, wr_lb, wr_dmac, wr_commit;
  logic wr_txfc, wr_rxfc, wr_thr, wr_thr2, wr_intst, wr_intmask, wr_inten;
  logic wr_txdata, wr_testc, wr_inj, wr_prbs, wr_rate, wr_muteval;

  assign wr_gctrl   = wr_en & (addr32 == I2S_ADDR_GLOBAL_CTRL);
  assign wr_txctrl  = wr_en & (addr32 == I2S_ADDR_TX_CTRL);
  assign wr_rxctrl  = wr_en & (addr32 == I2S_ADDR_RX_CTRL);
  assign wr_mode    = wr_en & (addr32 == I2S_ADDR_MODE_CTRL);
  assign wr_format  = wr_en & (addr32 == I2S_ADDR_FORMAT_CTRL);
  assign wr_sampw   = wr_en & (addr32 == I2S_ADDR_SAMPLE_WIDTH);
  assign wr_slotw   = wr_en & (addr32 == I2S_ADDR_SLOT_WIDTH);
  assign wr_chan    = wr_en & (addr32 == I2S_ADDR_CHANNEL_CTRL);
  assign wr_clkctrl = wr_en & (addr32 == I2S_ADDR_CLOCK_CTRL);
  assign wr_sckdiv  = wr_en & (addr32 == I2S_ADDR_SCK_DIVIDER);
  assign wr_mclk    = wr_en & (addr32 == I2S_ADDR_MCLK_CTRL);
  assign wr_wsctrl  = wr_en & (addr32 == I2S_ADDR_WS_CTRL);
  assign wr_sckctrl = wr_en & (addr32 == I2S_ADDR_SCK_CTRL);
  assign wr_delay   = wr_en & (addr32 == I2S_ADDR_DATA_DELAY);
  assign wr_pad     = wr_en & (addr32 == I2S_ADDR_PADDING_CTRL);
  assign wr_mutec   = wr_en & (addr32 == I2S_ADDR_MUTE_CTRL);
  assign wr_lb      = wr_en & (addr32 == I2S_ADDR_LOOPBACK_CTRL);
  assign wr_dmac    = wr_en & (addr32 == I2S_ADDR_DMA_CTRL);
  assign wr_commit  = wr_en & (addr32 == I2S_ADDR_CONFIG_COMMIT);
  assign wr_txfc    = wr_en & (addr32 == I2S_ADDR_TX_FIFO_CTRL);
  assign wr_rxfc    = wr_en & (addr32 == I2S_ADDR_RX_FIFO_CTRL);
  assign wr_thr     = wr_en & (addr32 == I2S_ADDR_FIFO_THRESHOLD);
  assign wr_thr2    = wr_en & (addr32 == I2S_ADDR_FIFO_THRESHOLD2);
  assign wr_rate    = wr_en & (addr32 == I2S_ADDR_SAMPLE_RATE_CFG);
  assign wr_muteval = wr_en & (addr32 == I2S_ADDR_MUTE_VALUE);
  assign wr_intst   = wr_en & (addr32 == I2S_ADDR_INT_STATUS);
  assign wr_intmask = wr_en & (addr32 == I2S_ADDR_INT_MASK);
  assign wr_inten   = wr_en & (addr32 == I2S_ADDR_INT_ENABLE);
  assign wr_txdata  = wr_en & (addr32 == I2S_ADDR_TX_DATA);
  assign wr_testc   = wr_en & (addr32 == I2S_ADDR_TEST_CTRL);
  assign wr_inj     = wr_en & (addr32 == I2S_ADDR_ERROR_INJECT_CTRL);
  assign wr_prbs    = wr_en & (addr32 == I2S_ADDR_PRBS_CTRL);

  assign commit_req = wr_commit & wdata_strobed[I2S_CMT_COMMIT_BIT];

  //---------------------------------------------------------------------------
  // Serial-domain events, reduced to "at least one happened this cycle".
  //
  // The counters below use the DELTA, so they stay exact; everything else here
  // is a sticky bit or an edge-triggered interrupt, for which "one or more" is
  // the whole question.
  //---------------------------------------------------------------------------
  // TX_SAMPLE and RX_SAMPLE have no sticky bit and no interrupt of their own -
  // they exist only to be counted - so only their deltas are used, further
  // down.
  logic ev_tx_underrun, ev_rx_overrun, ev_frame_err, ev_ws_err, ev_clk_err;
  logic ev_frame_done;

  assign ev_tx_underrun = (ev_tx_underrun_i != '0);
  assign ev_rx_overrun  = (ev_rx_overrun_i  != '0);
  assign ev_frame_err   = (ev_frame_err_i   != '0);
  assign ev_ws_err      = (ev_ws_err_i      != '0);
  assign ev_clk_err     = (ev_clk_err_i     != '0);
  assign ev_frame_done  = (ev_frame_done_i  != '0);

  //---------------------------------------------------------------------------
  // Sticky FIFO error flags and counters
  //---------------------------------------------------------------------------
  logic tx_ovf_q, tx_unf_q, rx_ovf_q, rx_unf_q;

  logic [CNT_WIDTH-1:0] cnt_tx_sample_q, cnt_rx_sample_q;
  logic [CNT_WIDTH-1:0] cnt_tx_undr_q,   cnt_rx_ovr_q;
  logic [CNT_WIDTH-1:0] cnt_frame_err_q, cnt_ws_err_q, cnt_sck_err_q;
  logic [CNT_WIDTH-1:0] cnt_frame_q;

  logic [I2S_INT_WIDTH-1:0] int_status_q, int_mask_q, int_enable_q;

  logic soft_reset_pulse, cnt_clear_pulse;
  assign soft_reset_pulse = wr_gctrl & wdata_strobed[I2S_GC_SOFT_RESET_BIT];
  assign cnt_clear_pulse  = wr_gctrl & wdata_strobed[I2S_GC_CNT_CLEAR_BIT];

  logic cnt_reset;
  assign cnt_reset = soft_reset_pulse | cnt_clear_pulse;

  //---------------------------------------------------------------------------
  // TX_DATA / RX_DATA
  //---------------------------------------------------------------------------
  logic rx_read_hit;
  assign rx_read_hit = rd_en & (addr32 == I2S_ADDR_RX_DATA);

  // A write presented while the FIFO is flushing is part of what the flush
  // discards, so it is not offered to the FIFO at all.  TX_FIFO_STATUS.FLUSH_BUSY
  // is how software avoids doing it; this is the hardware backstop.
  assign tx_push_o  = wr_txdata & ~tx_full_i & ~tx_flush_busy_i;
  assign tx_wdata_o = wdata32[SW-1:0];
  assign rx_pop_o   = rx_read_hit & ~rx_empty_i & ~rx_flush_busy_i;

  //---------------------------------------------------------------------------
  // Read mux.  Also supplies the "current value" used by the read-modify-write
  // merge, which is why the writable fields read back from their own storage.
  //---------------------------------------------------------------------------
  logic [31:0] reg_rdata;
  logic [31:0] rx_data_ext;

  // i2s_rx already extended the captured sample to SAMPLE_WIDTH_MAX bits
  // according to RX_CTRL.SIGN_EXTEND, so all that is left here is to widen it
  // to the 32-bit register.
  if (SAMPLE_WIDTH_MAX < 32) begin : gen_rx_data_ext
    always_comb begin
      rx_data_ext = 32'(rx_rdata_i);
      if (rx_sext_q && rx_rdata_i[SW-1]) rx_data_ext[31:SW] = '1;
    end
  end else begin : gen_rx_data_full
    assign rx_data_ext = 32'(rx_rdata_i);
  end

  always_comb begin
    reg_rdata = 32'h0;

    unique case (addr32)
      I2S_ADDR_ID      : reg_rdata = I2S_ID_VALUE;
      I2S_ADDR_VERSION : reg_rdata = I2S_VERSION_VALUE;

      I2S_ADDR_GLOBAL_CTRL : begin
        reg_rdata[I2S_GC_IP_ENABLE_BIT]     = ip_en_q;
        reg_rdata[I2S_GC_TX_ENABLE_BIT]     = tx_en_q;
        reg_rdata[I2S_GC_RX_ENABLE_BIT]     = rx_en_q;
        reg_rdata[I2S_GC_CONTROLLER_EN_BIT] = ctrl_en_q;
        reg_rdata[I2S_GC_LOOPBACK_EN_BIT]   = lb_en_q;
        reg_rdata[I2S_GC_MUTE_BIT]          = mute_q;
        reg_rdata[I2S_GC_DMA_ENABLE_BIT]    = dma_en_q;
        reg_rdata[I2S_GC_STOP_AT_FRAME_BIT] = stop_frame_q;
      end

      I2S_ADDR_GLOBAL_STATUS : begin
        reg_rdata[I2S_GS_TX_ACTIVE_BIT]   = sts_tx_active_i;
        reg_rdata[I2S_GS_RX_ACTIVE_BIT]   = sts_rx_active_i;
        reg_rdata[I2S_GS_SCK_RUNNING_BIT] = sts_sck_running_i;
        reg_rdata[I2S_GS_CFG_ACTIVE_BIT]  = cfg_active_q;
        reg_rdata[I2S_GS_CFG_ERROR_BIT]   = cfg_error_q;
        reg_rdata[I2S_GS_TX_BUSY_BIT]     = sts_tx_busy_i;
        reg_rdata[I2S_GS_RX_BUSY_BIT]     = sts_rx_busy_i;
        reg_rdata[I2S_GS_TARGET_MODE_BIT] = active_q.target;
      end

      I2S_ADDR_TX_CTRL : begin
        reg_rdata[I2S_TXC_UNDERRUN_LSB +: I2S_TXC_UNDERRUN_W] = undr_mode_q;
      end

      I2S_ADDR_RX_CTRL : begin
        reg_rdata[I2S_RXC_OVERRUN_LSB +: I2S_RXC_OVERRUN_W] = ovr_mode_q;
        reg_rdata[I2S_RXC_SIGN_EXTEND_BIT]                  = rx_sext_q;
      end

      I2S_ADDR_MODE_CTRL : begin
        reg_rdata[I2S_MC_TARGET_MODE_BIT] = shadow_q.target;
        reg_rdata[I2S_MC_TX_LAUNCH_BIT]   = shadow_q.launch_edge;
        reg_rdata[I2S_MC_RX_SAMPLE_BIT]   = shadow_q.sample_edge;
      end

      I2S_ADDR_FORMAT_CTRL : begin
        reg_rdata[I2S_FC_FORMAT_LSB +: I2S_FC_FORMAT_W] = shadow_q.format;
        reg_rdata[I2S_FC_WS_POL_BIT]                    = shadow_q.ws_pol;
      end

      I2S_ADDR_SAMPLE_WIDTH : reg_rdata[BW-1:0] = shadow_q.sample_width;
      I2S_ADDR_SLOT_WIDTH   : reg_rdata[BW-1:0] = shadow_q.slot_width;

      I2S_ADDR_CHANNEL_CTRL : begin
        reg_rdata[I2S_CC_MONO_LSB +: I2S_CC_MONO_W] = shadow_q.mono;
        reg_rdata[I2S_CC_CHAN_SWAP_BIT]             = shadow_q.swap;
      end

      I2S_ADDR_CLOCK_CTRL : begin
        reg_rdata[I2S_CK_MON_EN_BIT]     = clk_mon_q;
        reg_rdata[I2S_CK_TOL_LSB +: 8]   = clk_tol_q;
      end

      // configured_sample_rate (specification section 102), expressed as the
      // number of PCLK cycles in one audio frame: Fs = f_pclk / this.  A write
      // of zero disables the achievability check at commit.
      I2S_ADDR_SAMPLE_RATE_CFG : reg_rdata = rate_req_q;

      // actual_sample_rate (section 102) and the WS period (section 58), same
      // units, measured rather than requested.
      I2S_ADDR_SAMPLE_RATE_ACT : reg_rdata = clk_ws_period_i;

      // SCK duty cycle (section 58): the two phase lengths in PCLK cycles.
      I2S_ADDR_CLOCK_DUTY : begin
        reg_rdata[15:0]  = clk_sck_high_i;
        reg_rdata[31:16] = clk_sck_low_i;
      end

      I2S_ADDR_MUTE_VALUE : reg_rdata[SW-1:0] = mute_val_q;

      I2S_ADDR_SCK_DIVIDER : reg_rdata[DIV_WIDTH-1:0] = shadow_q.sck_div[DIV_WIDTH-1:0];

      I2S_ADDR_MCLK_CTRL : begin
        reg_rdata[I2S_MCK_EN_BIT]                    = shadow_q.mclk_en;
        reg_rdata[I2S_MCK_POL_BIT]                   = shadow_q.mclk_pol;
        reg_rdata[I2S_MCK_DIV_LSB +: DIV_WIDTH]      = shadow_q.mclk_div[DIV_WIDTH-1:0];
      end

      I2S_ADDR_WS_CTRL   : reg_rdata[I2S_WSC_FS_WIDTH_LSB +: BW] = shadow_q.fs_width;
      I2S_ADDR_SCK_CTRL  : reg_rdata[I2S_SCKC_INV_BIT]           = shadow_q.sck_inv;
      I2S_ADDR_DATA_DELAY: reg_rdata[DW-1:0]                     = shadow_q.ws_lead;

      I2S_ADDR_PADDING_CTRL :
        reg_rdata[I2S_PC_PAD_MODE_LSB +: I2S_PC_PAD_MODE_W] = shadow_q.pad_mode;

      I2S_ADDR_MUTE_CTRL : begin
        reg_rdata[I2S_MU_TX_BIT]    = mute_tx_q;
        reg_rdata[I2S_MU_RX_BIT]    = mute_rx_q;
        reg_rdata[I2S_MU_LEFT_BIT]  = mute_l_q;
        reg_rdata[I2S_MU_RIGHT_BIT] = mute_r_q;
      end

      I2S_ADDR_LOOPBACK_CTRL : reg_rdata[I2S_LB_ENABLE_BIT] = lb_en_q;

      I2S_ADDR_DMA_CTRL : begin
        reg_rdata[I2S_DMA_TX_EN_BIT] = tx_dma_q;
        reg_rdata[I2S_DMA_RX_EN_BIT] = rx_dma_q;
      end

      I2S_ADDR_CONFIG_STATUS : begin
        reg_rdata[I2S_CS_ACTIVE_BIT]   = cfg_active_q;
        reg_rdata[I2S_CS_PENDING_BIT]  = cfg_pending_q;
        reg_rdata[I2S_CS_ERROR_BIT]    = cfg_error_q;
        reg_rdata[I2S_CS_CODE_LSB +: 4] = cfg_code_q;
      end

      I2S_ADDR_TX_FIFO_STATUS : begin
        reg_rdata[I2S_FS_LEVEL_LSB +: 16] = tx_level_i;
        reg_rdata[I2S_FS_EMPTY_BIT]       = tx_empty_i;
        reg_rdata[I2S_FS_FULL_BIT]        = tx_full_i;
        reg_rdata[I2S_FS_ALMOST_BIT]      = tx_almost_o;
        reg_rdata[I2S_FS_OVERFLOW_BIT]    = tx_ovf_q;
        reg_rdata[I2S_FS_UNDERFLOW_BIT]   = tx_unf_q;
        reg_rdata[I2S_FS_FLUSH_BUSY_BIT]  = tx_flush_busy_i;
        reg_rdata[I2S_FS_DEPTH_LSB +: 8]  = 8'(TX_FIFO_DEPTH);
      end

      I2S_ADDR_RX_FIFO_STATUS : begin
        reg_rdata[I2S_FS_LEVEL_LSB +: 16] = rx_level_i;
        reg_rdata[I2S_FS_EMPTY_BIT]       = rx_empty_i;
        reg_rdata[I2S_FS_FULL_BIT]        = rx_full_i;
        reg_rdata[I2S_FS_ALMOST_BIT]      = rx_almost_o;
        reg_rdata[I2S_FS_OVERFLOW_BIT]    = rx_ovf_q;
        reg_rdata[I2S_FS_UNDERFLOW_BIT]   = rx_unf_q;
        reg_rdata[I2S_FS_FLUSH_BUSY_BIT]  = rx_flush_busy_i;
        reg_rdata[I2S_FS_DEPTH_LSB +: 8]  = 8'(RX_FIFO_DEPTH);
      end

      I2S_ADDR_FIFO_THRESHOLD : begin
        reg_rdata[I2S_FT_TX_LOW_LSB  +: 16] = tx_low_q;
        reg_rdata[I2S_FT_RX_HIGH_LSB +: 16] = rx_high_q;
      end

      I2S_ADDR_FIFO_THRESHOLD2 : begin
        reg_rdata[I2S_FT2_TX_EMPTY_LSB +: 16] = tx_empty_thr_q;
        reg_rdata[I2S_FT2_RX_FULL_LSB  +: 16] = rx_full_thr_q;
      end

      I2S_ADDR_INT_STATUS : reg_rdata[I2S_INT_WIDTH-1:0] = int_status_q;
      I2S_ADDR_INT_MASK   : reg_rdata[I2S_INT_WIDTH-1:0] = int_mask_q;
      I2S_ADDR_INT_ENABLE : reg_rdata[I2S_INT_WIDTH-1:0] = int_enable_q;

      I2S_ADDR_TX_SAMPLE_COUNT   : reg_rdata[CNT_WIDTH-1:0] = cnt_tx_sample_q;
      I2S_ADDR_RX_SAMPLE_COUNT   : reg_rdata[CNT_WIDTH-1:0] = cnt_rx_sample_q;
      I2S_ADDR_TX_UNDERRUN_COUNT : reg_rdata[CNT_WIDTH-1:0] = cnt_tx_undr_q;
      I2S_ADDR_RX_OVERRUN_COUNT  : reg_rdata[CNT_WIDTH-1:0] = cnt_rx_ovr_q;
      I2S_ADDR_FRAME_ERROR_COUNT : reg_rdata[CNT_WIDTH-1:0] = cnt_frame_err_q;
      I2S_ADDR_WS_ERROR_COUNT    : reg_rdata[CNT_WIDTH-1:0] = cnt_ws_err_q;
      I2S_ADDR_SCK_ERROR_COUNT   : reg_rdata[CNT_WIDTH-1:0] = cnt_sck_err_q;

      I2S_ADDR_CLOCK_STATUS : begin
        reg_rdata[15:0]  = clk_sck_period_i;
        reg_rdata[31:16] = clk_sck_per_ws_i;
      end

      I2S_ADDR_DEBUG_STATE : begin
        reg_rdata[2:0]    = dbg_tx_state_i;
        reg_rdata[6:4]    = dbg_rx_state_i;
        reg_rdata[8]      = dbg_tx_slot_i;
        reg_rdata[9]      = dbg_rx_slot_i;
        reg_rdata[16 +: BW] = dbg_tx_bit_i;
        reg_rdata[24 +: BW] = dbg_rx_bit_i;
      end

      I2S_ADDR_DEBUG_SHIFT : reg_rdata[SW-1:0]        = dbg_shift_i;
      I2S_ADDR_DEBUG_FRAME : reg_rdata[CNT_WIDTH-1:0] = cnt_frame_q;

      I2S_ADDR_DEBUG_ERROR : begin
        reg_rdata[3:0] = cfg_code_q;
        reg_rdata[8]   = int_status_q[I2S_INT_WS_ERROR_BIT];
        reg_rdata[9]   = int_status_q[I2S_INT_FRAME_ERROR_BIT];
        reg_rdata[10]  = int_status_q[I2S_INT_CLOCK_ERROR_BIT];
      end

      I2S_ADDR_RX_DATA : reg_rdata = rx_empty_i ? 32'h0 : rx_data_ext;

      I2S_ADDR_TEST_CTRL : begin
        reg_rdata[I2S_TC_SD_FORCE_EN_BIT]  = sd_force_en_q;
        reg_rdata[I2S_TC_SD_FORCE_VAL_BIT] = sd_force_val_q;
      end

      I2S_ADDR_ERROR_INJECT_CTRL : begin
        reg_rdata[I2S_EI_ENABLE_BIT]                = inj_en_q;
        reg_rdata[I2S_EI_TYPE_LSB +: I2S_EI_TYPE_W] = inj_type_q;
        reg_rdata[I2S_EI_COUNT_LSB +: 8]            = inj_count_q;
      end

      I2S_ADDR_PRBS_CTRL : begin
        reg_rdata[I2S_PR_SEL_LSB +: I2S_PR_SEL_W] = prbs_sel_q;
        reg_rdata[I2S_PR_TX_EN_BIT]               = prbs_tx_q;
        reg_rdata[I2S_PR_RX_EN_BIT]               = prbs_rx_q;
      end

      I2S_ADDR_TEST_STATUS : begin
        reg_rdata[I2S_TS_PRBS_LOCK_BIT]   = prbs_locked_i;
        reg_rdata[I2S_TS_PRBS_ERR_BIT]    = (prbs_err_cnt_i != 16'h0);
        reg_rdata[I2S_TS_ERRCNT_LSB +: 16] = prbs_err_cnt_i;
      end

      // Write-only registers and anything unmapped read as zero.
      default : reg_rdata = 32'h0;
    endcase
  end

  always_comb begin
    prdata_o = '0;
    if (rd_en) prdata_o[31:0] = reg_rdata;
  end

  logic [31:0] wdata_rmw;
  assign wdata_rmw = (wdata32 & strb_mask) | (reg_rdata & ~strb_mask);

  //---------------------------------------------------------------------------
  // Immediate-effect control registers
  //---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ip_en_q        <= 1'b0;
      tx_en_q        <= 1'b0;
      rx_en_q        <= 1'b0;
      ctrl_en_q      <= 1'b1;      // controller mode by default
      lb_en_q        <= 1'b0;
      mute_q         <= 1'b0;
      dma_en_q       <= 1'b0;
      stop_frame_q   <= 1'b0;
      undr_mode_q    <= I2S_UNDR_SEND_ZERO;
      ovr_mode_q     <= I2S_OVR_DROP_NEW;
      rx_sext_q      <= 1'b0;
      mute_tx_q      <= 1'b0;
      mute_rx_q      <= 1'b0;
      mute_l_q       <= 1'b0;
      mute_r_q       <= 1'b0;
      tx_dma_q       <= 1'b0;
      rx_dma_q       <= 1'b0;
      clk_mon_q      <= 1'b0;
      clk_tol_q      <= 8'd0;
      tx_low_q       <= 16'd1;
      rx_high_q      <= 16'(RX_FIFO_DEPTH - 1);
      // The reset values of the two structural thresholds reproduce the
      // structural conditions exactly: level <= 0 is "empty" and
      // level >= DEPTH is "full", so a driver that never writes
      // FIFO_THRESHOLD2 sees the section 33/35 behaviour unchanged.
      tx_empty_thr_q <= 16'd0;
      rx_full_thr_q  <= 16'(RX_FIFO_DEPTH);
      mute_val_q     <= '0;
      rate_req_q     <= 32'd0;
      sd_force_en_q  <= 1'b0;
      sd_force_val_q <= 1'b0;
      inj_en_q       <= 1'b0;
      inj_type_q     <= I2S_EINJ_BIT_FLIP;
      inj_count_q    <= 8'd0;
      prbs_sel_q     <= I2S_PRBS7;
      prbs_tx_q      <= 1'b0;
      prbs_rx_q      <= 1'b0;
    end else begin
      if (wr_gctrl) begin
        ip_en_q      <= wdata_rmw[I2S_GC_IP_ENABLE_BIT];
        tx_en_q      <= wdata_rmw[I2S_GC_TX_ENABLE_BIT];
        rx_en_q      <= wdata_rmw[I2S_GC_RX_ENABLE_BIT];
        ctrl_en_q    <= wdata_rmw[I2S_GC_CONTROLLER_EN_BIT];
        lb_en_q      <= wdata_rmw[I2S_GC_LOOPBACK_EN_BIT];
        mute_q       <= wdata_rmw[I2S_GC_MUTE_BIT];
        dma_en_q     <= wdata_rmw[I2S_GC_DMA_ENABLE_BIT];
        stop_frame_q <= wdata_rmw[I2S_GC_STOP_AT_FRAME_BIT];
      end
      if (wr_txctrl) begin
        undr_mode_q <= wdata_rmw[I2S_TXC_UNDERRUN_LSB +: I2S_TXC_UNDERRUN_W];
      end
      if (wr_rxctrl) begin
        ovr_mode_q <= wdata_rmw[I2S_RXC_OVERRUN_LSB +: I2S_RXC_OVERRUN_W];
        rx_sext_q  <= wdata_rmw[I2S_RXC_SIGN_EXTEND_BIT];
      end
      if (wr_clkctrl) begin
        clk_mon_q <= wdata_rmw[I2S_CK_MON_EN_BIT];
        clk_tol_q <= wdata_rmw[I2S_CK_TOL_LSB +: 8];
      end
      if (wr_mutec) begin
        mute_tx_q <= wdata_rmw[I2S_MU_TX_BIT];
        mute_rx_q <= wdata_rmw[I2S_MU_RX_BIT];
        mute_l_q  <= wdata_rmw[I2S_MU_LEFT_BIT];
        mute_r_q  <= wdata_rmw[I2S_MU_RIGHT_BIT];
      end
      // LOOPBACK_CTRL and GLOBAL_CTRL are two views of the same enable, so
      // they live at different addresses and their write enables are mutually
      // exclusive.
      if (wr_lb) begin
        lb_en_q <= wdata_rmw[I2S_LB_ENABLE_BIT];
      end
      if (wr_dmac) begin
        tx_dma_q <= wdata_rmw[I2S_DMA_TX_EN_BIT];
        rx_dma_q <= wdata_rmw[I2S_DMA_RX_EN_BIT];
      end
      if (wr_thr) begin
        tx_low_q  <= wdata_rmw[I2S_FT_TX_LOW_LSB  +: 16];
        rx_high_q <= wdata_rmw[I2S_FT_RX_HIGH_LSB +: 16];
      end
      if (wr_thr2) begin
        tx_empty_thr_q <= wdata_rmw[I2S_FT2_TX_EMPTY_LSB +: 16];
        rx_full_thr_q  <= wdata_rmw[I2S_FT2_RX_FULL_LSB  +: 16];
      end
      if (wr_rate)    rate_req_q <= wdata_rmw;
      if (wr_muteval) mute_val_q <= wdata_rmw[SW-1:0];
      if (wr_testc) begin
        sd_force_en_q  <= wdata_rmw[I2S_TC_SD_FORCE_EN_BIT];
        sd_force_val_q <= wdata_rmw[I2S_TC_SD_FORCE_VAL_BIT];
      end
      if (wr_inj) begin
        inj_en_q    <= wdata_rmw[I2S_EI_ENABLE_BIT];
        // The type is bounded here, exactly as PRBS_CTRL.SEL is, so that no
        // undefined encoding can ever reach the injection decoders: an
        // out-of-range write is ignored and the field keeps its previous value.
        if (wdata_rmw[I2S_EI_TYPE_LSB +: I2S_EI_TYPE_W] <= I2S_EINJ_MAX) begin
          inj_type_q <= wdata_rmw[I2S_EI_TYPE_LSB +: I2S_EI_TYPE_W];
        end
        inj_count_q <= wdata_rmw[I2S_EI_COUNT_LSB +: 8];
      end
      if (wr_prbs) begin
        // The selector is bounded here so that no illegal encoding can ever
        // reach i2s_prbs.
        if (wdata_rmw[I2S_PR_SEL_LSB +: I2S_PR_SEL_W] <= I2S_PRBS_MAX) begin
          prbs_sel_q <= wdata_rmw[I2S_PR_SEL_LSB +: I2S_PR_SEL_W];
        end
        prbs_tx_q <= wdata_rmw[I2S_PR_TX_EN_BIT];
        prbs_rx_q <= wdata_rmw[I2S_PR_RX_EN_BIT];
      end

      if (soft_reset_pulse) begin
        tx_en_q  <= 1'b0;
        rx_en_q  <= 1'b0;
        ip_en_q  <= 1'b0;
      end
    end
  end

  //---------------------------------------------------------------------------
  // Shadow configuration registers
  //---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      shadow_q <= i2s_cfg_reset_value(BW'(SAMPLE_WIDTH_MAX), BW'(SLOT_WIDTH_MAX));
    end else begin
      if (wr_mode) begin
        shadow_q.target      <= wdata_rmw[I2S_MC_TARGET_MODE_BIT];
        shadow_q.launch_edge <= wdata_rmw[I2S_MC_TX_LAUNCH_BIT];
        shadow_q.sample_edge <= wdata_rmw[I2S_MC_RX_SAMPLE_BIT];
      end
      if (wr_format) begin
        shadow_q.format <= wdata_rmw[I2S_FC_FORMAT_LSB +: I2S_FC_FORMAT_W];
        shadow_q.ws_pol <= wdata_rmw[I2S_FC_WS_POL_BIT];
      end
      if (wr_sampw)  shadow_q.sample_width <= wdata_rmw[BW-1:0];
      if (wr_slotw)  shadow_q.slot_width   <= wdata_rmw[BW-1:0];
      if (wr_chan) begin
        shadow_q.mono <= wdata_rmw[I2S_CC_MONO_LSB +: I2S_CC_MONO_W];
        shadow_q.swap <= wdata_rmw[I2S_CC_CHAN_SWAP_BIT];
      end
      if (wr_sckdiv) shadow_q.sck_div <= I2S_MAX_DIV_WIDTH'(wdata_rmw[DIV_WIDTH-1:0]);
      if (wr_mclk) begin
        shadow_q.mclk_en  <= wdata_rmw[I2S_MCK_EN_BIT];
        shadow_q.mclk_pol <= wdata_rmw[I2S_MCK_POL_BIT];
        shadow_q.mclk_div <= I2S_MAX_DIV_WIDTH'(wdata_rmw[I2S_MCK_DIV_LSB +: DIV_WIDTH]);
      end
      if (wr_wsctrl)  shadow_q.fs_width <= wdata_rmw[I2S_WSC_FS_WIDTH_LSB +: BW];
      if (wr_sckctrl) shadow_q.sck_inv  <= wdata_rmw[I2S_SCKC_INV_BIT];
      if (wr_delay)   shadow_q.ws_lead  <= wdata_rmw[DW-1:0];
      if (wr_pad)     shadow_q.pad_mode <= wdata_rmw[I2S_PC_PAD_MODE_LSB +: I2S_PC_PAD_MODE_W];
    end
  end

  //---------------------------------------------------------------------------
  // Active configuration and the commit engine
  //---------------------------------------------------------------------------
  // The transfer payload is captured AT THE COMMIT, from the same shadow copy
  // the validator has just graded.  The single-clock revision applied
  // `shadow_q` at the apply instant instead, so a shadow write landing between
  // the commit and the apply could put an unvalidated field into the active
  // configuration; capturing here closes that as well as giving the crossing a
  // payload that is stable by construction.
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      active_q      <= i2s_cfg_reset_value(BW'(SAMPLE_WIDTH_MAX), BW'(SLOT_WIDTH_MAX));
      cfg_xfer_q    <= i2s_cfg_reset_value(BW'(SAMPLE_WIDTH_MAX), BW'(SLOT_WIDTH_MAX));
      cfg_active_q  <= 1'b1;
      cfg_pending_q <= 1'b0;
      cfg_error_q   <= 1'b0;
      cfg_code_q    <= I2S_CFGE_NONE;
      cfg_req_q     <= 1'b0;
    end else begin
      if (cfg_launch_o) cfg_req_q <= 1'b0;

      if (commit_req) begin
        if (cfg_illegal) begin
          // Reject: the previous valid configuration is retained untouched
          // (specification section 107).
          cfg_error_q   <= 1'b1;
          cfg_code_q    <= cfg_err_code;
          cfg_pending_q <= 1'b0;
        end else begin
          cfg_error_q   <= 1'b0;
          cfg_code_q    <= I2S_CFGE_NONE;
          cfg_pending_q <= 1'b1;
          cfg_active_q  <= 1'b0;
          cfg_xfer_q    <= shadow_q;
          cfg_req_q     <= 1'b1;
        end
      end else if (do_apply && !cfg_req_q) begin
        // ... and only when no FURTHER transfer is still waiting to be
        // launched.  Two `CONFIG_COMMIT` writes closer together than one round
        // trip produce two transfers, and the first one's completion must not
        // be reported as the second one's: doing so would set
        // CONFIG_STATUS.ACTIVE, and update the mirror to the second
        // configuration, while the serial engine was still running the first.
        active_q      <= cfg_xfer_q;
        cfg_pending_q <= 1'b0;
        cfg_active_q  <= 1'b1;
      end
    end
  end

  // One launch pulse per accepted commit.  The request is held until the
  // crossing is idle, so a commit issued while a previous transfer is still in
  // flight is not silently dropped - which is what a bare pulse into a busy
  // handshake would do.
  assign cfg_launch_o = cfg_req_q & ~cfg_busy_i;
  assign cfg_data_o   = cfg_xfer_q;

  //---------------------------------------------------------------------------
  // Sticky FIFO error flags
  //---------------------------------------------------------------------------
  logic tx_wr_when_full, rx_rd_when_empty;
  assign tx_wr_when_full  = wr_txdata   & tx_full_i;
  assign rx_rd_when_empty = rx_read_hit & rx_empty_i;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      tx_ovf_q <= 1'b0;
      tx_unf_q <= 1'b0;
      rx_ovf_q <= 1'b0;
      rx_unf_q <= 1'b0;
    end else begin
      if (tx_overflow_i | tx_wr_when_full) tx_ovf_q <= 1'b1;
      else if (wr_txfc && wdata_strobed[I2S_FC_CLR_STICKY_BIT]) tx_ovf_q <= 1'b0;

      if (ev_tx_underrun) tx_unf_q <= 1'b1;
      else if (wr_txfc && wdata_strobed[I2S_FC_CLR_STICKY_BIT]) tx_unf_q <= 1'b0;

      if (rx_overflow_i) rx_ovf_q <= 1'b1;
      else if (wr_rxfc && wdata_strobed[I2S_FC_CLR_STICKY_BIT]) rx_ovf_q <= 1'b0;

      if (rx_rd_when_empty) rx_unf_q <= 1'b1;
      else if (wr_rxfc && wdata_strobed[I2S_FC_CLR_STICKY_BIT]) rx_unf_q <= 1'b0;
    end
  end

  assign tx_flush_o = soft_reset_pulse |
                      (wr_txfc & wdata_strobed[I2S_FC_FLUSH_BIT]);
  assign rx_flush_o = soft_reset_pulse |
                      (wr_rxfc & wdata_strobed[I2S_FC_FLUSH_BIT]);

  //---------------------------------------------------------------------------
  // Saturating event counters (specification sections 103 and 104).
  //
  // Saturating rather than wrapping: a wrapped counter reports a small number
  // after a long error burst, which is exactly the wrong answer for a
  // diagnostic register.  CNT_WIDTH is a parameter so that a narrow build can
  // actually reach the top of the range in a regression.
  //---------------------------------------------------------------------------
  localparam logic [CNT_WIDTH-1:0] CNT_MAX = {CNT_WIDTH{1'b1}};

  // The increment is the DELTA reported by the crossing, not one.  A serial
  // clock faster than PCLK can produce several events between two PCLK edges,
  // and adding one per PCLK cycle would under-count exactly when the counters
  // matter most.  The addition is done one bit wider so the carry out of the
  // top selects saturation rather than wrapping.
  `define I2S_SAT_CNT(reg_q, delta)                                          \
      always_ff @(posedge clk_i or negedge rst_ni) begin                      \
        logic [CNT_WIDTH:0] sum;                                              \
        sum = {1'b0, reg_q} + {{CNT_WIDTH+1-I2S_EVDELTA_W{1'b0}}, (delta)};   \
        if (!rst_ni)              reg_q <= '0;                                \
        else if (cnt_reset)       reg_q <= '0;                                \
        else if ((delta) != '0)   reg_q <= sum[CNT_WIDTH] ? CNT_MAX           \
                                                          : sum[CNT_WIDTH-1:0]; \
      end

  `I2S_SAT_CNT(cnt_tx_sample_q, ev_tx_sample_i)
  `I2S_SAT_CNT(cnt_rx_sample_q, ev_rx_sample_i)
  `I2S_SAT_CNT(cnt_tx_undr_q,   ev_tx_underrun_i)
  `I2S_SAT_CNT(cnt_rx_ovr_q,    ev_rx_overrun_i)
  `I2S_SAT_CNT(cnt_frame_err_q, ev_frame_err_i)
  `I2S_SAT_CNT(cnt_ws_err_q,    ev_ws_err_i)
  `I2S_SAT_CNT(cnt_sck_err_q,   ev_clk_err_i)
  `I2S_SAT_CNT(cnt_frame_q,     ev_frame_done_i)

  `undef I2S_SAT_CNT

  //---------------------------------------------------------------------------
  // Interrupts (specification section 55).
  //
  // Every status bit is sticky and write-one-to-clear.  Level conditions
  // (FIFO empty / full / threshold) are edge detected so that a standing
  // condition does not make its own status bit impossible to clear.
  //---------------------------------------------------------------------------
  // All four thresholds of specification section 34 drive interrupts:
  //   TX_LOW_THRESHOLD    -> tx_almost_i     (FIFO_THRESHOLD.TX_LOW)
  //   TX_EMPTY_THRESHOLD  -> tx_empty_cond   (FIFO_THRESHOLD2.TX_EMPTY)
  //   RX_HIGH_THRESHOLD   -> rx_almost_i     (FIFO_THRESHOLD.RX_HIGH)
  //   RX_FULL_THRESHOLD   -> rx_full_cond    (FIFO_THRESHOLD2.RX_FULL)
  //
  // The two structural flags tx_empty_i / rx_full_i still govern the FIFO's own
  // push and pop decisions and are still what TX_FIFO_STATUS / RX_FIFO_STATUS
  // report; only the INTERRUPT condition is programmable.  At the reset
  // thresholds the two are identical.
  logic tx_empty_cond, rx_full_cond;
  assign tx_empty_cond = (tx_level_i <= tx_empty_thr_q);
  assign rx_full_cond  = (rx_level_i >= rx_full_thr_q);

  // The two programmable "almost" flags are evaluated here rather than inside
  // the FIFO, because the FIFO is now asynchronous and each level is only
  // meaningful in the domain that produced it.  Both of these levels are the
  // PCLK-side view - the TX write port and the RX read port - which is exactly
  // the side the DMA request and the interrupt belong to.
  assign tx_almost_o = (tx_level_i <= tx_low_q);
  assign rx_almost_o = (rx_level_i >= rx_high_q);

  logic tx_empty_q, tx_almost_q, rx_full_q, rx_almost_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      tx_empty_q  <= 1'b1;
      tx_almost_q <= 1'b1;
      rx_full_q   <= 1'b0;
      rx_almost_q <= 1'b0;
    end else begin
      tx_empty_q  <= tx_empty_cond;
      tx_almost_q <= tx_almost_o;
      rx_full_q   <= rx_full_cond;
      rx_almost_q <= rx_almost_o;
    end
  end

  // DMA_ERROR (section 55): the DMA path failed to keep up.  A transmit
  // underrun with TX DMA enabled, or a receive overrun with RX DMA enabled, is
  // a failure of the DMA engine rather than of software, and it is what a DMA
  // engine's error handler needs to distinguish from a software-fed stall.
  logic dma_err;
  assign dma_err = (dma_en_q & tx_dma_q & ev_tx_underrun) |
                   (dma_en_q & rx_dma_q & ev_rx_overrun);

  // FATAL_ERROR (sections 55 and 56): the OR of every condition section 56
  // classifies as FATAL.  Its table names two - "Clock failure" and "Internal
  // FSM error" - and only the first is producible here: the transmit and
  // receive "states" reported in DEBUG_STATE are decoded combinationally from
  // live conditions, so there is no state register that can be corrupted.
  logic fatal_err;
  assign fatal_err = ev_clk_err;

  logic [I2S_INT_WIDTH-1:0] int_set;

  always_comb begin
    int_set = '0;
    int_set[I2S_INT_TX_EMPTY_BIT]        = tx_empty_cond & ~tx_empty_q;
    int_set[I2S_INT_TX_ALMOST_EMPTY_BIT] = tx_almost_o & ~tx_almost_q;
    int_set[I2S_INT_TX_UNDERRUN_BIT]     = ev_tx_underrun;
    int_set[I2S_INT_RX_FULL_BIT]         = rx_full_cond & ~rx_full_q;
    int_set[I2S_INT_RX_ALMOST_FULL_BIT]  = rx_almost_o & ~rx_almost_q;
    int_set[I2S_INT_RX_OVERRUN_BIT]      = ev_rx_overrun;
    int_set[I2S_INT_FRAME_ERROR_BIT]     = ev_frame_err;
    int_set[I2S_INT_WS_ERROR_BIT]        = ev_ws_err;
    int_set[I2S_INT_CLOCK_ERROR_BIT]     = ev_clk_err;
    int_set[I2S_INT_CONFIG_ERROR_BIT]    = commit_req & cfg_illegal;
    int_set[I2S_INT_CONFIG_DONE_BIT]     = do_apply;
    int_set[I2S_INT_FRAME_DONE_BIT]      = ev_frame_done;
    int_set[I2S_INT_DMA_ERROR_BIT]       = dma_err;
    int_set[I2S_INT_FATAL_ERROR_BIT]     = fatal_err;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      int_status_q <= '0;
    end else if (soft_reset_pulse) begin
      int_status_q <= '0;
    end else begin
      for (int unsigned i = 0; i < I2S_INT_WIDTH; i++) begin
        // Hardware set wins over a simultaneous software clear, so an event
        // can never be lost.
        if (int_set[i]) begin
          int_status_q[i] <= 1'b1;
        end else if (wr_intst && wdata_strobed[i]) begin
          int_status_q[i] <= 1'b0;
        end
      end
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      int_mask_q   <= '0;
      int_enable_q <= '0;
    end else begin
      if (wr_intmask) int_mask_q   <= wdata_rmw[I2S_INT_WIDTH-1:0];
      if (wr_inten)   int_enable_q <= wdata_rmw[I2S_INT_WIDTH-1:0];
    end
  end

  // INT_ENABLE selects which sources contribute; INT_MASK suppresses them.
  // Both are kept because specification section 47 lists both registers.
  assign irq_o = |(int_status_q & int_enable_q & ~int_mask_q);

  //---------------------------------------------------------------------------
  // Outputs
  //---------------------------------------------------------------------------
  assign soft_reset_o     = soft_reset_pulse;
  assign ip_enable_o      = ip_en_q;
  assign tx_enable_o      = tx_en_q;
  assign rx_enable_o      = rx_en_q;
  assign controller_en_o  = ctrl_en_q;
  assign loopback_en_o    = lb_en_q;
  assign mute_global_o    = mute_q;
  assign dma_enable_o     = dma_en_q;
  assign stop_at_frame_o  = stop_frame_q;
  assign underrun_mode_o  = undr_mode_q;
  assign overrun_mode_o   = ovr_mode_q;
  assign rx_sign_extend_o = rx_sext_q;
  assign mute_tx_o        = mute_tx_q;
  assign mute_rx_o        = mute_rx_q;
  assign mute_left_o      = mute_l_q;
  assign mute_right_o     = mute_r_q;
  assign mute_value_o     = mute_val_q;
  assign tx_dma_en_o      = tx_dma_q;
  assign rx_dma_en_o      = rx_dma_q;
  assign clk_mon_en_o     = clk_mon_q;
  assign clk_tol_o        = clk_tol_q;

  assign test_sd_force_en_o  = sd_force_en_q;
  assign test_sd_force_val_o = sd_force_val_q;
  assign inj_en_o            = inj_en_q;
  assign inj_type_o          = inj_type_q;
  assign inj_count_o         = inj_count_q;
  assign prbs_sel_o          = prbs_sel_q;
  assign prbs_tx_en_o        = prbs_tx_q;
  assign prbs_rx_en_o        = prbs_rx_q;
  assign prbs_reseed_o       = wr_prbs & wdata_strobed[I2S_PR_RESEED_BIT];

  //---------------------------------------------------------------------------
  // Unused signal absorption (legal but unused bits and lanes).
  //---------------------------------------------------------------------------
  logic unused_regs;
  // `active_q` is the PCLK mirror of the configuration the serial engine has
  // adopted.  Only TARGET_MODE is read back from it (GLOBAL_STATUS), so the
  // remaining fields exist to make the mirror a faithful copy and are absorbed
  // here rather than being dropped from the type - dropping them would make the
  // mirror silently partial.
  assign unused_regs = ^{pwdata_i, pstrb_i, paddr_i, prbs_locked_i,
                         active_q, 1'b0};

endmodule : i2s_regs

`default_nettype wire
