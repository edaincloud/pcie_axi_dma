//=============================================================================
// File        : i2s_cdc_pulse.sv
// Description : Single-cycle pulse crossing by toggle synchroniser, with a
//               one-deep pending slot and a round-trip busy indication.
//
//               A pulse cannot be synchronised directly: it may be shorter
//               than a destination clock period and would then be missed
//               entirely.  What crosses instead is a LEVEL - a toggle flop that
//               changes state once per pulse - and the destination recovers the
//               pulse from the edge of the synchronised toggle.  A level is
//               safe to synchronise because it is held until the next event.
//
//               Flow control
//               ------------
//               The destination's view of the toggle is echoed back through a
//               second synchroniser, so the source knows when the pulse has
//               been observed.  A pulse presented while a previous one is still
//               in flight is held in `pend_q` and launched as soon as the
//               channel frees, so two pulses arbitrarily close together are
//               both delivered.  A third inside the same round trip is dropped
//               and `src_busy_o` is high while that is possible.
//
//               This module is therefore used ONLY for events whose
//               destination effect is idempotent or sticky - a soft reset, a
//               PRBS reseed, a FIFO flush request, a sticky status bit.  Event
//               counting uses i2s_cdc_evcnt instead, which is exact.
//
// Notes       : `src_pulse_i` must be a single-cycle source-domain pulse.
//=============================================================================

`default_nettype none

module i2s_cdc_pulse #(
    parameter int unsigned STAGES = 2
) (
    input  wire  src_clk_i,
    input  wire  src_rst_ni,
    input  wire  src_pulse_i,
    output logic src_busy_o,

    input  wire  dst_clk_i,
    input  wire  dst_rst_ni,
    output logic dst_pulse_o
);

  if (STAGES < 2) begin : gen_chk_stages
    $error("i2s_cdc_pulse: STAGES must be >= 2 (got %0d)", STAGES);
  end

  //---------------------------------------------------------------------------
  // Source: toggle on every accepted pulse.
  //---------------------------------------------------------------------------
  logic tog_q, pend_q, echo_s, inflight;

  assign inflight = (tog_q != echo_s);

  always_ff @(posedge src_clk_i or negedge src_rst_ni) begin
    if (!src_rst_ni) begin
      tog_q  <= 1'b0;
      pend_q <= 1'b0;
    end else if (!inflight && (src_pulse_i || pend_q)) begin
      tog_q  <= ~tog_q;
      // A new pulse arriving on the very cycle the pending one is launched is
      // kept, so neither is lost.
      pend_q <= src_pulse_i & pend_q;
    end else if (src_pulse_i) begin
      pend_q <= 1'b1;
    end
  end

  assign src_busy_o = inflight | pend_q;

  //---------------------------------------------------------------------------
  // Destination: recover the pulse from the toggle edge.
  //---------------------------------------------------------------------------
  logic tog_s, tog_s_q;

  i2s_sync #(.WIDTH(1), .STAGES(STAGES)) u_tog_sync (
      .clk_i(dst_clk_i), .rst_ni(dst_rst_ni), .d_i(tog_q), .q_o(tog_s));

  always_ff @(posedge dst_clk_i or negedge dst_rst_ni) begin
    if (!dst_rst_ni) tog_s_q <= 1'b0;
    else             tog_s_q <= tog_s;
  end

  assign dst_pulse_o = tog_s ^ tog_s_q;

  //---------------------------------------------------------------------------
  // Echo back, so the source knows the pulse has been seen.
  //---------------------------------------------------------------------------
  i2s_sync #(.WIDTH(1), .STAGES(STAGES)) u_echo_sync (
      .clk_i(src_clk_i), .rst_ni(src_rst_ni), .d_i(tog_s), .q_o(echo_s));

endmodule : i2s_cdc_pulse

`default_nettype wire
