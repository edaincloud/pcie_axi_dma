//=============================================================================
// File        : i2s_frame.sv
// Description : Controller-mode frame generator: slot / bit position counters
//               and the WS (word select) or FS (frame sync) output.
//
//               Position model (design specification, "Frame model")
//               ---------------------------------------------------
//               A frame is I2S_NUM_SLOTS slots of `slot_width_i` SCK periods.
//               Position `p` runs 0 .. frame_len-1 and is split into
//               (slot, bit).  Bit 0 of a slot is the position at which the MSB
//               of that slot's sample is on the wire.
//
//               WS is NOT a function of `p` directly: it is a function of the
//               position shifted forward by `ws_lead_i`, so that WS changes
//               `ws_lead_i` SCK periods BEFORE the MSB.  With ws_lead = 1 that
//               is exactly the Philips I2S one-clock relationship
//               (specification sections 4.3 and 16); with ws_lead = 0 it is
//               left-justified timing.
//
//                   q = (p + ws_lead) mod frame_len
//                   I2S / LEFT_J / RIGHT_J : WS  = (q.slot != 0)
//                   PCM_SHORT              : FS  = (q == 0)
//                   PCM_LONG               : FS  = (q.slot == 0) &&
//                                                  (q.bit < fs_width)
//                   ... then XOR ws_polarity
//
//               Because WS leads the data rather than delimiting it, a
//               sample_width equal to slot_width is legal in every format -
//               the classic 32-bit-sample-in-32-bit-slot I2S case that a
//               WS-anchored implementation cannot express.
//
//               Everything advances on `adv_en_i`, the single-cycle PCLK
//               strobe marking the SCK launch edge.  There is no clock here.
//=============================================================================

`default_nettype none

module i2s_frame
  import i2s_pkg::*;
(
    input  wire                        clk_i,
    input  wire                        rst_ni,

    input  wire                        run_i,      // engine active
    input  wire                        adv_en_i,   // SCK launch-edge strobe

    // ---- active configuration ----------------------------------------------
    input  wire  [I2S_WIDTH_FIELD_W-1:0] slot_width_i,
    input  wire  [I2S_DELAY_FIELD_W-1:0] ws_lead_i,
    input  wire  [2:0]                   format_i,
    input  wire                          ws_pol_i,
    input  wire  [I2S_WIDTH_FIELD_W-1:0] fs_width_i,

    // Error injection: shift the generated WS one SCK later while asserted
    // (specification section 62).
    input  wire                          ws_phase_err_i,
    // Error injection: end each slot one SCK early while asserted, which is the
    // "slot-length error" of specification section 62.  A slot of one SCK
    // cannot be shortened, so the injection is inert there rather than
    // wrapping the counter.
    input  wire                          slot_len_err_i,

    // ---- outputs ------------------------------------------------------------
    output logic                         ws_o,
    // pos_* is the position of the bit launched AT THIS strobe and is only
    // meaningful while adv_en_i is high.  slot_o / bit_o are the registered
    // copies, describing the bit currently on the wire, and feed DEBUG_STATE.
    output logic                         pos_slot_o,
    output logic [I2S_WIDTH_FIELD_W-1:0] pos_bit_o,
    output logic                         slot_o,
    output logic [I2S_WIDTH_FIELD_W-1:0] bit_o,
    output logic                         started_o,
    output logic                         frame_start_o,   // pulse: p wraps to 0
    output logic                         slot_start_o,    // pulse: bit wraps to 0
    output logic                         frame_end_o      // pulse: last bit of frame
);

  localparam int unsigned BW = I2S_WIDTH_FIELD_W;

  logic          slot_q;
  logic [BW-1:0] bit_q;
  logic          started_q;
  logic          ws_q;

  // ---- next position ---------------------------------------------------------
  logic          nxt_slot;
  logic [BW-1:0] nxt_bit;
  logic          last_bit_of_slot;

  // Bit index of the last bit of a slot, one lower while a slot-length error is
  // being injected.
  logic [BW-1:0] slot_last_bit;
  always_comb begin
    if (slot_len_err_i && (slot_width_i > BW'(1))) slot_last_bit = slot_width_i - BW'(2);
    else                                           slot_last_bit = slot_width_i - BW'(1);
  end

  assign last_bit_of_slot = (bit_q >= slot_last_bit);

  always_comb begin
    if (!started_q) begin
      nxt_slot = 1'b0;
      nxt_bit  = '0;
    end else if (last_bit_of_slot) begin
      nxt_slot = ~slot_q;                 // I2S_NUM_SLOTS == 2
      nxt_bit  = '0;
    end else begin
      nxt_slot = slot_q;
      nxt_bit  = bit_q + BW'(1);
    end
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      slot_q    <= 1'b0;
      bit_q     <= '0;
      started_q <= 1'b0;
    end else if (!run_i) begin
      slot_q    <= 1'b0;
      bit_q     <= '0;
      started_q <= 1'b0;
    end else if (adv_en_i) begin
      slot_q    <= nxt_slot;
      bit_q     <= nxt_bit;
      started_q <= 1'b1;
    end
  end

  assign pos_slot_o    = nxt_slot;
  assign pos_bit_o     = nxt_bit;
  assign slot_o        = slot_q;
  assign bit_o         = bit_q;
  assign started_o     = started_q;
  assign frame_start_o = run_i & adv_en_i & (nxt_slot == 1'b0) & (nxt_bit == '0);
  assign slot_start_o  = run_i & adv_en_i & (nxt_bit == '0);
  assign frame_end_o   = run_i & adv_en_i & started_q &
                         (nxt_slot == 1'b1) & (nxt_bit == slot_last_bit);

  //---------------------------------------------------------------------------
  // WS / FS generation, computed from the position shifted by ws_lead.
  //---------------------------------------------------------------------------
  logic [BW:0]                 lead_ext;
  logic [BW:0]                 q_bit_sum;
  logic [BW-1:0]               q_bit;
  logic                        q_slot;
  logic                        ws_raw;
  logic                        ws_next;

  always_comb begin
    lead_ext  = {1'b0, BW'(ws_lead_i)} + {{BW{1'b0}}, ws_phase_err_i};
    q_bit_sum = {1'b0, nxt_bit} + lead_ext;

    if (q_bit_sum >= {1'b0, slot_width_i}) begin
      q_bit  = BW'(q_bit_sum - {1'b0, slot_width_i});
      q_slot = ~nxt_slot;                 // I2S_NUM_SLOTS == 2
    end else begin
      q_bit  = BW'(q_bit_sum);
      q_slot = nxt_slot;
    end

    unique case (format_i)
      I2S_FMT_PCM_SHORT : ws_raw = (q_slot == 1'b0) && (q_bit == '0);
      I2S_FMT_PCM_LONG  : ws_raw = (q_slot == 1'b0) && (q_bit < fs_width_i);
      default           : ws_raw = (q_slot != 1'b0);
    endcase

    ws_next = ws_raw ^ ws_pol_i;
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ws_q <= 1'b0;
    end else if (!run_i) begin
      // Parked level: the inactive WS/FS state for the configured polarity.
      ws_q <= ws_pol_i;
    end else if (adv_en_i) begin
      ws_q <= ws_next;
    end
  end

  assign ws_o = ws_q;

endmodule : i2s_frame

`default_nettype wire
