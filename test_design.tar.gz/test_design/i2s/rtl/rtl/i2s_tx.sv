//=============================================================================
// File        : i2s_tx.sv
// Description : I2S transmit path: frame assembly, serialiser, padding, mute
//               and underrun policy (specification section 18).
//
//               Frame assembly
//               --------------
//               The loader pulls one frame's worth of samples out of the TX
//               FIFO ahead of time, in stream order, into `load_buf`.  At the
//               frame boundary the stream entries are mapped onto the two
//               slots according to MONO_MODE and CHANNEL_SWAP, and the frame
//               is serialised from that snapshot.
//
//               Doing the channel mapping on a whole assembled frame - rather
//               than on each pop - is what lets CHANNEL_SWAP exchange left and
//               right WITHOUT touching the WS timing, as specification section
//               29 requires: a swap only changes which buffered entry feeds
//               which slot.  The cost is one frame of transmit latency, which
//               is documented in the design specification.
//
//               Serialiser
//               ----------
//               The sample is loaded MSB-aligned into `shift_q` at the slot
//               boundary and shifted left once per bit inside the data window.
//               The data window is [0, sample_width) for every format except
//               RIGHT_J, where it is [slot_width-sample_width, slot_width) so
//               that the LSB lands on the last bit of the slot (specification
//               section 26).  Outside the window the configured padding value
//               is transmitted (specification section 23).
//=============================================================================

`default_nettype none

module i2s_tx
  import i2s_pkg::*;
#(
    parameter int unsigned SAMPLE_WIDTH_MAX = 32
) (
    input  wire                            clk_i,
    input  wire                            rst_ni,

    input  wire                            run_i,          // engine active
    input  wire                            launch_en_i,    // SCK launch strobe
    input  wire                            pos_valid_i,    // position established
    input  wire                            pos_slot_i,
    input  wire  [I2S_WIDTH_FIELD_W-1:0]   pos_bit_i,
    input  wire                            frame_start_i,  // strobe: slot 0 bit 0

    // ---- active configuration ----------------------------------------------
    input  wire  [I2S_WIDTH_FIELD_W-1:0]   sample_width_i,
    input  wire  [I2S_WIDTH_FIELD_W-1:0]   slot_width_i,
    input  wire  [2:0]                     format_i,
    input  wire  [1:0]                     pad_mode_i,
    input  wire  [1:0]                     mono_i,
    input  wire                            swap_i,
    input  wire  [1:0]                     underrun_mode_i,
    input  wire                            mute_all_i,
    input  wire                            mute_left_i,
    input  wire                            mute_right_i,
    // Value substituted for a muted slot.  Specification section 37 gives
    // "0 or another configured mute value"; MUTE_VALUE is that value and its
    // reset value is zero, which is digital silence in every width.
    input  wire  [SAMPLE_WIDTH_MAX-1:0]    mute_value_i,

    // ---- TX FIFO ------------------------------------------------------------
    input  wire                            fifo_empty_i,
    input  wire  [SAMPLE_WIDTH_MAX-1:0]    fifo_rdata_i,
    output logic                           fifo_pop_o,

    // ---- test hooks ----------------------------------------------------------
    input  wire                            prbs_en_i,
    input  wire                            prbs_bit_i,
    input  wire                            inj_bitflip_i,
    input  wire                            inj_underrun_i,   // block the pop
    input  wire                            inj_missing_i,    // skip a payload bit
    input  wire                            inj_extra_i,      // repeat a payload bit
    input  wire                            inj_corrupt_i,    // corrupt the sample

    // ---- outputs -------------------------------------------------------------
    output logic                           sd_o,
    output logic                           data_bit_en_o,  // launching a payload bit
    output logic                           underrun_o,       // one pulse per frame
    output logic                           sample_sent_o,    // one pulse per slot
    output logic                           stop_req_o,       // UNDR_STOP policy
    output logic [SAMPLE_WIDTH_MAX-1:0]    shift_dbg_o,
    output logic [2:0]                     state_dbg_o
);

  localparam int unsigned SW = SAMPLE_WIDTH_MAX;
  localparam int unsigned BW = I2S_WIDTH_FIELD_W;

  //---------------------------------------------------------------------------
  // Frame loader
  //---------------------------------------------------------------------------
  // Number of stream entries a frame consumes: two in stereo, one in any of
  // the mono modes.
  logic [1:0] n_load;
  assign n_load = (mono_i == I2S_MONO_STEREO) ? 2'd2 : 2'd1;

  logic [SW-1:0] load_buf_q [I2S_NUM_SLOTS];
  logic [1:0]    load_cnt_q;
  logic [SW-1:0] last_sample_q;

  // The frame boundary consumes the buffer and resets the counter, so no pop
  // may be issued in that cycle - the popped word would have nowhere to go.
  logic can_load;
  assign can_load   = run_i & ~fifo_empty_i & ~inj_underrun_i &
                      ~frame_start_i & (load_cnt_q < n_load);
  assign fifo_pop_o = can_load;

  //---------------------------------------------------------------------------
  // Underrun substitution value (specification section 35)
  //---------------------------------------------------------------------------
  logic [SW-1:0] undr_value;
  always_comb begin
    unique case (underrun_mode_i)
      I2S_UNDR_HOLD_LAST : undr_value = last_sample_q;
      // MUTE substitutes the configured mute value; SEND_ZERO and STOP send
      // zero, which is what specification section 35 names them for.
      I2S_UNDR_MUTE      : undr_value = mute_value_i;
      default            : undr_value = '0;
    endcase
  end

  logic frame_underrun;
  assign frame_underrun = (load_cnt_q < n_load);

  // Stream entry i, substituted when the loader did not manage to fetch it.
  logic [SW-1:0] ent0, ent1;
  assign ent0 = (load_cnt_q > 2'd0) ? load_buf_q[0] : undr_value;
  assign ent1 = (load_cnt_q > 2'd1) ? load_buf_q[1] : undr_value;

  //---------------------------------------------------------------------------
  // Stream entry -> slot mapping: MONO_MODE then CHANNEL_SWAP
  //---------------------------------------------------------------------------
  logic [SW-1:0] map0, map1;    // before swap
  logic [SW-1:0] slot0_val, slot1_val;

  always_comb begin
    unique case (mono_i)
      I2S_MONO_LEFT_ONLY  : begin map0 = ent0; map1 = '0;   end
      I2S_MONO_RIGHT_ONLY : begin map0 = '0;   map1 = ent0; end
      I2S_MONO_DUPLICATE  : begin map0 = ent0; map1 = ent0; end
      default             : begin map0 = ent0; map1 = ent1; end   // stereo
    endcase
  end

  always_comb begin
    slot0_val = swap_i ? map1 : map0;
    slot1_val = swap_i ? map0 : map1;

    // Hardware mute (specification section 37) replaces the payload with the
    // configured mute value; the frame timing is unaffected.
    if (mute_all_i || mute_left_i)  slot0_val = mute_value_i;
    if (mute_all_i || mute_right_i) slot1_val = mute_value_i;
    if (underrun_mode_i == I2S_UNDR_MUTE) begin
      if (frame_underrun) begin
        slot0_val = mute_value_i;
        slot1_val = mute_value_i;
      end
    end

    // Sample-corruption injection (specification section 62) is applied LAST,
    // after mapping and mute, so what reaches the wire is unambiguously wrong
    // whatever the rest of the configuration is.
    if (inj_corrupt_i) begin
      slot0_val = ~slot0_val;
      slot1_val = ~slot1_val;
    end
  end

  //---------------------------------------------------------------------------
  // Serialiser
  //---------------------------------------------------------------------------
  logic [SW-1:0] shift_q;
  logic [SW-1:0] slot1_hold_q;
  logic          sign_q;
  logic          last_data_bit_q;
  logic          started_q;

  // Sample selected for the slot that starts at this strobe.
  logic [SW-1:0] slot_sample;
  assign slot_sample = frame_start_i ? slot0_val : slot1_hold_q;

  // MSB-aligned load value.
  logic [SW-1:0] load_val;
  always_comb begin
    load_val = slot_sample << (BW'(SW) - sample_width_i);
  end

  logic slot_start;
  assign slot_start = launch_en_i & pos_valid_i & (pos_bit_i == '0);

  // Data window within the slot.
  logic [BW-1:0] rj_start;
  logic          in_data;
  always_comb begin
    rj_start = (slot_width_i > sample_width_i) ? (slot_width_i - sample_width_i) : BW'(0);
    if (format_i == I2S_FMT_RIGHT_J) begin
      in_data = (pos_bit_i >= rj_start) && (pos_bit_i < slot_width_i);
    end else begin
      in_data = (pos_bit_i < sample_width_i);
    end
  end

  // Value the shift register holds while this bit is being launched.
  logic [SW-1:0] shift_cur;
  assign shift_cur = slot_start ? load_val : shift_q;

  logic pad_bit;
  always_comb begin
    unique case (pad_mode_i)
      I2S_PAD_SIGN : pad_bit = sign_q;
      I2S_PAD_HOLD : pad_bit = last_data_bit_q;
      default      : pad_bit = 1'b0;                 // I2S_PAD_ZERO
    endcase
  end

  logic data_bit;
  logic next_sd;
  assign data_bit = prbs_en_i ? prbs_bit_i : shift_cur[SW-1];
  assign next_sd  = (in_data ? data_bit : pad_bit) ^ inj_bitflip_i;

  //---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      for (int unsigned i = 0; i < I2S_NUM_SLOTS; i++) load_buf_q[i] <= '0;
      load_cnt_q      <= '0;
      last_sample_q   <= '0;
      shift_q         <= '0;
      slot1_hold_q    <= '0;
      sign_q          <= 1'b0;
      last_data_bit_q <= 1'b0;
      started_q       <= 1'b0;
      sd_o            <= 1'b0;
    end else if (!run_i) begin
      load_cnt_q      <= '0;
      shift_q         <= '0;
      started_q       <= 1'b0;
      sd_o            <= 1'b0;
      last_data_bit_q <= 1'b0;
    end else begin
      // ---- loader ---------------------------------------------------------
      if (frame_start_i) begin
        // The frame just snapshotted is consumed; start collecting the next.
        load_cnt_q <= '0;
      end else if (can_load) begin
        load_buf_q[load_cnt_q[0]] <= fifo_rdata_i;
        last_sample_q          <= fifo_rdata_i;
        load_cnt_q             <= load_cnt_q + 2'd1;
      end

      // ---- serialiser -----------------------------------------------------
      if (launch_en_i && pos_valid_i) begin
        started_q <= 1'b1;
        sd_o      <= next_sd;

        if (slot_start) begin
          // After MSB alignment the sample's sign bit is the top bit of the
          // load value, so no variable bit select is needed here.
          sign_q <= load_val[SW-1];
          if (frame_start_i) slot1_hold_q <= slot1_val;
        end

        if (in_data) begin
          // Missing-bit / extra-bit injection (specification section 62) acts
          // on the SHIFT rather than on the bit that was just launched:
          // shifting twice drops a payload bit from the stream, and not
          // shifting at all repeats one.  Both leave the frame timing intact,
          // which is what makes them distinguishable from a slot-length error.
          if      (inj_missing_i) shift_q <= shift_cur << 2;
          else if (inj_extra_i)   shift_q <= shift_cur;
          else                    shift_q <= shift_cur << 1;
          last_data_bit_q <= data_bit;
        end else begin
          shift_q         <= shift_cur;
        end
      end
    end
  end

  //---------------------------------------------------------------------------
  // Status
  //---------------------------------------------------------------------------
  assign data_bit_en_o = run_i & launch_en_i & pos_valid_i & in_data;
  assign underrun_o    = run_i & frame_start_i & frame_underrun;
  assign sample_sent_o = run_i & launch_en_i & pos_valid_i &
                         (pos_bit_i == (slot_width_i - BW'(1)));
  assign stop_req_o    = (underrun_mode_i == I2S_UNDR_STOP) & underrun_o;

  assign shift_dbg_o = shift_q;

  always_comb begin
    if      (!run_i)     state_dbg_o = I2S_TX_IDLE;
    else if (stop_req_o) state_dbg_o = I2S_TX_STOP;
    else if (!started_q) state_dbg_o = I2S_TX_LOAD;
    else if (in_data)    state_dbg_o = I2S_TX_SHIFT;
    else                 state_dbg_o = I2S_TX_PAD;
  end

  //---------------------------------------------------------------------------
  // The slot index is carried on the interface for symmetry with i2s_rx and
  // for the bound assertions; the serialiser itself distinguishes the two
  // slots through `frame_start_i` and the held slot-1 sample.
  //---------------------------------------------------------------------------
  logic unused_tx;
  assign unused_tx = ^{pos_slot_i, 1'b0};

endmodule : i2s_tx

`default_nettype wire
