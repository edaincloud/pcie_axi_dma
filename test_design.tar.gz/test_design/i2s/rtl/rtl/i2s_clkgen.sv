//=============================================================================
// File        : i2s_clkgen.sv
// Description : Serial bit clock (SCK) and master clock (MCLK) generation for
//               controller mode.
//
//               Both outputs are ordinary REGISTERED SIGNALS, not clocks: no
//               logic inside this IP is clocked by either of them.  The whole
//               design runs on PCLK and uses the `*_rise_en` / `*_fall_en`
//               single-cycle strobes produced here as clock enables.  That is
//               what keeps the netlist free of generated and gated clocks and
//               keeps it DFT clean (specification sections 90 and 92).
//
//               SCK duty cycle is exactly 50% for every divider value, because
//               a half period is `div_i` PCLK cycles by construction and the
//               same count is used for both phases (specification section 14).
//
//               Start / stop (specification sections 13 and 45)
//                 - start : the generator leaves the parked state with the
//                   internal clock low and counts a full `div_i` half period
//                   before the first rising edge, so the first pulse is full
//                   width and no runt is produced.
//                 - stop  : `run_i` is only sampled at a falling transition,
//                   so the last high pulse is always full width.  The parent
//                   gates `run_i` with the frame boundary when the programmed
//                   stop mode requires it.
//=============================================================================

`default_nettype none

module i2s_clkgen #(
    parameter int unsigned DIV_WIDTH = 8
) (
    input  wire                  clk_i,
    input  wire                  rst_ni,

    // ---- SCK ----------------------------------------------------------------
    input  wire                  run_i,        // request the SCK to run
    input  wire [DIV_WIDTH-1:0]  div_i,        // half period in PCLK cycles
    input  wire                  invert_i,     // invert the SCK pin

    output logic                 sck_o,        // pin value (post inversion)
    output logic                 running_o,    // generator is running
    // Single-cycle strobes marking the PCLK edge at which the SCK PIN makes
    // the named transition.  Everything downstream uses these as enables.
    output logic                 sck_rise_en_o,
    output logic                 sck_fall_en_o,

    // ---- MCLK ---------------------------------------------------------------
    input  wire                  mclk_en_i,
    input  wire [DIV_WIDTH-1:0]  mclk_div_i,
    input  wire                  mclk_pol_i,
    output logic                 mclk_o
);

  //---------------------------------------------------------------------------
  // SCK divider
  //---------------------------------------------------------------------------
  logic [DIV_WIDTH-1:0] div_m1;
  logic [DIV_WIDTH-1:0] cnt_q;
  logic                 sck_q;
  logic                 run_q;
  logic                 tick;

  // div_i == 0 is rejected by the configuration validator before it can ever
  // become the active divider, but the arithmetic is still made safe here so
  // that no configuration can produce an out-of-range count (specification
  // section 108).
  assign div_m1 = (div_i == '0) ? '0 : (div_i - DIV_WIDTH'(1));
  assign tick   = run_q & (cnt_q == div_m1);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cnt_q <= '0;
      sck_q <= 1'b0;
      run_q <= 1'b0;
    end else if (!run_q) begin
      cnt_q <= '0;
      sck_q <= 1'b0;
      run_q <= run_i;
    end else if (tick) begin
      cnt_q <= '0;
      sck_q <= ~sck_q;
      // Only ever leave the running state on a falling transition, so the
      // high phase can never be truncated into a runt.
      if (sck_q && !run_i) run_q <= 1'b0;
    end else begin
      cnt_q <= cnt_q + DIV_WIDTH'(1);
    end
  end

  assign sck_o     = invert_i ^ sck_q;
  assign running_o = run_q;

  // The strobes describe the PIN, so they swap when the pin is inverted.
  logic int_rise_en, int_fall_en;
  assign int_rise_en   = tick & ~sck_q;
  assign int_fall_en   = tick &  sck_q;
  assign sck_rise_en_o = invert_i ? int_fall_en : int_rise_en;
  assign sck_fall_en_o = invert_i ? int_rise_en : int_fall_en;

  //---------------------------------------------------------------------------
  // MCLK divider (specification section 12)
  //
  // Free running while enabled and completely independent of the frame, which
  // is what an external codec expects: MCLK must be present before and after
  // the audio stream.
  //---------------------------------------------------------------------------
  logic [DIV_WIDTH-1:0] mcnt_q;
  logic [DIV_WIDTH-1:0] mdiv_m1;
  logic                 mclk_q;

  assign mdiv_m1 = (mclk_div_i == '0) ? '0 : (mclk_div_i - DIV_WIDTH'(1));

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      mcnt_q <= '0;
      mclk_q <= 1'b0;
    end else if (!mclk_en_i) begin
      mcnt_q <= '0;
      mclk_q <= 1'b0;
    end else if (mcnt_q == mdiv_m1) begin
      mcnt_q <= '0;
      mclk_q <= ~mclk_q;
    end else begin
      mcnt_q <= mcnt_q + DIV_WIDTH'(1);
    end
  end

  assign mclk_o = mclk_pol_i ^ mclk_q;

endmodule : i2s_clkgen

`default_nettype wire
