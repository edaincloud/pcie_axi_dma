//=============================================================================
// File        : i2s_pkg.sv
// Description : Common constants, register offsets, field definitions and
//               enumerations for the APB4 I2S IP.  Every address and field
//               magic number used by the RTL, the verification environment and
//               software lives here so that they can never diverge.
//
// Project     : I2S audio interface IP (APB4 programmed)
// Standard    : IEEE 1800-2017 SystemVerilog
//
// Notes       : Compile-time constants and pure functions only.  Synthesizable
//               and stateless.
//=============================================================================

`ifndef I2S_PKG_SV
`define I2S_PKG_SV

package i2s_pkg;

  //---------------------------------------------------------------------------
  // Implementation limits
  //---------------------------------------------------------------------------
  // Upper bound on SAMPLE_WIDTH_MAX / SLOT_WIDTH_MAX.  TX_DATA / RX_DATA are a
  // single 32-bit register each, so a sample cannot be wider than 32 bits.
  localparam int unsigned I2S_MAX_WIDTH      = 32;
  localparam int unsigned I2S_MIN_WIDTH      = 8;

  // Number of slots in a frame.  This revision implements stereo only; see
  // Appendix A of the design specification for the TDM deviation.
  localparam int unsigned I2S_NUM_SLOTS      = 2;

  // Bounds on the FIFO depths (each must additionally be a power of two).
  localparam int unsigned I2S_MIN_FIFO_DEPTH = 2;
  localparam int unsigned I2S_MAX_FIFO_DEPTH = 64;

  // Bounds on the clock-divider field width.
  localparam int unsigned I2S_MIN_DIV_WIDTH  = 1;
  localparam int unsigned I2S_MAX_DIV_WIDTH  = 16;

  // Bounds on the event-counter width.
  localparam int unsigned I2S_MIN_CNT_WIDTH  = 8;
  localparam int unsigned I2S_MAX_CNT_WIDTH  = 32;

  // Bounds on the input-synchroniser depth.
  localparam int unsigned I2S_MIN_SYNC_STAGES = 2;
  localparam int unsigned I2S_MAX_SYNC_STAGES = 4;

  // Width of the shadow/active configuration fields that hold a bit count.
  // 6 bits spans 0..63, which covers I2S_MAX_WIDTH with headroom.
  localparam int unsigned I2S_WIDTH_FIELD_W  = 6;
  // Width of the WS-lead (data delay) field.
  localparam int unsigned I2S_DELAY_FIELD_W  = 4;

  // Widest FIFO pointer the asynchronous FIFOs can need: clog2 of the deepest
  // legal FIFO plus the one extra wrap bit a Gray-pointer FIFO uses to tell
  // "full" from "empty".  The Gray helpers below operate at this width and are
  // fed zero-extended narrower pointers, which is exact: a Gray code with
  // leading zeros converts to a binary value with the same leading zeros.
  localparam int unsigned I2S_MAX_PTR_W = 7;

  // Width of the event-delta field carried by i2s_cdc_evcnt.  It bounds how
  // many source-domain events may occur inside one destination clock period
  // without the crossing losing count; see that module's header.
  localparam int unsigned I2S_EVDELTA_W = 4;

  //---------------------------------------------------------------------------
  // Identification constants (read-only registers)
  //---------------------------------------------------------------------------
  // "I2S" in ASCII (0x49 0x32 0x53) followed by the peripheral class code 0x01.
  localparam logic [31:0] I2S_ID_VALUE = 32'h4932_5301;

  // VERSION layout: {MAJOR[31:24], MINOR[23:16], PATCH[15:8], RSVD[7:0]}
  localparam logic [7:0] I2S_VERSION_MAJOR = 8'd1;
  localparam logic [7:0] I2S_VERSION_MINOR = 8'd0;
  localparam logic [7:0] I2S_VERSION_PATCH = 8'd0;

  localparam logic [31:0] I2S_VERSION_VALUE =
      {I2S_VERSION_MAJOR, I2S_VERSION_MINOR, I2S_VERSION_PATCH, 8'h00};

  //---------------------------------------------------------------------------
  // Register byte offsets (specification section 47)
  //
  // The layout follows the recommended map of section 47 exactly where the
  // section allocates an offset: VERSION at 0x000 and IP_ID at 0x004,
  // SAMPLE_RATE_CFG at 0x02C.  Registers section 47 does not list occupy
  // offsets it leaves free (0x05C, 0x074, 0x0C0..0x0C8).
  //---------------------------------------------------------------------------
  localparam logic [31:0] I2S_ADDR_VERSION           = 32'h0000_0000;
  localparam logic [31:0] I2S_ADDR_ID                = 32'h0000_0004;
  localparam logic [31:0] I2S_ADDR_GLOBAL_CTRL       = 32'h0000_0008;
  localparam logic [31:0] I2S_ADDR_GLOBAL_STATUS     = 32'h0000_000C;
  localparam logic [31:0] I2S_ADDR_TX_CTRL           = 32'h0000_0010;
  localparam logic [31:0] I2S_ADDR_RX_CTRL           = 32'h0000_0014;
  localparam logic [31:0] I2S_ADDR_MODE_CTRL         = 32'h0000_0018;
  localparam logic [31:0] I2S_ADDR_FORMAT_CTRL       = 32'h0000_001C;
  localparam logic [31:0] I2S_ADDR_SAMPLE_WIDTH      = 32'h0000_0020;
  localparam logic [31:0] I2S_ADDR_SLOT_WIDTH        = 32'h0000_0024;
  localparam logic [31:0] I2S_ADDR_CHANNEL_CTRL      = 32'h0000_0028;
  localparam logic [31:0] I2S_ADDR_SAMPLE_RATE_CFG   = 32'h0000_002C;
  localparam logic [31:0] I2S_ADDR_SCK_DIVIDER       = 32'h0000_0030;
  localparam logic [31:0] I2S_ADDR_MCLK_CTRL         = 32'h0000_0034;
  localparam logic [31:0] I2S_ADDR_WS_CTRL           = 32'h0000_0038;
  localparam logic [31:0] I2S_ADDR_SCK_CTRL          = 32'h0000_003C;
  localparam logic [31:0] I2S_ADDR_DATA_DELAY        = 32'h0000_0040;
  localparam logic [31:0] I2S_ADDR_PADDING_CTRL      = 32'h0000_0044;
  localparam logic [31:0] I2S_ADDR_MUTE_CTRL         = 32'h0000_0048;
  localparam logic [31:0] I2S_ADDR_LOOPBACK_CTRL     = 32'h0000_004C;
  localparam logic [31:0] I2S_ADDR_DMA_CTRL          = 32'h0000_0050;
  localparam logic [31:0] I2S_ADDR_CONFIG_COMMIT     = 32'h0000_0054;
  localparam logic [31:0] I2S_ADDR_CONFIG_STATUS     = 32'h0000_0058;
  localparam logic [31:0] I2S_ADDR_MUTE_VALUE        = 32'h0000_005C;
  localparam logic [31:0] I2S_ADDR_TX_FIFO_CTRL      = 32'h0000_0060;
  localparam logic [31:0] I2S_ADDR_TX_FIFO_STATUS    = 32'h0000_0064;
  localparam logic [31:0] I2S_ADDR_RX_FIFO_CTRL      = 32'h0000_0068;
  localparam logic [31:0] I2S_ADDR_RX_FIFO_STATUS    = 32'h0000_006C;
  localparam logic [31:0] I2S_ADDR_FIFO_THRESHOLD    = 32'h0000_0070;
  localparam logic [31:0] I2S_ADDR_FIFO_THRESHOLD2   = 32'h0000_0074;
  localparam logic [31:0] I2S_ADDR_INT_STATUS        = 32'h0000_0080;
  localparam logic [31:0] I2S_ADDR_INT_MASK          = 32'h0000_0084;
  localparam logic [31:0] I2S_ADDR_INT_ENABLE        = 32'h0000_0088;
  localparam logic [31:0] I2S_ADDR_TX_SAMPLE_COUNT   = 32'h0000_0090;
  localparam logic [31:0] I2S_ADDR_RX_SAMPLE_COUNT   = 32'h0000_0094;
  localparam logic [31:0] I2S_ADDR_TX_UNDERRUN_COUNT = 32'h0000_0098;
  localparam logic [31:0] I2S_ADDR_RX_OVERRUN_COUNT  = 32'h0000_009C;
  localparam logic [31:0] I2S_ADDR_FRAME_ERROR_COUNT = 32'h0000_00A0;
  localparam logic [31:0] I2S_ADDR_WS_ERROR_COUNT    = 32'h0000_00A4;
  localparam logic [31:0] I2S_ADDR_SCK_ERROR_COUNT   = 32'h0000_00A8;
  localparam logic [31:0] I2S_ADDR_CLOCK_STATUS      = 32'h0000_00AC;
  localparam logic [31:0] I2S_ADDR_DEBUG_STATE       = 32'h0000_00B0;
  localparam logic [31:0] I2S_ADDR_DEBUG_SHIFT       = 32'h0000_00B4;
  localparam logic [31:0] I2S_ADDR_DEBUG_FRAME       = 32'h0000_00B8;
  localparam logic [31:0] I2S_ADDR_DEBUG_ERROR       = 32'h0000_00BC;
  localparam logic [31:0] I2S_ADDR_CLOCK_CTRL        = 32'h0000_00C0;
  localparam logic [31:0] I2S_ADDR_SAMPLE_RATE_ACT   = 32'h0000_00C4;
  localparam logic [31:0] I2S_ADDR_CLOCK_DUTY        = 32'h0000_00C8;
  localparam logic [31:0] I2S_ADDR_TX_DATA           = 32'h0000_0100;
  localparam logic [31:0] I2S_ADDR_RX_DATA           = 32'h0000_0104;
  localparam logic [31:0] I2S_ADDR_TEST_CTRL         = 32'h0000_0200;
  localparam logic [31:0] I2S_ADDR_ERROR_INJECT_CTRL = 32'h0000_0204;
  localparam logic [31:0] I2S_ADDR_PRBS_CTRL         = 32'h0000_0208;
  localparam logic [31:0] I2S_ADDR_TEST_STATUS       = 32'h0000_020C;

  // First byte address above the implemented register region.  Used both by
  // the address decoder and by the elaboration guard on APB_ADDR_WIDTH.
  localparam logic [31:0] I2S_REGION_END = 32'h0000_0210;

  //---------------------------------------------------------------------------
  // GLOBAL_CTRL fields (specification section 48)
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_GC_IP_ENABLE_BIT     = 0;
  localparam int unsigned I2S_GC_TX_ENABLE_BIT     = 1;
  localparam int unsigned I2S_GC_RX_ENABLE_BIT     = 2;
  localparam int unsigned I2S_GC_CONTROLLER_EN_BIT = 3;
  localparam int unsigned I2S_GC_LOOPBACK_EN_BIT   = 4;
  localparam int unsigned I2S_GC_MUTE_BIT          = 5;
  localparam int unsigned I2S_GC_SOFT_RESET_BIT    = 6;   // write-one-pulse
  localparam int unsigned I2S_GC_DMA_ENABLE_BIT    = 7;
  localparam int unsigned I2S_GC_STOP_AT_FRAME_BIT = 8;
  localparam int unsigned I2S_GC_CNT_CLEAR_BIT     = 9;   // write-one-pulse

  //---------------------------------------------------------------------------
  // GLOBAL_STATUS fields
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_GS_TX_ACTIVE_BIT   = 0;
  localparam int unsigned I2S_GS_RX_ACTIVE_BIT   = 1;
  localparam int unsigned I2S_GS_SCK_RUNNING_BIT = 2;
  localparam int unsigned I2S_GS_CFG_ACTIVE_BIT  = 3;
  localparam int unsigned I2S_GS_CFG_ERROR_BIT   = 4;
  localparam int unsigned I2S_GS_TX_BUSY_BIT     = 5;
  localparam int unsigned I2S_GS_RX_BUSY_BIT     = 6;
  localparam int unsigned I2S_GS_TARGET_MODE_BIT = 7;

  //---------------------------------------------------------------------------
  // TX_CTRL / RX_CTRL fields
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_TXC_UNDERRUN_LSB   = 0;   // 2 bits
  localparam int unsigned I2S_TXC_UNDERRUN_W     = 2;

  localparam int unsigned I2S_RXC_OVERRUN_LSB    = 0;   // 2 bits
  localparam int unsigned I2S_RXC_OVERRUN_W      = 2;
  localparam int unsigned I2S_RXC_SIGN_EXTEND_BIT = 2;

  //---------------------------------------------------------------------------
  // MODE_CTRL fields
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_MC_TARGET_MODE_BIT = 0;
  localparam int unsigned I2S_MC_TX_LAUNCH_BIT   = 1;   // 0 falling, 1 rising
  localparam int unsigned I2S_MC_RX_SAMPLE_BIT   = 2;   // 0 rising,  1 falling

  //---------------------------------------------------------------------------
  // FORMAT_CTRL fields
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_FC_FORMAT_LSB   = 0;      // 3 bits
  localparam int unsigned I2S_FC_FORMAT_W     = 3;
  localparam int unsigned I2S_FC_WS_POL_BIT   = 3;

  //---------------------------------------------------------------------------
  // CHANNEL_CTRL / PADDING_CTRL / MUTE_CTRL / LOOPBACK_CTRL / DMA_CTRL fields
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_CC_MONO_LSB      = 0;     // 2 bits
  localparam int unsigned I2S_CC_MONO_W        = 2;
  localparam int unsigned I2S_CC_CHAN_SWAP_BIT = 2;

  localparam int unsigned I2S_PC_PAD_MODE_LSB = 0;      // 2 bits
  localparam int unsigned I2S_PC_PAD_MODE_W   = 2;

  localparam int unsigned I2S_MU_TX_BIT    = 0;
  localparam int unsigned I2S_MU_RX_BIT    = 1;
  localparam int unsigned I2S_MU_LEFT_BIT  = 2;
  localparam int unsigned I2S_MU_RIGHT_BIT = 3;

  localparam int unsigned I2S_LB_ENABLE_BIT = 0;

  localparam int unsigned I2S_DMA_TX_EN_BIT = 0;
  localparam int unsigned I2S_DMA_RX_EN_BIT = 1;

  //---------------------------------------------------------------------------
  // CLOCK_CTRL / SCK_CTRL / MCLK_CTRL / WS_CTRL fields
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_CK_MON_EN_BIT = 0;
  localparam int unsigned I2S_CK_TOL_LSB    = 8;        // 8 bits

  // SCK_CTRL carries a single control: invert the SCK pin.  The idle level of
  // the pin therefore equals SCK_INVERT, because the generator parks its
  // internal clock low whenever it is stopped.
  localparam int unsigned I2S_SCKC_INV_BIT  = 0;

  localparam int unsigned I2S_MCK_EN_BIT    = 0;
  localparam int unsigned I2S_MCK_POL_BIT   = 1;
  localparam int unsigned I2S_MCK_DIV_LSB   = 8;

  localparam int unsigned I2S_WSC_FS_WIDTH_LSB = 0;     // 6 bits, PCM long FS

  //---------------------------------------------------------------------------
  // CONFIG_COMMIT / CONFIG_STATUS fields
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_CMT_COMMIT_BIT = 0;

  localparam int unsigned I2S_CS_ACTIVE_BIT  = 0;
  localparam int unsigned I2S_CS_PENDING_BIT = 1;
  localparam int unsigned I2S_CS_ERROR_BIT   = 2;
  localparam int unsigned I2S_CS_CODE_LSB    = 8;       // 4 bits

  // Configuration error codes reported in CONFIG_STATUS.ERROR_CODE.
  typedef enum logic [3:0] {
    I2S_CFGE_NONE        = 4'd0,
    I2S_CFGE_SAMPLE_W    = 4'd1,   // sample_width out of range
    I2S_CFGE_SLOT_W      = 4'd2,   // slot_width out of range
    I2S_CFGE_WIDTH_ORDER = 4'd3,   // sample_width > slot_width
    I2S_CFGE_DELAY       = 4'd4,   // ws_lead >= slot_width
    I2S_CFGE_DIVIDER     = 4'd5,   // sck_div == 0
    I2S_CFGE_FORMAT      = 4'd6,   // unsupported format encoding
    I2S_CFGE_RJ_DELAY    = 4'd7,   // right-justified requires ws_lead == 0
    I2S_CFGE_MCLK_DIV    = 4'd8,   // mclk enabled with mclk_div == 0
    I2S_CFGE_FS_WIDTH    = 4'd9,   // PCM long FS width out of range
    // The requested sample rate cannot be produced by the requested divider and
    // slot width (specification sections 52 "sample_rate achievable" and 101).
    I2S_CFGE_RATE        = 4'd10
  } i2s_cfg_err_e;

  //---------------------------------------------------------------------------
  // FIFO status fields
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_FS_LEVEL_LSB    = 0;      // 16 bits
  localparam int unsigned I2S_FS_EMPTY_BIT    = 16;
  localparam int unsigned I2S_FS_FULL_BIT     = 17;
  localparam int unsigned I2S_FS_ALMOST_BIT   = 18;
  localparam int unsigned I2S_FS_OVERFLOW_BIT  = 19;    // sticky, cleared via CTRL
  localparam int unsigned I2S_FS_UNDERFLOW_BIT = 20;    // sticky, cleared via CTRL
  // A flush is a cross-domain quiesce protocol and takes several cycles, so it
  // needs a completion indication: software must not write TX_DATA (or read
  // RX_DATA) while this is set, because the FIFO is holding both pointers at
  // zero and an access made in that window is part of what the flush discards.
  localparam int unsigned I2S_FS_FLUSH_BUSY_BIT = 21;
  localparam int unsigned I2S_FS_DEPTH_LSB     = 24;    // 8 bits: configured depth

  localparam int unsigned I2S_FC_FLUSH_BIT      = 0;    // *_FIFO_CTRL
  localparam int unsigned I2S_FC_CLR_STICKY_BIT = 1;

  // FIFO_THRESHOLD carries the two "almost" levels, FIFO_THRESHOLD2 the two
  // interrupt levels for the empty/full ends.  Together these are the four
  // programmable thresholds of specification section 34.
  localparam int unsigned I2S_FT_TX_LOW_LSB   = 0;      // 16 bits
  localparam int unsigned I2S_FT_RX_HIGH_LSB  = 16;     // 16 bits
  localparam int unsigned I2S_FT2_TX_EMPTY_LSB = 0;     // 16 bits
  localparam int unsigned I2S_FT2_RX_FULL_LSB  = 16;    // 16 bits

  //---------------------------------------------------------------------------
  // Interrupt sources (specification section 55)
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_INT_TX_EMPTY_BIT        = 0;
  localparam int unsigned I2S_INT_TX_ALMOST_EMPTY_BIT = 1;
  localparam int unsigned I2S_INT_TX_UNDERRUN_BIT     = 2;
  localparam int unsigned I2S_INT_RX_FULL_BIT         = 3;
  localparam int unsigned I2S_INT_RX_ALMOST_FULL_BIT  = 4;
  localparam int unsigned I2S_INT_RX_OVERRUN_BIT      = 5;
  localparam int unsigned I2S_INT_FRAME_ERROR_BIT     = 6;
  localparam int unsigned I2S_INT_WS_ERROR_BIT        = 7;
  localparam int unsigned I2S_INT_CLOCK_ERROR_BIT     = 8;
  localparam int unsigned I2S_INT_CONFIG_ERROR_BIT    = 9;
  localparam int unsigned I2S_INT_CONFIG_DONE_BIT     = 10;
  localparam int unsigned I2S_INT_FRAME_DONE_BIT      = 11;
  // DMA_ERROR : the DMA path did not keep up - a transmit underrun or a receive
  //             overrun happened while that direction's DMA was enabled.
  // FATAL_ERROR : the OR of every condition specification section 56 classifies
  //             as FATAL.  Clock failure is the only such condition this design
  //             can produce; there is no stored FSM state that can be corrupted.
  localparam int unsigned I2S_INT_DMA_ERROR_BIT       = 12;
  localparam int unsigned I2S_INT_FATAL_ERROR_BIT     = 13;
  localparam int unsigned I2S_INT_WIDTH               = 14;

  //---------------------------------------------------------------------------
  // TEST_CTRL / ERROR_INJECT_CTRL / PRBS_CTRL / TEST_STATUS fields
  //---------------------------------------------------------------------------
  localparam int unsigned I2S_TC_SD_FORCE_EN_BIT  = 0;
  localparam int unsigned I2S_TC_SD_FORCE_VAL_BIT = 1;

  localparam int unsigned I2S_EI_ENABLE_BIT = 0;
  localparam int unsigned I2S_EI_TYPE_LSB   = 1;        // 4 bits: nine types
  localparam int unsigned I2S_EI_TYPE_W     = 4;
  localparam int unsigned I2S_EI_COUNT_LSB  = 8;        // 8 bits

  localparam int unsigned I2S_PR_SEL_LSB    = 0;        // 3 bits
  localparam int unsigned I2S_PR_SEL_W      = 3;
  localparam int unsigned I2S_PR_TX_EN_BIT  = 3;
  localparam int unsigned I2S_PR_RX_EN_BIT  = 4;
  localparam int unsigned I2S_PR_RESEED_BIT = 5;        // write-one-pulse

  localparam int unsigned I2S_TS_PRBS_LOCK_BIT = 0;
  localparam int unsigned I2S_TS_PRBS_ERR_BIT  = 1;
  localparam int unsigned I2S_TS_ERRCNT_LSB    = 16;    // 16 bits

  //---------------------------------------------------------------------------
  // Enumerations
  //---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    I2S_FMT_I2S       = 3'd0,   // Philips I2S, WS level, one-SCK data delay
    I2S_FMT_LEFT_J    = 3'd1,   // left justified, WS level, no data delay
    I2S_FMT_RIGHT_J   = 3'd2,   // right justified, WS level, data at slot end
    I2S_FMT_PCM_SHORT = 3'd3,   // one-SCK frame-sync pulse
    I2S_FMT_PCM_LONG  = 3'd4    // frame sync high for FS_WIDTH SCKs
  } i2s_format_e;

  localparam logic [2:0] I2S_FMT_MAX = I2S_FMT_PCM_LONG;

  typedef enum logic [1:0] {
    I2S_MONO_STEREO    = 2'd0,
    I2S_MONO_LEFT_ONLY = 2'd1,
    I2S_MONO_RIGHT_ONLY= 2'd2,
    I2S_MONO_DUPLICATE = 2'd3
  } i2s_mono_e;

  typedef enum logic [1:0] {
    I2S_UNDR_SEND_ZERO = 2'd0,
    I2S_UNDR_HOLD_LAST = 2'd1,
    I2S_UNDR_MUTE      = 2'd2,
    I2S_UNDR_STOP      = 2'd3
  } i2s_underrun_e;

  typedef enum logic [1:0] {
    I2S_OVR_DROP_NEW = 2'd0,
    I2S_OVR_DROP_OLD = 2'd1,
    I2S_OVR_STOP     = 2'd2
  } i2s_overrun_e;

  typedef enum logic [1:0] {
    I2S_PAD_ZERO = 2'd0,
    I2S_PAD_SIGN = 2'd1,
    I2S_PAD_HOLD = 2'd2
  } i2s_pad_e;

  // Error injection types (specification section 62).  All nine of the
  // injections the section lists are implemented.
  typedef enum logic [3:0] {
    I2S_EINJ_BIT_FLIP    = 4'd0,   // invert the serialised bit
    I2S_EINJ_UNDERRUN    = 4'd1,   // suppress the TX FIFO pop
    I2S_EINJ_OVERRUN     = 4'd2,   // suppress the RX FIFO push credit
    I2S_EINJ_WS_PHASE    = 4'd3,   // shift the generated WS by one SCK
    I2S_EINJ_MISSING_BIT = 4'd4,   // skip a payload bit (shift twice)
    I2S_EINJ_EXTRA_BIT   = 4'd5,   // repeat a payload bit (do not shift)
    I2S_EINJ_SLOT_LEN    = 4'd6,   // shorten the generated slot by one SCK
    I2S_EINJ_CHAN_SWAP   = 4'd7,   // invert the transmit channel mapping
    I2S_EINJ_CORRUPT     = 4'd8    // corrupt the sample loaded into the frame
  } i2s_einj_e;

  localparam logic [3:0] I2S_EINJ_MAX = I2S_EINJ_CORRUPT;

  typedef enum logic [2:0] {
    I2S_PRBS7  = 3'd0,
    I2S_PRBS9  = 3'd1,
    I2S_PRBS15 = 3'd2,
    I2S_PRBS23 = 3'd3,
    I2S_PRBS31 = 3'd4
  } i2s_prbs_e;

  localparam logic [2:0] I2S_PRBS_MAX = I2S_PRBS31;

  // TX / RX engine states, exposed through DEBUG_STATE.
  typedef enum logic [2:0] {
    I2S_TX_IDLE   = 3'd0,
    I2S_TX_LOAD   = 3'd1,
    I2S_TX_SHIFT  = 3'd2,
    I2S_TX_PAD    = 3'd3,
    I2S_TX_STOP   = 3'd4
  } i2s_tx_state_e;

  typedef enum logic [2:0] {
    I2S_RX_IDLE    = 3'd0,
    I2S_RX_SYNC    = 3'd1,   // waiting for the first WS/FS edge
    I2S_RX_DELAY   = 3'd2,   // counting the WS-lead SCKs before the MSB
    I2S_RX_CAPTURE = 3'd3,
    I2S_RX_STOP    = 3'd4
  } i2s_rx_state_e;

  //---------------------------------------------------------------------------
  // Address helpers
  //---------------------------------------------------------------------------

  // Returns 1 when `addr` selects an implemented register.
  function automatic logic i2s_addr_is_valid(input logic [31:0] addr);
    unique case (addr)
      I2S_ADDR_ID, I2S_ADDR_VERSION, I2S_ADDR_GLOBAL_CTRL, I2S_ADDR_GLOBAL_STATUS,
      I2S_ADDR_TX_CTRL, I2S_ADDR_RX_CTRL, I2S_ADDR_MODE_CTRL, I2S_ADDR_FORMAT_CTRL,
      I2S_ADDR_SAMPLE_WIDTH, I2S_ADDR_SLOT_WIDTH, I2S_ADDR_CHANNEL_CTRL,
      I2S_ADDR_SAMPLE_RATE_CFG, I2S_ADDR_SCK_DIVIDER, I2S_ADDR_MCLK_CTRL,
      I2S_ADDR_WS_CTRL, I2S_ADDR_SCK_CTRL, I2S_ADDR_DATA_DELAY,
      I2S_ADDR_PADDING_CTRL, I2S_ADDR_MUTE_CTRL, I2S_ADDR_LOOPBACK_CTRL,
      I2S_ADDR_DMA_CTRL, I2S_ADDR_CONFIG_COMMIT, I2S_ADDR_CONFIG_STATUS,
      I2S_ADDR_MUTE_VALUE,
      I2S_ADDR_TX_FIFO_CTRL, I2S_ADDR_TX_FIFO_STATUS, I2S_ADDR_RX_FIFO_CTRL,
      I2S_ADDR_RX_FIFO_STATUS, I2S_ADDR_FIFO_THRESHOLD, I2S_ADDR_FIFO_THRESHOLD2,
      I2S_ADDR_INT_STATUS, I2S_ADDR_INT_MASK, I2S_ADDR_INT_ENABLE,
      I2S_ADDR_TX_SAMPLE_COUNT, I2S_ADDR_RX_SAMPLE_COUNT,
      I2S_ADDR_TX_UNDERRUN_COUNT, I2S_ADDR_RX_OVERRUN_COUNT,
      I2S_ADDR_FRAME_ERROR_COUNT, I2S_ADDR_WS_ERROR_COUNT,
      I2S_ADDR_SCK_ERROR_COUNT, I2S_ADDR_CLOCK_STATUS,
      I2S_ADDR_DEBUG_STATE, I2S_ADDR_DEBUG_SHIFT, I2S_ADDR_DEBUG_FRAME,
      I2S_ADDR_DEBUG_ERROR, I2S_ADDR_CLOCK_CTRL, I2S_ADDR_SAMPLE_RATE_ACT,
      I2S_ADDR_CLOCK_DUTY, I2S_ADDR_TX_DATA, I2S_ADDR_RX_DATA,
      I2S_ADDR_TEST_CTRL, I2S_ADDR_ERROR_INJECT_CTRL, I2S_ADDR_PRBS_CTRL,
      I2S_ADDR_TEST_STATUS : i2s_addr_is_valid = 1'b1;
      default              : i2s_addr_is_valid = 1'b0;
    endcase
  endfunction

  // Returns 1 when `addr` selects a register that ignores writes and must
  // raise PSLVERR when written.
  function automatic logic i2s_addr_is_ro(input logic [31:0] addr);
    unique case (addr)
      I2S_ADDR_ID, I2S_ADDR_VERSION, I2S_ADDR_GLOBAL_STATUS,
      I2S_ADDR_CONFIG_STATUS, I2S_ADDR_TX_FIFO_STATUS, I2S_ADDR_RX_FIFO_STATUS,
      I2S_ADDR_TX_SAMPLE_COUNT, I2S_ADDR_RX_SAMPLE_COUNT,
      I2S_ADDR_TX_UNDERRUN_COUNT, I2S_ADDR_RX_OVERRUN_COUNT,
      I2S_ADDR_FRAME_ERROR_COUNT, I2S_ADDR_WS_ERROR_COUNT,
      I2S_ADDR_SCK_ERROR_COUNT, I2S_ADDR_CLOCK_STATUS,
      I2S_ADDR_DEBUG_STATE, I2S_ADDR_DEBUG_SHIFT, I2S_ADDR_DEBUG_FRAME,
      I2S_ADDR_DEBUG_ERROR, I2S_ADDR_SAMPLE_RATE_ACT, I2S_ADDR_CLOCK_DUTY,
      I2S_ADDR_RX_DATA,
      I2S_ADDR_TEST_STATUS : i2s_addr_is_ro = 1'b1;
      default              : i2s_addr_is_ro = 1'b0;
    endcase
  endfunction

  // THERE IS DELIBERATELY NO `i2s_addr_is_wo`, AND THE ABSENCE IS THE POINT.
  //
  // There used to be one, returning true for CONFIG_COMMIT and TX_DATA, with a
  // comment saying they "ignore reads (reads as 0) and must NOT be treated as
  // an error" -- and nothing called it, correctly, because that is exactly what
  // the register table in doc/i2s_design_spec.md says: `CONFIG_COMMIT` and
  // `TX_DATA` both "read 0x00000000".
  //
  // A function nothing calls is not inert. `<prefix>_addr_is_ro`/`_is_wo` is
  // where thirteen IPs in this family declare access and where every tool that
  // reads RTL for access looks; socgen's extractor reads exactly this shape and
  // skips a function nothing calls, which is the only reason a claim the IP
  // does not implement never reached a generated header. Recorded there as E7,
  // whose proposed fix -- wire it into the PSLVERR term -- would have made
  // these two registers refuse a read the specification says is legal.
  //
  // Their write-only nature is still stated where it is read: the `WO` column
  // of the spec's register table, which data/rdl/i2s.rdl transcribes.

  //---------------------------------------------------------------------------
  // Pure helpers
  //---------------------------------------------------------------------------

  // Returns 1 when `v` is an exact power of two and non-zero.
  function automatic logic i2s_is_pow2(input int unsigned v);
    i2s_is_pow2 = (v != 0) && ((v & (v - 1)) == 0);
  endfunction

  // Ceiling log2 with a floor of 1, so that a one-bit index is never zero
  // wide.
  function automatic int unsigned i2s_clog2(input int unsigned v);
    int unsigned r;
    r = 0;
    while ((32'(1) << r) < v) r++;
    i2s_clog2 = (r == 0) ? 1 : r;
  endfunction

  //---------------------------------------------------------------------------
  // Gray-code helpers for the asynchronous FIFO pointers.
  //
  // Both operate at I2S_MAX_PTR_W and are used with zero-extended narrower
  // pointers.  That is exact rather than merely convenient: the Gray code of a
  // value whose top bits are zero also has those top bits zero, and the
  // reflected-binary conversion of a zero prefix reproduces the same zero
  // prefix, so the low bits are unaffected by the extension.
  //---------------------------------------------------------------------------
  function automatic logic [I2S_MAX_PTR_W-1:0]
      i2s_bin2gray(input logic [I2S_MAX_PTR_W-1:0] b);
    i2s_bin2gray = b ^ (b >> 1);
  endfunction

  function automatic logic [I2S_MAX_PTR_W-1:0]
      i2s_gray2bin(input logic [I2S_MAX_PTR_W-1:0] g);
    logic [I2S_MAX_PTR_W-1:0] b;
    b[I2S_MAX_PTR_W-1] = g[I2S_MAX_PTR_W-1];
    for (int unsigned i = I2S_MAX_PTR_W-1; i > 0; i--) begin
      b[i-1] = b[i] ^ g[i-1];
    end
    i2s_gray2bin = b;
  endfunction

  //---------------------------------------------------------------------------
  // The committed (timing-critical) configuration.
  //
  // This type is the payload of the pclk -> serial-clock configuration
  // crossing, so it lives in the package rather than in i2s_regs: the register
  // block builds it, i2s_cdc_data carries it, and i2s_core consumes it, and all
  // three must agree on the layout bit for bit.
  //
  // The two divider fields are I2S_MAX_DIV_WIDTH wide regardless of the DIV_WIDTH
  // parameter so that the crossing has a build-independent width; the register
  // block zero-extends on the way in and i2s_core truncates on the way out, and
  // bits above DIV_WIDTH are therefore always zero.
  //---------------------------------------------------------------------------
  typedef struct packed {
    logic [I2S_WIDTH_FIELD_W-1:0] sample_width;
    logic [I2S_WIDTH_FIELD_W-1:0] slot_width;
    logic [2:0]                   format;
    logic                         ws_pol;
    logic [I2S_DELAY_FIELD_W-1:0] ws_lead;
    logic [I2S_WIDTH_FIELD_W-1:0] fs_width;
    logic [I2S_MAX_DIV_WIDTH-1:0] sck_div;
    logic                         sck_inv;
    logic                         mclk_en;
    logic [I2S_MAX_DIV_WIDTH-1:0] mclk_div;
    logic                         mclk_pol;
    logic [1:0]                   mono;
    logic                         swap;
    logic                         target;
    logic                         launch_edge;
    logic                         sample_edge;
    logic [1:0]                   pad_mode;
  } i2s_cfg_t;

  localparam int unsigned I2S_CFG_W = $bits(i2s_cfg_t);

  // Reset / power-on configuration.  It is deliberately a LEGAL configuration
  // so that CONFIG_STATUS.ACTIVE is set out of reset and the IP can be enabled
  // without a commit.  Both the pclk mirror in i2s_regs and the serial-domain
  // active copy in i2s_core reset to exactly this value, which is why it is a
  // package function rather than a local one: if the two disagreed, the IP
  // would come out of reset reporting a configuration it is not running.
  function automatic i2s_cfg_t
      i2s_cfg_reset_value(input logic [I2S_WIDTH_FIELD_W-1:0] sample_width_max,
                          input logic [I2S_WIDTH_FIELD_W-1:0] slot_width_max);
    i2s_cfg_t c;
    c.sample_width = sample_width_max;
    c.slot_width   = slot_width_max;
    c.format       = I2S_FMT_I2S;
    c.ws_pol       = 1'b0;
    c.ws_lead      = I2S_DELAY_FIELD_W'(1);
    c.fs_width     = I2S_WIDTH_FIELD_W'(1);
    c.sck_div      = I2S_MAX_DIV_WIDTH'(1);
    c.sck_inv      = 1'b0;
    c.mclk_en      = 1'b0;
    c.mclk_div     = I2S_MAX_DIV_WIDTH'(1);
    c.mclk_pol     = 1'b0;
    c.mono         = I2S_MONO_STEREO;
    c.swap         = 1'b0;
    c.target       = 1'b0;
    c.launch_edge  = 1'b0;
    c.sample_edge  = 1'b0;
    c.pad_mode     = I2S_PAD_ZERO;
    return c;
  endfunction

endpackage : i2s_pkg

`endif // I2S_PKG_SV
