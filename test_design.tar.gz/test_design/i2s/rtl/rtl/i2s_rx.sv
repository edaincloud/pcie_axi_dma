//=============================================================================
// File        : i2s_rx.sv
// Description : I2S receive path: deserialiser, padding removal, sign
//               extension, channel mapping and overrun policy (specification
//               section 19).
//
//               The frame position comes from i2s_track, which recovers it
//               from the synchronised WS line, so the same deserialiser is
//               used in controller and in target mode - in controller mode it
//               simply follows the WS the IP itself generated, observed
//               through the same input synchronisers as an external one.
//               That is deliberate: the receive path has exactly one timing
//               model to verify, not two.
//
//               A completed frame is buffered and then pushed into the RX FIFO
//               in stream order with MONO_MODE and CHANNEL_SWAP applied, which
//               mirrors i2s_tx and keeps the channel mapping out of the
//               protocol timing (specification section 29).
//=============================================================================

`default_nettype none

module i2s_rx
  import i2s_pkg::*;
#(
    parameter int unsigned SAMPLE_WIDTH_MAX = 32
) (
    input  wire                            clk_i,
    input  wire                            rst_ni,

    input  wire                            run_i,          // engine active
    input  wire                            capture_en_i,   // SCK sample strobe
    input  wire                            pos_valid_i,    // position established
    input  wire                            pos_slot_i,
    input  wire  [I2S_WIDTH_FIELD_W-1:0]   pos_bit_i,
    input  wire                            sd_i,           // synchronised SD

    // ---- active configuration ----------------------------------------------
    input  wire  [I2S_WIDTH_FIELD_W-1:0]   sample_width_i,
    input  wire  [I2S_WIDTH_FIELD_W-1:0]   slot_width_i,
    input  wire  [2:0]                     format_i,
    input  wire  [1:0]                     mono_i,
    input  wire                            swap_i,
    input  wire                            sign_extend_i,
    input  wire  [1:0]                     overrun_mode_i,
    input  wire                            mute_rx_i,

    // ---- RX FIFO ------------------------------------------------------------
    input  wire                            fifo_full_i,
    output logic                           fifo_push_o,
    output logic [SAMPLE_WIDTH_MAX-1:0]    fifo_wdata_o,

    // ---- test hooks ----------------------------------------------------------
    input  wire                            inj_overrun_i,  // force the FIFO full

    // ---- outputs -------------------------------------------------------------
    output logic                           data_bit_en_o,  // capturing a payload bit
    output logic                           overrun_o,
    output logic                           sample_recv_o,  // one pulse per slot
    output logic                           stop_req_o,     // OVR_STOP policy
    output logic [SAMPLE_WIDTH_MAX-1:0]    shift_dbg_o,
    output logic [2:0]                     state_dbg_o
);

  localparam int unsigned SW = SAMPLE_WIDTH_MAX;
  localparam int unsigned BW = I2S_WIDTH_FIELD_W;

  //---------------------------------------------------------------------------
  // Data window inside the slot
  //---------------------------------------------------------------------------
  logic [BW-1:0] rj_start;
  logic          in_data;
  logic          first_data_bit;

  always_comb begin
    rj_start = (slot_width_i > sample_width_i) ? (slot_width_i - sample_width_i) : BW'(0);
    if (format_i == I2S_FMT_RIGHT_J) begin
      in_data        = (pos_bit_i >= rj_start) && (pos_bit_i < slot_width_i);
      first_data_bit = (pos_bit_i == rj_start);
    end else begin
      in_data        = (pos_bit_i < sample_width_i);
      first_data_bit = (pos_bit_i == '0);
    end
  end

  //---------------------------------------------------------------------------
  // Deserialiser
  //---------------------------------------------------------------------------
  logic [SW-1:0] shift_q;
  logic          sign_bit_q;
  logic [SW-1:0] shift_next;
  logic          sign_bit_now;

  assign shift_next   = in_data ? {shift_q[SW-2:0], sd_i} : shift_q;
  assign sign_bit_now = (in_data && first_data_bit) ? sd_i : sign_bit_q;

  // Zero or sign extension of the assembled sample to the full datapath width
  // (specification section 22).
  logic [SW-1:0] width_mask;
  logic [SW-1:0] cur_sample;

  always_comb begin
    width_mask = SW'((64'(1) << sample_width_i) - 64'd1);
    cur_sample = shift_next & width_mask;
    if (sign_extend_i && sign_bit_now) begin
      cur_sample = cur_sample | ~width_mask;
    end
  end

  logic slot_end;
  assign slot_end = run_i & capture_en_i & pos_valid_i &
                    (pos_bit_i == (slot_width_i - BW'(1)));

  logic frame_end;
  assign frame_end = slot_end & (pos_slot_i == 1'b1);

  logic [SW-1:0] slot0_q;

  //---------------------------------------------------------------------------
  // Slot -> stream mapping: CHANNEL_SWAP then MONO_MODE
  //---------------------------------------------------------------------------
  logic [SW-1:0] frame0, frame1;         // slot 0 / slot 1 samples of the frame
  logic [SW-1:0] sl0, sl1;               // after undoing the channel swap
  logic [SW-1:0] st0, st1;               // stream entries
  logic [1:0]    n_push;

  assign frame0 = slot0_q;
  assign frame1 = cur_sample;

  assign sl0 = swap_i ? frame1 : frame0;
  assign sl1 = swap_i ? frame0 : frame1;

  always_comb begin
    unique case (mono_i)
      I2S_MONO_LEFT_ONLY  : begin st0 = sl0; st1 = '0;  n_push = 2'd1; end
      I2S_MONO_RIGHT_ONLY : begin st0 = sl1; st1 = '0;  n_push = 2'd1; end
      I2S_MONO_DUPLICATE  : begin st0 = sl0; st1 = '0;  n_push = 2'd1; end
      default             : begin st0 = sl0; st1 = sl1; n_push = 2'd2; end
    endcase
    if (mute_rx_i) begin
      st0 = '0;
      st1 = '0;
    end
  end

  //---------------------------------------------------------------------------
  // Push queue.  A frame yields up to two samples but the FIFO has one write
  // port, so the frame is buffered and drained one entry per clock.
  //---------------------------------------------------------------------------
  logic [SW-1:0] pend_q [I2S_NUM_SLOTS];
  logic [1:0]    pend_cnt_q;
  logic [1:0]    pend_rd_q;

  logic          have_pend;
  logic [SW-1:0] pend_head;
  logic          fifo_blocked;

  assign have_pend    = (pend_rd_q < pend_cnt_q);
  assign pend_head    = pend_q[pend_rd_q[0]];
  assign fifo_blocked = fifo_full_i | inj_overrun_i;

  // Overrun handling (specification section 36).
  //
  // DROP_OLD still PRESENTS the sample when the FIFO reports itself full,
  // rather than discarding it the way DROP_NEW does.  With the asynchronous
  // FIFO the room is made on the far side - i2s_fifo_async discards the oldest
  // entry from its read port when RX_CTRL.OVERRUN_MODE selects DROP_OLD - so a
  // presented sample is stored as soon as that discard has propagated back
  // through the pointer synchroniser.  The write side of an asynchronous FIFO
  // cannot itself retire the oldest entry, because it does not own the read
  // pointer; the consequence is recorded in Appendix A of the design
  // specification.
  logic push_ok;
  always_comb begin
    push_ok = 1'b0;
    if (run_i && have_pend) begin
      if (!fifo_blocked || (overrun_mode_i == I2S_OVR_DROP_OLD)) begin
        push_ok = 1'b1;
      end
    end
  end

  assign fifo_push_o  = push_ok;
  assign fifo_wdata_o = pend_head;

  assign overrun_o  = run_i & have_pend & fifo_blocked;
  assign stop_req_o = (overrun_mode_i == I2S_OVR_STOP) & overrun_o;

  //---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      shift_q    <= '0;
      sign_bit_q <= 1'b0;
      slot0_q    <= '0;
      for (int unsigned i = 0; i < I2S_NUM_SLOTS; i++) pend_q[i] <= '0;
      pend_cnt_q <= '0;
      pend_rd_q  <= '0;
    end else if (!run_i) begin
      shift_q    <= '0;
      sign_bit_q <= 1'b0;
      // slot0_q holds the left sample while its right partner is still being
      // received, so it is live state and must clear with the rest of the
      // pipeline.  Leaving it set carried the previous burst's left sample into
      // the first frame of the next one, which then pushed a stale sample into
      // the RX FIFO ahead of any real data.
      slot0_q    <= '0;
      pend_cnt_q <= '0;
      pend_rd_q  <= '0;
    end else begin
      if (capture_en_i && pos_valid_i) begin
        shift_q <= shift_next;
        if (in_data && first_data_bit) sign_bit_q <= sd_i;
      end

      if (slot_end && (pos_slot_i == 1'b0)) begin
        slot0_q <= cur_sample;
      end

      if (frame_end) begin
        pend_q[0]  <= st0;
        pend_q[1]  <= st1;
        pend_cnt_q <= n_push;
        pend_rd_q  <= '0;
      end else if (push_ok) begin
        pend_rd_q <= pend_rd_q + 2'd1;
      end else if (have_pend && fifo_blocked &&
                   (overrun_mode_i != I2S_OVR_DROP_OLD)) begin
        // DROP_NEW and STOP both discard the entry that cannot be stored.
        pend_rd_q <= pend_rd_q + 2'd1;
      end
    end
  end

  assign data_bit_en_o = run_i & capture_en_i & pos_valid_i & in_data;
  assign sample_recv_o = slot_end;
  assign shift_dbg_o   = shift_q;

  always_comb begin
    if      (!run_i)       state_dbg_o = I2S_RX_IDLE;
    else if (stop_req_o)   state_dbg_o = I2S_RX_STOP;
    else if (!pos_valid_i) state_dbg_o = I2S_RX_SYNC;
    else if (in_data)      state_dbg_o = I2S_RX_CAPTURE;
    else                   state_dbg_o = I2S_RX_DELAY;
  end

endmodule : i2s_rx

`default_nettype wire
