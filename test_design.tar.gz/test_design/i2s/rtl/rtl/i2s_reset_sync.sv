//=============================================================================
// File        : i2s_reset_sync.sv
// Description : Reset synchronizer.  Asserts asynchronously, de-asserts
//               synchronously to the destination clock.
//
//               This removes the reset-recovery/removal timing hazard that a
//               raw asynchronous reset de-assertion creates, and keeps the
//               design RDC (Reset Domain Crossing) clean.
//
// Notes       : - No combinational logic in the reset path other than the
//                 optional polarity inversion done by the parent.
//               - The flops are intentionally reset to 0 and shift in a
//                 constant 1, so the output can only leave reset after
//                 STAGES rising clock edges with the input reset released.
//               - DFT: the synchronizer flops are ordinary flops and are scan
//                 replaceable.  Reset control during scan is handled at the
//                 SoC level by driving `rst_in_n` from the test reset.
//=============================================================================

`default_nettype none

module i2s_reset_sync #(
    // Number of synchronizer stages.  Two is the industry minimum; three is
    // sometimes used for very high frequency / high MTBF requirements.
    parameter int unsigned STAGES = 2
) (
    input  wire  clk,       // Destination clock
    input  wire  rst_in_n,  // Asynchronous active-low reset input
    output wire  rst_out_n  // Synchronously de-asserted active-low reset
);

  // ---------------------------------------------------------------------------
  // Elaboration checks
  // ---------------------------------------------------------------------------
  if (STAGES < 2) begin : gen_chk_stages
    $error("i2s_reset_sync: STAGES must be >= 2 (got %0d)", STAGES);
  end

  // A reset synchroniser is by construction a chain whose flops are reset
  // asynchronously and clocked synchronously; the SYNCASYNCNET check fires on
  // every correct implementation of this cell and is waived here only.
  /* verilator lint_off SYNCASYNCNET */
  logic [STAGES-1:0] sync_q;
  /* verilator lint_on SYNCASYNCNET */

  always_ff @(posedge clk or negedge rst_in_n) begin
    if (!rst_in_n) begin
      sync_q <= '0;
    end else begin
      sync_q <= {sync_q[STAGES-2:0], 1'b1};
    end
  end

  assign rst_out_n = sync_q[STAGES-1];

endmodule : i2s_reset_sync

`default_nettype wire
