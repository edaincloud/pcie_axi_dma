//=============================================================================
// File        : i2s_cdc_data.sv
// Description : Multi-bit clock-domain crossing by four-phase request/
//               acknowledge handshake with the payload held stable across the
//               whole transfer.
//
//               Why this and not a synchroniser per bit
//               --------------------------------------
//               A vector taken through one i2s_sync per bit is NOT a crossing
//               of that vector.  Each bit resolves independently, so on the
//               cycle a multi-bit field changes the destination can observe a
//               mixture of old and new bits - a value that never existed in the
//               source domain.  For an audio configuration that means, for
//               example, the new SAMPLE_WIDTH with the old SLOT_WIDTH, which is
//               an illegal combination the validator explicitly rejects.
//
//               Here the payload is captured into `hold_q` at the instant the
//               request is raised and is not touched again until the
//               destination has acknowledged, so the destination samples a
//               value that is stable for the whole of the synchroniser delay
//               and is by construction a value the source really held.
//
//               Protocol (four phase, both edges of the handshake sequenced)
//               -----------------------------------------------------------
//                 source                        destination
//                 hold <= data, req = 1  --->    capture hold, valid = 1
//                                                consume, ack = 1
//                 req = 0                <---
//                                        --->    ack = 0
//                 done pulse, idle       <---
//
//               Only `req` and `ack` cross, each a single bit through
//               STAGES flops, and each is guaranteed to be stable for many
//               destination cycles by the phase that precedes it.
//
//               AUTO mode
//               ---------
//               With AUTO the source launches a transfer by itself whenever
//               the live value differs from the one last delivered, which
//               turns the channel into an eventually-consistent mirror of a
//               source register - the right structure for a control field
//               whose semantics are "takes effect promptly" rather than "takes
//               effect at a specific instant".  A transfer is also forced once
//               out of reset (`first_q`), so the destination is initialised
//               from the source even when the source value happens to equal
//               the destination's reset value.
//
//               With AUTO cleared the source launches on `src_launch_i` and
//               the destination decides when to consume, which is what the
//               configuration commit needs: the serial domain holds the new
//               configuration until its own frame boundary and only then
//               acknowledges, so `src_done_o` means "applied", not "arrived".
//
// Notes       : No combinational path exists from any source input to any
//               destination output: every destination output is a flop whose
//               input comes either from `hold_q` (stable, and only sampled
//               after STAGES destination edges) or from local state.
//=============================================================================

`default_nettype none

module i2s_cdc_data #(
    parameter int unsigned WIDTH  = 1,
    // Synchroniser depth in each direction.
    parameter int unsigned STAGES = 2,
    // 1: launch automatically on a change of `src_data_i` (mirror a register).
    // 0: launch on `src_launch_i` and let the destination choose when to
    //    consume (deferred application).
    parameter bit          AUTO   = 1'b1
) (
    // ---- source domain -------------------------------------------------------
    input  wire              src_clk_i,
    input  wire              src_rst_ni,
    input  wire  [WIDTH-1:0] src_data_i,
    input  wire              src_launch_i,
    output logic             src_busy_o,
    output logic             src_done_o,

    // ---- destination domain --------------------------------------------------
    input  wire              dst_clk_i,
    input  wire              dst_rst_ni,
    output logic [WIDTH-1:0] dst_data_o,
    output logic             dst_valid_o,
    input  wire              dst_consume_i
);

  if (STAGES < 2) begin : gen_chk_stages
    $error("i2s_cdc_data: STAGES must be >= 2 (got %0d)", STAGES);
  end
  if (WIDTH < 1) begin : gen_chk_width
    $error("i2s_cdc_data: WIDTH must be >= 1 (got %0d)", WIDTH);
  end

  //---------------------------------------------------------------------------
  // Source side
  //---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    S_IDLE = 2'd0,
    S_REQ  = 2'd1,
    S_WAIT = 2'd2
  } src_state_e;

  src_state_e       src_st_q;
  logic [WIDTH-1:0] hold_q;
  logic             req_q;
  logic             first_q;
  logic             done_q;
  logic             ack_s;
  logic             launch;

  assign launch = AUTO ? (first_q | (src_data_i != hold_q)) : src_launch_i;

  always_ff @(posedge src_clk_i or negedge src_rst_ni) begin
    if (!src_rst_ni) begin
      src_st_q <= S_IDLE;
      hold_q   <= '0;
      req_q    <= 1'b0;
      first_q  <= 1'b1;
      done_q   <= 1'b0;
    end else begin
      done_q <= 1'b0;
      unique case (src_st_q)
        S_IDLE : begin
          if (launch) begin
            hold_q   <= src_data_i;
            req_q    <= 1'b1;
            first_q  <= 1'b0;
            src_st_q <= S_REQ;
          end
        end
        S_REQ : begin
          if (ack_s) begin
            req_q    <= 1'b0;
            src_st_q <= S_WAIT;
          end
        end
        S_WAIT : begin
          if (!ack_s) begin
            done_q   <= 1'b1;
            src_st_q <= S_IDLE;
          end
        end
        default : src_st_q <= S_IDLE;
      endcase
    end
  end

  assign src_busy_o = (src_st_q != S_IDLE);
  assign src_done_o = done_q;

  //---------------------------------------------------------------------------
  // Destination side
  //---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    D_IDLE = 2'd0,
    D_PEND = 2'd1,
    D_ACK  = 2'd2
  } dst_state_e;

  dst_state_e       dst_st_q;
  logic [WIDTH-1:0] data_q;
  logic             valid_q;
  logic             ack_q;
  logic             req_s;

  always_ff @(posedge dst_clk_i or negedge dst_rst_ni) begin
    if (!dst_rst_ni) begin
      dst_st_q <= D_IDLE;
      data_q   <= '0;
      valid_q  <= 1'b0;
      ack_q    <= 1'b0;
    end else begin
      unique case (dst_st_q)
        D_IDLE : begin
          if (req_s) begin
            // `hold_q` has been constant since at least STAGES destination
            // edges ago, because the source raised `req_q` on the same edge it
            // loaded `hold_q` and cannot reload it before this handshake ends.
            data_q   <= hold_q;
            valid_q  <= 1'b1;
            dst_st_q <= D_PEND;
          end
        end
        D_PEND : begin
          if (dst_consume_i) begin
            valid_q  <= 1'b0;
            ack_q    <= 1'b1;
            dst_st_q <= D_ACK;
          end
        end
        D_ACK : begin
          if (!req_s) begin
            ack_q    <= 1'b0;
            dst_st_q <= D_IDLE;
          end
        end
        default : dst_st_q <= D_IDLE;
      endcase
    end
  end

  assign dst_data_o  = data_q;
  assign dst_valid_o = valid_q;

  //---------------------------------------------------------------------------
  // The two single-bit crossings
  //---------------------------------------------------------------------------
  i2s_sync #(.WIDTH(1), .STAGES(STAGES)) u_req_sync (
      .clk_i  (dst_clk_i),
      .rst_ni (dst_rst_ni),
      .d_i    (req_q),
      .q_o    (req_s)
  );

  i2s_sync #(.WIDTH(1), .STAGES(STAGES)) u_ack_sync (
      .clk_i  (src_clk_i),
      .rst_ni (src_rst_ni),
      .d_i    (ack_q),
      .q_o    (ack_s)
  );

endmodule : i2s_cdc_data

`default_nettype wire
