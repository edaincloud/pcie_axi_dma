//=============================================================================
// File        : i2s_fifo_async.sv
// Description : Dual-clock (asynchronous) show-ahead sample FIFO with
//               Gray-coded pointers.  This is the structure specification
//               section 32 asks for: the software/DMA side and the I2S serial
//               side each own one port and run on their own clock, with no
//               defined phase relationship between them.
//
//               Pointer crossing
//               ----------------
//                 - each side keeps its pointer in BOTH binary and Gray form.
//                   The binary copy is local arithmetic and never crosses; the
//                   Gray copy is what crosses, and it changes exactly one bit
//                   per increment, so a sample taken while it is changing is
//                   either the value before or the value after - never a value
//                   that never existed.
//                 - the Gray pointer is registered before it leaves its domain
//                   and enters the other domain through SYNC_STAGES flops with
//                   no logic between them (i2s_sync).
//                 - full, empty and both levels are derived ONLY from the local
//                   pointer and the SYNCHRONISED far pointer.  No raw
//                   far-domain pointer is used anywhere, and there is no
//                   combinational path from one clock domain to the other.
//                 - each side's view of the other therefore LAGS.  That lag is
//                   in the safe direction on both sides and by construction:
//                   the writer under-counts reads, so it can only think the
//                   FIFO is fuller than it is and never overwrites live data;
//                   the reader under-counts writes, so it can only think the
//                   FIFO is emptier than it is and never reads an entry the
//                   writer has not finished writing.
//                 - the payload crosses through the memory array and is
//                   therefore not a crossing at all in the CDC sense: the
//                   address the reader presents can only reach an entry whose
//                   write completed at least SYNC_STAGES read clocks earlier,
//                   which is exactly what the pointer handshake guarantees.
//
//               Flush (specification section 33)
//               -------------------------------
//               Flushing one side of an asynchronous FIFO on its own is not
//               safe: zeroing a pointer is a multi-bit change that the other
//               side would see through its synchroniser as an arbitrary
//               intermediate value, and the other side is meanwhile still
//               pushing or popping against a level computed from it.
//
//               A flush here is therefore a QUIESCE protocol, and both sides
//               take part.  A request from either side starts one write-domain
//               state machine:
//
//                 1. the write side raises `w_flushing` and stops accepting
//                    pushes;
//                 2. the read side sees `w_flushing` through its synchroniser,
//                    stops popping, zeroes its own pointer and raises its
//                    quiesced indication;
//                 3. the write side sees that indication - by which time the
//                    zeroed read pointer has already propagated through the
//                    write side's own synchroniser, because both travel the
//                    same number of stages from the same edge - and zeroes its
//                    own pointer;
//                 4. the write side holds the zeroed pointer for a full cycle
//                    before dropping `w_flushing`, so the read side cannot
//                    resume until the zero has propagated to it;
//                 5. both sides resume, with both pointers and both
//                    synchronised copies at zero.
//
//               Throughout, both sides report empty / level zero and neither
//               pushes nor pops, so no transient pointer value is ever visible
//               in a flag or acted upon.
//
//               Overrun policy
//               --------------
//               `r_drop_when_full_i` implements RX_CTRL.OVERRUN_MODE = DROP_OLD
//               on the READ side: when the reader sees the FIFO full and no
//               software or DMA read is taking the entry, it discards the
//               oldest entry itself and so keeps making room for new samples.
//               DROP_OLD cannot be done from the write side of an asynchronous
//               FIFO - the write side does not own the read pointer - and the
//               consequence is recorded in Appendix A of the design
//               specification.
//=============================================================================

`default_nettype none

module i2s_fifo_async
  import i2s_pkg::*;
#(
    parameter int unsigned WIDTH       = 32,
    // Must be a power of two in [I2S_MIN_FIFO_DEPTH : I2S_MAX_FIFO_DEPTH].
    parameter int unsigned DEPTH       = 8,
    parameter int unsigned SYNC_STAGES = 2
) (
    // ---- write domain --------------------------------------------------------
    input  wire                w_clk_i,
    input  wire                w_rst_ni,
    input  wire                w_flush_req_i,    // level, write domain
    output logic               w_flush_busy_o,
    input  wire                push_i,
    input  wire  [WIDTH-1:0]   wdata_i,
    output logic [15:0]        w_level_o,
    output logic               w_full_o,
    output logic               w_empty_o,
    output logic               w_overflow_o,

    // ---- read domain ---------------------------------------------------------
    input  wire                r_clk_i,
    input  wire                r_rst_ni,
    input  wire                r_flush_req_i,    // level, read domain
    output logic               r_flush_busy_o,
    input  wire                pop_i,
    input  wire                r_drop_when_full_i,
    output logic [WIDTH-1:0]   rdata_o,
    output logic [15:0]        r_level_o,
    output logic               r_empty_o,
    output logic               r_full_o,
    output logic               r_underflow_o
);

  //---------------------------------------------------------------------------
  // Elaboration checks
  //---------------------------------------------------------------------------
  if (!i2s_is_pow2(DEPTH)) begin : gen_chk_pow2
    $error("i2s_fifo_async: DEPTH must be a power of two (got %0d)", DEPTH);
  end
  if (DEPTH < I2S_MIN_FIFO_DEPTH) begin : gen_chk_depth_min
    $error("i2s_fifo_async: DEPTH must be >= %0d (got %0d)", I2S_MIN_FIFO_DEPTH, DEPTH);
  end
  if (DEPTH > I2S_MAX_FIFO_DEPTH) begin : gen_chk_depth_max
    $error("i2s_fifo_async: DEPTH must be <= %0d (got %0d)", I2S_MAX_FIFO_DEPTH, DEPTH);
  end
  if (SYNC_STAGES < I2S_MIN_SYNC_STAGES) begin : gen_chk_sync_min
    $error("i2s_fifo_async: SYNC_STAGES must be >= %0d (got %0d)",
           I2S_MIN_SYNC_STAGES, SYNC_STAGES);
  end

  localparam int unsigned PTR_W = i2s_clog2(DEPTH);
  // One extra bit above the address so that a pointer difference of exactly
  // DEPTH is representable and "full" is distinguishable from "empty".
  localparam int unsigned AW    = PTR_W + 1;

  logic [WIDTH-1:0] mem_q [DEPTH];

  //---------------------------------------------------------------------------
  // Write-domain state
  //---------------------------------------------------------------------------
  logic [AW-1:0] wbin_q, wgray_q;
  logic [AW-1:0] rgray_ws, rbin_ws;
  logic [AW-1:0] w_used;
  logic [AW-1:0] wbin_next;
  logic          do_push;

  //---------------------------------------------------------------------------
  // Read-domain state
  //---------------------------------------------------------------------------
  logic [AW-1:0] rbin_q, rgray_q;
  logic [AW-1:0] wgray_rs, wbin_rs;
  logic [AW-1:0] r_used;
  logic [AW-1:0] rbin_next;
  logic          do_pop, drop_pop;

  //---------------------------------------------------------------------------
  // Flush control
  //---------------------------------------------------------------------------
  typedef enum logic [1:0] {
    F_IDLE    = 2'd0,
    F_QUIESCE = 2'd1,
    F_ZERO    = 2'd2,
    F_DRAIN   = 2'd3
  } flush_state_e;

  flush_state_e flush_q;
  logic         w_flushing;
  logic         r_flushing_q, r_flushing;
  logic         r_quiesced_ws;    // read side quiesced, seen in the write domain
  logic         r_req_ws;         // read-side flush request, seen in write domain
  logic         w_flushing_rs;    // write-side flush level, seen in read domain
  logic         r_req_q;          // read-side request, held until taken

  // `w_flushing` is the level that CROSSES, and it must fall in F_DRAIN: the
  // read side follows it, and the write side leaves F_DRAIN only when the read
  // side has stopped following.  Deriving it from `flush_q != F_IDLE` instead
  // makes the two wait for each other forever, and a FIFO stuck flushing
  // silently discards everything ever written to it.
  assign w_flushing = (flush_q == F_QUIESCE) || (flush_q == F_ZERO);

  // Busy, by contrast, covers the whole sequence including F_DRAIN, so a new
  // request cannot be accepted until the previous flush has fully unwound.
  assign w_flush_busy_o = (flush_q != F_IDLE);

  // The registered copy is what the write side handshakes against, because it
  // changes on the same edge as the zeroed read pointer and therefore reaches
  // the write domain with exactly the same delay.  The combinational OR is what
  // gates the read port, so a pop is already blocked on the cycle the flush
  // level arrives and stays blocked one cycle after it leaves.
  assign r_flushing     = r_flushing_q | w_flushing_rs;
  assign r_flush_busy_o = r_flushing | r_flush_req_i | r_req_q;

  // A READ-SIDE REQUEST IS HELD UNTIL THE WRITE SIDE HAS TAKEN IT.
  //
  // `r_flush_req_i` can be as short as one r_clk cycle: i2s_top's hold flop
  // drops it the moment this FIFO reports busy, and busy includes the request
  // itself. It crosses into the write domain through a LEVEL synchroniser, so
  // a request shorter than a w_clk period is simply missed. On the RX FIFO,
  // written on sclk, that was about three software flushes in four at pclk
  // 100 MHz / sclk 25 MHz -- each one reported complete by FLUSH_BUSY, with
  // the FIFO still full of what it was meant to discard (found by the socgen
  // demo SoCs, whose I2S loop test failed on some firmware builds and not
  // others).
  //
  // So the request is captured here and held until the write side's flush
  // level comes back (`w_flushing_rs`), which is the write side's
  // acknowledgement. It is cleared on the same edge that raises
  // `r_flushing_q`, so its fall reaches the write domain with the same delay
  // as `r_quiesced_ws` rises: the state machine is out of F_IDLE long before
  // and cannot see it again, and one request is one flush. A request made
  // while a flush is already running is absorbed by it, as before; one made
  // during F_DRAIN waits and starts the next.
  always_ff @(posedge r_clk_i or negedge r_rst_ni) begin
    if (!r_rst_ni)          r_req_q <= 1'b0;
    else if (w_flushing_rs) r_req_q <= 1'b0;
    else if (r_flush_req_i) r_req_q <= 1'b1;
  end

  i2s_sync #(.WIDTH(1), .STAGES(SYNC_STAGES)) u_r_req_sync (
      .clk_i(w_clk_i), .rst_ni(w_rst_ni), .d_i(r_req_q), .q_o(r_req_ws));

  i2s_sync #(.WIDTH(1), .STAGES(SYNC_STAGES)) u_r_quiesced_sync (
      .clk_i(w_clk_i), .rst_ni(w_rst_ni), .d_i(r_flushing_q), .q_o(r_quiesced_ws));

  i2s_sync #(.WIDTH(1), .STAGES(SYNC_STAGES)) u_w_flushing_sync (
      .clk_i(r_clk_i), .rst_ni(r_rst_ni), .d_i(w_flushing), .q_o(w_flushing_rs));

  always_ff @(posedge w_clk_i or negedge w_rst_ni) begin
    if (!w_rst_ni) begin
      flush_q <= F_IDLE;
    end else begin
      unique case (flush_q)
        F_IDLE    : if (w_flush_req_i || r_req_ws) flush_q <= F_QUIESCE;
        // Wait for the reader to confirm it has stopped and zeroed its pointer.
        F_QUIESCE : if (r_quiesced_ws)             flush_q <= F_ZERO;
        // One whole cycle with the write pointer already at zero and the flush
        // level still high, so the reader cannot resume before the zero has
        // reached it.
        F_ZERO    :                                flush_q <= F_DRAIN;
        // Hold off a new request until the reader has withdrawn its quiesced
        // indication, so two flushes cannot overlap.
        F_DRAIN   : if (!r_quiesced_ws)            flush_q <= F_IDLE;
        default   :                                flush_q <= F_IDLE;
      endcase
    end
  end

  //---------------------------------------------------------------------------
  // Write side
  //---------------------------------------------------------------------------
  // The incremented pointer is computed into an AW-wide net BEFORE it is widened
  // for the Gray conversion, and it has to be.  Written inline as
  // `I2S_MAX_PTR_W'(wbin_q + AW'(1))` the cast makes the addition itself
  // I2S_MAX_PTR_W wide, so the wrap from all-ones to zero produces 2**AW instead
  // of 0 - and the Gray copy then encodes a pointer the binary copy never held.
  assign wbin_next = wbin_q + AW'(1);

  assign rbin_ws = AW'(i2s_gray2bin(I2S_MAX_PTR_W'(rgray_ws)));
  assign w_used  = wbin_q - rbin_ws;

  assign w_full_o     = ~w_flushing & (w_used == AW'(DEPTH));
  assign w_empty_o    =  w_flushing | (w_used == AW'(0));
  assign w_level_o    =  w_flushing ? 16'h0 : 16'(w_used);
  assign do_push      =  push_i & ~w_full_o & ~w_flushing;
  // A push presented during a flush is part of what the flush discards, so it
  // is dropped without raising overflow; overflow means "the FIFO was full",
  // which is a different report.
  assign w_overflow_o =  push_i & w_full_o & ~w_flushing;

  always_ff @(posedge w_clk_i or negedge w_rst_ni) begin
    if (!w_rst_ni) begin
      wbin_q  <= '0;
      wgray_q <= '0;
    end else if (flush_q == F_QUIESCE && r_quiesced_ws) begin
      wbin_q  <= '0;
      wgray_q <= '0;
    end else if (do_push) begin
      wbin_q  <= wbin_next;
      wgray_q <= AW'(i2s_bin2gray(I2S_MAX_PTR_W'(wbin_next)));
    end
  end

  always_ff @(posedge w_clk_i or negedge w_rst_ni) begin
    if (!w_rst_ni) begin
      for (int unsigned i = 0; i < DEPTH; i++) mem_q[i] <= '0;
    end else if (do_push) begin
      mem_q[wbin_q[PTR_W-1:0]] <= wdata_i;
    end
  end

  i2s_sync #(.WIDTH(AW), .STAGES(SYNC_STAGES)) u_rgray_sync (
      .clk_i(w_clk_i), .rst_ni(w_rst_ni), .d_i(rgray_q), .q_o(rgray_ws));

  //---------------------------------------------------------------------------
  // Read side
  //---------------------------------------------------------------------------
  assign rbin_next = rbin_q + AW'(1);

  assign wbin_rs = AW'(i2s_gray2bin(I2S_MAX_PTR_W'(wgray_rs)));
  assign r_used  = wbin_rs - rbin_q;

  assign r_empty_o = r_flushing | (r_used == AW'(0));
  assign r_full_o  = ~r_flushing & (r_used == AW'(DEPTH));
  assign r_level_o = r_flushing ? 16'h0 : 16'(r_used);

  // DROP_OLD: discard the oldest entry when the FIFO is full and nothing else
  // is taking it, so the writer keeps finding room.
  assign drop_pop      = r_drop_when_full_i & r_full_o & ~pop_i;
  assign do_pop        = (pop_i | drop_pop) & ~r_empty_o;
  assign r_underflow_o = pop_i & r_empty_o;

  always_ff @(posedge r_clk_i or negedge r_rst_ni) begin
    if (!r_rst_ni) begin
      rbin_q       <= '0;
      rgray_q      <= '0;
      r_flushing_q <= 1'b0;
    end else begin
      r_flushing_q <= w_flushing_rs;
      if (w_flushing_rs) begin
        rbin_q  <= '0;
        rgray_q <= '0;
      end else if (do_pop) begin
        rbin_q  <= rbin_next;
        rgray_q <= AW'(i2s_bin2gray(I2S_MAX_PTR_W'(rbin_next)));
      end
    end
  end

  assign rdata_o = mem_q[rbin_q[PTR_W-1:0]];

  i2s_sync #(.WIDTH(AW), .STAGES(SYNC_STAGES)) u_wgray_sync (
      .clk_i(r_clk_i), .rst_ni(r_rst_ni), .d_i(wgray_q), .q_o(wgray_rs));

endmodule : i2s_fifo_async

`default_nettype wire
