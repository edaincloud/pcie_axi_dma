//=============================================================================
// File        : i2s_top.sv
// Description : Top level of the APB4-programmed I2S audio interface IP.
//
//               Structure
//               ---------
//                 pclk domain                    | sclk domain
//                 ------------------------------ | ---------------------------
//                  APB4 -> i2s_regs              |
//                            shadow bank         |
//                            commit engine       |
//                            counters + IRQ      |
//                                |               |
//                                +-- i2s_cdc_data (config commit, 4-phase)
//                                +-- i2s_cdc_data (immediate control mirror)
//                                +-- i2s_cdc_pulse (soft reset, PRBS reseed)
//                                +-- i2s_cdc_evcnt x8 (exact event counts)
//                                +-- i2s_sync     (status levels)
//                                +-- i2s_cdc_data (debug / clock monitor)
//                                |               |
//                                |               +-> i2s_core
//                                |                     clkgen -> SCK / MCLK
//                                |                     frame  -> WS
//                                |                     tx/rx  <-> SD
//                  DMA <-> i2s_fifo_async (TX) --------------> serial read port
//                  DMA <-> i2s_fifo_async (RX) <-------------- serial write port
//
//               Two clocks (specification section 32)
//               -------------------------------------
//               `pclk` runs the APB, the register bank, the counters, the
//               interrupt block and the software/DMA side of both sample
//               FIFOs.  `sclk` runs the entire serial datapath: the SCK and
//               MCLK dividers, the frame engine, the serialiser, the
//               deserialiser, the clock monitor and the active configuration.
//               The two have no defined frequency or phase relationship.
//
//               `sclk` is a real clock input rather than SCK itself, and it has
//               to be.  SCK is internally generated in controller mode and an
//               input in target mode, so clocking the datapath from it would
//               need a clock mux and a generated clock - both forbidden by the
//               RTL contract and by the no-generated/no-gated-clock property
//               the synthesis gates check.  Dividing SCK down from `sclk`
//               keeps SCK an ordinary registered output while making the FIFO
//               boundary a genuine asynchronous crossing.
//
//               There are no generated and no gated clocks anywhere: SCK and
//               MCLK are registered outputs, and all serial timing is expressed
//               as `sclk` clock enables.
//
//               Crossing structures (specification section 71)
//               ---------------------------------------------
//               Every signal that changes domain does so through exactly one of
//               five approved structures, chosen by what the signal MEANS:
//
//                 i2s_sync        single-bit levels whose relative skew does
//                                 not matter - the three serial pins, and the
//                                 independent status bits read back by software
//                 i2s_cdc_data    multi-bit values that must land atomically:
//                                 the committed configuration, the whole
//                                 immediate-control bundle, and the debug and
//                                 clock-monitor snapshot
//                 i2s_cdc_pulse   single events whose effect is idempotent:
//                                 soft reset, PRBS reseed, FIFO overflow flag
//                 i2s_cdc_evcnt   events that must be COUNTED exactly, for the
//                                 saturating event counters
//                 i2s_fifo_async  the sample payload, through Gray pointers
//
//               Nothing crosses by any other means, and no combinational path
//               exists between the two domains.
//
//               Reset
//               -----
//               `presetn` and `sresetn` are separate ports because each must be
//               de-asserted synchronously to its own clock.  They are one
//               system reset as far as this IP is concerned and MUST be
//               asserted together: an asynchronous FIFO whose two sides are
//               reset independently loses pointer coherence, which no crossing
//               structure can repair.  See the integration guide.
//
// Parameters   : see below.  Illegal combinations fail elaboration with a
//                specific message; run/scripts/elab_check.sh tests every guard
//                in both directions.
//=============================================================================

`default_nettype none

module i2s_top
  import i2s_pkg::*;
#(
    // Widest audio sample the datapath carries, in bits (8 .. 32).
    parameter int unsigned SAMPLE_WIDTH_MAX  = 32,
    // Widest slot the frame engine supports, in SCK periods.  Must be at
    // least SAMPLE_WIDTH_MAX and at most 32.
    parameter int unsigned SLOT_WIDTH_MAX    = 32,
    // TX / RX FIFO depths in samples.  Powers of two in [2 : 64].
    parameter int unsigned TX_FIFO_DEPTH     = 8,
    parameter int unsigned RX_FIFO_DEPTH     = 8,
    // Width of the SCK_DIVIDER and MCLK_DIVIDER fields (1 .. 16).
    parameter int unsigned DIV_WIDTH         = 8,
    // Width of the saturating event counters (8 .. 32).
    parameter int unsigned CNT_WIDTH         = 16,
    // Depth of every synchroniser in the design: the serial input
    // synchronisers, the FIFO pointer synchronisers and the handshake
    // synchronisers of the CDC cells (2 .. 4).
    parameter int unsigned SYNC_STAGES       = 2,
    // APB address bus width.  Must cover the whole register region.
    parameter int unsigned APB_ADDR_WIDTH    = 12,
    // APB data bus width.  Must be >= 32 and a multiple of 8.
    parameter int unsigned APB_DATA_WIDTH    = 32,
    // 1'b0 : `presetn` / `sresetn` are active low (default, APB standard)
    // 1'b1 : `presetn` / `sresetn` are active high
    parameter bit          RESET_POLARITY    = 1'b0,
    // Level driven on SD_TX while the transmitter is not running.
    parameter bit          SD_IDLE_LEVEL     = 1'b0,
    // Instantiate the MCLK divider (specification section 12 makes MCLK
    // optional).
    parameter bit          HAS_MCLK          = 1'b1,
    // Reset synchroniser depth (asynchronous assert, synchronous de-assert).
    parameter int unsigned RESET_SYNC_STAGES = 2
) (
    input  wire                          pclk,
    input  wire                          presetn,

    // ------------------------------------------------ serial clock domain
    // The clock the whole serial datapath runs on.  SCK is divided down from
    // it in controller mode.  Asynchronous to `pclk`.
    input  wire                          sclk,
    input  wire                          sresetn,

    // ------------------------------------------------------------------ APB4
    input  wire                          psel,
    input  wire                          penable,
    input  wire                          pwrite,
    input  wire  [APB_ADDR_WIDTH-1:0]    paddr,
    input  wire  [APB_DATA_WIDTH-1:0]    pwdata,
    input  wire  [APB_DATA_WIDTH/8-1:0]  pstrb,
    output logic [APB_DATA_WIDTH-1:0]    prdata,
    output logic                         pready,
    output logic                         pslverr,

    // -------------------------------------------------------- I2S serial bus
    input  wire                          sck_i,
    input  wire                          ws_i,
    input  wire                          sd_rx_i,
    output logic                         sck_o,
    output logic                         ws_o,
    output logic                         sd_tx_o,
    output logic                         mclk_o,
    // Pad output enables.  In target mode the IP must not drive SCK or WS.
    output logic                         sck_oe_o,
    output logic                         ws_oe_o,
    output logic                         sd_tx_oe_o,
    output logic                         mclk_oe_o,

    // ---------------------------------------------------------- streaming DMA
    input  wire                          tx_dma_valid_i,
    input  wire  [SAMPLE_WIDTH_MAX-1:0]  tx_dma_data_i,
    output logic                         tx_dma_ready_o,
    output logic                         tx_dma_req_o,
    output logic                         rx_dma_valid_o,
    output logic [SAMPLE_WIDTH_MAX-1:0]  rx_dma_data_o,
    input  wire                          rx_dma_ready_i,
    output logic                         rx_dma_req_o,

    // ------------------------------------------------------------- interrupt
    output logic                         irq
);

  //---------------------------------------------------------------------------
  // Elaboration checks (specification sections 52 and 108)
  //---------------------------------------------------------------------------
  if (SAMPLE_WIDTH_MAX < I2S_MIN_WIDTH) begin : gen_chk_sw_min
    $error("i2s_top: SAMPLE_WIDTH_MAX must be >= %0d (got %0d)",
           I2S_MIN_WIDTH, SAMPLE_WIDTH_MAX);
  end
  if (SAMPLE_WIDTH_MAX > I2S_MAX_WIDTH) begin : gen_chk_sw_max
    $error("i2s_top: SAMPLE_WIDTH_MAX must be <= %0d (got %0d)",
           I2S_MAX_WIDTH, SAMPLE_WIDTH_MAX);
  end
  if (SLOT_WIDTH_MAX < SAMPLE_WIDTH_MAX) begin : gen_chk_slw_order
    $error("i2s_top: SLOT_WIDTH_MAX (%0d) must be >= SAMPLE_WIDTH_MAX (%0d)",
           SLOT_WIDTH_MAX, SAMPLE_WIDTH_MAX);
  end
  if (SLOT_WIDTH_MAX > I2S_MAX_WIDTH) begin : gen_chk_slw_max
    $error("i2s_top: SLOT_WIDTH_MAX must be <= %0d (got %0d)",
           I2S_MAX_WIDTH, SLOT_WIDTH_MAX);
  end
  if (!i2s_is_pow2(TX_FIFO_DEPTH)) begin : gen_chk_txf_pow2
    $error("i2s_top: TX_FIFO_DEPTH must be a power of two (got %0d)", TX_FIFO_DEPTH);
  end
  if ((TX_FIFO_DEPTH < I2S_MIN_FIFO_DEPTH) ||
      (TX_FIFO_DEPTH > I2S_MAX_FIFO_DEPTH)) begin : gen_chk_txf_range
    $error("i2s_top: TX_FIFO_DEPTH must be in [%0d:%0d] (got %0d)",
           I2S_MIN_FIFO_DEPTH, I2S_MAX_FIFO_DEPTH, TX_FIFO_DEPTH);
  end
  if (!i2s_is_pow2(RX_FIFO_DEPTH)) begin : gen_chk_rxf_pow2
    $error("i2s_top: RX_FIFO_DEPTH must be a power of two (got %0d)", RX_FIFO_DEPTH);
  end
  if ((RX_FIFO_DEPTH < I2S_MIN_FIFO_DEPTH) ||
      (RX_FIFO_DEPTH > I2S_MAX_FIFO_DEPTH)) begin : gen_chk_rxf_range
    $error("i2s_top: RX_FIFO_DEPTH must be in [%0d:%0d] (got %0d)",
           I2S_MIN_FIFO_DEPTH, I2S_MAX_FIFO_DEPTH, RX_FIFO_DEPTH);
  end
  if (DIV_WIDTH < I2S_MIN_DIV_WIDTH) begin : gen_chk_div_min
    $error("i2s_top: DIV_WIDTH must be >= %0d (got %0d)", I2S_MIN_DIV_WIDTH, DIV_WIDTH);
  end
  if (DIV_WIDTH > I2S_MAX_DIV_WIDTH) begin : gen_chk_div_max
    $error("i2s_top: DIV_WIDTH must be <= %0d (got %0d)", I2S_MAX_DIV_WIDTH, DIV_WIDTH);
  end
  if (CNT_WIDTH < I2S_MIN_CNT_WIDTH) begin : gen_chk_cnt_min
    $error("i2s_top: CNT_WIDTH must be >= %0d (got %0d)", I2S_MIN_CNT_WIDTH, CNT_WIDTH);
  end
  if (CNT_WIDTH > I2S_MAX_CNT_WIDTH) begin : gen_chk_cnt_max
    $error("i2s_top: CNT_WIDTH must be <= %0d (got %0d)", I2S_MAX_CNT_WIDTH, CNT_WIDTH);
  end
  if (SYNC_STAGES < I2S_MIN_SYNC_STAGES) begin : gen_chk_sync_min
    $error("i2s_top: SYNC_STAGES must be >= %0d (got %0d)",
           I2S_MIN_SYNC_STAGES, SYNC_STAGES);
  end
  if (SYNC_STAGES > I2S_MAX_SYNC_STAGES) begin : gen_chk_sync_max
    $error("i2s_top: SYNC_STAGES must be <= %0d (got %0d)",
           I2S_MAX_SYNC_STAGES, SYNC_STAGES);
  end
  if (APB_DATA_WIDTH < 32) begin : gen_chk_dw_min
    $error("i2s_top: APB_DATA_WIDTH must be >= 32 (got %0d)", APB_DATA_WIDTH);
  end
  if ((APB_DATA_WIDTH % 8) != 0) begin : gen_chk_dw_mod
    $error("i2s_top: APB_DATA_WIDTH must be a multiple of 8 (got %0d)", APB_DATA_WIDTH);
  end
  if (APB_ADDR_WIDTH > 32) begin : gen_chk_aw_max
    $error("i2s_top: APB_ADDR_WIDTH must be <= 32 (got %0d)", APB_ADDR_WIDTH);
  end
  // The whole register region must be addressable.
  //
  // The shift is evaluated in 64 bits on purpose: `32'(1) << 32` is zero in a
  // 32-bit context, which would make this check fire for APB_ADDR_WIDTH == 32
  // - a value gen_chk_aw_max above explicitly permits, and the natural choice
  // for an SoC with a 32-bit APB address bus.
  if ((64'(1) << APB_ADDR_WIDTH) < 64'(I2S_REGION_END)) begin : gen_chk_aw_span
    $error("i2s_top: APB_ADDR_WIDTH=%0d cannot address the 0x%0h byte register region",
           APB_ADDR_WIDTH, I2S_REGION_END);
  end

  localparam int unsigned SW = SAMPLE_WIDTH_MAX;
  localparam int unsigned BW = I2S_WIDTH_FIELD_W;

  //---------------------------------------------------------------------------
  // Reset conditioning
  //
  //   1. Normalise the configured reset polarity to an internal active-low
  //      asynchronous reset, per domain.
  //   2. Synchronise each de-assertion to its own clock (asynchronous assert,
  //      synchronous de-assert) to remove the recovery/removal hazard.
  //
  // The two resets are one system reset seen from two clocks.  Asserting only
  // one of them is outside the contract: it would zero one side of an
  // asynchronous FIFO while the other keeps its pointer.
  //---------------------------------------------------------------------------
  logic rst_async_n, srst_async_n;
  assign rst_async_n  = RESET_POLARITY ? ~presetn : presetn;
  assign srst_async_n = RESET_POLARITY ? ~sresetn : sresetn;

  logic rst_n, srst_n;

  i2s_reset_sync #(
      .STAGES (RESET_SYNC_STAGES)
  ) u_reset_sync (
      .clk      (pclk),
      .rst_in_n (rst_async_n),
      .rst_out_n(rst_n)
  );

  i2s_reset_sync #(
      .STAGES (RESET_SYNC_STAGES)
  ) u_sreset_sync (
      .clk      (sclk),
      .rst_in_n (srst_async_n),
      .rst_out_n(srst_n)
  );

  // "The serial domain is out of reset", observed from pclk.  The event-count
  // crossings hold their baseline while this is low so that the serial-side
  // counters returning to zero cannot be mistaken for a burst of events.
  logic ser_alive_q, ser_alive_p, ev_resync;

  always_ff @(posedge sclk or negedge srst_n) begin
    if (!srst_n) ser_alive_q <= 1'b0;
    else         ser_alive_q <= 1'b1;
  end

  i2s_sync #(.WIDTH(1), .STAGES(SYNC_STAGES)) u_ser_alive_sync (
      .clk_i(pclk), .rst_ni(rst_n), .d_i(ser_alive_q), .q_o(ser_alive_p));

  assign ev_resync = ~ser_alive_p;

  //---------------------------------------------------------------------------
  // The immediate-control bundle.
  //
  // Every field here is an "immediate effect" register bit, and the whole
  // bundle crosses on ONE handshake rather than on a synchroniser per bit.
  // That is not belt and braces, it is required: GLOBAL_CTRL.IP_ENABLE,
  // TX_ENABLE, RX_ENABLE and CONTROLLER_ENABLE are written by a single APB
  // access, and i2s_core's role-selection gate freezes the controller/target
  // role at the first edge on which the link stops being quiescent.  Let those
  // four bits arrive on different cycles and the enabling write is seen as
  // "link already active", the role freezes at its reset value, and the IP
  // never becomes a controller at all.  One handshake makes the bundle land on
  // one edge, exactly as one APB write produced it.
  //---------------------------------------------------------------------------
  typedef struct packed {
    logic                     ip_enable;
    logic                     tx_enable;
    logic                     rx_enable;
    logic                     controller_en;
    logic                     loopback_en;
    logic                     mute_global;
    logic                     stop_at_frame;
    logic [1:0]               underrun_mode;
    logic [1:0]               overrun_mode;
    logic                     rx_sign_extend;
    logic                     mute_tx;
    logic                     mute_rx;
    logic                     mute_left;
    logic                     mute_right;
    logic [SW-1:0]            mute_value;
    logic                     clk_mon_en;
    logic [7:0]               clk_tol;
    logic                     test_sd_force_en;
    logic                     test_sd_force_val;
    logic                     inj_en;
    logic [I2S_EI_TYPE_W-1:0] inj_type;
    logic [7:0]               inj_count;
    logic [2:0]               prbs_sel;
    logic                     prbs_tx_en;
    logic                     prbs_rx_en;
  } i2s_ctrl_t;

  //---------------------------------------------------------------------------
  // The serial-to-pclk observability snapshot.
  //
  // DEBUG_STATE, DEBUG_SHIFT, CLOCK_STATUS, SAMPLE_RATE_ACT, CLOCK_DUTY and the
  // PRBS error count are all multi-bit values produced on the serial clock and
  // read as single 32-bit registers.  They travel together on one handshake so
  // that a register read returns a set of values that co-existed, rather than
  // fields from different instants stitched together.
  //---------------------------------------------------------------------------
  typedef struct packed {
    logic [2:0]    tx_state;
    logic [2:0]    rx_state;
    logic          tx_slot;
    logic          rx_slot;
    logic [BW-1:0] tx_bit;
    logic [BW-1:0] rx_bit;
    logic [SW-1:0] shift;
    logic [15:0]   sck_period;
    logic [15:0]   sck_per_ws;
    logic [31:0]   ws_period;
    logic [15:0]   sck_high;
    logic [15:0]   sck_low;
    logic [15:0]   prbs_err_cnt;
  } i2s_dbg_t;

  //---------------------------------------------------------------------------
  // Register block <-> crossing interconnect (pclk side)
  //---------------------------------------------------------------------------
  logic                        soft_reset_p, prbs_reseed_p;
  logic                        dma_enable_p, tx_dma_en_p, rx_dma_en_p;
  i2s_ctrl_t                   ctrl_p;

  i2s_cfg_t                    cfg_data_p;
  logic                        cfg_launch_p, cfg_busy_p, cfg_applied_p;

  logic                        tx_push_p, tx_flush_p, rx_pop_p, rx_flush_p;
  // Flush request holding and completion, declared here rather than beside the
  // FIFOs because the register block reads them back: an identifier has to be
  // declared before it is referenced, and yosys-slang enforces that even where
  // the simulator does not.
  logic                        tx_flush_hold_q, rx_flush_hold_q;
  logic                        tx_flush_busy, rx_flush_busy;
  logic                        tx_flush_pending, rx_flush_pending;
  logic [SW-1:0]               tx_wdata_p;
  logic                        tx_almost_p, rx_almost_p;

  logic [15:0]                 tx_level_p, rx_level_p;
  logic                        tx_empty_p, tx_full_p, tx_overflow_p;
  logic                        rx_empty_p, rx_full_p, rx_overflow_p;
  logic [SW-1:0]               rx_rdata_p;

  logic [I2S_EVDELTA_W-1:0]    ev_tx_underrun_p, ev_rx_overrun_p, ev_frame_err_p;
  logic [I2S_EVDELTA_W-1:0]    ev_ws_err_p, ev_clk_err_p, ev_frame_done_p;
  logic [I2S_EVDELTA_W-1:0]    ev_tx_sample_p, ev_rx_sample_p;

  logic [5:0]                  sts_s, sts_p;
  i2s_dbg_t                    dbg_s, dbg_p;

  //---------------------------------------------------------------------------
  // Serial-domain interconnect (sclk side)
  //---------------------------------------------------------------------------
  logic                        soft_reset_s, prbs_reseed_s;
  i2s_ctrl_t                   ctrl_s;
  i2s_cfg_t                    cfg_data_s;
  logic                        cfg_valid_s, cfg_consume_s;

  logic                        tx_fifo_empty_s, tx_fifo_pop_s;
  logic [SW-1:0]               tx_fifo_rdata_s;
  logic                        rx_fifo_full_s, rx_fifo_push_s, rx_fifo_overflow_s;
  logic [SW-1:0]               rx_fifo_wdata_s;

  logic                        ev_tx_underrun_s, ev_rx_overrun_s, ev_frame_err_s;
  logic                        ev_ws_err_s, ev_clk_err_s, ev_frame_done_s;
  logic                        ev_tx_sample_s, ev_rx_sample_s;

  logic                        prbs_locked_s;

  //---------------------------------------------------------------------------
  i2s_regs #(
      .SAMPLE_WIDTH_MAX (SAMPLE_WIDTH_MAX),
      .SLOT_WIDTH_MAX   (SLOT_WIDTH_MAX),
      .TX_FIFO_DEPTH    (TX_FIFO_DEPTH),
      .RX_FIFO_DEPTH    (RX_FIFO_DEPTH),
      .DIV_WIDTH        (DIV_WIDTH),
      .CNT_WIDTH        (CNT_WIDTH),
      .APB_ADDR_WIDTH   (APB_ADDR_WIDTH),
      .APB_DATA_WIDTH   (APB_DATA_WIDTH)
  ) u_regs (
      .clk_i               (pclk),
      .rst_ni              (rst_n),

      .psel_i              (psel),
      .penable_i           (penable),
      .pwrite_i            (pwrite),
      .paddr_i             (paddr),
      .pwdata_i            (pwdata),
      .pstrb_i             (pstrb),
      .prdata_o            (prdata),
      .pready_o            (pready),
      .pslverr_o           (pslverr),

      .soft_reset_o        (soft_reset_p),
      .ip_enable_o         (ctrl_p.ip_enable),
      .tx_enable_o         (ctrl_p.tx_enable),
      .rx_enable_o         (ctrl_p.rx_enable),
      .controller_en_o     (ctrl_p.controller_en),
      .loopback_en_o       (ctrl_p.loopback_en),
      .mute_global_o       (ctrl_p.mute_global),
      .dma_enable_o        (dma_enable_p),
      .stop_at_frame_o     (ctrl_p.stop_at_frame),
      .underrun_mode_o     (ctrl_p.underrun_mode),
      .overrun_mode_o      (ctrl_p.overrun_mode),
      .rx_sign_extend_o    (ctrl_p.rx_sign_extend),
      .mute_tx_o           (ctrl_p.mute_tx),
      .mute_rx_o           (ctrl_p.mute_rx),
      .mute_left_o         (ctrl_p.mute_left),
      .mute_right_o        (ctrl_p.mute_right),
      .mute_value_o        (ctrl_p.mute_value),
      .tx_dma_en_o         (tx_dma_en_p),
      .rx_dma_en_o         (rx_dma_en_p),
      .clk_mon_en_o        (ctrl_p.clk_mon_en),
      .clk_tol_o           (ctrl_p.clk_tol),

      .cfg_data_o          (cfg_data_p),
      .cfg_launch_o        (cfg_launch_p),
      .cfg_busy_i          (cfg_busy_p),
      .cfg_applied_i       (cfg_applied_p),

      .tx_push_o           (tx_push_p),
      .tx_wdata_o          (tx_wdata_p),
      .tx_flush_o          (tx_flush_p),
      .rx_pop_o            (rx_pop_p),
      .rx_flush_o          (rx_flush_p),
      .tx_almost_o         (tx_almost_p),
      .rx_almost_o         (rx_almost_p),

      .tx_level_i          (tx_level_p),
      .tx_empty_i          (tx_empty_p),
      .tx_full_i           (tx_full_p),
      .tx_overflow_i       (tx_overflow_p),
      .tx_flush_busy_i     (tx_flush_pending),
      .rx_level_i          (rx_level_p),
      .rx_empty_i          (rx_empty_p),
      .rx_full_i           (rx_full_p),
      .rx_overflow_i       (rx_overflow_p),
      .rx_flush_busy_i     (rx_flush_pending),
      .rx_rdata_i          (rx_rdata_p),

      .ev_tx_underrun_i    (ev_tx_underrun_p),
      .ev_rx_overrun_i     (ev_rx_overrun_p),
      .ev_frame_err_i      (ev_frame_err_p),
      .ev_ws_err_i         (ev_ws_err_p),
      .ev_clk_err_i        (ev_clk_err_p),
      .ev_frame_done_i     (ev_frame_done_p),
      .ev_tx_sample_i      (ev_tx_sample_p),
      .ev_rx_sample_i      (ev_rx_sample_p),

      .sts_tx_active_i     (sts_p[0]),
      .sts_rx_active_i     (sts_p[1]),
      .sts_sck_running_i   (sts_p[2]),
      .sts_tx_busy_i       (sts_p[3]),
      .sts_rx_busy_i       (sts_p[4]),
      .dbg_tx_state_i      (dbg_p.tx_state),
      .dbg_rx_state_i      (dbg_p.rx_state),
      .dbg_tx_slot_i       (dbg_p.tx_slot),
      .dbg_rx_slot_i       (dbg_p.rx_slot),
      .dbg_tx_bit_i        (dbg_p.tx_bit),
      .dbg_rx_bit_i        (dbg_p.rx_bit),
      .dbg_shift_i         (dbg_p.shift),
      .clk_sck_period_i    (dbg_p.sck_period),
      .clk_sck_per_ws_i    (dbg_p.sck_per_ws),
      .clk_ws_period_i     (dbg_p.ws_period),
      .clk_sck_high_i      (dbg_p.sck_high),
      .clk_sck_low_i       (dbg_p.sck_low),

      .test_sd_force_en_o  (ctrl_p.test_sd_force_en),
      .test_sd_force_val_o (ctrl_p.test_sd_force_val),
      .inj_en_o            (ctrl_p.inj_en),
      .inj_type_o          (ctrl_p.inj_type),
      .inj_count_o         (ctrl_p.inj_count),
      .prbs_sel_o          (ctrl_p.prbs_sel),
      .prbs_tx_en_o        (ctrl_p.prbs_tx_en),
      .prbs_rx_en_o        (ctrl_p.prbs_rx_en),
      .prbs_reseed_o       (prbs_reseed_p),
      .prbs_locked_i       (sts_p[5]),
      .prbs_err_cnt_i      (dbg_p.prbs_err_cnt),

      .irq_o               (irq)
  );

  //===========================================================================
  // Clock-domain crossings
  //===========================================================================

  //---------------------------------------------------------------------------
  // 1. Configuration commit, pclk -> sclk, four phase with a deferred consume.
  //
  // `cfg_applied_p` is the completion of the round trip, so it means the serial
  // engine has ADOPTED the configuration at one of its own frame boundaries -
  // not merely that the data arrived.  That is what lets CONFIG_STATUS.PENDING
  // keep its documented meaning across the boundary.
  //---------------------------------------------------------------------------
  i2s_cdc_data #(
      .WIDTH  (I2S_CFG_W),
      .STAGES (SYNC_STAGES),
      .AUTO   (1'b0)
  ) u_cdc_cfg (
      .src_clk_i    (pclk),
      .src_rst_ni   (rst_n),
      .src_data_i   (cfg_data_p),
      .src_launch_i (cfg_launch_p),
      .src_busy_o   (cfg_busy_p),
      .src_done_o   (cfg_applied_p),
      .dst_clk_i    (sclk),
      .dst_rst_ni   (srst_n),
      .dst_data_o   (cfg_data_s),
      .dst_valid_o  (cfg_valid_s),
      .dst_consume_i(cfg_consume_s)
  );

  //---------------------------------------------------------------------------
  // 2. Immediate control bundle, pclk -> sclk, self-launching mirror.
  //---------------------------------------------------------------------------
  logic ctrl_busy_unused, ctrl_done_unused, ctrl_valid_unused;

  i2s_cdc_data #(
      .WIDTH  ($bits(i2s_ctrl_t)),
      .STAGES (SYNC_STAGES),
      .AUTO   (1'b1)
  ) u_cdc_ctrl (
      .src_clk_i    (pclk),
      .src_rst_ni   (rst_n),
      .src_data_i   (ctrl_p),
      .src_launch_i (1'b0),
      .src_busy_o   (ctrl_busy_unused),
      .src_done_o   (ctrl_done_unused),
      .dst_clk_i    (sclk),
      .dst_rst_ni   (srst_n),
      .dst_data_o   (ctrl_s),
      .dst_valid_o  (ctrl_valid_unused),
      .dst_consume_i(1'b1)
  );

  //---------------------------------------------------------------------------
  // 3. Single events, pclk -> sclk.  Both are idempotent: applying a soft reset
  //    or a PRBS reseed twice is indistinguishable from applying it once.
  //---------------------------------------------------------------------------
  logic sr_busy_unused, rs_busy_unused;

  i2s_cdc_pulse #(.STAGES(SYNC_STAGES)) u_cdc_soft_reset (
      .src_clk_i(pclk), .src_rst_ni(rst_n), .src_pulse_i(soft_reset_p),
      .src_busy_o(sr_busy_unused),
      .dst_clk_i(sclk), .dst_rst_ni(srst_n), .dst_pulse_o(soft_reset_s));

  i2s_cdc_pulse #(.STAGES(SYNC_STAGES)) u_cdc_prbs_reseed (
      .src_clk_i(pclk), .src_rst_ni(rst_n), .src_pulse_i(prbs_reseed_p),
      .src_busy_o(rs_busy_unused),
      .dst_clk_i(sclk), .dst_rst_ni(srst_n), .dst_pulse_o(prbs_reseed_s));

  //---------------------------------------------------------------------------
  // 4. Event counts, sclk -> pclk.  Exact, because the register they feed is a
  //    count and a dropped event there is a wrong answer, not a late one.
  //---------------------------------------------------------------------------
  logic [7:0] ev_pulse_unused;

  `define I2S_EVCNT(name, src, dst, idx)                      \
      i2s_cdc_evcnt #(.STAGES(SYNC_STAGES)) name (            \
          .src_clk_i   (sclk),                                 \
          .src_rst_ni  (srst_n),                               \
          .src_event_i (src),                                  \
          .dst_clk_i   (pclk),                                 \
          .dst_rst_ni  (rst_n),                                \
          .dst_resync_i(ev_resync),                            \
          .dst_delta_o (dst),                                  \
          .dst_pulse_o (ev_pulse_unused[idx]))

  `I2S_EVCNT(u_ev_tx_underrun, ev_tx_underrun_s, ev_tx_underrun_p, 0);
  `I2S_EVCNT(u_ev_rx_overrun,  ev_rx_overrun_s,  ev_rx_overrun_p,  1);
  `I2S_EVCNT(u_ev_frame_err,   ev_frame_err_s,   ev_frame_err_p,   2);
  `I2S_EVCNT(u_ev_ws_err,      ev_ws_err_s,      ev_ws_err_p,      3);
  `I2S_EVCNT(u_ev_clk_err,     ev_clk_err_s,     ev_clk_err_p,     4);
  `I2S_EVCNT(u_ev_frame_done,  ev_frame_done_s,  ev_frame_done_p,  5);
  `I2S_EVCNT(u_ev_tx_sample,   ev_tx_sample_s,   ev_tx_sample_p,   6);
  `I2S_EVCNT(u_ev_rx_sample,   ev_rx_sample_s,   ev_rx_sample_p,   7);

  `undef I2S_EVCNT

  //---------------------------------------------------------------------------
  // 5. Status levels, sclk -> pclk.  These are six INDEPENDENT single-bit
  //    status flags, each read on its own by software; there is no combination
  //    of them whose consistency matters, so a plain synchroniser per bit is
  //    the right structure and a handshake would only add latency.
  //---------------------------------------------------------------------------
  i2s_sync #(.WIDTH(6), .STAGES(SYNC_STAGES)) u_sts_sync (
      .clk_i(pclk), .rst_ni(rst_n), .d_i(sts_s), .q_o(sts_p));

  //---------------------------------------------------------------------------
  // 6. Debug and clock-monitor snapshot, sclk -> pclk.
  //---------------------------------------------------------------------------
  logic dbg_busy_unused, dbg_done_unused, dbg_valid_unused;

  i2s_cdc_data #(
      .WIDTH  ($bits(i2s_dbg_t)),
      .STAGES (SYNC_STAGES),
      .AUTO   (1'b1)
  ) u_cdc_dbg (
      .src_clk_i    (sclk),
      .src_rst_ni   (srst_n),
      .src_data_i   (dbg_s),
      .src_launch_i (1'b0),
      .src_busy_o   (dbg_busy_unused),
      .src_done_o   (dbg_done_unused),
      .dst_clk_i    (pclk),
      .dst_rst_ni   (rst_n),
      .dst_data_o   (dbg_p),
      .dst_valid_o  (dbg_valid_unused),
      .dst_consume_i(1'b1)
  );

  //---------------------------------------------------------------------------
  // 7. RX FIFO overflow, sclk (write port) -> pclk.  The destination is a
  //    sticky status bit, so idempotent delivery is sufficient.
  //---------------------------------------------------------------------------
  logic rxovf_busy_unused;

  i2s_cdc_pulse #(.STAGES(SYNC_STAGES)) u_cdc_rx_overflow (
      .src_clk_i(sclk), .src_rst_ni(srst_n), .src_pulse_i(rx_fifo_overflow_s),
      .src_busy_o(rxovf_busy_unused),
      .dst_clk_i(pclk), .dst_rst_ni(rst_n), .dst_pulse_o(rx_overflow_p));

  //===========================================================================
  // Asynchronous sample FIFOs
  //===========================================================================
  //
  // The flush request from the register block is a single PCLK pulse, and the
  // quiesce protocol needs a level that survives until the FIFO has started.
  // The two hold flops below do exactly that: set by the pulse, cleared once the
  // FIFO reports itself busy.
  //
  // `*_flush_pending` is what software sees in TX/RX_FIFO_STATUS.FLUSH_BUSY.  It
  // covers the hold as well as the FIFO's own busy, so there is no window in
  // which the bit reads clear while the flush is still to come - which is the
  // window a driver would otherwise refill the FIFO in, only for the flush to
  // discard what it had just written.
  assign tx_flush_pending = tx_flush_hold_q | tx_flush_busy;
  assign rx_flush_pending = rx_flush_hold_q | rx_flush_busy;

  always_ff @(posedge pclk or negedge rst_n) begin
    if (!rst_n) begin
      tx_flush_hold_q <= 1'b0;
      rx_flush_hold_q <= 1'b0;
    end else begin
      if      (tx_flush_p)    tx_flush_hold_q <= 1'b1;
      else if (tx_flush_busy) tx_flush_hold_q <= 1'b0;

      if      (rx_flush_p)    rx_flush_hold_q <= 1'b1;
      else if (rx_flush_busy) rx_flush_hold_q <= 1'b0;
    end
  end

  //---------------------------------------------------------------------------
  // TX FIFO: written by software / DMA on pclk, read by the serialiser on sclk.
  //---------------------------------------------------------------------------
  logic          tx_fifo_push_p, dma_tx_fire;
  logic [SW-1:0] tx_fifo_wdata_p;
  logic          tx_r_underflow_unused, tx_r_full_unused, tx_r_flush_busy_unused;
  logic [15:0]   tx_r_level_unused;

  assign tx_dma_ready_o  = dma_enable_p & tx_dma_en_p & ~tx_full_p & ~tx_push_p;
  assign dma_tx_fire     = tx_dma_valid_i & tx_dma_ready_o;
  assign tx_fifo_push_p  = tx_push_p | dma_tx_fire;
  assign tx_fifo_wdata_p = tx_push_p ? tx_wdata_p : tx_dma_data_i;

  i2s_fifo_async #(
      .WIDTH       (SW),
      .DEPTH       (TX_FIFO_DEPTH),
      .SYNC_STAGES (SYNC_STAGES)
  ) u_tx_fifo (
      .w_clk_i            (pclk),
      .w_rst_ni           (rst_n),
      .w_flush_req_i      (tx_flush_hold_q),
      .w_flush_busy_o     (tx_flush_busy),
      .push_i             (tx_fifo_push_p),
      .wdata_i            (tx_fifo_wdata_p),
      .w_level_o          (tx_level_p),
      .w_full_o           (tx_full_p),
      .w_empty_o          (tx_empty_p),
      .w_overflow_o       (tx_overflow_p),

      .r_clk_i            (sclk),
      .r_rst_ni           (srst_n),
      .r_flush_req_i      (1'b0),
      .r_flush_busy_o     (tx_r_flush_busy_unused),
      .pop_i              (tx_fifo_pop_s),
      .r_drop_when_full_i (1'b0),
      .rdata_o            (tx_fifo_rdata_s),
      .r_level_o          (tx_r_level_unused),
      .r_empty_o          (tx_fifo_empty_s),
      .r_full_o           (tx_r_full_unused),
      .r_underflow_o      (tx_r_underflow_unused)
  );

  //---------------------------------------------------------------------------
  // RX FIFO: written by the deserialiser on sclk, read by software / DMA on
  // pclk.  DROP_OLD is applied on the read side; see i2s_fifo_async.
  //---------------------------------------------------------------------------
  logic          rx_fifo_pop_p, dma_rx_fire;
  logic          rx_w_empty_unused, rx_w_flush_busy_unused;
  logic [15:0]   rx_w_level_unused;
  logic          rx_r_underflow_unused;

  assign rx_dma_valid_o = dma_enable_p & rx_dma_en_p & ~rx_empty_p & ~rx_pop_p;
  assign dma_rx_fire    = rx_dma_valid_o & rx_dma_ready_i;
  assign rx_fifo_pop_p  = rx_pop_p | dma_rx_fire;

  i2s_fifo_async #(
      .WIDTH       (SW),
      .DEPTH       (RX_FIFO_DEPTH),
      .SYNC_STAGES (SYNC_STAGES)
  ) u_rx_fifo (
      .w_clk_i            (sclk),
      .w_rst_ni           (srst_n),
      .w_flush_req_i      (1'b0),
      .w_flush_busy_o     (rx_w_flush_busy_unused),
      .push_i             (rx_fifo_push_s),
      .wdata_i            (rx_fifo_wdata_s),
      .w_level_o          (rx_w_level_unused),
      .w_full_o           (rx_fifo_full_s),
      .w_empty_o          (rx_w_empty_unused),
      .w_overflow_o       (rx_fifo_overflow_s),

      .r_clk_i            (pclk),
      .r_rst_ni           (rst_n),
      .r_flush_req_i      (rx_flush_hold_q),
      .r_flush_busy_o     (rx_flush_busy),
      .pop_i              (rx_fifo_pop_p),
      .r_drop_when_full_i (ctrl_p.overrun_mode == I2S_OVR_DROP_OLD),
      .rdata_o            (rx_rdata_p),
      .r_level_o          (rx_level_p),
      .r_empty_o          (rx_empty_p),
      .r_full_o           (rx_full_p),
      .r_underflow_o      (rx_r_underflow_unused)
  );

  assign rx_dma_data_o = rx_rdata_p;
  assign tx_dma_req_o  = dma_enable_p & tx_dma_en_p & tx_almost_p;
  assign rx_dma_req_o  = dma_enable_p & rx_dma_en_p & rx_almost_p;

  //===========================================================================
  // Serial datapath (sclk domain)
  //===========================================================================
  i2s_core #(
      .SAMPLE_WIDTH_MAX (SAMPLE_WIDTH_MAX),
      .SLOT_WIDTH_MAX   (SLOT_WIDTH_MAX),
      .DIV_WIDTH        (DIV_WIDTH),
      .SYNC_STAGES      (SYNC_STAGES),
      .HAS_MCLK         (HAS_MCLK),
      .SD_IDLE_LEVEL    (SD_IDLE_LEVEL)
  ) u_core (
      .clk_i               (sclk),
      .rst_ni              (srst_n),

      .sck_i               (sck_i),
      .ws_i                (ws_i),
      .sd_rx_i             (sd_rx_i),
      .sck_o               (sck_o),
      .ws_o                (ws_o),
      .sd_tx_o             (sd_tx_o),
      .mclk_o              (mclk_o),
      .sck_oe_o            (sck_oe_o),
      .ws_oe_o             (ws_oe_o),
      .sd_tx_oe_o          (sd_tx_oe_o),
      .mclk_oe_o           (mclk_oe_o),

      .soft_reset_i        (soft_reset_s),
      .ip_enable_i         (ctrl_s.ip_enable),
      .tx_enable_i         (ctrl_s.tx_enable),
      .rx_enable_i         (ctrl_s.rx_enable),
      .controller_en_i     (ctrl_s.controller_en),
      .loopback_en_i       (ctrl_s.loopback_en),
      .mute_global_i       (ctrl_s.mute_global),
      .stop_at_frame_i     (ctrl_s.stop_at_frame),
      .underrun_mode_i     (ctrl_s.underrun_mode),
      .overrun_mode_i      (ctrl_s.overrun_mode),
      .rx_sign_extend_i    (ctrl_s.rx_sign_extend),
      .mute_tx_i           (ctrl_s.mute_tx),
      .mute_rx_i           (ctrl_s.mute_rx),
      .mute_left_i         (ctrl_s.mute_left),
      .mute_right_i        (ctrl_s.mute_right),
      .mute_value_i        (ctrl_s.mute_value),
      .clk_mon_en_i        (ctrl_s.clk_mon_en),
      .clk_tol_i           (ctrl_s.clk_tol),

      .cfg_data_i          (cfg_data_s),
      .cfg_valid_i         (cfg_valid_s),
      .cfg_consume_o       (cfg_consume_s),

      .tx_fifo_empty_i     (tx_fifo_empty_s),
      .tx_fifo_rdata_i     (tx_fifo_rdata_s),
      .tx_fifo_pop_o       (tx_fifo_pop_s),
      .rx_fifo_full_i      (rx_fifo_full_s),
      .rx_fifo_push_o      (rx_fifo_push_s),
      .rx_fifo_wdata_o     (rx_fifo_wdata_s),

      .test_sd_force_en_i  (ctrl_s.test_sd_force_en),
      .test_sd_force_val_i (ctrl_s.test_sd_force_val),
      .inj_en_i            (ctrl_s.inj_en),
      .inj_type_i          (ctrl_s.inj_type),
      .inj_count_i         (ctrl_s.inj_count),
      .prbs_sel_i          (ctrl_s.prbs_sel),
      .prbs_tx_en_i        (ctrl_s.prbs_tx_en),
      .prbs_rx_en_i        (ctrl_s.prbs_rx_en),
      .prbs_reseed_i       (prbs_reseed_s),
      .prbs_locked_o       (prbs_locked_s),
      .prbs_err_cnt_o      (dbg_s.prbs_err_cnt),

      .ev_tx_underrun_o    (ev_tx_underrun_s),
      .ev_rx_overrun_o     (ev_rx_overrun_s),
      .ev_frame_err_o      (ev_frame_err_s),
      .ev_ws_err_o         (ev_ws_err_s),
      .ev_clk_err_o        (ev_clk_err_s),
      .ev_frame_done_o     (ev_frame_done_s),
      .ev_tx_sample_o      (ev_tx_sample_s),
      .ev_rx_sample_o      (ev_rx_sample_s),

      .sts_tx_active_o     (sts_s[0]),
      .sts_rx_active_o     (sts_s[1]),
      .sts_sck_running_o   (sts_s[2]),
      .sts_tx_busy_o       (sts_s[3]),
      .sts_rx_busy_o       (sts_s[4]),
      .dbg_tx_state_o      (dbg_s.tx_state),
      .dbg_rx_state_o      (dbg_s.rx_state),
      .dbg_tx_slot_o       (dbg_s.tx_slot),
      .dbg_rx_slot_o       (dbg_s.rx_slot),
      .dbg_tx_bit_o        (dbg_s.tx_bit),
      .dbg_rx_bit_o        (dbg_s.rx_bit),
      .dbg_shift_o         (dbg_s.shift),
      .clk_sck_period_o    (dbg_s.sck_period),
      .clk_sck_per_ws_o    (dbg_s.sck_per_ws),
      .clk_ws_period_o     (dbg_s.ws_period),
      .clk_sck_high_o      (dbg_s.sck_high),
      .clk_sck_low_o       (dbg_s.sck_low)
  );

  assign sts_s[5] = prbs_locked_s;

  //---------------------------------------------------------------------------
  // Signals present so that every crossing cell has a complete port map, but
  // not consumed at this level.
  //---------------------------------------------------------------------------
  logic unused_top;
  assign unused_top = ^{ctrl_busy_unused, ctrl_done_unused, ctrl_valid_unused,
                        dbg_busy_unused, dbg_done_unused, dbg_valid_unused,
                        sr_busy_unused, rs_busy_unused, rxovf_busy_unused,
                        ev_pulse_unused,
                        tx_r_underflow_unused, tx_r_full_unused,
                        tx_r_flush_busy_unused, tx_r_level_unused,
                        rx_w_empty_unused, rx_w_flush_busy_unused,
                        rx_w_level_unused, rx_r_underflow_unused, 1'b0};

endmodule : i2s_top

`default_nettype wire
