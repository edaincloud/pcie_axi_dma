//=============================================================================
// File        : i2s_prbs.sv
// Description : PRBS pattern generator and self-synchronising checker
//               (specification section 61).
//
//               One instance runs on the TX launch strobe and substitutes its
//               output for the payload bit; a second runs on the RX capture
//               strobe and compares the received bit against its own
//               prediction.  Together they give a bit-level data-integrity
//               test of the complete serialise / deserialise path that does
//               not depend on the FIFOs or on software keeping up.
//
//               Fibonacci LFSR, x^n + x^m + 1, shifted MSB-first so that the
//               transmitted sequence is the standard PRBSn sequence.
//
//               In checker mode the RECEIVED bit is shifted into the state,
//               not the predicted one.  That makes the checker
//               self-synchronising: a burst of errors costs `order` extra
//               errors and then re-locks, instead of desynchronising the
//               comparison for the rest of the run.
//=============================================================================

`default_nettype none

module i2s_prbs
  import i2s_pkg::*;
#(
    // Consecutive correct bits required before `locked_o` asserts.
    parameter int unsigned LOCK_LEN = 16
) (
    input  wire        clk_i,
    input  wire        rst_ni,

    input  wire        en_i,          // advance one bit
    input  wire        reseed_i,      // reload the initial state
    input  wire  [2:0] sel_i,         // i2s_prbs_e
    input  wire        check_mode_i,  // 0 = generator, 1 = checker
    input  wire        rx_bit_i,      // received bit (checker mode)

    output logic       bit_o,         // generated / predicted bit
    output logic       locked_o,
    output logic       error_o        // single-cycle mismatch pulse
);

  localparam int unsigned STATE_W = 31;
  localparam int unsigned LOCK_W  = 8;

  logic [STATE_W-1:0] state_q;
  logic [5:0]         fill_q;
  logic [LOCK_W-1:0]  good_q;

  // ---- tap selection ---------------------------------------------------------
  logic [5:0] order;
  logic       fb;

  always_comb begin
    unique case (sel_i)
      I2S_PRBS7  : begin order = 6'd7;  fb = state_q[6]  ^ state_q[5];  end
      I2S_PRBS9  : begin order = 6'd9;  fb = state_q[8]  ^ state_q[4];  end
      I2S_PRBS15 : begin order = 6'd15; fb = state_q[14] ^ state_q[13]; end
      I2S_PRBS23 : begin order = 6'd23; fb = state_q[22] ^ state_q[17]; end
      I2S_PRBS31 : begin order = 6'd31; fb = state_q[30] ^ state_q[27]; end
      // Defensive recovery arm: PRBS_CTRL.SEL is bounded to the legal range by
      // the register block, so this is unreachable in a correct build.  It is
      // kept so that a corrupted register value produces a defined pattern
      // rather than an undefined one.
      default    : begin order = 6'd7;  fb = state_q[6]  ^ state_q[5];  end
    endcase
  end

  logic filling;
  assign filling = check_mode_i && (fill_q < order);

  assign bit_o    = fb;
  assign error_o  = en_i & check_mode_i & ~filling & (rx_bit_i != fb);
  assign locked_o = check_mode_i ? (good_q >= LOCK_W'(LOCK_LEN)) : 1'b1;

  // Bit shifted into the state: the received bit in checker mode (so the
  // checker re-synchronises), the predicted bit in generator mode.
  logic shift_in;
  assign shift_in = check_mode_i ? rx_bit_i : fb;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q <= {STATE_W{1'b1}};
      fill_q  <= '0;
      good_q  <= '0;
    end else if (reseed_i) begin
      state_q <= {STATE_W{1'b1}};
      fill_q  <= '0;
      good_q  <= '0;
    end else if (en_i) begin
      state_q <= {state_q[STATE_W-2:0], shift_in};

      if (filling) begin
        fill_q <= fill_q + 6'd1;
        good_q <= '0;
      end else if (check_mode_i) begin
        if (rx_bit_i != fb)                  good_q <= '0;
        else if (good_q < LOCK_W'(LOCK_LEN)) good_q <= good_q + LOCK_W'(1);
      end
    end
  end

endmodule : i2s_prbs

`default_nettype wire
