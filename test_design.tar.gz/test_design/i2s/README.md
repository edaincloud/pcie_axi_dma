# i2s

Top module: **`i2s_top`**. RTL: 16 files (5696 lines per the benchmark list),
copied from `/home/test/designs/i2s` with the original layout under `rtl/`.

## Files

| Path | Contents |
|---|---|
| `filelist.f` | include dirs (`+incdir+`), defines (`+define+`), source files in compile order |
| `rtl/` | sources and complete include directories |
| `sdc/i2s_top.sdc` | the design's own SDC, unchanged (byte-identical to `/home/test/designs/i2s/inputs/i2s_top.sdc`) |
| `design.json` | the same information in machine-readable form, plus the results below |


Technology: nangate45 typical, `../_tech/NangateOpenCellLibrary_typical.lib`. Settings used by both runs below:
- don't-use `TAPCELL_X1 FILLCELL_X1 AOI211_X1 OAI211_X1`;
- tie cells `LOGIC1_X1`/`LOGIC0_X1`;
- latch mapping `../_tech/latch_map.v`.

## Clocks (from the SDC)

| Clock | Source | Period (ns) |
|---|---|---:|
| pclk | pclk | 1.23 |
| sclk | sclk | 1.48 |

Minimum period: **1.23 ns**. Both runs below used it as the synthesis delay target.

## Tool notes

- **Top-level parameter overrides** (apply them in every tool; they are not defaults in the RTL): `SAMPLE_WIDTH_MAX=32`, `SLOT_WIDTH_MAX=32`, `TX_FIFO_DEPTH=8`, `RX_FIFO_DEPTH=8`, `DIV_WIDTH=8`, `CNT_WIDTH=16`, `SYNC_STAGES=2`, `APB_ADDR_WIDTH=12`, `APB_DATA_WIDTH=32`, `SD_IDLE_LEVEL=0`, `HAS_MCLK=1`, `RESET_POLARITY=0`, `RESET_SYNC_STAGES=2`.

## Results with the same RTL and SDC (OpenSTA 3.1.0 sign-off, SDC unchanged)

| Flow | Cells | Flip-flops | Area (µm²) | Data setup WS (ns) | Data setup TNS (ns) | Async recovery WS (ns) | Synth time | Peak memory |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| reference: upstream yosys 0.69 standard flow | 11,520 | 2,585 | 24,921 | -0.173 | -42.666 | -5.652 | 14 s | 98 MB |
| compcarta yosys 2bb4677e6, synth_ppa -goal area | 9,104 | 2,578 | 21,442 | +0.007 | 0.000 | +0.960 | 29 s | 195 MB |
